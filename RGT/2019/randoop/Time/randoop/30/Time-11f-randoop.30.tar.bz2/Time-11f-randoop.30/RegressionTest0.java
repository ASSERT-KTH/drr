import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 1, (java.lang.Number) (short) 100, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = periodType0.getFieldType((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = null;
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100.0f, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        int int2 = periodType0.indexOf(durationFieldType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.months();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period((java.lang.Object) int2, periodType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(periodType3);
    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test008");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        boolean boolean2 = periodType0.equals((java.lang.Object) (byte) 100);
        try {
            org.joda.time.DurationFieldType durationFieldType4 = periodType0.getFieldType((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        org.joda.time.Period period4 = period1.plusSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period8 = period4.minusYears(10);
        int int9 = period4.size();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.Period period12 = period4.withFieldAdded(durationFieldType10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) "", (java.lang.Object) 1.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (-1L), (java.lang.Number) 1, (java.lang.Number) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        org.joda.time.Period period4 = period1.plusSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Hours hours7 = period4.toStandardHours();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.months();
        boolean boolean10 = periodType8.equals((java.lang.Object) (byte) 100);
        try {
            org.joda.time.Period period11 = period4.withPeriodType(periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'minutes'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(hours7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.months();
        boolean boolean4 = periodType2.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType5 = periodType2.withMillisRemoved();
        try {
            org.joda.time.Period period6 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.minutes((int) (byte) 1);
        int int3 = period2.getMillis();
        org.joda.time.Period period5 = period2.plusSeconds((int) (byte) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePeriod) period2, 100L);
        try {
            org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) iSOChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.Period period4 = new org.joda.time.Period((int) '#', (int) (byte) -1, (int) ' ', 8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.Period period6 = period1.withFieldAdded(durationFieldType4, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (byte) 10);
        org.joda.time.Period period3 = period1.plusWeeks((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Float");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, (int) ' ', 8, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField7 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField5, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) -1);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("hi!", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.minutes((int) (byte) 1);
        int int3 = period2.getMillis();
        org.joda.time.Period period5 = period2.plusSeconds((int) (byte) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePeriod) period2, 100L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        boolean boolean17 = period2.equals((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("hi!", (int) (short) 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addCutover((int) (byte) -1, '#', (int) ' ', (int) (byte) 10, (int) (short) 1, false, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "-1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32) + "'", int1 == (-32));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.Period period4 = org.joda.time.Period.minutes((int) (byte) 1);
        int int5 = period4.getMillis();
        org.joda.time.Period period7 = period4.plusSeconds((int) (byte) 100);
        org.joda.time.Period period9 = period7.minusMinutes(10);
        org.joda.time.Period period11 = period7.minusYears(10);
        org.joda.time.Period period13 = period11.plusWeeks((int) (short) -1);
        long long16 = iSOChronology0.add((org.joda.time.ReadablePeriod) period11, 0L, 0);
        org.joda.time.DurationField durationField17 = iSOChronology0.halfdays();
        try {
            long long20 = durationField17.subtract((long) 10, (-1104537600001L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 1104537600001 * 43200000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        boolean boolean2 = periodType0.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType3 = periodType0.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        int int5 = periodType0.indexOf(durationFieldType4);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("hi!", (int) (short) 0);
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder3.writeTo("-1", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.Period period0 = new org.joda.time.Period();
        try {
            org.joda.time.DurationFieldType durationFieldType2 = period0.getFieldType((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (short) 100);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str8 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "-1" + "'", str8.equals("-1"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.months();
        boolean boolean3 = periodType1.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType4 = periodType1.withMillisRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(0L, periodType1);
        int int6 = period5.getMinutes();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test053");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560630012090L + "'", long1 == 1560630012090L);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, dateTimeFieldType4, 8, (int) (byte) 10, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(1, 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period3 = period1.withMonths((int) (short) 10);
        org.joda.time.Period period5 = period3.plusDays(0);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDayTime();
        try {
            org.joda.time.Period period7 = period5.normalizedStandard(periodType6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        org.joda.time.Period period4 = period1.plusSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period8 = period4.minusYears(10);
        int int9 = period4.size();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.Period period12 = period4.withField(durationFieldType10, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.field.FieldUtils.verifyValueBounds("-1", (int) (byte) 0, 0, 8);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560630012727L + "'", long0 == 1560630012727L);
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = new org.joda.time.DurationFieldType[] {};
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((-604799992L));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType3 = periodType1.getFieldType(0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.Period period4 = org.joda.time.Period.minutes((int) (byte) 1);
        int int5 = period4.getMillis();
        org.joda.time.Period period7 = period4.plusSeconds((int) (byte) 100);
        org.joda.time.Period period9 = period7.minusMinutes(10);
        org.joda.time.Period period11 = period7.minusYears(10);
        org.joda.time.Period period13 = period11.plusWeeks((int) (short) -1);
        long long16 = iSOChronology0.add((org.joda.time.ReadablePeriod) period11, 0L, 0);
        org.joda.time.DurationFieldType[] durationFieldTypeArray17 = period11.getFieldTypes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(durationFieldTypeArray17);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "ISOChronology[UTC]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-32), 1L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-32) + "'", int2 == (-32));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) (short) 100, 100, (int) (short) -1, (-32));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.years();
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) iSOChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfYear();
        java.lang.Object obj4 = null;
        boolean boolean5 = iSOChronology2.equals(obj4);
        org.joda.time.DurationField durationField6 = iSOChronology2.eras();
        try {
            org.joda.time.Period period7 = new org.joda.time.Period((java.lang.Object) periodType0, periodType1, (org.joda.time.Chronology) iSOChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) ' ', 0, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period3 = period1.withMonths((int) (short) 10);
        org.joda.time.Period period5 = period3.plusDays(0);
        int int6 = period5.getMonths();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            long long9 = iSOChronology0.set(readablePartial7, (long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.millis();
        org.joda.time.PeriodType periodType1 = periodType0.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("org.joda.time.IllegalFieldValueException: Value -1 for  must be in the range [1,100]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        int int3 = period1.getDays();
        int int4 = period1.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(0, 0, (int) '4', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale13 = null;
        try {
            java.lang.String str14 = offsetDateTimeField8.getAsShortText(readablePartial12, locale13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(8, 'a', 100, (int) (byte) 0, (int) (byte) -1, true, (int) (byte) 100);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder8.writeTo("11", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = offsetDateTimeField8.getAsShortText(readablePartial9, locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "hi!");
        java.lang.Throwable[] throwableArray3 = illegalInstantException2.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("hi!", (int) (short) 0);
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder6.writeTo("ISOChronology[UTC]", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "clockhourOfHalfday");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.File file4 = null;
        java.io.File file5 = null;
        java.io.File[] fileArray6 = new java.io.File[] { file5 };
        try {
            java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap7 = zoneInfoCompiler0.compile(file4, fileArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
        org.junit.Assert.assertNotNull(fileArray6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-32));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(3600000L, (long) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        try {
//            long long19 = zonedChronology11.getDateTimeMillis(52, (int) (byte) 0, (int) (short) 1, (int) '#', (int) ' ', 1, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test095");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.Period period13 = org.joda.time.Period.minutes((int) (byte) 1);
//        org.joda.time.Period period15 = period13.withMonths((int) (short) 10);
//        org.joda.time.Period period17 = org.joda.time.Period.minutes((int) (byte) 1);
//        int int18 = period17.size();
//        org.joda.time.Period period19 = period13.minus((org.joda.time.ReadablePeriod) period17);
//        org.joda.time.Period period21 = period17.minusYears(8);
//        long long24 = zonedChronology11.add((org.joda.time.ReadablePeriod) period17, 10L, (int) (short) 0);
//        org.joda.time.Period period26 = period17.minusMonths(10);
//        org.joda.time.Weeks weeks27 = period17.toStandardWeeks();
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(weeks27);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.months();
        boolean boolean10 = periodType8.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType11 = periodType8.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        boolean boolean13 = periodType11.isSupported(durationFieldType12);
        org.joda.time.PeriodType periodType14 = org.joda.time.DateTimeUtils.getPeriodType(periodType11);
        java.lang.Class<?> wildcardClass15 = periodType11.getClass();
        try {
            org.joda.time.Period period16 = new org.joda.time.Period((int) (short) -1, 100, (-1), (-32), (int) (short) -1, 8, 0, (int) '4', periodType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.months();
        boolean boolean3 = periodType1.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType4 = periodType1.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, periodType4, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Period period8 = period6.plusWeeks((int) (byte) 0);
        org.joda.time.Weeks weeks9 = period8.toStandardWeeks();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(weeks9);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        org.joda.time.Period period4 = period1.plusSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Hours hours7 = period4.toStandardHours();
        org.joda.time.Period period9 = period4.plusSeconds((int) (byte) -1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(hours7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.Period period4 = org.joda.time.Period.minutes((int) (byte) 1);
        int int5 = period4.getMillis();
        org.joda.time.Period period7 = period4.plusSeconds((int) (byte) 100);
        org.joda.time.Period period9 = period7.minusMinutes(10);
        org.joda.time.Period period11 = period7.minusYears(10);
        org.joda.time.Period period13 = period11.plusWeeks((int) (short) -1);
        long long16 = iSOChronology0.add((org.joda.time.ReadablePeriod) period11, 0L, 0);
        org.joda.time.DurationField durationField17 = iSOChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = iSOChronology19.equals(obj21);
        org.joda.time.DurationField durationField23 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (-1));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField27.getAsText((long) (short) 0, locale29);
        long long33 = offsetDateTimeField27.add((-1104537600001L), (int) (byte) 1);
        int int35 = offsetDateTimeField27.getLeapAmount(60001L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField27.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField27.getType();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType38, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "11" + "'", str30.equals("11"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1104534000001L) + "'", long33 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 100, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.ReadableInstant readableInstant2 = null;
//        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant1, readableInstant2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = dateTimeZone4.getName(10L, locale6);
//        long long11 = dateTimeZone4.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance(chronology3, dateTimeZone4);
//        long long14 = dateTimeZone0.getMillisKeepLocal(dateTimeZone4, (-1104537600001L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Coordinated Universal Time" + "'", str7.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1104566400001L) + "'", long14 == (-1104566400001L));
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.ReadablePartial readablePartial4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period7 = org.joda.time.Period.minutes((int) (byte) 1);
        int int8 = period7.getMillis();
        org.joda.time.Period period10 = period7.plusSeconds((int) (byte) 100);
        int[] intArray12 = iSOChronology5.get((org.joda.time.ReadablePeriod) period7, 100L);
        try {
            iSOChronology0.validate(readablePartial4, intArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField8.getAsText(52, locale18);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = offsetDateTimeField8.getAsShortText(readablePartial20, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "52" + "'", str19.equals("52"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 10.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        org.joda.time.Period period4 = period1.plusSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period8 = period4.minusYears(10);
        org.joda.time.Period period10 = period8.plusWeeks((int) (short) -1);
        org.joda.time.Period period12 = period10.plusMonths(1);
        int int13 = period12.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.months();
        boolean boolean3 = periodType1.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType4 = periodType1.withMillisRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(10L, periodType4);
        try {
            org.joda.time.Period period7 = period5.withMillis((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.minutes((int) (byte) 1);
        int int3 = period2.getMillis();
        org.joda.time.Period period5 = period2.plusSeconds((int) (byte) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePeriod) period2, 100L);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.months();
        boolean boolean11 = periodType9.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType12 = periodType9.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) 100, periodType12, (org.joda.time.Chronology) iSOChronology13);
        boolean boolean15 = iSOChronology0.equals((java.lang.Object) iSOChronology13);
        org.joda.time.DurationField durationField16 = iSOChronology13.days();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology13.dayOfWeek();
        try {
            long long25 = iSOChronology13.getDateTimeMillis((-1), 32, (int) (byte) 1, (int) 'a', 4, (-32), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (short) 100);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str8 = illegalFieldValueException4.getFieldName();
        org.joda.time.DurationFieldType durationFieldType9 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNull(durationFieldType9);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 100);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 32");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10, number2, (java.lang.Number) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfYear();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.DurationField durationField5 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (-1));
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsText((long) (short) 0, locale11);
        long long15 = offsetDateTimeField9.add((-1104537600001L), (int) (byte) 1);
        int int17 = offsetDateTimeField9.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "-1");
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField21 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "11" + "'", str12.equals("11"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1104534000001L) + "'", long15 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        org.joda.time.Period period4 = period1.plusSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        boolean boolean8 = period4.isSupported(durationFieldType7);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField8.getAsText(readablePartial9, (int) (short) 0, locale11);
        long long14 = offsetDateTimeField8.roundFloor(1L);
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period19 = org.joda.time.Period.minutes((int) (byte) 1);
        int int20 = period19.getMillis();
        org.joda.time.Period period22 = period19.plusSeconds((int) (byte) 100);
        int[] intArray24 = iSOChronology17.get((org.joda.time.ReadablePeriod) period19, 100L);
        java.util.Locale locale26 = null;
        try {
            int[] intArray27 = offsetDateTimeField8.set(readablePartial15, (int) ' ', intArray24, "0", locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(intArray24);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.Period period13 = org.joda.time.Period.minutes((int) (byte) 1);
//        org.joda.time.Period period15 = period13.withMonths((int) (short) 10);
//        org.joda.time.Period period17 = org.joda.time.Period.minutes((int) (byte) 1);
//        int int18 = period17.size();
//        org.joda.time.Period period19 = period13.minus((org.joda.time.ReadablePeriod) period17);
//        org.joda.time.Period period21 = period17.minusYears(8);
//        long long24 = zonedChronology11.add((org.joda.time.ReadablePeriod) period17, 10L, (int) (short) 0);
//        org.joda.time.Period period26 = period17.minusMonths(10);
//        try {
//            org.joda.time.Days days27 = period26.toStandardDays();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Days as this period contains months and months vary in length");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertNotNull(period26);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField8.getAsText(readablePartial9, (int) (short) 0, locale11);
        long long14 = offsetDateTimeField8.roundFloor(1L);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField8.getAsText((long) (short) 10, locale16);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "11" + "'", str17.equals("11"));
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.Period period13 = org.joda.time.Period.minutes((int) (byte) 1);
//        org.joda.time.Period period15 = period13.withMonths((int) (short) 10);
//        org.joda.time.Period period17 = org.joda.time.Period.minutes((int) (byte) 1);
//        int int18 = period17.size();
//        org.joda.time.Period period19 = period13.minus((org.joda.time.ReadablePeriod) period17);
//        org.joda.time.Period period21 = period17.minusYears(8);
//        long long24 = zonedChronology11.add((org.joda.time.ReadablePeriod) period17, 10L, (int) (short) 0);
//        org.joda.time.DurationFieldType durationFieldType25 = null;
//        int int26 = period17.indexOf(durationFieldType25);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("org.joda.time.IllegalFieldValueException: Value -1 for  must be in the range [1,100]");
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.minutes((int) (byte) 1);
        int int3 = period2.getMillis();
        org.joda.time.Period period5 = period2.plusSeconds((int) (byte) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePeriod) period2, 100L);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.months();
        boolean boolean11 = periodType9.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType12 = periodType9.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) 100, periodType12, (org.joda.time.Chronology) iSOChronology13);
        boolean boolean15 = iSOChronology0.equals((java.lang.Object) iSOChronology13);
        org.joda.time.DurationField durationField16 = iSOChronology13.days();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology13.dayOfWeek();
        org.joda.time.ReadablePartial readablePartial18 = null;
        try {
            int[] intArray20 = iSOChronology13.get(readablePartial18, (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-1104566400001L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (short) 100);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number8 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (byte) -1 + "'", number8.equals((byte) -1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", "clockhourOfHalfday");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "clockhourOfHalfday" + "'", str3.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.Period period13 = org.joda.time.Period.minutes((int) (byte) 1);
//        org.joda.time.Period period15 = period13.withMonths((int) (short) 10);
//        org.joda.time.Period period17 = org.joda.time.Period.minutes((int) (byte) 1);
//        int int18 = period17.size();
//        org.joda.time.Period period19 = period13.minus((org.joda.time.ReadablePeriod) period17);
//        org.joda.time.Period period21 = period17.minusYears(8);
//        long long24 = zonedChronology11.add((org.joda.time.ReadablePeriod) period17, 10L, (int) (short) 0);
//        org.joda.time.Period period26 = org.joda.time.Period.minutes((int) (short) 0);
//        org.joda.time.Period period28 = period26.plusSeconds(100);
//        int[] intArray30 = zonedChronology11.get((org.joda.time.ReadablePeriod) period28, (long) 10);
//        java.lang.String str31 = zonedChronology11.toString();
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//        org.junit.Assert.assertNotNull(period26);
//        org.junit.Assert.assertNotNull(period28);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ZonedChronology[ISOChronology[UTC], UTC]" + "'", str31.equals("ZonedChronology[ISOChronology[UTC], UTC]"));
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.months();
        boolean boolean3 = periodType1.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType4 = periodType1.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, periodType4, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.format.PeriodFormatter periodFormatter7 = null;
        java.lang.String str8 = period6.toString(periodFormatter7);
        try {
            org.joda.time.Period period10 = period6.minusWeeks(52);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "P0M" + "'", str8.equals("P0M"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(32, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 64 + "'", int2 == 64);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '#', 10, (int) ' ', 52);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 45 + "'", int4 == 45);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (int) (short) 1, 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for  must be in the range [10,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getMaximumValue(60001L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfYear();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.DurationField durationField5 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (-1));
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsText((long) (short) 0, locale11);
        long long15 = offsetDateTimeField9.add((-1104537600001L), (int) (byte) 1);
        int int17 = offsetDateTimeField9.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField9.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "11" + "'", str12.equals("11"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1104534000001L) + "'", long15 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        long long3 = dateTimeZone1.convertUTCToLocal((long) '4');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 52L + "'", long3 == 52L);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        try {
//            long long8 = gregorianChronology3.getDateTimeMillis(0, (int) (byte) 100, 4, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.Period period4 = new org.joda.time.Period(100, 4, (int) '#', 8);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField12 = zonedChronology11.yearOfEra();
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField12 = zonedChronology11.clockhourOfDay();
//        org.joda.time.DurationField durationField13 = zonedChronology11.millis();
//        try {
//            long long19 = zonedChronology11.getDateTimeMillis((long) 10, (int) (short) 0, (int) (short) -1, (int) (short) 0, 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        int int14 = dateTimeZone12.getOffset(readableInstant13);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 0, (int) '4', 4, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 4, "clockhourOfHalfday");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.secondOfMinute();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.dayOfYear();
        java.lang.Object obj7 = null;
        boolean boolean8 = iSOChronology5.equals(obj7);
        org.joda.time.DurationField durationField9 = iSOChronology5.eras();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.clockhourOfHalfday();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.dayOfYear();
        java.lang.Object obj14 = null;
        boolean boolean15 = iSOChronology12.equals(obj14);
        org.joda.time.DurationField durationField16 = iSOChronology12.eras();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology12.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (-1));
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField20.getAsText((long) (short) 0, locale22);
        long long26 = offsetDateTimeField20.add((-1104537600001L), (int) (byte) 1);
        int int28 = offsetDateTimeField20.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField20.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType29, 4);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField33 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType29, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "11" + "'", str23.equals("11"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-1104534000001L) + "'", long26 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period3 = period1.withMonths((int) (short) 10);
        org.joda.time.Period period5 = period3.plusDays(0);
        java.lang.String str6 = period3.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "P10MT1M" + "'", str6.equals("P10MT1M"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.months();
        boolean boolean3 = periodType1.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType4 = periodType1.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, periodType4, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.dayOfYear();
        java.lang.Object obj20 = null;
        boolean boolean21 = iSOChronology18.equals(obj20);
        org.joda.time.DurationField durationField22 = iSOChronology18.eras();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology18.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology18.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology18.centuryOfEra();
        org.joda.time.Period period27 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType28 = null;
        int int29 = period27.indexOf(durationFieldType28);
        org.joda.time.Days days30 = period27.toStandardDays();
        int[] intArray32 = iSOChronology18.get((org.joda.time.ReadablePeriod) period27, (-1L));
        int int33 = offsetDateTimeField8.getMinimumValue(readablePartial17, intArray32);
        long long35 = offsetDateTimeField8.roundCeiling((long) 8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(days30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 3600000L + "'", long35 == 3600000L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.Period period1 = new org.joda.time.Period((-1104534000001L));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        long long34 = zeroIsMaxDateTimeField32.remainder((-1104566400001L));
        try {
            long long37 = zeroIsMaxDateTimeField32.set(0L, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for clockhourOfHalfday must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599999L + "'", long34 == 3599999L);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((-1L), locale2);
//        long long5 = dateTimeZone0.convertUTCToLocal(100L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 100L + "'", long5 == 100L);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray16 = null;
        try {
            int[] intArray18 = offsetDateTimeField8.set(readablePartial14, (int) '#', intArray16, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for clockhourOfHalfday must be in the range [0,11]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) ' ', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 320 + "'", int2 == 320);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        try {
            long long6 = gregorianChronology0.getDateTimeMillis((int) (short) -1, (int) (byte) -1, (int) (short) -1, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        long long34 = zeroIsMaxDateTimeField32.remainder((-1104566400001L));
        org.joda.time.ReadablePartial readablePartial35 = null;
        java.util.Locale locale36 = null;
        try {
            java.lang.String str37 = zeroIsMaxDateTimeField32.getAsText(readablePartial35, locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599999L + "'", long34 == 3599999L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getName((long) (short) -1, locale4);
        java.lang.String str7 = dateTimeZone2.getShortName(3600000L);
        long long11 = dateTimeZone2.convertLocalToUTC((long) (short) 0, true, (long) '#');
        java.util.TimeZone timeZone12 = dateTimeZone2.toTimeZone();
        java.util.Locale locale14 = null;
        java.lang.String str15 = dateTimeZone2.getName((long) (-1), locale14);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+97:10" + "'", str5.equals("+97:10"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+97:10" + "'", str7.equals("+97:10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-349800000L) + "'", long11 == (-349800000L));
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+97:10" + "'", str15.equals("+97:10"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField8.getAsText(readablePartial9, (int) (short) 0, locale11);
        long long14 = offsetDateTimeField8.roundFloor(1L);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale16 = null;
        try {
            java.lang.String str17 = offsetDateTimeField8.getAsText(readablePartial15, locale16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        long long34 = zeroIsMaxDateTimeField32.remainder((-1104566400001L));
        boolean boolean36 = zeroIsMaxDateTimeField32.isLeap((long) 32);
        java.util.Locale locale39 = null;
        try {
            long long40 = zeroIsMaxDateTimeField32.set(1560630012727L, "", locale39);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for clockhourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599999L + "'", long34 == 3599999L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        int int15 = offsetDateTimeField8.getLeapAmount(1560630012727L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1L, 45);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(10, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 970 + "'", int2 == 970);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField8.getType();
        org.joda.time.ReadablePartial readablePartial15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period19 = org.joda.time.Period.minutes((int) (byte) 1);
        int int20 = period19.getMillis();
        org.joda.time.Period period22 = period19.plusSeconds((int) (byte) 100);
        int[] intArray24 = iSOChronology17.get((org.joda.time.ReadablePeriod) period19, 100L);
        try {
            int[] intArray26 = offsetDateTimeField8.set(readablePartial15, 8, intArray24, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("UTC", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"UTC/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-1104534000001L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2427803.541666655d + "'", double1 == 2427803.541666655d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) 100);
        org.joda.time.DurationField durationField6 = iSOChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.Chronology chronology10 = iSOChronology0.withZone(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology0.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfYear();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.DurationField durationField5 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.dayOfYear();
        java.lang.Object obj10 = null;
        boolean boolean11 = iSOChronology8.equals(obj10);
        org.joda.time.DurationField durationField12 = iSOChronology8.eras();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology8.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology8.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (-1));
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField16.getAsText((long) (short) 0, locale18);
        long long22 = offsetDateTimeField16.add((-1104537600001L), (int) (byte) 1);
        int int24 = offsetDateTimeField16.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType25, 4);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "11" + "'", str19.equals("11"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1104534000001L) + "'", long22 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (byte) 10);
        try {
            org.joda.time.Days days2 = period1.toStandardDays();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Days as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfYear();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.DurationField durationField5 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (-1));
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsText((long) (short) 0, locale11);
        long long15 = offsetDateTimeField9.add((-1104537600001L), (int) (byte) 1);
        int int17 = offsetDateTimeField9.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, "-1");
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField21 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "11" + "'", str12.equals("11"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1104534000001L) + "'", long15 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.minutes((int) (byte) 1);
        int int3 = period2.getMillis();
        org.joda.time.Period period5 = period2.plusSeconds((int) (byte) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePeriod) period2, 100L);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.months();
        boolean boolean11 = periodType9.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType12 = periodType9.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) 100, periodType12, (org.joda.time.Chronology) iSOChronology13);
        boolean boolean15 = iSOChronology0.equals((java.lang.Object) iSOChronology13);
        org.joda.time.DurationField durationField16 = iSOChronology13.days();
        org.joda.time.Chronology chronology17 = iSOChronology13.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        java.io.BufferedReader bufferedReader4 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfYear();
        java.lang.Object obj5 = null;
        boolean boolean6 = iSOChronology3.equals(obj5);
        boolean boolean8 = iSOChronology3.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.clockhourOfDay();
        java.lang.Class<?> wildcardClass10 = iSOChronology3.getClass();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, 1560630012090L, periodType2, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone14.getName((long) (short) -1, locale16);
        org.joda.time.Chronology chronology18 = iSOChronology3.withZone(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology3.dayOfWeek();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+97:10" + "'", str17.equals("+97:10"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = offsetDateTimeField8.getMinimumValue(readablePartial15);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType17, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.months();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period6 = org.joda.time.Period.minutes((int) (byte) 1);
        int int7 = period6.getMillis();
        org.joda.time.Period period9 = period6.plusSeconds((int) (byte) 100);
        int[] intArray11 = iSOChronology4.get((org.joda.time.ReadablePeriod) period6, 100L);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.months();
        boolean boolean15 = periodType13.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType16 = periodType13.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period18 = new org.joda.time.Period((long) (byte) 100, periodType16, (org.joda.time.Chronology) iSOChronology17);
        boolean boolean19 = iSOChronology4.equals((java.lang.Object) iSOChronology17);
        org.joda.time.DurationField durationField20 = iSOChronology17.days();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology17.dayOfWeek();
        org.joda.time.Period period22 = new org.joda.time.Period((long) 52, (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.Period period23 = new org.joda.time.Period((long) 8, (long) 11, periodType2, (org.joda.time.Chronology) iSOChronology17);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.dayOfYear();
        java.lang.Object obj13 = null;
        boolean boolean14 = iSOChronology11.equals(obj13);
        org.joda.time.DurationField durationField15 = iSOChronology11.eras();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology11.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology11.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology11.centuryOfEra();
        org.joda.time.Period period20 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = period20.indexOf(durationFieldType21);
        org.joda.time.Days days23 = period20.toStandardDays();
        int[] intArray25 = iSOChronology11.get((org.joda.time.ReadablePeriod) period20, (-1L));
        try {
            int[] intArray27 = offsetDateTimeField8.addWrapPartial(readablePartial9, 52, intArray25, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(days23);
        org.junit.Assert.assertNotNull(intArray25);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        org.joda.time.DurationField durationField14 = offsetDateTimeField8.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = offsetDateTimeField8.getMaximumValue(readablePartial15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 11 + "'", int16 == 11);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PT-9M100S", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PT-9M100S/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long14 = offsetDateTimeField8.add((-1104537600001L), (int) (byte) 1);
        int int16 = offsetDateTimeField8.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField8.getType();
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.dayOfYear();
        java.lang.Object obj20 = null;
        boolean boolean21 = iSOChronology18.equals(obj20);
        org.joda.time.DurationField durationField22 = iSOChronology18.weeks();
        long long25 = durationField22.subtract((long) 8, 1L);
        long long28 = durationField22.subtract(1560630012090L, 1);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.dayOfYear();
        java.lang.Object obj31 = null;
        boolean boolean32 = iSOChronology29.equals(obj31);
        org.joda.time.DurationField durationField33 = iSOChronology29.hours();
        long long36 = durationField33.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period38 = org.joda.time.Period.minutes((int) (byte) 1);
        int int39 = period38.getMillis();
        org.joda.time.Period period41 = period38.plusSeconds((int) (byte) 100);
        org.joda.time.Period period43 = period41.minusMinutes(10);
        org.joda.time.Period period45 = period41.minusYears(10);
        int int46 = period41.size();
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType48 = periodType47.withMonthsRemoved();
        org.joda.time.PeriodType periodType49 = periodType48.withHoursRemoved();
        org.joda.time.PeriodType periodType52 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType53 = periodType52.withYearsRemoved();
        org.joda.time.Period period54 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType52);
        org.joda.time.DurationFieldType durationFieldType56 = periodType52.getFieldType(0);
        boolean boolean57 = periodType49.isSupported(durationFieldType56);
        boolean boolean58 = period41.isSupported(durationFieldType56);
        org.joda.time.field.ScaledDurationField scaledDurationField60 = new org.joda.time.field.ScaledDurationField(durationField33, durationFieldType56, 320);
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField61 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType17, durationField22, durationField33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1104534000001L) + "'", long14 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-604799992L) + "'", long25 == (-604799992L));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560025212090L + "'", long28 == 1560025212090L);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-3599999L) + "'", long36 == (-3599999L));
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 8 + "'", int46 == 8);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(periodType48);
        org.junit.Assert.assertNotNull(periodType49);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(durationFieldType56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("11");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '11' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(100.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long14 = offsetDateTimeField8.add((-1104537600001L), (int) (byte) 1);
        int int16 = offsetDateTimeField8.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField8.getType();
        long long19 = offsetDateTimeField8.roundHalfFloor((long) (byte) -1);
        long long22 = offsetDateTimeField8.add((long) (-1), (long) 64);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1104534000001L) + "'", long14 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 230399999L + "'", long22 == 230399999L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.Period period8 = new org.joda.time.Period(320, 52, 45, 0, 970, (-1), (int) 'a', (int) (short) 10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 100, 0L, chronology2);
        org.joda.time.DurationFieldType[] durationFieldTypeArray4 = period3.getFieldTypes();
        int int5 = period3.getMonths();
        org.joda.time.Period period7 = period3.minusMillis(1);
        int int8 = period3.getYears();
        org.junit.Assert.assertNotNull(durationFieldTypeArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long14 = offsetDateTimeField8.add((-1104537600001L), (int) (byte) 1);
        int int16 = offsetDateTimeField8.getLeapAmount(60001L);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = offsetDateTimeField8.getMinimumValue(readablePartial17);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField8.getType();
        long long21 = offsetDateTimeField8.roundHalfFloor(10L);
        java.lang.String str23 = offsetDateTimeField8.getAsShortText(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1104534000001L) + "'", long14 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "11" + "'", str23.equals("11"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("org.joda.time.IllegalFieldValueException: Value -1 for  must be in the range [1,100]");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.Period period4 = org.joda.time.Period.minutes((int) (short) 0);
        org.joda.time.Period period6 = period4.plusSeconds(100);
        org.joda.time.Period period8 = period6.minusSeconds((int) '#');
        boolean boolean9 = jodaTimePermission1.equals((java.lang.Object) '#');
        java.security.PermissionCollection permissionCollection10 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(permissionCollection10);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (short) 100);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number9 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (byte) -1 + "'", number9.equals((byte) -1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("America/Los_Angeles");
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((-604799992L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440581L + "'", long1 == 2440581L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(3600045L, 11);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 39600495L + "'", long2 == 39600495L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period3 = org.joda.time.Period.minutes((int) (byte) 1);
        int int4 = period3.getMillis();
        org.joda.time.Period period6 = period3.plusSeconds((int) (byte) 100);
        org.joda.time.Period period8 = period6.minusMinutes(10);
        org.joda.time.Period period9 = period1.minus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period11 = period1.plusMillis((int) (byte) 1);
        org.joda.time.Weeks weeks12 = period1.toStandardWeeks();
        int int13 = period1.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(weeks12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("org.joda.time.IllegalFieldValueException: Value -1 for  must be in the range [1,100]", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("11", "11");
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test201");
//        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearDayTime();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfYear();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = iSOChronology4.equals(obj6);
//        boolean boolean9 = iSOChronology4.equals((java.lang.Object) 100);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.clockhourOfDay();
//        java.lang.Class<?> wildcardClass11 = iSOChronology4.getClass();
//        org.joda.time.Period period12 = new org.joda.time.Period(0L, 1560630012090L, periodType3, (org.joda.time.Chronology) iSOChronology4);
//        org.joda.time.PeriodType periodType13 = periodType3.withMinutesRemoved();
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName(10L, locale19);
//        long long24 = dateTimeZone17.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance(chronology16, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField26 = zonedChronology25.clockhourOfDay();
//        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) 0, periodType3, (org.joda.time.Chronology) zonedChronology25);
//        try {
//            long long35 = zonedChronology25.getDateTimeMillis(8, 11, 45, 12, (int) '4', (-32), 11);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(periodType13);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 32L + "'", long24 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(8, 'a', 100, (int) (byte) 0, (int) (byte) -1, true, (int) (byte) 100);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setStandardOffset((int) (short) 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder10.addCutover(52, '#', 0, (int) 'a', (-1), true, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long14 = offsetDateTimeField8.add((-1104537600001L), (int) (byte) 1);
        int int16 = offsetDateTimeField8.getLeapAmount(60001L);
        java.lang.Class<?> wildcardClass17 = offsetDateTimeField8.getClass();
        try {
            org.joda.time.Period period18 = new org.joda.time.Period((java.lang.Object) wildcardClass17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Class");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1104534000001L) + "'", long14 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        try {
            long long35 = zeroIsMaxDateTimeField32.set((long) 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for clockhourOfHalfday must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        try {
            long long11 = iSOChronology0.getDateTimeMillis(0L, (int) 'a', 64, (int) (byte) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        long long18 = offsetDateTimeField8.roundFloor((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = iSOChronology19.equals(obj21);
        org.joda.time.DurationField durationField23 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (-1));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField27.getAsText((long) (short) 0, locale29);
        long long33 = offsetDateTimeField27.add((-1104537600001L), (int) (byte) 1);
        int int35 = offsetDateTimeField27.getLeapAmount(60001L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField27.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField27.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType38);
        long long42 = zeroIsMaxDateTimeField39.getDifferenceAsLong((long) (short) 100, (-1104537600001L));
        try {
            long long45 = zeroIsMaxDateTimeField39.set((-1104566400001L), 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for clockhourOfHalfday must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3600000L) + "'", long18 == (-3600000L));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "11" + "'", str30.equals("11"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1104534000001L) + "'", long33 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 306816L + "'", long42 == 306816L);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test207");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.DurationField durationField12 = zonedChronology11.years();
//        try {
//            long long20 = zonedChronology11.getDateTimeMillis(45, 970, (int) '#', (int) (byte) 1, 10, (int) (short) 10, 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 970 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.months();
        boolean boolean3 = periodType1.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType4 = periodType1.withMillisRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(10L, periodType4);
        org.joda.time.Hours hours6 = period5.toStandardHours();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(hours6);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, 52);
        try {
            long long13 = offsetDateTimeField10.set((long) (short) 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for clockhourOfHalfday must be in the range [53,64]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt((-1104537600001L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -1104537600001");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType34 = periodType33.withHoursRemoved();
        org.joda.time.PeriodType periodType35 = periodType33.withWeeksRemoved();
        org.joda.time.PeriodType periodType36 = periodType35.withDaysRemoved();
        try {
            org.joda.time.Period period37 = new org.joda.time.Period((java.lang.Object) offsetDateTimeField8, periodType36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.field.OffsetDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType36);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField8.getAsText(readablePartial9, (int) (short) 0, locale11);
        long long14 = offsetDateTimeField8.roundHalfCeiling((long) 10);
        org.joda.time.DurationField durationField15 = offsetDateTimeField8.getLeapDurationField();
        int int16 = offsetDateTimeField8.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNull(durationField15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.months();
        boolean boolean11 = periodType9.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType12 = periodType9.withMillisRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period(10L, periodType12);
        try {
            org.joda.time.Period period14 = new org.joda.time.Period((int) (short) -1, (int) (short) -1, 12, 4, (int) (byte) 1, 32, (int) '4', 32, periodType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType12);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test216");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (short) 1);
//        java.lang.String str4 = dateTimeZone0.getShortName((long) (short) 1);
//        java.lang.String str5 = dateTimeZone0.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UTC" + "'", str5.equals("UTC"));
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.Period period4 = org.joda.time.Period.minutes((int) (byte) 1);
        int int5 = period4.getMillis();
        org.joda.time.Period period7 = period4.plusSeconds((int) (byte) 100);
        org.joda.time.Period period9 = period7.minusMinutes(10);
        org.joda.time.Period period11 = period7.minusYears(10);
        org.joda.time.Period period13 = period11.plusWeeks((int) (short) -1);
        long long16 = iSOChronology0.add((org.joda.time.ReadablePeriod) period11, 0L, 0);
        int int17 = period11.getMillis();
        org.joda.time.Period period19 = period11.plusYears((-1));
        org.joda.time.Period period21 = period19.plusHours(0);
        int int22 = period21.getSeconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) '4', 273599999L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 14227199948");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        long long18 = offsetDateTimeField8.roundFloor((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = iSOChronology19.equals(obj21);
        org.joda.time.DurationField durationField23 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (-1));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField27.getAsText((long) (short) 0, locale29);
        long long33 = offsetDateTimeField27.add((-1104537600001L), (int) (byte) 1);
        int int35 = offsetDateTimeField27.getLeapAmount(60001L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField27.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField27.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType38);
        int int40 = zeroIsMaxDateTimeField39.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial41 = null;
        int[] intArray42 = null;
        int int43 = zeroIsMaxDateTimeField39.getMinimumValue(readablePartial41, intArray42);
        try {
            long long46 = zeroIsMaxDateTimeField39.set(10L, (-32));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for clockhourOfHalfday must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3600000L) + "'", long18 == (-3600000L));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "11" + "'", str30.equals("11"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1104534000001L) + "'", long33 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) '#', 3599999L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 125999965 + "'", int2 == 125999965);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("America/Los_Angeles");
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test224");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (short) 1);
//        org.joda.time.ReadableInstant readableInstant3 = null;
//        int int4 = dateTimeZone0.getOffset(readableInstant3);
//        long long6 = dateTimeZone0.convertUTCToLocal((long) 52);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 52L + "'", long6 == 52L);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField8.getAsText(52, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField8.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "");
        java.lang.String str23 = illegalFieldValueException22.getFieldName();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "52" + "'", str19.equals("52"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "clockhourOfHalfday" + "'", str23.equals("clockhourOfHalfday"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(52);
        org.joda.time.DurationFieldType[] durationFieldTypeArray2 = period1.getFieldTypes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(durationFieldTypeArray2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.Period period4 = new org.joda.time.Period(970, 4, (int) (byte) 0, (int) (short) 100);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PeriodType[YearDayTime]", "+97:10");
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (short) 100);
        java.lang.Number number8 = illegalFieldValueException7.getUpperBound();
        illegalFieldValueException7.prependMessage("P0M");
        boolean boolean11 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException7);
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Throwable[] throwableArray13 = illegalFieldValueException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 100 + "'", number8.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField7 = iSOChronology0.seconds();
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        int int11 = period9.getWeeks();
        org.joda.time.Days days12 = period9.toStandardDays();
        int int13 = period9.getSeconds();
        int[] intArray15 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (long) (byte) 0);
        int int16 = period9.getDays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(days12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(3600045L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5416671876d + "'", double1 == 2440587.5416671876d);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField12 = zonedChronology11.clockhourOfDay();
//        org.joda.time.DurationField durationField13 = zonedChronology11.millis();
//        long long16 = durationField13.subtract(100L, 0L);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("P10MT1M", "PeriodType[YearDayTime]", (-1), (int) (short) -1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 'a');
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((-1104534000001L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.DurationField durationField17 = offsetDateTimeField8.getLeapDurationField();
        long long20 = offsetDateTimeField8.add((long) 45, (int) (short) 1);
        try {
            long long23 = offsetDateTimeField8.set(2440588L, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 12 for clockhourOfHalfday must be in the range [0,11]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 3600045L + "'", long20 == 3600045L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (short) 100);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 100, 0L, chronology2);
        org.joda.time.DurationFieldType[] durationFieldTypeArray4 = period3.getFieldTypes();
        int int5 = period3.getMonths();
        int int6 = period3.getHours();
        org.joda.time.Period period8 = period3.multipliedBy(0);
        org.junit.Assert.assertNotNull(durationFieldTypeArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale2 = null;
        java.lang.String str5 = defaultNameProvider0.getName(locale2, "", "32");
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long14 = offsetDateTimeField8.add((-1104537600001L), (int) (byte) 1);
        int int16 = offsetDateTimeField8.getLeapAmount(60001L);
        java.lang.Class<?> wildcardClass17 = offsetDateTimeField8.getClass();
        long long20 = offsetDateTimeField8.add((long) 52, (-100L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1104534000001L) + "'", long14 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-359999948L) + "'", long20 == (-359999948L));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(0L, chronology1);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        long long18 = offsetDateTimeField8.roundFloor((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = iSOChronology19.equals(obj21);
        org.joda.time.DurationField durationField23 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (-1));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField27.getAsText((long) (short) 0, locale29);
        long long33 = offsetDateTimeField27.add((-1104537600001L), (int) (byte) 1);
        int int35 = offsetDateTimeField27.getLeapAmount(60001L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField27.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField27.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType38);
        java.lang.Number number42 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, (java.lang.Number) 10.0d, (java.lang.Number) 39600495L, number42);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3600000L) + "'", long18 == (-3600000L));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "11" + "'", str30.equals("11"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1104534000001L) + "'", long33 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 306816L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-184357857600000L) + "'", long1 == (-184357857600000L));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType3 = null;
        int int4 = period2.indexOf(durationFieldType3);
        org.joda.time.Period period5 = period0.withFields((org.joda.time.ReadablePeriod) period2);
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.dayOfYear();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology6.dayOfYear();
        org.joda.time.Period period10 = org.joda.time.Period.minutes((int) (byte) 1);
        int int11 = period10.getMillis();
        org.joda.time.Period period13 = period10.plusSeconds((int) (byte) 100);
        org.joda.time.Period period15 = period13.minusMinutes(10);
        org.joda.time.Period period17 = period13.minusYears(10);
        org.joda.time.Period period19 = period17.plusWeeks((int) (short) -1);
        long long22 = iSOChronology6.add((org.joda.time.ReadablePeriod) period17, 0L, 0);
        int int23 = period17.getMillis();
        org.joda.time.Period period25 = period17.plusYears((-1));
        org.joda.time.Period period27 = period25.plusHours(0);
        org.joda.time.Period period28 = period2.withFields((org.joda.time.ReadablePeriod) period27);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period28);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType3 = periodType2.withHoursRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfYear();
        java.lang.Object obj6 = null;
        boolean boolean7 = iSOChronology4.equals(obj6);
        org.joda.time.DurationField durationField8 = iSOChronology4.eras();
        org.joda.time.Chronology chronology9 = iSOChronology4.withUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.halfdayOfDay();
        org.joda.time.Period period11 = new org.joda.time.Period((long) '4', (-1104537600001L), periodType2, (org.joda.time.Chronology) iSOChronology4);
        java.lang.String str12 = periodType2.toString();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PeriodType[Standard]" + "'", str12.equals("PeriodType[Standard]"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        boolean boolean32 = scaledDurationField31.isSupported();
        int int34 = scaledDurationField31.getValue(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        org.joda.time.DurationField durationField14 = offsetDateTimeField8.getLeapDurationField();
        long long16 = offsetDateTimeField8.roundHalfCeiling((-100L));
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField8.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.era();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.centuryOfEra();
        int int21 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField22 = gregorianChronology18.years();
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.dayOfYear();
        java.lang.Object obj25 = null;
        boolean boolean26 = iSOChronology23.equals(obj25);
        boolean boolean28 = iSOChronology23.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology23.clockhourOfDay();
        org.joda.time.DurationField durationField30 = iSOChronology23.seconds();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField31 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType17, durationField22, durationField30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(durationField30);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.Days days4 = period1.toStandardDays();
        org.joda.time.Period period6 = period1.plusWeeks(0);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType8 = periodType7.withHoursRemoved();
        org.joda.time.PeriodType periodType9 = periodType7.withWeeksRemoved();
        org.joda.time.Period period10 = period1.withPeriodType(periodType9);
        int int11 = period1.getMonths();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(days4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        long long3 = dateTimeZone1.convertUTCToLocal(1152000000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1152000000L + "'", long3 == 1152000000L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period((java.lang.Object) gregorianChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        org.joda.time.DurationField durationField14 = offsetDateTimeField8.getLeapDurationField();
        int int16 = offsetDateTimeField8.getMinimumValue((long) (byte) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField8.getAsText(readablePartial9, (int) ' ', locale11);
        int int13 = offsetDateTimeField8.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "32" + "'", str12.equals("32"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period3 = period1.withMonths((int) (short) 10);
        org.joda.time.Period period5 = period1.minusWeeks((int) 'a');
        org.joda.time.Period period7 = period1.withYears((int) (short) -1);
        int int9 = period7.getValue((int) (short) 1);
        org.joda.time.Period period11 = period7.plusMonths((int) (short) -1);
        int int12 = period11.getMonths();
        int int13 = period11.getYears();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.months();
        boolean boolean3 = periodType1.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType4 = periodType1.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, periodType4, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray8 = null;
        try {
            iSOChronology5.validate(readablePartial7, intArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "hi!", "hi!");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getName(locale6, "", "");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        int int35 = scaledDurationField31.getScalar();
        org.joda.time.DurationFieldType durationFieldType36 = scaledDurationField31.getType();
        long long39 = scaledDurationField31.getMillis(0, (long) 2);
        org.joda.time.DurationFieldType durationFieldType40 = scaledDurationField31.getType();
        long long43 = scaledDurationField31.add(126000002L, (int) (short) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 320 + "'", int35 == 320);
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 11646000002L + "'", long43 == 11646000002L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period3 = period1.withMonths((int) (short) 10);
        org.joda.time.Period period5 = period1.minusWeeks((int) 'a');
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.months();
        boolean boolean8 = periodType6.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType9 = periodType6.withMillisRemoved();
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType13 = periodType12.withYearsRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType12);
        org.joda.time.DurationFieldType durationFieldType16 = periodType12.getFieldType(0);
        int int17 = periodType6.indexOf(durationFieldType16);
        org.joda.time.Period period19 = period5.withField(durationFieldType16, 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(durationFieldType16, (java.lang.Number) (byte) 1, (java.lang.Number) 52L, (java.lang.Number) (-32));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (short) 10);
        org.joda.time.Period period3 = period1.minusMillis(4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField8.getAsText(52, locale18);
        long long21 = offsetDateTimeField8.roundHalfEven((long) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "52" + "'", str19.equals("52"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.secondOfMinute();
        org.joda.time.ReadablePartial readablePartial4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.dayOfYear();
        java.lang.Object obj7 = null;
        boolean boolean8 = iSOChronology5.equals(obj7);
        org.joda.time.DurationField durationField9 = iSOChronology5.eras();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (-1));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField13.getAsText((long) (short) 0, locale15);
        int int18 = offsetDateTimeField13.getLeapAmount((-604799992L));
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField13.getAsShortText((long) (short) 1, locale20);
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.dayOfYear();
        java.lang.Object obj25 = null;
        boolean boolean26 = iSOChronology23.equals(obj25);
        org.joda.time.DurationField durationField27 = iSOChronology23.eras();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology23.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology23.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology23.centuryOfEra();
        org.joda.time.Period period32 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType33 = null;
        int int34 = period32.indexOf(durationFieldType33);
        org.joda.time.Days days35 = period32.toStandardDays();
        int[] intArray37 = iSOChronology23.get((org.joda.time.ReadablePeriod) period32, (-1L));
        int int38 = offsetDateTimeField13.getMinimumValue(readablePartial22, intArray37);
        try {
            iSOChronology0.validate(readablePartial4, intArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "11" + "'", str21.equals("11"));
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(days35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(32L, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withMonthsRemoved();
        java.lang.String str4 = periodType3.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "YearDayTimeNoYears" + "'", str4.equals("YearDayTimeNoYears"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType1 = periodType0.withHoursRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType5 = periodType2.getFieldType(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        int int35 = scaledDurationField31.getScalar();
        org.joda.time.DurationFieldType durationFieldType36 = scaledDurationField31.getType();
        long long39 = scaledDurationField31.getMillis(0, (long) 2);
        long long41 = scaledDurationField31.getMillis((int) (short) 1);
        long long43 = scaledDurationField31.getMillis(39600495L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 320 + "'", int35 == 320);
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1152000000L + "'", long41 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 45619770240000000L + "'", long43 == 45619770240000000L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.Period period4 = org.joda.time.Period.minutes((int) (byte) 1);
        int int5 = period4.getMillis();
        org.joda.time.Period period7 = period4.plusSeconds((int) (byte) 100);
        org.joda.time.Period period9 = period7.minusMinutes(10);
        org.joda.time.Period period11 = period7.minusYears(10);
        org.joda.time.Period period13 = period11.plusWeeks((int) (short) -1);
        long long16 = iSOChronology0.add((org.joda.time.ReadablePeriod) period11, 0L, 0);
        org.joda.time.DurationField durationField17 = iSOChronology0.halfdays();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        long long36 = scaledDurationField31.getMillis(0L);
        long long38 = scaledDurationField31.getMillis((long) 64);
        long long39 = scaledDurationField31.getUnitMillis();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 73728000000L + "'", long38 == 73728000000L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1152000000L + "'", long39 == 1152000000L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        org.joda.time.Period period4 = period1.plusSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period8 = period4.minusYears(10);
        org.joda.time.Period period10 = period8.minusMinutes((int) '#');
        org.joda.time.PeriodType periodType11 = period10.getPeriodType();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = iSOChronology0.equals(obj2);
//        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
//        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
//        org.joda.time.ReadablePartial readablePartial14 = null;
//        org.joda.time.ReadableInstant readableInstant16 = null;
//        org.joda.time.ReadableInstant readableInstant17 = null;
//        org.joda.time.Chronology chronology18 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant16, readableInstant17);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = dateTimeZone19.getName(10L, locale21);
//        long long26 = dateTimeZone19.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance(chronology18, dateTimeZone19);
//        org.joda.time.Period period29 = org.joda.time.Period.minutes((int) (byte) 1);
//        org.joda.time.Period period31 = period29.withMonths((int) (short) 10);
//        org.joda.time.Period period33 = org.joda.time.Period.minutes((int) (byte) 1);
//        int int34 = period33.size();
//        org.joda.time.Period period35 = period29.minus((org.joda.time.ReadablePeriod) period33);
//        org.joda.time.Period period37 = period33.minusYears(8);
//        long long40 = zonedChronology27.add((org.joda.time.ReadablePeriod) period33, 10L, (int) (short) 0);
//        org.joda.time.Period period42 = org.joda.time.Period.minutes((int) (short) 0);
//        org.joda.time.Period period44 = period42.plusSeconds(100);
//        int[] intArray46 = zonedChronology27.get((org.joda.time.ReadablePeriod) period44, (long) 10);
//        try {
//            int[] intArray48 = offsetDateTimeField8.add(readablePartial14, 1, intArray46, 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Coordinated Universal Time" + "'", str22.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 32L + "'", long26 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology27);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertNotNull(period31);
//        org.junit.Assert.assertNotNull(period33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 8 + "'", int34 == 8);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(period37);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 10L + "'", long40 == 10L);
//        org.junit.Assert.assertNotNull(period42);
//        org.junit.Assert.assertNotNull(period44);
//        org.junit.Assert.assertNotNull(intArray46);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) -1);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("11", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long14 = offsetDateTimeField8.add((-1104537600001L), (int) (byte) 1);
        int int16 = offsetDateTimeField8.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField8.getType();
        org.joda.time.ReadablePartial readablePartial18 = null;
        int int19 = offsetDateTimeField8.getMinimumValue(readablePartial18);
        int int21 = offsetDateTimeField8.getLeapAmount((long) (byte) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1104534000001L) + "'", long14 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.Period period4 = org.joda.time.Period.minutes((int) (byte) 1);
        int int5 = period4.getMillis();
        org.joda.time.Period period7 = period4.plusSeconds((int) (byte) 100);
        org.joda.time.Period period9 = period7.minusMinutes(10);
        org.joda.time.Period period11 = period7.minusYears(10);
        org.joda.time.Period period13 = period11.plusWeeks((int) (short) -1);
        long long16 = iSOChronology0.add((org.joda.time.ReadablePeriod) period11, 0L, 0);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.minuteOfDay();
        try {
            long long22 = iSOChronology0.getDateTimeMillis((int) (short) 10, (int) (byte) 0, 320, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 100, 0L, chronology2);
        org.joda.time.format.PeriodFormatter periodFormatter4 = null;
        java.lang.String str5 = period3.toString(periodFormatter4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT-0.100S" + "'", str5.equals("PT-0.100S"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone2.getName((long) (short) -1, locale4);
        java.lang.String str7 = dateTimeZone2.getShortName(3600000L);
        long long11 = dateTimeZone2.convertLocalToUTC((long) (short) 0, true, (long) '#');
        java.util.TimeZone timeZone12 = dateTimeZone2.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forTimeZone(timeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+97:10" + "'", str5.equals("+97:10"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+97:10" + "'", str7.equals("+97:10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-349800000L) + "'", long11 == (-349800000L));
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (-32));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        int int3 = period1.getWeeks();
        org.joda.time.Period period5 = period1.plusYears(0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        long long34 = zeroIsMaxDateTimeField32.remainder((-1104566400001L));
        boolean boolean36 = zeroIsMaxDateTimeField32.isLeap((long) 32);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int int38 = zeroIsMaxDateTimeField32.getMaximumValue(readablePartial37);
        long long41 = zeroIsMaxDateTimeField32.set((long) 'a', (int) (byte) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599999L + "'", long34 == 3599999L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 7200097L + "'", long41 == 7200097L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(4147200000000000L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.months();
        boolean boolean3 = periodType1.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType4 = periodType1.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        boolean boolean6 = periodType4.isSupported(durationFieldType5);
        org.joda.time.PeriodType periodType7 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType7);
        org.joda.time.Period period10 = period8.minusWeeks((int) (short) 0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfYear();
        java.lang.Object obj5 = null;
        boolean boolean6 = iSOChronology3.equals(obj5);
        boolean boolean8 = iSOChronology3.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.clockhourOfDay();
        java.lang.Class<?> wildcardClass10 = iSOChronology3.getClass();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, 1560630012090L, periodType2, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        try {
            int[] intArray15 = iSOChronology3.get(readablePeriod12, (-100L), (-210865896000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType1 = periodType0.withMonthsRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withHoursRemoved();
        org.joda.time.Period period3 = org.joda.time.Period.ZERO;
        org.joda.time.Period period5 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.indexOf(durationFieldType6);
        org.joda.time.Period period8 = period3.withFields((org.joda.time.ReadablePeriod) period5);
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.dayOfYear();
        java.lang.Object obj11 = null;
        boolean boolean12 = iSOChronology9.equals(obj11);
        org.joda.time.DurationField durationField13 = iSOChronology9.hours();
        long long16 = durationField13.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period18 = org.joda.time.Period.minutes((int) (byte) 1);
        int int19 = period18.getMillis();
        org.joda.time.Period period21 = period18.plusSeconds((int) (byte) 100);
        org.joda.time.Period period23 = period21.minusMinutes(10);
        org.joda.time.Period period25 = period21.minusYears(10);
        int int26 = period21.size();
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType28 = periodType27.withMonthsRemoved();
        org.joda.time.PeriodType periodType29 = periodType28.withHoursRemoved();
        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType33 = periodType32.withYearsRemoved();
        org.joda.time.Period period34 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType32);
        org.joda.time.DurationFieldType durationFieldType36 = periodType32.getFieldType(0);
        boolean boolean37 = periodType29.isSupported(durationFieldType36);
        boolean boolean38 = period21.isSupported(durationFieldType36);
        org.joda.time.field.ScaledDurationField scaledDurationField40 = new org.joda.time.field.ScaledDurationField(durationField13, durationFieldType36, 320);
        long long43 = scaledDurationField40.getDifferenceAsLong((long) 52, (long) 11);
        int int44 = scaledDurationField40.getScalar();
        org.joda.time.DurationFieldType durationFieldType45 = scaledDurationField40.getType();
        org.joda.time.Period period47 = period5.withFieldAdded(durationFieldType45, (int) (byte) -1);
        int int48 = periodType2.indexOf(durationFieldType45);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-3599999L) + "'", long16 == (-3599999L));
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 8 + "'", int26 == 8);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 320 + "'", int44 == 320);
        org.junit.Assert.assertNotNull(durationFieldType45);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.weekyearOfCentury();
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.dayOfYear();
//        java.lang.Object obj10 = null;
//        boolean boolean11 = iSOChronology8.equals(obj10);
//        org.joda.time.DurationField durationField12 = iSOChronology8.weeks();
//        org.joda.time.Period period13 = org.joda.time.Period.ZERO;
//        int[] intArray14 = period13.getValues();
//        long long17 = iSOChronology8.add((org.joda.time.ReadablePeriod) period13, (long) (short) 1, 10);
//        org.joda.time.Period period19 = period13.withMonths((int) (byte) 0);
//        org.joda.time.Period period21 = period13.multipliedBy(100);
//        int[] intArray24 = iSOChronology6.get((org.joda.time.ReadablePeriod) period13, (long) (-1), (-1104537600001L));
//        try {
//            gregorianChronology3.validate(readablePartial5, intArray24);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertNotNull(intArray24);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName((-1L), locale2);
//        long long6 = dateTimeZone0.adjustOffset(28800000L, true);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 28800000L + "'", long6 == 28800000L);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("P10MT1M", "PeriodType[YearDayTime]", (-1), (int) (short) -1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 'a');
        long long8 = fixedDateTimeZone4.previousTransition((-210866760000000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-210866760000000L) + "'", long8 == (-210866760000000L));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(32);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test287");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField12 = zonedChronology11.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology11.getZone();
//        java.lang.String str15 = dateTimeZone13.getName(126000002L);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Coordinated Universal Time" + "'", str15.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone5 = iSOChronology0.getZone();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType7 = periodType6.withYearsRemoved();
        java.lang.String str8 = periodType6.toString();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period((java.lang.Object) iSOChronology0, periodType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PeriodType[YearDayTime]" + "'", str8.equals("PeriodType[YearDayTime]"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        org.joda.time.Period period4 = period1.plusSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period8 = period4.minusYears(10);
        org.joda.time.Period period10 = period8.plusWeeks((int) (short) -1);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationTo(readableInstant11);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        long long6 = dateTimeZone2.convertLocalToUTC(1560630012090L, true);
        java.util.TimeZone timeZone7 = dateTimeZone2.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560629952090L + "'", long6 == 1560629952090L);
        org.junit.Assert.assertNotNull(timeZone7);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test292");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale2 = null;
//        java.lang.String str3 = dateTimeZone0.getName(10L, locale2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
//        long long8 = dateTimeZone4.convertLocalToUTC((long) 100, false, 0L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Coordinated Universal Time" + "'", str3.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period3 = period1.withMonths((int) (short) 10);
        org.joda.time.Period period5 = period1.minusWeeks((int) 'a');
        org.joda.time.Period period7 = period1.withYears((int) (short) -1);
        int int9 = period7.getValue((int) (short) 1);
        org.joda.time.Period period11 = period7.plusMonths((int) (short) -1);
        int int12 = period7.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "hi!", "hi!");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale6 = null;
        java.lang.String str9 = defaultNameProvider0.getShortName(locale6, "(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value -1 for  must be in the range [1,100]\")", "PT-9M100S");
        java.util.Locale locale10 = null;
        java.lang.String str13 = defaultNameProvider0.getShortName(locale10, "ISOChronology[America/Los_Angeles]", "UTC");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNull(str13);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = iSOChronology0.equals(obj2);
//        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
//        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
//        java.lang.String str14 = offsetDateTimeField8.getName();
//        java.util.Locale locale15 = null;
//        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
//        java.lang.Object obj19 = null;
//        boolean boolean20 = iSOChronology17.equals(obj19);
//        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
//        int int30 = offsetDateTimeField25.get((long) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
//        long long34 = zeroIsMaxDateTimeField32.remainder((-1104566400001L));
//        boolean boolean36 = zeroIsMaxDateTimeField32.isLeap((long) 32);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant38, readableInstant39);
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = dateTimeZone41.getName(10L, locale43);
//        long long48 = dateTimeZone41.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology49 = org.joda.time.chrono.ZonedChronology.getInstance(chronology40, dateTimeZone41);
//        org.joda.time.Period period51 = org.joda.time.Period.minutes((int) (byte) 1);
//        org.joda.time.Period period53 = period51.withMonths((int) (short) 10);
//        org.joda.time.Period period55 = org.joda.time.Period.minutes((int) (byte) 1);
//        int int56 = period55.size();
//        org.joda.time.Period period57 = period51.minus((org.joda.time.ReadablePeriod) period55);
//        org.joda.time.Period period59 = period55.minusYears(8);
//        long long62 = zonedChronology49.add((org.joda.time.ReadablePeriod) period55, 10L, (int) (short) 0);
//        org.joda.time.Period period64 = org.joda.time.Period.minutes((int) (short) 0);
//        org.joda.time.Period period66 = period64.plusSeconds(100);
//        int[] intArray68 = zonedChronology49.get((org.joda.time.ReadablePeriod) period66, (long) 10);
//        int int69 = zeroIsMaxDateTimeField32.getMinimumValue(readablePartial37, intArray68);
//        long long72 = zeroIsMaxDateTimeField32.add(230399999L, 12);
//        org.joda.time.ReadablePartial readablePartial73 = null;
//        int int74 = zeroIsMaxDateTimeField32.getMinimumValue(readablePartial73);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599999L + "'", long34 == 3599999L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Coordinated Universal Time" + "'", str44.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 32L + "'", long48 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology49);
//        org.junit.Assert.assertNotNull(period51);
//        org.junit.Assert.assertNotNull(period53);
//        org.junit.Assert.assertNotNull(period55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 8 + "'", int56 == 8);
//        org.junit.Assert.assertNotNull(period57);
//        org.junit.Assert.assertNotNull(period59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 10L + "'", long62 == 10L);
//        org.junit.Assert.assertNotNull(period64);
//        org.junit.Assert.assertNotNull(period66);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 273599999L + "'", long72 == 273599999L);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        try {
            long long7 = iSOChronology0.getDateTimeMillis(0L, 125999965, (-32), (int) (short) 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 125999965 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("P10MT1M", "PeriodType[YearDayTime]", (-1), (int) (short) -1);
        int int6 = fixedDateTimeZone4.getStandardOffset(3600045L);
        boolean boolean8 = fixedDateTimeZone4.equals((java.lang.Object) 10L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long14 = offsetDateTimeField8.add((-1104537600001L), (int) (byte) 1);
        int int16 = offsetDateTimeField8.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField8.getType();
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField8.getWrappedField();
        org.joda.time.ReadablePartial readablePartial19 = null;
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = offsetDateTimeField8.getAsText(readablePartial19, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1104534000001L) + "'", long14 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        org.joda.time.DurationField durationField14 = offsetDateTimeField8.getLeapDurationField();
        boolean boolean15 = offsetDateTimeField8.isLenient();
        long long17 = offsetDateTimeField8.remainder(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 0);
        org.joda.time.Period period3 = period1.plusSeconds(100);
        org.joda.time.Period period5 = period3.minusSeconds((int) '#');
        org.joda.time.Period period7 = period3.minusMillis((int) '#');
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        long long36 = scaledDurationField31.getMillis(0L);
        long long38 = scaledDurationField31.getValueAsLong((-3599999L));
        long long40 = scaledDurationField31.getValueAsLong(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        int int3 = period1.getWeeks();
        org.joda.time.Days days4 = period1.toStandardDays();
        int int5 = period1.getSeconds();
        org.joda.time.Period period7 = period1.withMillis(320);
        int int8 = period7.getSeconds();
        int int9 = period7.getMillis();
        int int10 = period7.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(days4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 320 + "'", int9 == 320);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) 100);
        org.joda.time.DurationField durationField6 = iSOChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.Chronology chronology10 = iSOChronology0.withZone(dateTimeZone9);
        org.joda.time.LocalDateTime localDateTime11 = null;
        boolean boolean12 = dateTimeZone9.isLocalDateTimeGap(localDateTime11);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        long long11 = offsetDateTimeField8.add((long) 1, 0);
        long long13 = offsetDateTimeField8.roundHalfFloor((long) (byte) 100);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (byte) 10);
        org.joda.time.Period period3 = period1.withMillis(11);
        try {
            org.joda.time.Minutes minutes4 = period3.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.Days days4 = period1.toStandardDays();
        org.joda.time.Period period6 = period1.plusWeeks(0);
        int int7 = period1.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(days4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap3);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.Period period8 = new org.joda.time.Period(52, 12, (int) (byte) 10, (-1), (int) '4', 10, (int) (byte) -1, (int) (short) 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        org.joda.time.ReadablePartial readablePartial12 = null;
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField8.getAsText(readablePartial12, 100, locale14);
        long long18 = offsetDateTimeField8.add((long) 100, 8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "100" + "'", str15.equals("100"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 28800100L + "'", long18 == 28800100L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period6 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period8 = period6.withMonths((int) (short) 10);
        int int9 = period6.getHours();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.months();
        boolean boolean12 = periodType10.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType13 = periodType10.withMillisRemoved();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType17 = periodType16.withYearsRemoved();
        org.joda.time.Period period18 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType16);
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType(0);
        int int21 = periodType10.indexOf(durationFieldType20);
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(durationFieldType20, (java.lang.Number) 0.0d, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0);
        int int26 = period6.get(durationFieldType20);
        int int27 = periodType3.indexOf(durationFieldType20);
        int int28 = periodType0.indexOf(durationFieldType20);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        long long36 = scaledDurationField31.getMillis(0L);
        long long38 = scaledDurationField31.getValueAsLong((-3599999L));
        java.lang.String str39 = scaledDurationField31.toString();
        try {
            long long41 = scaledDurationField31.getMillis((-210858120000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -67474598400000000 * 3600000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[years]" + "'", str39.equals("DurationField[years]"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        long long36 = scaledDurationField31.getMillis(0L);
        java.lang.String str37 = scaledDurationField31.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DurationField[years]" + "'", str37.equals("DurationField[years]"));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        int int3 = period1.getWeeks();
        int int4 = period1.getMonths();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period3 = period1.withMonths((int) (short) 10);
        int int4 = period1.getHours();
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.months();
        boolean boolean7 = periodType5.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType8 = periodType5.withMillisRemoved();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType12 = periodType11.withYearsRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType11);
        org.joda.time.DurationFieldType durationFieldType15 = periodType11.getFieldType(0);
        int int16 = periodType5.indexOf(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) 0.0d, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0);
        int int21 = period1.get(durationFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException25 = new org.joda.time.IllegalFieldValueException(durationFieldType15, (java.lang.Number) 8, (java.lang.Number) (-1L), (java.lang.Number) 2440587L);
        boolean boolean26 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException25);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("ISOChronology[America/Los_Angeles]", "");
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 52);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfYear();
        java.lang.Object obj5 = null;
        boolean boolean6 = iSOChronology3.equals(obj5);
        boolean boolean8 = iSOChronology3.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.clockhourOfDay();
        java.lang.Class<?> wildcardClass10 = iSOChronology3.getClass();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, 1560630012090L, periodType2, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone14.getName((long) (short) -1, locale16);
        org.joda.time.Chronology chronology18 = iSOChronology3.withZone(dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14, (-63));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -63");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+97:10" + "'", str17.equals("+97:10"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        long long36 = scaledDurationField31.getMillis((long) (byte) -1);
        long long38 = scaledDurationField31.getMillis(100);
        int int41 = scaledDurationField31.getDifference((long) (-10), 0L);
        long long43 = scaledDurationField31.getMillis(320);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-1152000000L) + "'", long36 == (-1152000000L));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 115200000000L + "'", long38 == 115200000000L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 368640000000L + "'", long43 == 368640000000L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        int int35 = zeroIsMaxDateTimeField32.getDifference((long) 320, (long) 'a');
        long long37 = zeroIsMaxDateTimeField32.roundHalfFloor((long) 8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long33 = scaledDurationField31.getMillis(0L);
        try {
            long long35 = scaledDurationField31.getMillis(115200000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 36864000000000 * 3600000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        boolean boolean33 = offsetDateTimeField8.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period2 = org.joda.time.Period.minutes((int) (byte) 1);
        int int3 = period2.getMillis();
        org.joda.time.Period period5 = period2.plusSeconds((int) (byte) 100);
        int[] intArray7 = iSOChronology0.get((org.joda.time.ReadablePeriod) period2, 100L);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.months();
        boolean boolean11 = periodType9.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType12 = periodType9.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period14 = new org.joda.time.Period((long) (byte) 100, periodType12, (org.joda.time.Chronology) iSOChronology13);
        boolean boolean15 = iSOChronology0.equals((java.lang.Object) iSOChronology13);
        org.joda.time.DurationField durationField16 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withWeeksRemoved();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) dateTimeField1, periodType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.BasicDayOfYearDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (short) 100);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        illegalFieldValueException4.prependMessage("P0M");
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number10 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 100 + "'", number10.equals((short) 100));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
        boolean boolean4 = periodType0.equals((java.lang.Object) dateTimeZone2);
        org.joda.time.PeriodType periodType5 = periodType0.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(52);
        org.joda.time.Duration duration2 = period1.toStandardDuration();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.months();
        boolean boolean5 = periodType3.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType6 = periodType3.withMillisRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period(10L, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withMinutesRemoved();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology3 = gregorianChronology0.withZone(dateTimeZone2);
        long long6 = dateTimeZone2.convertLocalToUTC((-349800000L), false);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-349800000L) + "'", long6 == (-349800000L));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        int int2 = periodType0.indexOf(durationFieldType1);
        org.joda.time.PeriodType periodType3 = periodType0.withYearsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfYear();
        java.lang.Object obj5 = null;
        boolean boolean6 = iSOChronology3.equals(obj5);
        boolean boolean8 = iSOChronology3.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.clockhourOfDay();
        java.lang.Class<?> wildcardClass10 = iSOChronology3.getClass();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, 1560630012090L, periodType2, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        java.util.Locale locale16 = null;
        java.lang.String str17 = dateTimeZone14.getName((long) (short) -1, locale16);
        org.joda.time.Chronology chronology18 = iSOChronology3.withZone(dateTimeZone14);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
        long long23 = dateTimeZone14.convertLocalToUTC(3600045L, false, 1152000001L);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+97:10" + "'", str17.equals("+97:10"));
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-346199955L) + "'", long23 == (-346199955L));
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (short) 1);
//        org.joda.time.LocalDateTime localDateTime3 = null;
//        boolean boolean4 = dateTimeZone0.isLocalDateTimeGap(localDateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfYear();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.DurationField durationField5 = iSOChronology1.eras();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (-1));
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField9.getAsText((long) (short) 0, locale11);
        int int14 = offsetDateTimeField9.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField9.getType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField16 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "11" + "'", str12.equals("11"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 11 + "'", int14 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("52");
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test336");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.joda.time.Chronology chronology14 = gregorianChronology13.withUTC();
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, 125999965);
        java.lang.String str16 = offsetDateTimeField15.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "DateTimeField[clockhourOfHalfday]" + "'", str16.equals("DateTimeField[clockhourOfHalfday]"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) 100);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.yearOfEra();
        org.joda.time.Chronology chronology8 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period3 = period1.withMonths((int) (short) 10);
        int int4 = period1.getHours();
        org.joda.time.Period period6 = period1.plusMonths((int) (short) 1);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        int int8 = period6.indexOf(durationFieldType7);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        int int35 = scaledDurationField31.getScalar();
        org.joda.time.DurationFieldType durationFieldType36 = scaledDurationField31.getType();
        long long39 = scaledDurationField31.getMillis(0, (long) 2);
        long long41 = scaledDurationField31.getMillis((int) (short) 1);
        long long44 = scaledDurationField31.add(2440581L, (int) '#');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 320 + "'", int35 == 320);
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1152000000L + "'", long41 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 40322440581L + "'", long44 == 40322440581L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.Days days4 = period1.toStandardDays();
        org.joda.time.Period period6 = period1.plusWeeks(0);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType8 = periodType7.withHoursRemoved();
        org.joda.time.PeriodType periodType9 = periodType7.withWeeksRemoved();
        org.joda.time.Period period10 = period1.withPeriodType(periodType9);
        int int11 = period10.getMonths();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(days4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        long long18 = offsetDateTimeField8.roundFloor((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = iSOChronology19.equals(obj21);
        org.joda.time.DurationField durationField23 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (-1));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField27.getAsText((long) (short) 0, locale29);
        long long33 = offsetDateTimeField27.add((-1104537600001L), (int) (byte) 1);
        int int35 = offsetDateTimeField27.getLeapAmount(60001L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField27.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField27.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType38);
        int int40 = zeroIsMaxDateTimeField39.getMinimumValue();
        org.joda.time.ReadablePartial readablePartial41 = null;
        int[] intArray42 = null;
        int int43 = zeroIsMaxDateTimeField39.getMinimumValue(readablePartial41, intArray42);
        long long45 = zeroIsMaxDateTimeField39.roundHalfEven((long) (short) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3600000L) + "'", long18 == (-3600000L));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "11" + "'", str30.equals("11"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1104534000001L) + "'", long33 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfYear();
//        java.lang.Object obj3 = null;
//        boolean boolean4 = iSOChronology1.equals(obj3);
//        org.joda.time.DurationField durationField5 = iSOChronology1.weeks();
//        org.joda.time.Period period6 = org.joda.time.Period.ZERO;
//        int[] intArray7 = period6.getValues();
//        long long10 = iSOChronology1.add((org.joda.time.ReadablePeriod) period6, (long) (short) 1, 10);
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology1.dayOfWeek();
//        org.joda.time.Period period12 = new org.joda.time.Period(230399999L, (org.joda.time.Chronology) iSOChronology1);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone13.getName(10L, locale15);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeUtils.getZone(dateTimeZone13);
//        org.joda.time.ReadableInstant readableInstant18 = null;
//        int int19 = dateTimeZone17.getOffset(readableInstant18);
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology1, dateTimeZone17);
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(period6);
//        org.junit.Assert.assertNotNull(intArray7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(zonedChronology20);
//    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField12 = zonedChronology11.clockhourOfDay();
//        try {
//            long long20 = zonedChronology11.getDateTimeMillis(100, (-161387), 11, (int) (short) -1, 1, 60000, (-63));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        int int35 = scaledDurationField31.getScalar();
        long long37 = scaledDurationField31.getMillis(3600000L);
        int int38 = scaledDurationField31.getScalar();
        int int41 = scaledDurationField31.getDifference(165600000L, 73728000000L);
        long long44 = scaledDurationField31.getMillis(10, 1560628800000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 320 + "'", int35 == 320);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 4147200000000000L + "'", long37 == 4147200000000000L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 320 + "'", int38 == 320);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-63) + "'", int41 == (-63));
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 11520000000L + "'", long44 == 11520000000L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str1 = dateTimeZone0.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName((long) (short) -1, locale6);
        java.lang.String str9 = dateTimeZone4.getShortName(3600000L);
        long long11 = dateTimeZone0.getMillisKeepLocal(dateTimeZone4, 52L);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+97:10" + "'", str7.equals("+97:10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+97:10" + "'", str9.equals("+97:10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-349799948L) + "'", long11 == (-349799948L));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long14 = offsetDateTimeField8.add((-1104537600001L), (int) (byte) 1);
        int int16 = offsetDateTimeField8.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField8.getType();
        org.joda.time.DateTimeField dateTimeField18 = offsetDateTimeField8.getWrappedField();
        long long20 = offsetDateTimeField8.roundFloor(0L);
        org.joda.time.ReadablePartial readablePartial21 = null;
        org.joda.time.Period period23 = org.joda.time.Period.ZERO;
        int[] intArray24 = period23.getValues();
        try {
            int[] intArray26 = offsetDateTimeField8.addWrapField(readablePartial21, (int) (byte) 10, intArray24, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1104534000001L) + "'", long14 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(intArray24);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        long long34 = zeroIsMaxDateTimeField32.remainder((-1104566400001L));
        boolean boolean36 = zeroIsMaxDateTimeField32.isLeap((long) 32);
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.chrono.ISOChronology iSOChronology38 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period40 = org.joda.time.Period.minutes((int) (byte) 1);
        int int41 = period40.getMillis();
        org.joda.time.Period period43 = period40.plusSeconds((int) (byte) 100);
        int[] intArray45 = iSOChronology38.get((org.joda.time.ReadablePeriod) period40, 100L);
        int int46 = zeroIsMaxDateTimeField32.getMinimumValue(readablePartial37, intArray45);
        int int49 = zeroIsMaxDateTimeField32.getDifference(230399999L, 28800000L);
        org.joda.time.ReadablePartial readablePartial50 = null;
        org.joda.time.chrono.ISOChronology iSOChronology52 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology52.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology54 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField55 = iSOChronology54.dayOfYear();
        java.lang.Object obj56 = null;
        boolean boolean57 = iSOChronology54.equals(obj56);
        org.joda.time.DurationField durationField58 = iSOChronology54.weeks();
        org.joda.time.Period period59 = org.joda.time.Period.ZERO;
        int[] intArray60 = period59.getValues();
        long long63 = iSOChronology54.add((org.joda.time.ReadablePeriod) period59, (long) (short) 1, 10);
        org.joda.time.Period period65 = period59.withMonths((int) (byte) 0);
        org.joda.time.Period period67 = period59.multipliedBy(100);
        int[] intArray70 = iSOChronology52.get((org.joda.time.ReadablePeriod) period59, (long) (-1), (-1104537600001L));
        try {
            int[] intArray72 = zeroIsMaxDateTimeField32.add(readablePartial50, (int) '4', intArray70, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599999L + "'", long34 == 3599999L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(iSOChronology38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 55 + "'", int49 == 55);
        org.junit.Assert.assertNotNull(iSOChronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(iSOChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1L + "'", long63 == 1L);
        org.junit.Assert.assertNotNull(period65);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(intArray70);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withMinutesRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withDaysRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        long long18 = offsetDateTimeField8.roundFloor((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = iSOChronology19.equals(obj21);
        org.joda.time.DurationField durationField23 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (-1));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField27.getAsText((long) (short) 0, locale29);
        long long33 = offsetDateTimeField27.add((-1104537600001L), (int) (byte) 1);
        int int35 = offsetDateTimeField27.getLeapAmount(60001L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField27.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField27.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType38);
        long long41 = zeroIsMaxDateTimeField39.roundHalfCeiling((long) (short) 1);
        org.joda.time.ReadablePartial readablePartial42 = null;
        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.dayOfYear();
        java.lang.Object obj45 = null;
        boolean boolean46 = iSOChronology43.equals(obj45);
        org.joda.time.DurationField durationField47 = iSOChronology43.eras();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology43.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology43.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, (-1));
        java.util.Locale locale53 = null;
        java.lang.String str54 = offsetDateTimeField51.getAsText((long) (short) 0, locale53);
        long long56 = offsetDateTimeField51.roundCeiling((long) (byte) 10);
        java.lang.String str57 = offsetDateTimeField51.getName();
        java.util.Locale locale58 = null;
        int int59 = offsetDateTimeField51.getMaximumTextLength(locale58);
        org.joda.time.chrono.ISOChronology iSOChronology60 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology60.dayOfYear();
        java.lang.Object obj62 = null;
        boolean boolean63 = iSOChronology60.equals(obj62);
        org.joda.time.DurationField durationField64 = iSOChronology60.eras();
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology60.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField66 = iSOChronology60.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField(dateTimeField66, (-1));
        java.util.Locale locale70 = null;
        java.lang.String str71 = offsetDateTimeField68.getAsText((long) (short) 0, locale70);
        int int73 = offsetDateTimeField68.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType74 = offsetDateTimeField68.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField75 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField51, dateTimeFieldType74);
        long long77 = zeroIsMaxDateTimeField75.remainder((-1104566400001L));
        boolean boolean79 = zeroIsMaxDateTimeField75.isLeap((long) 32);
        org.joda.time.ReadablePartial readablePartial80 = null;
        org.joda.time.chrono.ISOChronology iSOChronology81 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period83 = org.joda.time.Period.minutes((int) (byte) 1);
        int int84 = period83.getMillis();
        org.joda.time.Period period86 = period83.plusSeconds((int) (byte) 100);
        int[] intArray88 = iSOChronology81.get((org.joda.time.ReadablePeriod) period83, 100L);
        int int89 = zeroIsMaxDateTimeField75.getMinimumValue(readablePartial80, intArray88);
        int int90 = zeroIsMaxDateTimeField39.getMaximumValue(readablePartial42, intArray88);
        org.joda.time.ReadablePartial readablePartial91 = null;
        int int92 = zeroIsMaxDateTimeField39.getMinimumValue(readablePartial91);
        try {
            long long95 = zeroIsMaxDateTimeField39.set(115200000000L, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for clockhourOfHalfday must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3600000L) + "'", long18 == (-3600000L));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "11" + "'", str30.equals("11"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1104534000001L) + "'", long33 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "11" + "'", str54.equals("11"));
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 3600000L + "'", long56 == 3600000L);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "clockhourOfHalfday" + "'", str57.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
        org.junit.Assert.assertNotNull(iSOChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(durationField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(dateTimeField66);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "11" + "'", str71.equals("11"));
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 11 + "'", int73 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType74);
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 3599999L + "'", long77 == 3599999L);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(iSOChronology81);
        org.junit.Assert.assertNotNull(period83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertNotNull(period86);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1 + "'", int89 == 1);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 12 + "'", int90 == 12);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        long long34 = zeroIsMaxDateTimeField32.remainder((-1104566400001L));
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = zeroIsMaxDateTimeField32.getMinimumValue(readablePartial35);
        long long39 = zeroIsMaxDateTimeField32.add((long) (byte) 10, (int) '#');
        org.joda.time.ReadablePartial readablePartial40 = null;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.weekyearOfCentury();
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.dayOfYear();
        java.lang.Object obj46 = null;
        boolean boolean47 = iSOChronology44.equals(obj46);
        org.joda.time.DurationField durationField48 = iSOChronology44.weeks();
        org.joda.time.Period period49 = org.joda.time.Period.ZERO;
        int[] intArray50 = period49.getValues();
        long long53 = iSOChronology44.add((org.joda.time.ReadablePeriod) period49, (long) (short) 1, 10);
        org.joda.time.Period period55 = period49.withMonths((int) (byte) 0);
        org.joda.time.Period period57 = period49.multipliedBy(100);
        int[] intArray60 = iSOChronology42.get((org.joda.time.ReadablePeriod) period49, (long) (-1), (-1104537600001L));
        try {
            int[] intArray62 = zeroIsMaxDateTimeField32.addWrapPartial(readablePartial40, 10, intArray60, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599999L + "'", long34 == 3599999L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 126000010L + "'", long39 == 126000010L);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1L + "'", long53 == 1L);
        org.junit.Assert.assertNotNull(period55);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(intArray60);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField8.getAsText(52, locale18);
        long long21 = offsetDateTimeField8.roundHalfCeiling(32L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "52" + "'", str19.equals("52"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearDayTime();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfYear();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = iSOChronology4.equals(obj6);
//        boolean boolean9 = iSOChronology4.equals((java.lang.Object) 100);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.clockhourOfDay();
//        java.lang.Class<?> wildcardClass11 = iSOChronology4.getClass();
//        org.joda.time.Period period12 = new org.joda.time.Period(0L, 1560630012090L, periodType3, (org.joda.time.Chronology) iSOChronology4);
//        org.joda.time.PeriodType periodType13 = periodType3.withMinutesRemoved();
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName(10L, locale19);
//        long long24 = dateTimeZone17.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance(chronology16, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField26 = zonedChronology25.clockhourOfDay();
//        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) 0, periodType3, (org.joda.time.Chronology) zonedChronology25);
//        org.joda.time.Period period29 = org.joda.time.Period.minutes((int) (byte) 1);
//        int int30 = period29.getMillis();
//        int int31 = period29.size();
//        org.joda.time.Minutes minutes32 = period29.toStandardMinutes();
//        org.joda.time.Period period34 = period29.plusYears((int) '4');
//        org.joda.time.Period period35 = period27.minus((org.joda.time.ReadablePeriod) period34);
//        org.joda.time.Period period37 = period34.withSeconds(125999965);
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(periodType13);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 32L + "'", long24 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(period29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 8 + "'", int31 == 8);
//        org.junit.Assert.assertNotNull(minutes32);
//        org.junit.Assert.assertNotNull(period34);
//        org.junit.Assert.assertNotNull(period35);
//        org.junit.Assert.assertNotNull(period37);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        long long34 = zeroIsMaxDateTimeField32.remainder((-1104566400001L));
        boolean boolean36 = zeroIsMaxDateTimeField32.isLeap((long) 32);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int int38 = zeroIsMaxDateTimeField32.getMaximumValue(readablePartial37);
        int int39 = zeroIsMaxDateTimeField32.getMinimumValue();
        long long41 = zeroIsMaxDateTimeField32.roundFloor(306816L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599999L + "'", long34 == 3599999L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 12 + "'", int38 == 12);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withMonthsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withWeeksRemoved();
        java.lang.String str5 = periodType4.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PeriodType[YearDayTimeNoYears]" + "'", str5.equals("PeriodType[YearDayTimeNoYears]"));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.Period period1 = org.joda.time.Period.days(64);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.dayOfYear();
        java.lang.Object obj7 = null;
        boolean boolean8 = iSOChronology5.equals(obj7);
        boolean boolean10 = iSOChronology5.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.clockhourOfDay();
        java.lang.Class<?> wildcardClass12 = iSOChronology5.getClass();
        org.joda.time.Period period13 = new org.joda.time.Period(0L, 1560630012090L, periodType4, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Period period14 = period1.withFields((org.joda.time.ReadablePeriod) period13);
        int int15 = period13.getDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 165 + "'", int15 == 165);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (short) 100);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str8 = illegalFieldValueException4.toString();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (short) 100);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.joda.time.IllegalFieldValueException: Value -1 for  must be in the range [1,100]" + "'", str8.equals("org.joda.time.IllegalFieldValueException: Value -1 for  must be in the range [1,100]"));
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField12 = zonedChronology11.dayOfYear();
//        long long18 = zonedChronology11.getDateTimeMillis((long) (byte) -1, 4, (int) (byte) 10, (int) '#', (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField19 = zonedChronology11.secondOfMinute();
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-71364999L) + "'", long18 == (-71364999L));
//        org.junit.Assert.assertNotNull(dateTimeField19);
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        long long15 = dateTimeZone12.convertUTCToLocal((long) '4');
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 52L + "'", long15 == 52L);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfYear();
        java.lang.Object obj6 = null;
        boolean boolean7 = iSOChronology4.equals(obj6);
        org.joda.time.DurationField durationField8 = iSOChronology4.weeks();
        java.lang.String str9 = iSOChronology4.toString();
        org.joda.time.Period period11 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period13 = period11.withMonths((int) (short) 10);
        int[] intArray15 = iSOChronology4.get((org.joda.time.ReadablePeriod) period11, (long) 4);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology4.year();
        boolean boolean17 = cachedDateTimeZone3.equals((java.lang.Object) dateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone18 = cachedDateTimeZone3.getUncachedZone();
        boolean boolean19 = cachedDateTimeZone3.isFixed();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[UTC]" + "'", str9.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.dayOfYear();
        java.lang.Object obj9 = null;
        boolean boolean10 = iSOChronology7.equals(obj9);
        org.joda.time.DurationField durationField11 = iSOChronology7.eras();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology7.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology7.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (-1));
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsText((long) (short) 0, locale17);
        long long21 = offsetDateTimeField15.add((-1104537600001L), (int) (byte) 1);
        int int23 = offsetDateTimeField15.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField15.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType24, 4);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.weekyearOfCentury();
        org.joda.time.DurationField durationField29 = iSOChronology27.eras();
        try {
            org.joda.time.Period period30 = new org.joda.time.Period((java.lang.Object) dateTimeFieldType24, (org.joda.time.Chronology) iSOChronology27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.DateTimeFieldType$StandardDateTimeFieldType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "11" + "'", str18.equals("11"));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1104534000001L) + "'", long21 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = org.joda.time.Period.minutes((int) (byte) 1);
        int int4 = period3.getMillis();
        org.joda.time.Period period6 = period3.plusSeconds((int) (byte) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePeriod) period3, 100L);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.months();
        boolean boolean12 = periodType10.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType13 = periodType10.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 100, periodType13, (org.joda.time.Chronology) iSOChronology14);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) iSOChronology14);
        org.joda.time.DurationField durationField17 = iSOChronology14.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology14.dayOfWeek();
        org.joda.time.Period period19 = new org.joda.time.Period((long) 52, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DurationField durationField20 = iSOChronology14.hours();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.dayOfYear();
        java.lang.Object obj23 = null;
        boolean boolean24 = iSOChronology21.equals(obj23);
        org.joda.time.DurationField durationField25 = iSOChronology21.hours();
        long long28 = durationField25.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period30 = org.joda.time.Period.minutes((int) (byte) 1);
        int int31 = period30.getMillis();
        org.joda.time.Period period33 = period30.plusSeconds((int) (byte) 100);
        org.joda.time.Period period35 = period33.minusMinutes(10);
        org.joda.time.Period period37 = period33.minusYears(10);
        int int38 = period33.size();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType40 = periodType39.withMonthsRemoved();
        org.joda.time.PeriodType periodType41 = periodType40.withHoursRemoved();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType45 = periodType44.withYearsRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType44);
        org.joda.time.DurationFieldType durationFieldType48 = periodType44.getFieldType(0);
        boolean boolean49 = periodType41.isSupported(durationFieldType48);
        boolean boolean50 = period33.isSupported(durationFieldType48);
        org.joda.time.field.ScaledDurationField scaledDurationField52 = new org.joda.time.field.ScaledDurationField(durationField25, durationFieldType48, 320);
        long long55 = scaledDurationField52.getDifferenceAsLong((long) 52, (long) 11);
        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField57 = iSOChronology56.dayOfYear();
        java.lang.Object obj58 = null;
        boolean boolean59 = iSOChronology56.equals(obj58);
        org.joda.time.DurationField durationField60 = iSOChronology56.weeks();
        int int61 = scaledDurationField52.compareTo(durationField60);
        int int64 = scaledDurationField52.getValue((long) (byte) 100, 0L);
        int int65 = scaledDurationField52.getScalar();
        org.joda.time.DurationFieldType durationFieldType66 = scaledDurationField52.getType();
        org.joda.time.field.ScaledDurationField scaledDurationField68 = new org.joda.time.field.ScaledDurationField(durationField20, durationFieldType66, (-1));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-3599999L) + "'", long28 == (-3599999L));
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 8 + "'", int38 == 8);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(durationFieldType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(durationField60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 320 + "'", int65 == 320);
        org.junit.Assert.assertNotNull(durationFieldType66);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 52);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfYear();
        java.lang.Object obj5 = null;
        boolean boolean6 = iSOChronology3.equals(obj5);
        boolean boolean8 = iSOChronology3.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.clockhourOfDay();
        java.lang.Class<?> wildcardClass10 = iSOChronology3.getClass();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, 1560630012090L, periodType2, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology3.millisOfSecond();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.dayOfYear();
        java.lang.Object obj15 = null;
        boolean boolean16 = iSOChronology13.equals(obj15);
        org.joda.time.DurationField durationField17 = iSOChronology13.weeks();
        org.joda.time.Period period18 = org.joda.time.Period.ZERO;
        int[] intArray19 = period18.getValues();
        long long22 = iSOChronology13.add((org.joda.time.ReadablePeriod) period18, (long) (short) 1, 10);
        org.joda.time.Period period24 = period18.withMonths((int) (byte) 0);
        org.joda.time.Period period26 = period18.multipliedBy(100);
        org.joda.time.Days days27 = period18.toStandardDays();
        long long30 = iSOChronology3.add((org.joda.time.ReadablePeriod) days27, (long) 165, 32);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(days27);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 165L + "'", long30 == 165L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (short) 10);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType5 = periodType4.withHoursRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.dayOfYear();
        java.lang.Object obj8 = null;
        boolean boolean9 = iSOChronology6.equals(obj8);
        org.joda.time.DurationField durationField10 = iSOChronology6.eras();
        org.joda.time.Chronology chronology11 = iSOChronology6.withUTC();
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology6.halfdayOfDay();
        org.joda.time.Period period13 = new org.joda.time.Period((long) '4', (-1104537600001L), periodType4, (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.PeriodType periodType14 = periodType4.withMillisRemoved();
        int int15 = periodType14.size();
        org.joda.time.Period period16 = period1.normalizedStandard(periodType14);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 7 + "'", int15 == 7);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        int int16 = offsetDateTimeField8.getMinimumValue((-100L));
        java.util.Locale locale17 = null;
        int int18 = offsetDateTimeField8.getMaximumTextLength(locale17);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        org.joda.time.Period period4 = period1.plusSeconds((int) (byte) 100);
        int int5 = period4.getSeconds();
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period4.indexOf(durationFieldType6);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        boolean boolean32 = scaledDurationField31.isSupported();
        long long35 = scaledDurationField31.add(2440588L, (int) (byte) 0);
        long long37 = scaledDurationField31.getValueAsLong(4147200000000000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 2440588L + "'", long35 == 2440588L);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3600000L + "'", long37 == 3600000L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (short) 100);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str8 = illegalFieldValueException4.getFieldName();
        java.lang.String str9 = illegalFieldValueException4.getIllegalValueAsString();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType11 = periodType10.withYearsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.dayOfYear();
        java.lang.Object obj14 = null;
        boolean boolean15 = iSOChronology12.equals(obj14);
        org.joda.time.DurationField durationField16 = iSOChronology12.weeks();
        try {
            org.joda.time.Period period17 = new org.joda.time.Period((java.lang.Object) illegalFieldValueException4, periodType11, (org.joda.time.Chronology) iSOChronology12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.IllegalFieldValueException");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-1" + "'", str9.equals("-1"));
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        int int35 = scaledDurationField31.getScalar();
        long long37 = scaledDurationField31.getMillis(3600000L);
        int int38 = scaledDurationField31.getScalar();
        long long40 = scaledDurationField31.getMillis(126000010L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 320 + "'", int35 == 320);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 4147200000000000L + "'", long37 == 4147200000000000L);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 320 + "'", int38 == 320);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 145152011520000000L + "'", long40 == 145152011520000000L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.DurationFieldType durationFieldType3 = null;
        boolean boolean4 = periodType2.isSupported(durationFieldType3);
        java.lang.String str5 = periodType2.toString();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period(10L, 3600045L, periodType2, chronology6);
        try {
            org.joda.time.Period period9 = period7.minusWeeks(8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PeriodType[Millis]" + "'", str5.equals("PeriodType[Millis]"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(165, 7);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField8.getAsText(52, locale18);
        java.lang.String str21 = offsetDateTimeField8.getAsShortText((-349800000L));
        long long23 = offsetDateTimeField8.roundCeiling((long) 8);
        int int25 = offsetDateTimeField8.getLeapAmount((long) 45);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "52" + "'", str19.equals("52"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9" + "'", str21.equals("9"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3600000L + "'", long23 == 3600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        boolean boolean17 = offsetDateTimeField8.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("PeriodType[YearDayTime]", "+97:10");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-3599999L), "PT-0.100S");
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        org.joda.time.DurationField durationField14 = offsetDateTimeField8.getLeapDurationField();
        long long16 = offsetDateTimeField8.roundHalfCeiling((-346199955L));
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.Period period20 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period22 = period20.withMonths((int) (short) 10);
        org.joda.time.Period period24 = period20.minusWeeks((int) 'a');
        org.joda.time.Period period26 = period20.withYears((int) (short) -1);
        int[] intArray27 = period20.getValues();
        try {
            int[] intArray29 = offsetDateTimeField8.add(readablePartial17, 0, intArray27, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-345600000L) + "'", long16 == (-345600000L));
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        long long18 = offsetDateTimeField8.roundFloor((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = iSOChronology19.equals(obj21);
        org.joda.time.DurationField durationField23 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (-1));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField27.getAsText((long) (short) 0, locale29);
        long long33 = offsetDateTimeField27.add((-1104537600001L), (int) (byte) 1);
        int int35 = offsetDateTimeField27.getLeapAmount(60001L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField27.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField27.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType38);
        int int41 = zeroIsMaxDateTimeField39.getMaximumValue((-3599999L));
        long long43 = zeroIsMaxDateTimeField39.roundHalfFloor(306816L);
        int int45 = zeroIsMaxDateTimeField39.getMinimumValue(4147200000000572L);
        int int47 = zeroIsMaxDateTimeField39.get((long) '4');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3600000L) + "'", long18 == (-3600000L));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "11" + "'", str30.equals("11"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1104534000001L) + "'", long33 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 11 + "'", int47 == 11);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        org.joda.time.Period period5 = org.joda.time.Period.ZERO;
        int[] intArray6 = period5.getValues();
        long long9 = iSOChronology0.add((org.joda.time.ReadablePeriod) period5, (long) (short) 1, 10);
        org.joda.time.Period period11 = period5.withMonths((int) (byte) 0);
        org.joda.time.Period period13 = period11.minusMinutes((int) ' ');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(7, 11, 12);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 11 + "'", int3 == 11);
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.Period period13 = org.joda.time.Period.minutes((int) (byte) 1);
//        org.joda.time.Period period15 = period13.withMonths((int) (short) 10);
//        org.joda.time.Period period17 = org.joda.time.Period.minutes((int) (byte) 1);
//        int int18 = period17.size();
//        org.joda.time.Period period19 = period13.minus((org.joda.time.ReadablePeriod) period17);
//        org.joda.time.Period period21 = period17.minusYears(8);
//        long long24 = zonedChronology11.add((org.joda.time.ReadablePeriod) period17, 10L, (int) (short) 0);
//        try {
//            long long30 = zonedChronology11.getDateTimeMillis(145152011520000000L, 0, (int) (byte) 100, (-32), (-10));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertNotNull(period15);
//        org.junit.Assert.assertNotNull(period17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 10L + "'", long24 == 10L);
//    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField12 = zonedChronology11.dayOfYear();
//        long long18 = zonedChronology11.getDateTimeMillis((long) (byte) -1, 4, (int) (byte) 10, (int) '#', (int) (short) 1);
//        org.joda.time.Chronology chronology19 = zonedChronology11.withUTC();
//        try {
//            long long27 = zonedChronology11.getDateTimeMillis(7, (int) ' ', (int) (short) 10, (int) 'a', 60000, (int) (byte) 100, 8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-71364999L) + "'", long18 == (-71364999L));
//        org.junit.Assert.assertNotNull(chronology19);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.Period period1 = org.joda.time.Period.months((-161387));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("hi!", (int) (short) 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder14 = dateTimeZoneBuilder3.addCutover((int) (short) 1, '#', 60000, (int) (byte) 10, 2, false, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: #");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) 100);
        org.joda.time.DurationField durationField6 = iSOChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        org.joda.time.Chronology chronology10 = iSOChronology0.withZone(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        java.util.Locale locale15 = null;
        java.lang.String str16 = dateTimeZone13.getName((long) (short) -1, locale15);
        long long18 = dateTimeZone9.getMillisKeepLocal(dateTimeZone13, (long) (byte) -1);
        java.lang.String str20 = dateTimeZone9.getName(368640000000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+97:10" + "'", str16.equals("+97:10"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+97:10" + "'", str20.equals("+97:10"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.Period period4 = org.joda.time.Period.minutes((int) (byte) 1);
        int int5 = period4.getMillis();
        org.joda.time.Period period7 = period4.plusSeconds((int) (byte) 100);
        org.joda.time.Period period9 = period7.minusMinutes(10);
        org.joda.time.Period period11 = period7.minusYears(10);
        org.joda.time.Period period13 = period11.plusWeeks((int) (short) -1);
        long long16 = iSOChronology0.add((org.joda.time.ReadablePeriod) period11, 0L, 0);
        int int17 = period11.getMillis();
        org.joda.time.Period period19 = period11.plusYears((-1));
        org.joda.time.Period period21 = org.joda.time.Period.minutes((int) (byte) 1);
        int int22 = period21.getMillis();
        org.joda.time.Period period24 = period21.plusSeconds((int) (byte) 100);
        org.joda.time.Period period25 = period19.minus((org.joda.time.ReadablePeriod) period21);
        org.joda.time.Period period27 = period19.withMonths(60000);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(period27);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 0);
        org.joda.time.Period period3 = period1.plusSeconds(100);
        org.joda.time.Period period5 = period3.minusSeconds((int) '#');
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType7 = periodType6.withHoursRemoved();
        org.joda.time.Period period8 = period3.normalizedStandard(periodType6);
        org.joda.time.Minutes minutes9 = period3.toStandardMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(minutes9);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 0);
        org.joda.time.Period period3 = period1.plusSeconds(100);
        org.joda.time.Weeks weeks4 = period3.toStandardWeeks();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(weeks4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        long long18 = offsetDateTimeField8.roundFloor((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = iSOChronology19.equals(obj21);
        org.joda.time.DurationField durationField23 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (-1));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField27.getAsText((long) (short) 0, locale29);
        long long33 = offsetDateTimeField27.add((-1104537600001L), (int) (byte) 1);
        int int35 = offsetDateTimeField27.getLeapAmount(60001L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField27.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField27.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType38);
        long long41 = zeroIsMaxDateTimeField39.roundHalfCeiling((long) (short) 1);
        int int44 = zeroIsMaxDateTimeField39.getDifference((long) (byte) 1, 40322440581L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3600000L) + "'", long18 == (-3600000L));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "11" + "'", str30.equals("11"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1104534000001L) + "'", long33 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-11200) + "'", int44 == (-11200));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        org.joda.time.Period period4 = period1.plusSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period8 = period4.minusYears(10);
        org.joda.time.Period period10 = period8.plusWeeks((int) (short) -1);
        org.joda.time.Period period12 = period10.minusSeconds((int) 'a');
        org.joda.time.Period period14 = period12.minusDays(8);
        org.joda.time.DurationFieldType[] durationFieldTypeArray15 = period14.getFieldTypes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(durationFieldTypeArray15);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.Period period1 = org.joda.time.Period.days(100);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        boolean boolean3 = period1.isSupported(durationFieldType2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        org.joda.time.Period period4 = period1.plusSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period8 = period4.minusYears(10);
        org.joda.time.Period period10 = period8.plusWeeks((int) (short) -1);
        org.joda.time.Period period12 = period10.minusSeconds((int) 'a');
        org.joda.time.Period period14 = period10.plusYears((int) (byte) -1);
        try {
            org.joda.time.Minutes minutes15 = period14.toStandardMinutes();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Minutes as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.months();
        boolean boolean4 = periodType2.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType5 = periodType2.withMillisRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withMonthsRemoved();
        try {
            org.joda.time.Period period7 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = org.joda.time.Period.minutes((int) (byte) 1);
        int int4 = period3.getMillis();
        org.joda.time.Period period6 = period3.plusSeconds((int) (byte) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePeriod) period3, 100L);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.months();
        boolean boolean12 = periodType10.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType13 = periodType10.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 100, periodType13, (org.joda.time.Chronology) iSOChronology14);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) iSOChronology14);
        org.joda.time.DurationField durationField17 = iSOChronology14.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology14.dayOfWeek();
        org.joda.time.Period period19 = new org.joda.time.Period((long) 52, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DurationField durationField20 = iSOChronology14.hours();
        long long24 = iSOChronology14.add(4147200000000000L, (long) 11, 52);
        org.joda.time.DurationField durationField25 = iSOChronology14.weekyears();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 4147200000000572L + "'", long24 == 4147200000000572L);
        org.junit.Assert.assertNotNull(durationField25);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.centuryOfEra();
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        int int11 = period9.indexOf(durationFieldType10);
        org.joda.time.Days days12 = period9.toStandardDays();
        int[] intArray14 = iSOChronology0.get((org.joda.time.ReadablePeriod) period9, (-1L));
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.months();
        boolean boolean17 = periodType15.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType18 = periodType15.withMillisRemoved();
        org.joda.time.Period period19 = period9.normalizedStandard(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(days12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period19);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField7 = iSOChronology0.seconds();
        org.joda.time.DurationField durationField8 = iSOChronology0.millis();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        long long11 = offsetDateTimeField8.add((long) 1, 0);
        java.util.Locale locale12 = null;
        int int13 = offsetDateTimeField8.getMaximumTextLength(locale12);
        org.joda.time.ReadablePartial readablePartial14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period18 = org.joda.time.Period.minutes((int) (byte) 1);
        int int19 = period18.getMillis();
        org.joda.time.Period period21 = period18.plusSeconds((int) (byte) 100);
        int[] intArray23 = iSOChronology16.get((org.joda.time.ReadablePeriod) period18, 100L);
        try {
            int[] intArray25 = offsetDateTimeField8.add(readablePartial14, (-11200), intArray23, (-161387));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -11200");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period3 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period5 = org.joda.time.Period.minutes((int) (byte) 1);
        int int6 = period5.getMillis();
        org.joda.time.Period period8 = period5.plusSeconds((int) (byte) 100);
        org.joda.time.Period period10 = period8.minusMinutes(10);
        org.joda.time.Period period11 = period3.minus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period3.plusMillis((int) (byte) 1);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period13.toDurationFrom(readableInstant14);
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.dayTime();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration15, periodType16);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.dayOfYear();
        java.lang.Object obj20 = null;
        boolean boolean21 = iSOChronology18.equals(obj20);
        org.joda.time.DurationField durationField22 = iSOChronology18.eras();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology18.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology18.dayOfMonth();
        try {
            org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) 1152000001L, periodType16, (org.joda.time.Chronology) iSOChronology18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long33 = scaledDurationField31.getMillis(0L);
        long long36 = scaledDurationField31.add(73728000000L, 970);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1191168000000L + "'", long36 == 1191168000000L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        int int35 = zeroIsMaxDateTimeField32.getDifference((long) 320, (long) 'a');
        long long38 = zeroIsMaxDateTimeField32.getDifferenceAsLong((long) 11, 306816L);
        org.joda.time.DurationField durationField39 = zeroIsMaxDateTimeField32.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNull(durationField39);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.dayOfYear();
        java.lang.Object obj5 = null;
        boolean boolean6 = iSOChronology3.equals(obj5);
        boolean boolean8 = iSOChronology3.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology3.clockhourOfDay();
        java.lang.Class<?> wildcardClass10 = iSOChronology3.getClass();
        org.joda.time.Period period11 = new org.joda.time.Period(0L, 1560630012090L, periodType2, (org.joda.time.Chronology) iSOChronology3);
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology3);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(chronology12);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.years();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.ReadableInterval readableInterval4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval4);
        org.joda.time.Period period6 = new org.joda.time.Period(126000010L, periodType1, chronology5);
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Period period8 = period6.normalizedStandard(periodType7);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.months();
        boolean boolean3 = periodType1.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType4 = periodType1.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, periodType4, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.hourOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.dayOfWeek();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period3 = period1.withMonths((int) (short) 10);
        org.joda.time.Period period5 = org.joda.time.Period.minutes((int) (byte) 1);
        int int6 = period5.size();
        org.joda.time.Period period7 = period1.minus((org.joda.time.ReadablePeriod) period5);
        org.joda.time.Period period9 = period7.plusSeconds((int) (short) -1);
        org.joda.time.Period period11 = period9.plusHours((-161387));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.yearDayTime();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfYear();
//        java.lang.Object obj6 = null;
//        boolean boolean7 = iSOChronology4.equals(obj6);
//        boolean boolean9 = iSOChronology4.equals((java.lang.Object) 100);
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology4.clockhourOfDay();
//        java.lang.Class<?> wildcardClass11 = iSOChronology4.getClass();
//        org.joda.time.Period period12 = new org.joda.time.Period(0L, 1560630012090L, periodType3, (org.joda.time.Chronology) iSOChronology4);
//        org.joda.time.PeriodType periodType13 = periodType3.withMinutesRemoved();
//        org.joda.time.ReadableInstant readableInstant14 = null;
//        org.joda.time.ReadableInstant readableInstant15 = null;
//        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant14, readableInstant15);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = dateTimeZone17.getName(10L, locale19);
//        long long24 = dateTimeZone17.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance(chronology16, dateTimeZone17);
//        org.joda.time.DateTimeField dateTimeField26 = zonedChronology25.clockhourOfDay();
//        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) 0, periodType3, (org.joda.time.Chronology) zonedChronology25);
//        org.joda.time.Chronology chronology28 = zonedChronology25.withUTC();
//        org.junit.Assert.assertNotNull(periodType3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(periodType13);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Coordinated Universal Time" + "'", str20.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 32L + "'", long24 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(chronology28);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period3 = period1.withMonths((int) (short) 10);
        int int4 = period1.getHours();
        org.joda.time.Period period6 = period1.plusMonths((int) (short) 1);
        int int7 = period1.getDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        boolean boolean5 = iSOChronology0.equals((java.lang.Object) 100);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.yearOfEra();
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            long long10 = iSOChronology0.set(readablePartial8, 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = iSOChronology0.equals(obj2);
//        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
//        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
//        java.lang.String str14 = offsetDateTimeField8.getName();
//        java.util.Locale locale15 = null;
//        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
//        java.lang.Object obj19 = null;
//        boolean boolean20 = iSOChronology17.equals(obj19);
//        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
//        int int30 = offsetDateTimeField25.get((long) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
//        long long34 = zeroIsMaxDateTimeField32.remainder((-1104566400001L));
//        boolean boolean36 = zeroIsMaxDateTimeField32.isLeap((long) 32);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant38, readableInstant39);
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = dateTimeZone41.getName(10L, locale43);
//        long long48 = dateTimeZone41.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology49 = org.joda.time.chrono.ZonedChronology.getInstance(chronology40, dateTimeZone41);
//        org.joda.time.Period period51 = org.joda.time.Period.minutes((int) (byte) 1);
//        org.joda.time.Period period53 = period51.withMonths((int) (short) 10);
//        org.joda.time.Period period55 = org.joda.time.Period.minutes((int) (byte) 1);
//        int int56 = period55.size();
//        org.joda.time.Period period57 = period51.minus((org.joda.time.ReadablePeriod) period55);
//        org.joda.time.Period period59 = period55.minusYears(8);
//        long long62 = zonedChronology49.add((org.joda.time.ReadablePeriod) period55, 10L, (int) (short) 0);
//        org.joda.time.Period period64 = org.joda.time.Period.minutes((int) (short) 0);
//        org.joda.time.Period period66 = period64.plusSeconds(100);
//        int[] intArray68 = zonedChronology49.get((org.joda.time.ReadablePeriod) period66, (long) 10);
//        int int69 = zeroIsMaxDateTimeField32.getMinimumValue(readablePartial37, intArray68);
//        long long72 = zeroIsMaxDateTimeField32.add(230399999L, 12);
//        int int73 = zeroIsMaxDateTimeField32.getMinimumValue();
//        long long75 = zeroIsMaxDateTimeField32.roundHalfFloor(165600000L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599999L + "'", long34 == 3599999L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Coordinated Universal Time" + "'", str44.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 32L + "'", long48 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology49);
//        org.junit.Assert.assertNotNull(period51);
//        org.junit.Assert.assertNotNull(period53);
//        org.junit.Assert.assertNotNull(period55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 8 + "'", int56 == 8);
//        org.junit.Assert.assertNotNull(period57);
//        org.junit.Assert.assertNotNull(period59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 10L + "'", long62 == 10L);
//        org.junit.Assert.assertNotNull(period64);
//        org.junit.Assert.assertNotNull(period66);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 273599999L + "'", long72 == 273599999L);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 165600000L + "'", long75 == 165600000L);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866673600000L) + "'", long1 == (-210866673600000L));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 0.0d, (java.lang.Number) 126000010L, (java.lang.Number) 1560025212090L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekOfWeekyear();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis(2, 0, (-11200), 4, 1, 52, (-161387));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -161387 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((-696729590510400001L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.061559302666667E9d) + "'", double1 == (-8.061559302666667E9d));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        boolean boolean2 = periodType0.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType3 = periodType0.withMillisRemoved();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType7 = periodType6.withYearsRemoved();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType6);
        org.joda.time.DurationFieldType durationFieldType10 = periodType6.getFieldType(0);
        int int11 = periodType0.indexOf(durationFieldType10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException15 = new org.joda.time.IllegalFieldValueException(durationFieldType10, (java.lang.Number) 3599999L, (java.lang.Number) 1, (java.lang.Number) 1.0d);
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(durationFieldType10, (java.lang.Number) 73728000000L, (java.lang.Number) (byte) 10, (java.lang.Number) (-1.0f));
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) '#', 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1120 + "'", int2 == 1120);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        long long36 = scaledDurationField31.getMillis(0L);
        long long38 = scaledDurationField31.getValueAsLong((-3599999L));
        java.lang.String str39 = scaledDurationField31.toString();
        int int42 = scaledDurationField31.getDifference((-184357857600000L), 1560630012727L);
        java.lang.String str43 = scaledDurationField31.toString();
        long long46 = scaledDurationField31.getDifferenceAsLong(126000002L, 11L);
        long long48 = scaledDurationField31.getValueAsLong((-604799992L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[years]" + "'", str39.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-161387) + "'", int42 == (-161387));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DurationField[years]" + "'", str43.equals("DurationField[years]"));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("Coordinated Universal Time", "clockhourOfHalfday");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str4 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "clockhourOfHalfday" + "'", str3.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "clockhourOfHalfday" + "'", str4.equals("clockhourOfHalfday"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (short) 100);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number7 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-1" + "'", str6.equals("-1"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (byte) -1, (java.lang.Number) 1L, (java.lang.Number) (short) 100);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType7 = illegalFieldValueException4.getDurationFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str9 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNull(durationFieldType7);
        org.junit.Assert.assertNull(dateTimeFieldType8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        org.joda.time.DurationField durationField14 = offsetDateTimeField8.getLeapDurationField();
        long long16 = offsetDateTimeField8.roundHalfCeiling((-100L));
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = offsetDateTimeField8.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType17, (java.lang.Number) 45, (java.lang.Number) 100, (java.lang.Number) (short) 1);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType17, 125999965, (-63), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 125999965 for clockhourOfHalfday must be in the range [-63,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType17);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField12 = zonedChronology11.clockhourOfDay();
//        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.weekyearOfCentury();
//        org.joda.time.DurationField durationField14 = zonedChronology11.eras();
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (byte) 1, (java.lang.Number) (byte) -1, (java.lang.Number) (-1104534000001L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test425");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
//        org.joda.time.Period period4 = org.joda.time.Period.minutes((int) (byte) 1);
//        int int5 = period4.getMillis();
//        org.joda.time.Period period7 = period4.plusSeconds((int) (byte) 100);
//        org.joda.time.Period period9 = period7.minusMinutes(10);
//        org.joda.time.Period period11 = period7.minusYears(10);
//        org.joda.time.Period period13 = period11.plusWeeks((int) (short) -1);
//        long long16 = iSOChronology0.add((org.joda.time.ReadablePeriod) period11, 0L, 0);
//        int int17 = period11.getMillis();
//        org.joda.time.Period period19 = period11.plusYears((-1));
//        org.joda.time.Period period21 = org.joda.time.Period.minutes((int) (byte) 1);
//        int int22 = period21.getMillis();
//        org.joda.time.Period period24 = period21.plusSeconds((int) (byte) 100);
//        org.joda.time.Period period25 = period19.minus((org.joda.time.ReadablePeriod) period21);
//        org.joda.time.ReadableInstant readableInstant26 = null;
//        org.joda.time.ReadableInstant readableInstant27 = null;
//        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant26, readableInstant27);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = dateTimeZone29.getName(10L, locale31);
//        long long36 = dateTimeZone29.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology37 = org.joda.time.chrono.ZonedChronology.getInstance(chronology28, dateTimeZone29);
//        org.joda.time.DurationField durationField38 = zonedChronology37.years();
//        org.joda.time.DateTimeField dateTimeField39 = zonedChronology37.monthOfYear();
//        boolean boolean40 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period25, (java.lang.Object) zonedChronology37);
//        try {
//            long long46 = zonedChronology37.getDateTimeMillis((long) (byte) -1, 0, (-161387), (int) '4', (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -161387 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(period4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(period7);
//        org.junit.Assert.assertNotNull(period9);
//        org.junit.Assert.assertNotNull(period11);
//        org.junit.Assert.assertNotNull(period13);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(period19);
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(period24);
//        org.junit.Assert.assertNotNull(period25);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Coordinated Universal Time" + "'", str32.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 32L + "'", long36 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType2);
        org.joda.time.PeriodType periodType5 = periodType2.withMillisRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.Chronology chronology5 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("0", "P10MT1M", 64, (int) ' ');
        long long6 = fixedDateTimeZone4.previousTransition(0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.lang.String str1 = dateTimeZone0.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) 'a', (int) (short) 10);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTimeZone4.getName((long) (short) -1, locale6);
        java.lang.String str9 = dateTimeZone4.getShortName(3600000L);
        long long11 = dateTimeZone0.getMillisKeepLocal(dateTimeZone4, 52L);
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = dateTimeZone4.isLocalDateTimeGap(localDateTime12);
        java.lang.String str15 = dateTimeZone4.getName((long) 32);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UTC" + "'", str1.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+97:10" + "'", str7.equals("+97:10"));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+97:10" + "'", str9.equals("+97:10"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-349799948L) + "'", long11 == (-349799948L));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+97:10" + "'", str15.equals("+97:10"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.DurationField durationField17 = offsetDateTimeField8.getLeapDurationField();
        int int18 = offsetDateTimeField8.getOffset();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNull(durationField17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period3 = period1.withMonths((int) (short) 10);
        org.joda.time.Period period5 = org.joda.time.Period.minutes((int) (byte) 1);
        int int6 = period5.size();
        org.joda.time.Period period7 = period1.minus((org.joda.time.ReadablePeriod) period5);
        org.joda.time.Period period9 = period7.withMonths(4);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.Period period1 = org.joda.time.Period.days(64);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.dayOfYear();
        java.lang.Object obj7 = null;
        boolean boolean8 = iSOChronology5.equals(obj7);
        boolean boolean10 = iSOChronology5.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.clockhourOfDay();
        java.lang.Class<?> wildcardClass12 = iSOChronology5.getClass();
        org.joda.time.Period period13 = new org.joda.time.Period(0L, 1560630012090L, periodType4, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Period period14 = period1.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period15 = period14.negated();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", (int) (byte) -1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("hi!", (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder6.setStandardOffset((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
//        try {
//            long long9 = gregorianChronology3.getDateTimeMillis(0, 32, 12, 64);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.Period period1 = org.joda.time.Period.days(64);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.dayOfYear();
        java.lang.Object obj7 = null;
        boolean boolean8 = iSOChronology5.equals(obj7);
        boolean boolean10 = iSOChronology5.equals((java.lang.Object) 100);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.clockhourOfDay();
        java.lang.Class<?> wildcardClass12 = iSOChronology5.getClass();
        org.joda.time.Period period13 = new org.joda.time.Period(0L, 1560630012090L, periodType4, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Period period14 = period1.withFields((org.joda.time.ReadablePeriod) period13);
        org.joda.time.Period period16 = period14.minusMinutes(7);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        java.lang.String str1 = iSOChronology0.toString();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[UTC]" + "'", str1.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        long long34 = zeroIsMaxDateTimeField32.remainder((-1104566400001L));
        boolean boolean36 = zeroIsMaxDateTimeField32.isLeap((long) 32);
        long long38 = zeroIsMaxDateTimeField32.remainder(0L);
        org.joda.time.ReadablePartial readablePartial39 = null;
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period42 = org.joda.time.Period.minutes((int) (byte) 1);
        int int43 = period42.getMillis();
        org.joda.time.Period period45 = period42.plusSeconds((int) (byte) 100);
        int[] intArray47 = iSOChronology40.get((org.joda.time.ReadablePeriod) period42, 100L);
        int int48 = zeroIsMaxDateTimeField32.getMinimumValue(readablePartial39, intArray47);
        int int51 = zeroIsMaxDateTimeField32.getDifference(11646000002L, 1560025212090L);
        long long53 = zeroIsMaxDateTimeField32.roundHalfFloor((long) 2);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599999L + "'", long34 == 3599999L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-430105) + "'", int51 == (-430105));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000116d + "'", double1 == 2440587.500000116d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.year();
        try {
            long long10 = iSOChronology0.getDateTimeMillis(1, (-63), (int) (byte) -1, 11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -63 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str2 = dateTimeZone0.getShortName((long) (short) 1);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
//        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
//        try {
//            long long9 = gregorianChronology3.getDateTimeMillis((-10), (int) '#', 11, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfMonth();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.dayOfYear();
        java.lang.Object obj4 = null;
        boolean boolean5 = iSOChronology2.equals(obj4);
        org.joda.time.DurationField durationField6 = iSOChronology2.eras();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology2.clockhourOfHalfday();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.dayOfYear();
        java.lang.Object obj11 = null;
        boolean boolean12 = iSOChronology9.equals(obj11);
        org.joda.time.DurationField durationField13 = iSOChronology9.eras();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology9.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology9.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (-1));
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField17.getAsText((long) (short) 0, locale19);
        long long23 = offsetDateTimeField17.add((-1104537600001L), (int) (byte) 1);
        int int25 = offsetDateTimeField17.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField17.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType26, 4);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField30 = new org.joda.time.field.DividedDateTimeField(dateTimeField1, dateTimeFieldType26, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "11" + "'", str20.equals("11"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1104534000001L) + "'", long23 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (-11200), 2440581L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -27334507200");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.dayOfYear();
        java.lang.Object obj37 = null;
        boolean boolean38 = iSOChronology35.equals(obj37);
        org.joda.time.DurationField durationField39 = iSOChronology35.weeks();
        int int40 = scaledDurationField31.compareTo(durationField39);
        int int43 = scaledDurationField31.getValue((long) (byte) 100, 0L);
        int int44 = scaledDurationField31.getScalar();
        boolean boolean45 = scaledDurationField31.isPrecise();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 320 + "'", int44 == 320);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.centuryOfEra();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField4 = gregorianChronology0.years();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(970, 12, 4, (-430105));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -430105 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        long long18 = offsetDateTimeField8.roundFloor((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = iSOChronology19.equals(obj21);
        org.joda.time.DurationField durationField23 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (-1));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField27.getAsText((long) (short) 0, locale29);
        long long33 = offsetDateTimeField27.add((-1104537600001L), (int) (byte) 1);
        int int35 = offsetDateTimeField27.getLeapAmount(60001L);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField27.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField27.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField39 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType38);
        int int40 = zeroIsMaxDateTimeField39.getMinimumValue();
        java.lang.String str42 = zeroIsMaxDateTimeField39.getAsText(1560025212090L);
        int int44 = zeroIsMaxDateTimeField39.get(7200097L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-3600000L) + "'", long18 == (-3600000L));
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "11" + "'", str30.equals("11"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1104534000001L) + "'", long33 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "7" + "'", str42.equals("7"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(2440588L, "11");
        java.lang.Throwable throwable3 = null;
        try {
            illegalInstantException2.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period3 = org.joda.time.Period.minutes((int) (byte) 1);
        int int4 = period3.getMillis();
        org.joda.time.Period period6 = period3.plusSeconds((int) (byte) 100);
        int[] intArray8 = iSOChronology1.get((org.joda.time.ReadablePeriod) period3, 100L);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.months();
        boolean boolean12 = periodType10.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType13 = periodType10.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (byte) 100, periodType13, (org.joda.time.Chronology) iSOChronology14);
        boolean boolean16 = iSOChronology1.equals((java.lang.Object) iSOChronology14);
        org.joda.time.DurationField durationField17 = iSOChronology14.days();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology14.dayOfWeek();
        org.joda.time.Period period19 = new org.joda.time.Period((long) 52, (org.joda.time.Chronology) iSOChronology14);
        org.joda.time.chrono.ISOChronology iSOChronology20 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology20.dayOfYear();
        java.lang.Object obj22 = null;
        boolean boolean23 = iSOChronology20.equals(obj22);
        org.joda.time.DurationField durationField24 = iSOChronology20.weeks();
        java.lang.String str25 = iSOChronology20.toString();
        org.joda.time.Period period27 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period29 = period27.withMonths((int) (short) 10);
        int[] intArray31 = iSOChronology20.get((org.joda.time.ReadablePeriod) period27, (long) 4);
        org.joda.time.DateTimeField dateTimeField32 = iSOChronology20.year();
        boolean boolean33 = iSOChronology14.equals((java.lang.Object) dateTimeField32);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(iSOChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ISOChronology[UTC]" + "'", str25.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.Days days4 = period1.toStandardDays();
        org.joda.time.Period period6 = period1.plusWeeks(0);
        org.joda.time.Period period8 = period1.minusMinutes((int) (byte) 1);
        org.joda.time.Duration duration9 = period1.toStandardDuration();
        org.joda.time.Period period11 = period1.withMonths((-161387));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(days4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.months();
        boolean boolean3 = periodType1.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType4 = periodType1.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (byte) 100, periodType4, (org.joda.time.Chronology) iSOChronology5);
        org.joda.time.format.PeriodFormatter periodFormatter7 = null;
        java.lang.String str8 = period6.toString(periodFormatter7);
        int[] intArray9 = period6.getValues();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "P0M" + "'", str8.equals("P0M"));
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        java.lang.String str5 = iSOChronology0.toString();
        org.joda.time.DurationField durationField6 = iSOChronology0.days();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        org.joda.time.ReadableInstant readableInstant1 = null;
//        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTimeZone3.getName(10L, locale5);
//        long long10 = dateTimeZone3.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance(chronology2, dateTimeZone3);
//        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        long long18 = gregorianChronology13.getDateTimeMillis((int) (byte) 10, 2, 10, 64);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-61848143999936L) + "'", long18 == (-61848143999936L));
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        int int5 = cachedDateTimeZone3.getOffset((long) 2);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 60000 + "'", int5 == 60000);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withDaysRemoved();
        java.lang.String str2 = periodType1.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PeriodType[YearMonthDayTimeNoDays]" + "'", str2.equals("PeriodType[YearMonthDayTimeNoDays]"));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long14 = offsetDateTimeField8.add((-1104537600001L), (int) (byte) 1);
        int int16 = offsetDateTimeField8.getLeapAmount(60001L);
        int int18 = offsetDateTimeField8.get((-3599999L));
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.dayOfYear();
        java.lang.Object obj21 = null;
        boolean boolean22 = iSOChronology19.equals(obj21);
        org.joda.time.DurationField durationField23 = iSOChronology19.eras();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology19.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology19.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (-1));
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField27.getAsText((long) (short) 0, locale29);
        long long33 = offsetDateTimeField27.add((-1104537600001L), (int) (byte) 1);
        int int35 = offsetDateTimeField27.getLeapAmount(60001L);
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = offsetDateTimeField27.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType36);
        org.joda.time.ReadablePartial readablePartial38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.dayOfYear();
        java.lang.Object obj42 = null;
        boolean boolean43 = iSOChronology40.equals(obj42);
        org.joda.time.DurationField durationField44 = iSOChronology40.eras();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology40.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology40.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, (-1));
        java.util.Locale locale50 = null;
        java.lang.String str51 = offsetDateTimeField48.getAsText((long) (short) 0, locale50);
        int int53 = offsetDateTimeField48.getLeapAmount((-604799992L));
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField48.getAsShortText((long) (short) 1, locale55);
        org.joda.time.ReadablePartial readablePartial57 = null;
        org.joda.time.chrono.ISOChronology iSOChronology58 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField59 = iSOChronology58.dayOfYear();
        java.lang.Object obj60 = null;
        boolean boolean61 = iSOChronology58.equals(obj60);
        org.joda.time.DurationField durationField62 = iSOChronology58.eras();
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology58.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField64 = iSOChronology58.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology58.centuryOfEra();
        org.joda.time.Period period67 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType68 = null;
        int int69 = period67.indexOf(durationFieldType68);
        org.joda.time.Days days70 = period67.toStandardDays();
        int[] intArray72 = iSOChronology58.get((org.joda.time.ReadablePeriod) period67, (-1L));
        int int73 = offsetDateTimeField48.getMinimumValue(readablePartial57, intArray72);
        try {
            int[] intArray75 = offsetDateTimeField8.addWrapPartial(readablePartial38, 0, intArray72, 320);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1104534000001L) + "'", long14 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "11" + "'", str30.equals("11"));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1104534000001L) + "'", long33 == (-1104534000001L));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "11" + "'", str51.equals("11"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "11" + "'", str56.equals("11"));
        org.junit.Assert.assertNotNull(iSOChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(durationField62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
        org.junit.Assert.assertNotNull(days70);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (short) -1, 11, 100, 8, 0, (int) (byte) 0, 970, (int) ' ');
        org.joda.time.Period period9 = period8.toPeriod();
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 0);
        org.joda.time.Period period3 = period1.plusSeconds(100);
        java.lang.String str4 = period1.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PT0S" + "'", str4.equals("PT0S"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period3 = period1.withMonths((int) (short) 10);
        org.joda.time.Period period5 = period1.minusWeeks((int) 'a');
        org.joda.time.Period period7 = period5.plusMonths(0);
        org.joda.time.Hours hours8 = period7.toStandardHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(hours8);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField8.getAsText(readablePartial9, (int) (short) 0, locale11);
        long long14 = offsetDateTimeField8.roundHalfCeiling((long) 10);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, (int) (byte) -1);
        long long19 = offsetDateTimeField8.set((long) 970, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 3600970L + "'", long19 == 3600970L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (byte) 0, 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone3 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone2);
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfYear();
        java.lang.Object obj6 = null;
        boolean boolean7 = iSOChronology4.equals(obj6);
        org.joda.time.DurationField durationField8 = iSOChronology4.weeks();
        java.lang.String str9 = iSOChronology4.toString();
        org.joda.time.Period period11 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period13 = period11.withMonths((int) (short) 10);
        int[] intArray15 = iSOChronology4.get((org.joda.time.ReadablePeriod) period11, (long) 4);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology4.year();
        boolean boolean17 = cachedDateTimeZone3.equals((java.lang.Object) dateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone18 = cachedDateTimeZone3.getUncachedZone();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(cachedDateTimeZone3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ISOChronology[UTC]" + "'", str9.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTimeZone18);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.months();
        java.lang.String str2 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[UTC]" + "'", str2.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(10);
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = iSOChronology0.years();
        org.joda.time.DurationField durationField7 = iSOChronology0.halfdays();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.weeks();
        long long5 = iSOChronology0.add((long) (byte) 100, (long) 52, (-32));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1564L) + "'", long5 == (-1564L));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        int int3 = period1.getWeeks();
        org.joda.time.Days days4 = period1.toStandardDays();
        int int5 = period1.getSeconds();
        org.joda.time.Period period7 = period1.withHours((int) (short) 10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(days4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-3599999L), (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3599999L + "'", long2 == 3599999L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.Period period4 = org.joda.time.Period.minutes((int) (byte) 1);
        int int5 = period4.getMillis();
        org.joda.time.Period period7 = period4.plusSeconds((int) (byte) 100);
        org.joda.time.Period period9 = period7.minusMinutes(10);
        org.joda.time.Period period11 = period7.minusYears(10);
        org.joda.time.Period period13 = period11.plusWeeks((int) (short) -1);
        long long16 = iSOChronology0.add((org.joda.time.ReadablePeriod) period11, 0L, 0);
        org.joda.time.DurationField durationField17 = iSOChronology0.halfdays();
        org.joda.time.Period period19 = org.joda.time.Period.years((int) '#');
        long long22 = iSOChronology0.add((org.joda.time.ReadablePeriod) period19, (-1L), (-1));
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology0.dayOfMonth();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology0.minuteOfHour();
        org.joda.time.ReadableInstant readableInstant25 = null;
        org.joda.time.Period period27 = org.joda.time.Period.minutes((int) (byte) 1);
        int int28 = period27.getMillis();
        org.joda.time.Period period30 = period27.plusSeconds((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant31 = null;
        org.joda.time.Duration duration32 = period30.toDurationFrom(readableInstant31);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration32, readableInstant33);
        org.joda.time.Period period35 = new org.joda.time.Period(readableInstant25, (org.joda.time.ReadableDuration) duration32);
        long long38 = iSOChronology0.add((org.joda.time.ReadablePeriod) period35, (-3599999L), 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1104537600001L) + "'", long22 == (-1104537600001L));
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(duration32);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-1999999L) + "'", long38 == (-1999999L));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        long long34 = zeroIsMaxDateTimeField32.remainder((-1104566400001L));
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = zeroIsMaxDateTimeField32.getMinimumValue(readablePartial35);
        long long38 = zeroIsMaxDateTimeField32.roundHalfCeiling((long) (byte) 10);
        java.util.Locale locale40 = null;
        java.lang.String str41 = zeroIsMaxDateTimeField32.getAsText(0L, locale40);
        long long43 = zeroIsMaxDateTimeField32.roundHalfCeiling(2L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599999L + "'", long34 == 3599999L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "11" + "'", str41.equals("11"));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        boolean boolean2 = periodType0.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType3 = periodType0.withMillisRemoved();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = periodType3.isSupported(durationFieldType4);
        org.joda.time.PeriodType periodType6 = periodType3.withMinutesRemoved();
        org.joda.time.PeriodType periodType7 = periodType6.withSecondsRemoved();
        int int8 = periodType6.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearDay();
        java.lang.Class<?> wildcardClass3 = periodType2.getClass();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology4.dayOfYear();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology4.dayOfYear();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        int int9 = period8.getMillis();
        org.joda.time.Period period11 = period8.plusSeconds((int) (byte) 100);
        org.joda.time.Period period13 = period11.minusMinutes(10);
        org.joda.time.Period period15 = period11.minusYears(10);
        org.joda.time.Period period17 = period15.plusWeeks((int) (short) -1);
        long long20 = iSOChronology4.add((org.joda.time.ReadablePeriod) period15, 0L, 0);
        org.joda.time.DurationField durationField21 = iSOChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology4.weekyearOfCentury();
        org.joda.time.Period period23 = new org.joda.time.Period(60001L, (long) (short) 100, periodType2, (org.joda.time.Chronology) iSOChronology4);
        int int24 = period23.getSeconds();
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period28 = org.joda.time.Period.minutes((int) (byte) 1);
        int int29 = period28.getMillis();
        org.joda.time.Period period31 = period28.plusSeconds((int) (byte) 100);
        int[] intArray33 = iSOChronology26.get((org.joda.time.ReadablePeriod) period28, 100L);
        org.joda.time.PeriodType periodType35 = org.joda.time.PeriodType.months();
        boolean boolean37 = periodType35.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType38 = periodType35.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period40 = new org.joda.time.Period((long) (byte) 100, periodType38, (org.joda.time.Chronology) iSOChronology39);
        boolean boolean41 = iSOChronology26.equals((java.lang.Object) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.days();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology39.dayOfWeek();
        org.joda.time.Period period44 = new org.joda.time.Period((long) 52, (org.joda.time.Chronology) iSOChronology39);
        org.joda.time.Period period46 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.Period period48 = period46.withMonths((int) (short) 10);
        int int49 = period46.getHours();
        org.joda.time.PeriodType periodType50 = org.joda.time.PeriodType.months();
        boolean boolean52 = periodType50.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType53 = periodType50.withMillisRemoved();
        org.joda.time.PeriodType periodType56 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType57 = periodType56.withYearsRemoved();
        org.joda.time.Period period58 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType56);
        org.joda.time.DurationFieldType durationFieldType60 = periodType56.getFieldType(0);
        int int61 = periodType50.indexOf(durationFieldType60);
        org.joda.time.IllegalFieldValueException illegalFieldValueException65 = new org.joda.time.IllegalFieldValueException(durationFieldType60, (java.lang.Number) 0.0d, (java.lang.Number) (byte) 0, (java.lang.Number) (byte) 0);
        int int66 = period46.get(durationFieldType60);
        org.joda.time.IllegalFieldValueException illegalFieldValueException70 = new org.joda.time.IllegalFieldValueException(durationFieldType60, (java.lang.Number) 8, (java.lang.Number) (-1L), (java.lang.Number) 2440587L);
        int int71 = period44.get(durationFieldType60);
        try {
            org.joda.time.Period period72 = period23.minus((org.joda.time.ReadablePeriod) period44);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(periodType38);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertNotNull(period48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(periodType50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(durationFieldType60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        int int35 = scaledDurationField31.getScalar();
        org.joda.time.DurationFieldType durationFieldType36 = scaledDurationField31.getType();
        long long39 = scaledDurationField31.getMillis(0, (long) 2);
        org.joda.time.DurationFieldType durationFieldType40 = scaledDurationField31.getType();
        org.joda.time.DurationFieldType durationFieldType41 = scaledDurationField31.getType();
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.dayOfYear();
        java.lang.Object obj44 = null;
        boolean boolean45 = iSOChronology42.equals(obj44);
        org.joda.time.DurationField durationField46 = iSOChronology42.weeks();
        org.joda.time.DateTimeField dateTimeField47 = iSOChronology42.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology42.weekyear();
        boolean boolean49 = scaledDurationField31.equals((java.lang.Object) dateTimeField48);
        long long52 = scaledDurationField31.subtract((long) 12, (long) (-1));
        long long54 = scaledDurationField31.getMillis(0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 320 + "'", int35 == 320);
        org.junit.Assert.assertNotNull(durationFieldType36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(durationField46);
        org.junit.Assert.assertNotNull(dateTimeField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1152000012L + "'", long52 == 1152000012L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 55, number2, (java.lang.Number) (-1564L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        org.joda.time.Period period4 = period1.plusSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period8 = period4.minusYears(10);
        org.joda.time.Period period10 = period8.plusWeeks((int) (short) -1);
        org.joda.time.Period period12 = period10.plusMonths(1);
        org.joda.time.Period period14 = period10.minusYears(1);
        int int15 = period10.getSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("(\"org.joda.time.JodaTimePermission\" \"org.joda.time.IllegalFieldValueException: Value -1 for  must be in the range [1,100]\")");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"(\"org.joda.time.JodaTimePermissi...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        org.joda.time.DurationField durationField14 = offsetDateTimeField8.getLeapDurationField();
        boolean boolean15 = offsetDateTimeField8.isLenient();
        java.lang.String str16 = offsetDateTimeField8.getName();
        long long18 = offsetDateTimeField8.roundHalfCeiling((long) (-161387));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(durationField14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "clockhourOfHalfday" + "'", str16.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("ISOChronology[America/Los_Angeles]", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableInstant1);
        org.joda.time.Period period4 = period2.plusDays((int) (short) 0);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
        java.lang.String str14 = offsetDateTimeField8.getName();
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
        java.lang.Object obj19 = null;
        boolean boolean20 = iSOChronology17.equals(obj19);
        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
        int int30 = offsetDateTimeField25.get((long) 100);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
        long long34 = zeroIsMaxDateTimeField32.remainder((-1104566400001L));
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = zeroIsMaxDateTimeField32.getMinimumValue(readablePartial35);
        long long38 = zeroIsMaxDateTimeField32.roundHalfCeiling((long) (byte) 10);
        org.joda.time.DurationField durationField39 = zeroIsMaxDateTimeField32.getLeapDurationField();
        java.util.Locale locale40 = null;
        int int41 = zeroIsMaxDateTimeField32.getMaximumTextLength(locale40);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599999L + "'", long34 == 3599999L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertNull(durationField39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.Chronology chronology2 = null;
        try {
            org.joda.time.Period period3 = new org.joda.time.Period((java.lang.Object) dateTimeZone1, chronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.tz.FixedDateTimeZone");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "hi!", "hi!");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "", "ZonedChronology[ISOChronology[UTC], UTC]");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getShortName(locale9, "P10MT1M", "Coordinated Universal Time");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(11);
        int int2 = period1.getSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField8.getAsText(readablePartial9, (int) (short) 0, locale11);
        long long15 = offsetDateTimeField8.add(0L, 8);
        long long17 = offsetDateTimeField8.roundHalfFloor((long) 45);
        try {
            long long20 = offsetDateTimeField8.set(165L, "+00:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+00:00\" for clockhourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 45);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000005206d + "'", double1 == 2440587.5000005206d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMillis();
        org.joda.time.Period period4 = period1.plusSeconds((int) (byte) 100);
        org.joda.time.Period period6 = period4.minusMinutes(10);
        org.joda.time.Period period8 = period4.minusYears(10);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType10 = periodType9.withYearsRemoved();
        org.joda.time.Period period11 = period8.withPeriodType(periodType9);
        org.joda.time.Period period13 = period11.plusDays(125999965);
        org.joda.time.Period period15 = period13.plusSeconds((int) ' ');
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (short) 0);
        org.joda.time.Period period3 = period1.plusSeconds(100);
        org.joda.time.Period period5 = period3.minusSeconds((int) '#');
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.standard();
        org.joda.time.PeriodType periodType7 = periodType6.withHoursRemoved();
        org.joda.time.Period period8 = period3.normalizedStandard(periodType6);
        org.joda.time.Period period10 = period3.withYears((int) 'a');
        org.joda.time.MutablePeriod mutablePeriod11 = period10.toMutablePeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(mutablePeriod11);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.dayOfYear();
        java.lang.Object obj3 = null;
        boolean boolean4 = iSOChronology1.equals(obj3);
        org.joda.time.DurationField durationField5 = iSOChronology1.hours();
        long long8 = durationField5.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period10 = org.joda.time.Period.minutes((int) (byte) 1);
        int int11 = period10.getMillis();
        org.joda.time.Period period13 = period10.plusSeconds((int) (byte) 100);
        org.joda.time.Period period15 = period13.minusMinutes(10);
        org.joda.time.Period period17 = period13.minusYears(10);
        int int18 = period13.size();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType20 = periodType19.withMonthsRemoved();
        org.joda.time.PeriodType periodType21 = periodType20.withHoursRemoved();
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType25 = periodType24.withYearsRemoved();
        org.joda.time.Period period26 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType24);
        org.joda.time.DurationFieldType durationFieldType28 = periodType24.getFieldType(0);
        boolean boolean29 = periodType21.isSupported(durationFieldType28);
        boolean boolean30 = period13.isSupported(durationFieldType28);
        org.joda.time.field.ScaledDurationField scaledDurationField32 = new org.joda.time.field.ScaledDurationField(durationField5, durationFieldType28, 320);
        long long35 = scaledDurationField32.getDifferenceAsLong((long) 52, (long) 11);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.dayOfYear();
        java.lang.Object obj38 = null;
        boolean boolean39 = iSOChronology36.equals(obj38);
        org.joda.time.DurationField durationField40 = iSOChronology36.weeks();
        int int41 = scaledDurationField32.compareTo(durationField40);
        int int44 = scaledDurationField32.getValue((long) (byte) 100, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.dayOfYear();
        java.lang.Object obj47 = null;
        boolean boolean48 = iSOChronology45.equals(obj47);
        org.joda.time.DurationField durationField49 = iSOChronology45.hours();
        long long52 = durationField49.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period54 = org.joda.time.Period.minutes((int) (byte) 1);
        int int55 = period54.getMillis();
        org.joda.time.Period period57 = period54.plusSeconds((int) (byte) 100);
        org.joda.time.Period period59 = period57.minusMinutes(10);
        org.joda.time.Period period61 = period57.minusYears(10);
        int int62 = period57.size();
        org.joda.time.PeriodType periodType63 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType64 = periodType63.withMonthsRemoved();
        org.joda.time.PeriodType periodType65 = periodType64.withHoursRemoved();
        org.joda.time.PeriodType periodType68 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType69 = periodType68.withYearsRemoved();
        org.joda.time.Period period70 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType68);
        org.joda.time.DurationFieldType durationFieldType72 = periodType68.getFieldType(0);
        boolean boolean73 = periodType65.isSupported(durationFieldType72);
        boolean boolean74 = period57.isSupported(durationFieldType72);
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField49, durationFieldType72, 320);
        long long79 = scaledDurationField76.getDifferenceAsLong((long) 52, (long) 11);
        int int80 = scaledDurationField76.getScalar();
        org.joda.time.DurationFieldType durationFieldType81 = scaledDurationField76.getType();
        long long84 = scaledDurationField76.getMillis(0, (long) 2);
        long long85 = scaledDurationField76.getUnitMillis();
        long long88 = scaledDurationField76.add((long) (short) 1, (long) (short) 1);
        long long91 = scaledDurationField76.add(1152000000L, 0L);
        int int92 = scaledDurationField32.compareTo((org.joda.time.DurationField) scaledDurationField76);
        long long95 = scaledDurationField76.add(1152000000L, (-100L));
        int int98 = scaledDurationField76.getValue((-210866673600000L), (long) 8);
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField99 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, (org.joda.time.DurationField) scaledDurationField76);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-3599999L) + "'", long8 == (-3599999L));
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-3599999L) + "'", long52 == (-3599999L));
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(period59);
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 8 + "'", int62 == 8);
        org.junit.Assert.assertNotNull(periodType63);
        org.junit.Assert.assertNotNull(periodType64);
        org.junit.Assert.assertNotNull(periodType65);
        org.junit.Assert.assertNotNull(periodType68);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(durationFieldType72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 0L + "'", long79 == 0L);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 320 + "'", int80 == 320);
        org.junit.Assert.assertNotNull(durationFieldType81);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 0L + "'", long84 == 0L);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 1152000000L + "'", long85 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 1152000001L + "'", long88 == 1152000001L);
        org.junit.Assert.assertTrue("'" + long91 + "' != '" + 1152000000L + "'", long91 == 1152000000L);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + (-114048000000L) + "'", long95 == (-114048000000L));
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + (-183043) + "'", int98 == (-183043));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
//        java.lang.Object obj2 = null;
//        boolean boolean3 = iSOChronology0.equals(obj2);
//        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
//        long long13 = offsetDateTimeField8.roundCeiling((long) (byte) 10);
//        java.lang.String str14 = offsetDateTimeField8.getName();
//        java.util.Locale locale15 = null;
//        int int16 = offsetDateTimeField8.getMaximumTextLength(locale15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.dayOfYear();
//        java.lang.Object obj19 = null;
//        boolean boolean20 = iSOChronology17.equals(obj19);
//        org.joda.time.DurationField durationField21 = iSOChronology17.eras();
//        org.joda.time.DateTimeField dateTimeField22 = iSOChronology17.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField23 = iSOChronology17.clockhourOfHalfday();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (-1));
//        java.util.Locale locale27 = null;
//        java.lang.String str28 = offsetDateTimeField25.getAsText((long) (short) 0, locale27);
//        int int30 = offsetDateTimeField25.get((long) 100);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField25.getType();
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField8, dateTimeFieldType31);
//        long long34 = zeroIsMaxDateTimeField32.remainder((-1104566400001L));
//        boolean boolean36 = zeroIsMaxDateTimeField32.isLeap((long) 32);
//        org.joda.time.ReadablePartial readablePartial37 = null;
//        org.joda.time.ReadableInstant readableInstant38 = null;
//        org.joda.time.ReadableInstant readableInstant39 = null;
//        org.joda.time.Chronology chronology40 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant38, readableInstant39);
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.UTC;
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = dateTimeZone41.getName(10L, locale43);
//        long long48 = dateTimeZone41.convertLocalToUTC((long) ' ', true, (long) (-32));
//        org.joda.time.chrono.ZonedChronology zonedChronology49 = org.joda.time.chrono.ZonedChronology.getInstance(chronology40, dateTimeZone41);
//        org.joda.time.Period period51 = org.joda.time.Period.minutes((int) (byte) 1);
//        org.joda.time.Period period53 = period51.withMonths((int) (short) 10);
//        org.joda.time.Period period55 = org.joda.time.Period.minutes((int) (byte) 1);
//        int int56 = period55.size();
//        org.joda.time.Period period57 = period51.minus((org.joda.time.ReadablePeriod) period55);
//        org.joda.time.Period period59 = period55.minusYears(8);
//        long long62 = zonedChronology49.add((org.joda.time.ReadablePeriod) period55, 10L, (int) (short) 0);
//        org.joda.time.Period period64 = org.joda.time.Period.minutes((int) (short) 0);
//        org.joda.time.Period period66 = period64.plusSeconds(100);
//        int[] intArray68 = zonedChronology49.get((org.joda.time.ReadablePeriod) period66, (long) 10);
//        int int69 = zeroIsMaxDateTimeField32.getMinimumValue(readablePartial37, intArray68);
//        long long72 = zeroIsMaxDateTimeField32.add(230399999L, 12);
//        org.joda.time.DurationField durationField73 = zeroIsMaxDateTimeField32.getLeapDurationField();
//        java.util.Locale locale75 = null;
//        java.lang.String str76 = zeroIsMaxDateTimeField32.getAsShortText((long) 0, locale75);
//        int int78 = zeroIsMaxDateTimeField32.getMinimumValue(10L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3600000L + "'", long13 == 3600000L);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "clockhourOfHalfday" + "'", str14.equals("clockhourOfHalfday"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "11" + "'", str28.equals("11"));
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 11 + "'", int30 == 11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 3599999L + "'", long34 == 3599999L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Coordinated Universal Time" + "'", str44.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 32L + "'", long48 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology49);
//        org.junit.Assert.assertNotNull(period51);
//        org.junit.Assert.assertNotNull(period53);
//        org.junit.Assert.assertNotNull(period55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 8 + "'", int56 == 8);
//        org.junit.Assert.assertNotNull(period57);
//        org.junit.Assert.assertNotNull(period59);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 10L + "'", long62 == 10L);
//        org.junit.Assert.assertNotNull(period64);
//        org.junit.Assert.assertNotNull(period66);
//        org.junit.Assert.assertNotNull(intArray68);
//        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
//        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 273599999L + "'", long72 == 273599999L);
//        org.junit.Assert.assertNull(durationField73);
//        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "11" + "'", str76.equals("11"));
//        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("P10MT1M", "PeriodType[YearDayTime]", (-1), (int) (short) -1);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 'a');
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType8 = periodType7.withMinutesRemoved();
        boolean boolean9 = fixedDateTimeZone4.equals((java.lang.Object) periodType7);
        java.util.TimeZone timeZone10 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        java.util.TimeZone timeZone1 = dateTimeZone0.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(timeZone1);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField8.getAsText(52, locale18);
        java.lang.String str21 = offsetDateTimeField8.getAsShortText((-349800000L));
        long long23 = offsetDateTimeField8.roundCeiling((long) 8);
        int int25 = offsetDateTimeField8.getLeapAmount(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "52" + "'", str19.equals("52"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "9" + "'", str21.equals("9"));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 3600000L + "'", long23 == 3600000L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.joda.time.Days days4 = period1.toStandardDays();
        org.joda.time.Period period6 = period1.plusWeeks(0);
        org.joda.time.Period period8 = period1.minusMinutes((int) (byte) 1);
        org.joda.time.Duration duration9 = period1.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forID("UTC");
        org.joda.time.DateTimeZone.setDefault(dateTimeZone13);
        boolean boolean15 = periodType11.equals((java.lang.Object) dateTimeZone13);
        org.joda.time.Period period16 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant10, periodType11);
        try {
            org.joda.time.Period period18 = period16.withMinutes(1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(days4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.hours();
        long long7 = durationField4.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period9 = org.joda.time.Period.minutes((int) (byte) 1);
        int int10 = period9.getMillis();
        org.joda.time.Period period12 = period9.plusSeconds((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusMinutes(10);
        org.joda.time.Period period16 = period12.minusYears(10);
        int int17 = period12.size();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType19 = periodType18.withMonthsRemoved();
        org.joda.time.PeriodType periodType20 = periodType19.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType24 = periodType23.withYearsRemoved();
        org.joda.time.Period period25 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType23);
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType(0);
        boolean boolean28 = periodType20.isSupported(durationFieldType27);
        boolean boolean29 = period12.isSupported(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField31 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, 320);
        long long34 = scaledDurationField31.getDifferenceAsLong((long) 52, (long) 11);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.dayOfYear();
        java.lang.Object obj37 = null;
        boolean boolean38 = iSOChronology35.equals(obj37);
        org.joda.time.DurationField durationField39 = iSOChronology35.weeks();
        int int40 = scaledDurationField31.compareTo(durationField39);
        int int43 = scaledDurationField31.getValue((long) (byte) 100, 0L);
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField45 = iSOChronology44.dayOfYear();
        java.lang.Object obj46 = null;
        boolean boolean47 = iSOChronology44.equals(obj46);
        org.joda.time.DurationField durationField48 = iSOChronology44.hours();
        long long51 = durationField48.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period53 = org.joda.time.Period.minutes((int) (byte) 1);
        int int54 = period53.getMillis();
        org.joda.time.Period period56 = period53.plusSeconds((int) (byte) 100);
        org.joda.time.Period period58 = period56.minusMinutes(10);
        org.joda.time.Period period60 = period56.minusYears(10);
        int int61 = period56.size();
        org.joda.time.PeriodType periodType62 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType63 = periodType62.withMonthsRemoved();
        org.joda.time.PeriodType periodType64 = periodType63.withHoursRemoved();
        org.joda.time.PeriodType periodType67 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType68 = periodType67.withYearsRemoved();
        org.joda.time.Period period69 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType67);
        org.joda.time.DurationFieldType durationFieldType71 = periodType67.getFieldType(0);
        boolean boolean72 = periodType64.isSupported(durationFieldType71);
        boolean boolean73 = period56.isSupported(durationFieldType71);
        org.joda.time.field.ScaledDurationField scaledDurationField75 = new org.joda.time.field.ScaledDurationField(durationField48, durationFieldType71, 320);
        long long78 = scaledDurationField75.getDifferenceAsLong((long) 52, (long) 11);
        int int79 = scaledDurationField75.getScalar();
        org.joda.time.DurationFieldType durationFieldType80 = scaledDurationField75.getType();
        long long83 = scaledDurationField75.getMillis(0, (long) 2);
        long long84 = scaledDurationField75.getUnitMillis();
        long long87 = scaledDurationField75.add((long) (short) 1, (long) (short) 1);
        long long90 = scaledDurationField75.add(1152000000L, 0L);
        int int91 = scaledDurationField31.compareTo((org.joda.time.DurationField) scaledDurationField75);
        try {
            long long93 = scaledDurationField31.getMillis(1191168000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 381173760000000 * 3600000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3599999L) + "'", long7 == (-3599999L));
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 8 + "'", int17 == 8);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(durationField39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-3599999L) + "'", long51 == (-3599999L));
        org.junit.Assert.assertNotNull(period53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(period56);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 8 + "'", int61 == 8);
        org.junit.Assert.assertNotNull(periodType62);
        org.junit.Assert.assertNotNull(periodType63);
        org.junit.Assert.assertNotNull(periodType64);
        org.junit.Assert.assertNotNull(periodType67);
        org.junit.Assert.assertNotNull(periodType68);
        org.junit.Assert.assertNotNull(durationFieldType71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertTrue("'" + long78 + "' != '" + 0L + "'", long78 == 0L);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 320 + "'", int79 == 320);
        org.junit.Assert.assertNotNull(durationFieldType80);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 0L + "'", long83 == 0L);
        org.junit.Assert.assertTrue("'" + long84 + "' != '" + 1152000000L + "'", long84 == 1152000000L);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1152000001L + "'", long87 == 1152000001L);
        org.junit.Assert.assertTrue("'" + long90 + "' != '" + 1152000000L + "'", long90 == 1152000000L);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsShortText((-1), locale10);
        long long13 = offsetDateTimeField8.roundHalfFloor((-1104534000001L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1104534000000L) + "'", long13 == (-1104534000000L));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440588L + "'", long1 == 2440588L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        java.lang.Object obj2 = null;
        boolean boolean3 = iSOChronology0.equals(obj2);
        org.joda.time.DurationField durationField4 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (-1));
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsText((long) (short) 0, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount((-604799992L));
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField8.getAsShortText((long) (short) 1, locale15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField8.getAsText(52, locale18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField8.getType();
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.dayOfYear();
        java.lang.Object obj23 = null;
        boolean boolean24 = iSOChronology21.equals(obj23);
        org.joda.time.DurationField durationField25 = iSOChronology21.hours();
        long long28 = durationField25.subtract((long) (byte) 1, 1L);
        org.joda.time.Period period30 = org.joda.time.Period.minutes((int) (byte) 1);
        int int31 = period30.getMillis();
        org.joda.time.Period period33 = period30.plusSeconds((int) (byte) 100);
        org.joda.time.Period period35 = period33.minusMinutes(10);
        org.joda.time.Period period37 = period33.minusYears(10);
        int int38 = period33.size();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.yearDay();
        org.joda.time.PeriodType periodType40 = periodType39.withMonthsRemoved();
        org.joda.time.PeriodType periodType41 = periodType40.withHoursRemoved();
        org.joda.time.PeriodType periodType44 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.PeriodType periodType45 = periodType44.withYearsRemoved();
        org.joda.time.Period period46 = new org.joda.time.Period((long) 1, (long) (short) 10, periodType44);
        org.joda.time.DurationFieldType durationFieldType48 = periodType44.getFieldType(0);
        boolean boolean49 = periodType41.isSupported(durationFieldType48);
        boolean boolean50 = period33.isSupported(durationFieldType48);
        org.joda.time.field.ScaledDurationField scaledDurationField52 = new org.joda.time.field.ScaledDurationField(durationField25, durationFieldType48, 320);
        long long55 = scaledDurationField52.getDifferenceAsLong((long) 52, (long) 11);
        int int56 = scaledDurationField52.getScalar();
        org.joda.time.DurationFieldType durationFieldType57 = scaledDurationField52.getType();
        long long60 = scaledDurationField52.getMillis(0, (long) 2);
        long long61 = scaledDurationField52.getUnitMillis();
        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period64 = org.joda.time.Period.minutes((int) (byte) 1);
        int int65 = period64.getMillis();
        org.joda.time.Period period67 = period64.plusSeconds((int) (byte) 100);
        int[] intArray69 = iSOChronology62.get((org.joda.time.ReadablePeriod) period64, 100L);
        org.joda.time.PeriodType periodType71 = org.joda.time.PeriodType.months();
        boolean boolean73 = periodType71.equals((java.lang.Object) (byte) 100);
        org.joda.time.PeriodType periodType74 = periodType71.withMillisRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology75 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Period period76 = new org.joda.time.Period((long) (byte) 100, periodType74, (org.joda.time.Chronology) iSOChronology75);
        boolean boolean77 = iSOChronology62.equals((java.lang.Object) iSOChronology75);
        org.joda.time.DurationField durationField78 = iSOChronology62.hours();
        org.joda.time.DateTimeField dateTimeField79 = iSOChronology62.weekyear();
        org.joda.time.DateTimeField dateTimeField80 = iSOChronology62.weekyearOfCentury();
        org.joda.time.DurationField durationField81 = iSOChronology62.weeks();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField82 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType20, (org.joda.time.DurationField) scaledDurationField52, durationField81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The effective range must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "11" + "'", str11.equals("11"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "52" + "'", str19.equals("52"));
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-3599999L) + "'", long28 == (-3599999L));
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 8 + "'", int38 == 8);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(periodType44);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(durationFieldType48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 320 + "'", int56 == 320);
        org.junit.Assert.assertNotNull(durationFieldType57);
        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 0L + "'", long60 == 0L);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1152000000L + "'", long61 == 1152000000L);
        org.junit.Assert.assertNotNull(iSOChronology62);
        org.junit.Assert.assertNotNull(period64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(period67);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(periodType71);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(periodType74);
        org.junit.Assert.assertNotNull(iSOChronology75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertNotNull(durationField81);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("", true);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("PeriodType[YearMonthDayTimeNoDays]", false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }
}

