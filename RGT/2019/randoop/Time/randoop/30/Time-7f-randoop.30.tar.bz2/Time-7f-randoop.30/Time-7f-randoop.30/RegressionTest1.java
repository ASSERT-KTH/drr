import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((int) (short) 0, locale10);
        java.lang.String str13 = skipUndoDateTimeField8.getAsShortText((long) (byte) 10);
        boolean boolean15 = skipUndoDateTimeField8.isLeap((long) 3);
        java.lang.String str17 = skipUndoDateTimeField8.getAsText(1L);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        long long23 = dateTimeZone19.adjustOffset((long) (byte) -1, true);
        org.joda.time.MutableDateTime mutableDateTime24 = org.joda.time.MutableDateTime.now(dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27);
        java.util.Locale locale29 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket32 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology28, locale29, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.plus(readablePeriod35);
        org.joda.time.LocalDateTime localDateTime37 = dateTime36.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime40 = dateTime36.withDurationAdded(readableDuration38, (int) 'a');
        org.joda.time.DateTime dateTime42 = dateTime40.minusMonths((-10));
        boolean boolean43 = dateTimeParserBucket32.restoreState((java.lang.Object) dateTime40);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46);
        java.util.Locale locale48 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket51 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology47, locale48, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone53 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology54 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone53);
        org.joda.time.chrono.ZonedChronology zonedChronology55 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology47, dateTimeZone53);
        org.joda.time.chrono.ISOChronology iSOChronology56 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone53);
        org.joda.time.DateTimeField dateTimeField57 = iSOChronology56.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime(dateTimeZone58);
        org.joda.time.ReadablePeriod readablePeriod60 = null;
        org.joda.time.DateTime dateTime61 = dateTime59.plus(readablePeriod60);
        org.joda.time.LocalDateTime localDateTime62 = dateTime61.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration63 = null;
        org.joda.time.DateTime dateTime65 = dateTime61.withDurationAdded(readableDuration63, (int) 'a');
        org.joda.time.DateTime.Property property66 = dateTime61.centuryOfEra();
        org.joda.time.DateTime.Property property67 = dateTime61.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = property67.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField69 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField57, dateTimeFieldType68);
        java.util.Locale locale71 = null;
        dateTimeParserBucket32.saveField(dateTimeFieldType68, "32", locale71);
        org.joda.time.MutableDateTime.Property property73 = mutableDateTime24.property(dateTimeFieldType68);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField75 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField8, dateTimeFieldType68, (-98));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "4" + "'", str13.equals("4"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4" + "'", str17.equals("4"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-1L) + "'", long23 == (-1L));
        org.junit.Assert.assertNotNull(mutableDateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(gJChronology28);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDateTime37);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(gJChronology47);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(gJChronology54);
        org.junit.Assert.assertNotNull(zonedChronology55);
        org.junit.Assert.assertNotNull(iSOChronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(localDateTime62);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(property67);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
        org.junit.Assert.assertNotNull(property73);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        mutableDateTime0.setSecondOfMinute(12);
        org.joda.time.DateTime dateTime4 = mutableDateTime0.toDateTime();
        mutableDateTime0.addDays(24);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        java.lang.String str3 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology0.weekyears();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField6 = new org.joda.time.field.ScaledDurationField(durationField3, durationFieldType4, 292279588);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("2019-W24-3T18:13:33.971-07:00", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019-W24-3T18:13:33.971-07:00\" is malformed at \"W24-3T18:13:33.971-07:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder6.clear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(readableDuration13, (int) 'a');
        org.joda.time.DateTime.Property property16 = dateTime11.centuryOfEra();
        org.joda.time.DateTime.Property property17 = dateTime11.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType18, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType18, (int) (short) 0, 100);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField27 = buddhistChronology26.millis();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology26.hourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = dateTimeFormatter25.withChronology((org.joda.time.Chronology) buddhistChronology26);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter30 = dateTimeFormatter25.withOffsetParsed();
        org.joda.time.format.DateTimePrinter dateTimePrinter31 = dateTimeFormatter25.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime(dateTimeZone34);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.DateTime dateTime37 = dateTime35.plus(readablePeriod36);
        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.DateTime dateTime41 = dateTime37.withDurationAdded(readableDuration39, (int) 'a');
        org.joda.time.DateTime.Property property42 = dateTime37.centuryOfEra();
        org.joda.time.DateTime.Property property43 = dateTime37.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = property43.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder32.appendSignedDecimal(dateTimeFieldType44, 411, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology51 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone50);
        java.util.Locale locale52 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket55 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology51, locale52, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone57);
        org.joda.time.chrono.ZonedChronology zonedChronology59 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology51, dateTimeZone57);
        org.joda.time.chrono.ISOChronology iSOChronology60 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone57);
        org.joda.time.DateTimeField dateTimeField61 = iSOChronology60.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone62 = null;
        org.joda.time.DateTime dateTime63 = new org.joda.time.DateTime(dateTimeZone62);
        org.joda.time.ReadablePeriod readablePeriod64 = null;
        org.joda.time.DateTime dateTime65 = dateTime63.plus(readablePeriod64);
        org.joda.time.LocalDateTime localDateTime66 = dateTime65.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration67 = null;
        org.joda.time.DateTime dateTime69 = dateTime65.withDurationAdded(readableDuration67, (int) 'a');
        org.joda.time.DateTime.Property property70 = dateTime65.centuryOfEra();
        org.joda.time.DateTime.Property property71 = dateTime65.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = property71.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField73 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField61, dateTimeFieldType72);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder76 = dateTimeFormatterBuilder32.appendSignedDecimal(dateTimeFieldType72, 1, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = dateTimeFormatterBuilder32.appendDayOfMonth(5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter79 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.Chronology chronology80 = dateTimeFormatter79.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter82 = dateTimeFormatter79.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder83 = dateTimeFormatterBuilder32.append(dateTimeFormatter79);
        org.joda.time.format.DateTimeParser dateTimeParser84 = dateTimeFormatterBuilder83.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder85 = dateTimeFormatterBuilder24.append(dateTimePrinter31, dateTimeParser84);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFormatter29);
        org.junit.Assert.assertNotNull(dateTimeFormatter30);
        org.junit.Assert.assertNotNull(dateTimePrinter31);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(localDateTime38);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(gJChronology51);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(gJChronology58);
        org.junit.Assert.assertNotNull(zonedChronology59);
        org.junit.Assert.assertNotNull(iSOChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(localDateTime66);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(property71);
        org.junit.Assert.assertNotNull(dateTimeFieldType72);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder76);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder78);
        org.junit.Assert.assertNotNull(dateTimeFormatter79);
        org.junit.Assert.assertNull(chronology80);
        org.junit.Assert.assertNotNull(dateTimeFormatter82);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder83);
        org.junit.Assert.assertNotNull(dateTimeParser84);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder85);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((-10L), (org.joda.time.Chronology) julianChronology1, locale2);
        int int4 = dateTimeParserBucket3.getOffset();
        dateTimeParserBucket3.setOffset((java.lang.Integer) 2019);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime dateTime12 = dateTime9.withHourOfDay(0);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime.Property property15 = dateTime12.dayOfWeek();
        org.joda.time.DateTime dateTime16 = property15.roundHalfCeilingCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
        try {
            org.joda.time.DateTime dateTime19 = dateTime16.withField(dateTimeFieldType17, 20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.chrono.BuddhistChronology buddhistChronology70 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField71 = buddhistChronology70.millis();
        org.joda.time.DateTimeField dateTimeField72 = buddhistChronology70.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology73 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField74 = buddhistChronology73.millis();
        org.joda.time.DateTime dateTime75 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology73);
        org.joda.time.DateTimeField dateTimeField76 = buddhistChronology73.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField78 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology70, dateTimeField76, (int) ' ');
        boolean boolean79 = skipUndoDateTimeField78.isSupported();
        java.lang.String str80 = skipUndoDateTimeField78.toString();
        long long82 = skipUndoDateTimeField78.roundFloor((long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone84 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTimeZone dateTimeZone85 = null;
        org.joda.time.DateTime dateTime86 = new org.joda.time.DateTime(dateTimeZone85);
        org.joda.time.ReadablePeriod readablePeriod87 = null;
        org.joda.time.DateTime dateTime88 = dateTime86.plus(readablePeriod87);
        org.joda.time.LocalDateTime localDateTime89 = dateTime88.toLocalDateTime();
        boolean boolean90 = dateTimeZone84.isLocalDateTimeGap(localDateTime89);
        int[] intArray91 = null;
        int int92 = skipUndoDateTimeField78.getMinimumValue((org.joda.time.ReadablePartial) localDateTime89, intArray91);
        int int93 = dividedDateTimeField69.getMaximumValue((org.joda.time.ReadablePartial) localDateTime89);
        java.lang.String str95 = dividedDateTimeField69.getAsText((long) (-98));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(buddhistChronology70);
        org.junit.Assert.assertNotNull(durationField71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertNotNull(buddhistChronology73);
        org.junit.Assert.assertNotNull(durationField74);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str80.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone84);
        org.junit.Assert.assertNotNull(dateTime88);
        org.junit.Assert.assertNotNull(localDateTime89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "0" + "'", str95.equals("0"));
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
//        boolean boolean9 = gJChronology3.equals((java.lang.Object) "0");
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
//        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfEra(100);
//        org.joda.time.ReadableDuration readableDuration13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime12.plus(readableDuration13);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = new org.joda.time.format.DateTimeFormatterBuilder();
//        dateTimeFormatterBuilder15.clear();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
//        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
//        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
//        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder15.appendSignedDecimal(dateTimeFieldType27, 411, (int) '#');
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology34 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone33);
//        java.util.Locale locale35 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket38 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology34, locale35, (java.lang.Integer) 4, (int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone40);
//        org.joda.time.chrono.ZonedChronology zonedChronology42 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology34, dateTimeZone40);
//        org.joda.time.chrono.ISOChronology iSOChronology43 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone40);
//        org.joda.time.DateTimeField dateTimeField44 = iSOChronology43.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone45 = null;
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime(dateTimeZone45);
//        org.joda.time.ReadablePeriod readablePeriod47 = null;
//        org.joda.time.DateTime dateTime48 = dateTime46.plus(readablePeriod47);
//        org.joda.time.LocalDateTime localDateTime49 = dateTime48.toLocalDateTime();
//        org.joda.time.ReadableDuration readableDuration50 = null;
//        org.joda.time.DateTime dateTime52 = dateTime48.withDurationAdded(readableDuration50, (int) 'a');
//        org.joda.time.DateTime.Property property53 = dateTime48.centuryOfEra();
//        org.joda.time.DateTime.Property property54 = dateTime48.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = property54.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField56 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField44, dateTimeFieldType55);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder15.appendSignedDecimal(dateTimeFieldType55, 1, 4);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder61 = dateTimeFormatterBuilder15.appendDayOfMonth(5);
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology65 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone64);
//        java.util.Locale locale66 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket69 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology65, locale66, (java.lang.Integer) 4, (int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology72 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone71);
//        org.joda.time.chrono.ZonedChronology zonedChronology73 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology65, dateTimeZone71);
//        org.joda.time.chrono.ISOChronology iSOChronology74 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone71);
//        org.joda.time.DateTimeField dateTimeField75 = iSOChronology74.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone76 = null;
//        org.joda.time.DateTime dateTime77 = new org.joda.time.DateTime(dateTimeZone76);
//        org.joda.time.ReadablePeriod readablePeriod78 = null;
//        org.joda.time.DateTime dateTime79 = dateTime77.plus(readablePeriod78);
//        org.joda.time.LocalDateTime localDateTime80 = dateTime79.toLocalDateTime();
//        org.joda.time.ReadableDuration readableDuration81 = null;
//        org.joda.time.DateTime dateTime83 = dateTime79.withDurationAdded(readableDuration81, (int) 'a');
//        org.joda.time.DateTime.Property property84 = dateTime79.centuryOfEra();
//        org.joda.time.DateTime.Property property85 = dateTime79.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType86 = property85.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField87 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField75, dateTimeFieldType86);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder88 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType86);
//        int int89 = dateTime12.get(dateTimeFieldType86);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(gJChronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(zonedChronology42);
//        org.junit.Assert.assertNotNull(iSOChronology43);
//        org.junit.Assert.assertNotNull(dateTimeField44);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(localDateTime49);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder61);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertNotNull(gJChronology65);
//        org.junit.Assert.assertNotNull(dateTimeZone71);
//        org.junit.Assert.assertNotNull(gJChronology72);
//        org.junit.Assert.assertNotNull(zonedChronology73);
//        org.junit.Assert.assertNotNull(iSOChronology74);
//        org.junit.Assert.assertNotNull(dateTimeField75);
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(localDateTime80);
//        org.junit.Assert.assertNotNull(dateTime83);
//        org.junit.Assert.assertNotNull(property84);
//        org.junit.Assert.assertNotNull(property85);
//        org.junit.Assert.assertNotNull(dateTimeFieldType86);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 12 + "'", int89 == 12);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
//        java.util.Locale locale4 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
//        org.joda.time.DurationField durationField8 = gJChronology3.days();
//        long long13 = gJChronology3.getDateTimeMillis(19, 10, 3, 2019);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone15 = null;
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
//        org.joda.time.ReadablePeriod readablePeriod17 = null;
//        org.joda.time.DateTime dateTime18 = dateTime16.plus(readablePeriod17);
//        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
//        java.lang.String str20 = dateTimeFormatter14.print((org.joda.time.ReadablePartial) localDateTime19);
//        int[] intArray22 = gJChronology3.get((org.joda.time.ReadablePartial) localDateTime19, 0L);
//        java.lang.String str23 = gJChronology3.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61544015997982L) + "'", long13 == (-61544015997982L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "2019163T061413.310" + "'", str20.equals("2019163T061413.310"));
//        org.junit.Assert.assertNotNull(intArray22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "GJChronology[+00:00:00.001]" + "'", str23.equals("GJChronology[+00:00:00.001]"));
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        org.joda.time.DurationField durationField10 = skipUndoDateTimeField8.getRangeDurationField();
        org.joda.time.DurationField durationField11 = skipUndoDateTimeField8.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNull(durationField11);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
//        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
//        org.joda.time.DateTime dateTime12 = dateTime9.withHourOfDay(0);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes((int) (byte) 0);
//        org.joda.time.DateTime.Property property15 = dateTime12.dayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
//        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone24 = null;
//        org.joda.time.DateTime dateTime25 = dateTime19.withZoneRetainFields(dateTimeZone24);
//        int int26 = dateTime25.getDayOfWeek();
//        int int27 = property15.getDifference((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology29 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField30 = buddhistChronology29.millis();
//        org.joda.time.DateTimeField dateTimeField31 = buddhistChronology29.hourOfHalfday();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = dateTimeFormatter28.withChronology((org.joda.time.Chronology) buddhistChronology29);
//        boolean boolean33 = dateTimeFormatter28.isPrinter();
//        java.lang.String str34 = dateTime25.toString(dateTimeFormatter28);
//        java.lang.Appendable appendable35 = null;
//        org.joda.time.ReadableInstant readableInstant36 = null;
//        try {
//            dateTimeFormatter28.printTo(appendable35, readableInstant36);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDateTime4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDateTime20);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-7102) + "'", int27 == (-7102));
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(buddhistChronology29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "061413-0700" + "'", str34.equals("061413-0700"));
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
//        mutableDateTime4.setMonthOfYear((int) (byte) 1);
//        mutableDateTime4.addMinutes((int) (byte) 10);
//        int int10 = mutableDateTime4.getHourOfDay();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField12 = buddhistChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology11.hourOfHalfday();
//        org.joda.time.DurationField durationField14 = buddhistChronology11.weekyears();
//        org.joda.time.DurationField durationField15 = buddhistChronology11.weeks();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.Chronology chronology19 = buddhistChronology11.withZone(dateTimeZone17);
//        mutableDateTime4.setZoneRetainFields(dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone21 = null;
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
//        org.joda.time.ReadablePeriod readablePeriod23 = null;
//        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
//        org.joda.time.LocalDateTime localDateTime25 = dateTime24.toLocalDateTime();
//        org.joda.time.ReadableDuration readableDuration26 = null;
//        org.joda.time.DateTime dateTime28 = dateTime24.withDurationAdded(readableDuration26, (int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone29 = null;
//        org.joda.time.DateTime dateTime30 = dateTime24.withZoneRetainFields(dateTimeZone29);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField32 = buddhistChronology31.millis();
//        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology31.hourOfHalfday();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField35 = buddhistChronology34.millis();
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology34);
//        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology34.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField37, (int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone40 = buddhistChronology31.getZone();
//        org.joda.time.MutableDateTime mutableDateTime41 = dateTime30.toMutableDateTime(dateTimeZone40);
//        long long43 = dateTimeZone17.getMillisKeepLocal(dateTimeZone40, 0L);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(chronology19);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(localDateTime25);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(buddhistChronology34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(mutableDateTime41);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800001L + "'", long43 == 28800001L);
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        java.lang.String str10 = skipUndoDateTimeField8.toString();
        long long12 = skipUndoDateTimeField8.roundFloor((long) (byte) 100);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology17, locale18, (java.lang.Integer) 4, (int) 'a');
        java.lang.Integer int22 = dateTimeParserBucket21.getOffsetInteger();
        boolean boolean24 = dateTimeParserBucket21.restoreState((java.lang.Object) 4);
        int int25 = dateTimeParserBucket21.getOffset();
        java.util.Locale locale26 = dateTimeParserBucket21.getLocale();
        try {
            java.lang.String str27 = skipUndoDateTimeField8.getAsText(readablePartial13, locale26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str10.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNull(int22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(locale26);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField5 = buddhistChronology4.millis();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField7, (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = buddhistChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology1.clockhourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField11);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder14.clear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) 'a');
        org.joda.time.DateTime.Property property24 = dateTime19.centuryOfEra();
        org.joda.time.DateTime.Property property25 = dateTime19.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder14.appendSignedDecimal(dateTimeFieldType26, 411, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32);
        java.util.Locale locale34 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket37 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology33, locale34, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39);
        org.joda.time.chrono.ZonedChronology zonedChronology41 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology33, dateTimeZone39);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone44);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime47 = dateTime45.plus(readablePeriod46);
        org.joda.time.LocalDateTime localDateTime48 = dateTime47.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration49 = null;
        org.joda.time.DateTime dateTime51 = dateTime47.withDurationAdded(readableDuration49, (int) 'a');
        org.joda.time.DateTime.Property property52 = dateTime47.centuryOfEra();
        org.joda.time.DateTime.Property property53 = dateTime47.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property53.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField43, dateTimeFieldType54);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder14.appendSignedDecimal(dateTimeFieldType54, 1, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType54, (int) '4');
        java.lang.String str61 = offsetDateTimeField60.toString();
        long long63 = offsetDateTimeField60.roundHalfFloor(28800001L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(zonedChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDateTime48);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str61.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 28800000L + "'", long63 == 28800000L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((-10L), (org.joda.time.Chronology) julianChronology1, locale2);
        java.lang.Integer int4 = dateTimeParserBucket3.getPivotYear();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNull(int4);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(dateTimeZone7);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.plus(readablePeriod9);
        org.joda.time.LocalDateTime localDateTime11 = dateTime10.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime14 = dateTime10.withDurationAdded(readableDuration12, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.hourOfHalfday();
        org.joda.time.DateTime dateTime17 = dateTime14.toDateTime((org.joda.time.Chronology) gregorianChronology15);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(22403, 115, 3, 292279588, 87, (-8), 115, (org.joda.time.Chronology) gregorianChronology15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279588 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(localDateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfSecond(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        long long5 = dateTimeZone1.adjustOffset((long) (byte) -1, true);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.monthOfYear();
        int int8 = property7.getMaximumValueOverall();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.roundHalfCeiling();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 12 + "'", int8 == 12);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        int int3 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        java.lang.String str71 = dividedDateTimeField69.getAsShortText((long) (byte) 0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "0" + "'", str71.equals("0"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.Object obj0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
        mutableDateTime1.setYear((int) (byte) 100);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.dayOfWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime7.toMutableDateTime();
        int int13 = dateTimeFormatter5.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime10, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime10.secondOfDay();
        org.joda.time.Interval interval15 = property14.toInterval();
        org.joda.time.MutableDateTime mutableDateTime16 = property14.roundCeiling();
        org.joda.time.MutableDateTime mutableDateTime17 = property14.roundCeiling();
        org.joda.time.MutableDateTime mutableDateTime19 = property14.add(0L);
        boolean boolean20 = property4.equals((java.lang.Object) 0L);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(interval15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(mutableDateTime17);
        org.junit.Assert.assertNotNull(mutableDateTime19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
//        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
//        int int11 = skipUndoDateTimeField8.getDifference((long) 12, (long) ' ');
//        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField14 = buddhistChronology13.millis();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
//        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology13.hourOfHalfday();
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime((long) 4, (org.joda.time.Chronology) buddhistChronology13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology18.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        long long25 = dateTimeZone21.adjustOffset((long) (byte) -1, true);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTimeZone dateTimeZone28 = null;
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime(dateTimeZone28);
//        org.joda.time.ReadablePeriod readablePeriod30 = null;
//        org.joda.time.DateTime dateTime31 = dateTime29.plus(readablePeriod30);
//        org.joda.time.LocalDateTime localDateTime32 = dateTime31.toLocalDateTime();
//        boolean boolean33 = dateTimeZone27.isLocalDateTimeGap(localDateTime32);
//        boolean boolean34 = dateTimeZone21.isLocalDateTimeGap(localDateTime32);
//        int[] intArray36 = gregorianChronology18.get((org.joda.time.ReadablePartial) localDateTime32, 110L);
//        long long38 = buddhistChronology13.set((org.joda.time.ReadablePartial) localDateTime32, 0L);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology40 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField41 = buddhistChronology40.millis();
//        org.joda.time.DateTimeField dateTimeField42 = buddhistChronology40.hourOfHalfday();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology43 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField44 = buddhistChronology43.millis();
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology43);
//        org.joda.time.DateTimeField dateTimeField46 = buddhistChronology43.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField48 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology40, dateTimeField46, (int) ' ');
//        java.util.Locale locale50 = null;
//        java.lang.String str51 = skipUndoDateTimeField48.getAsShortText((int) (short) 0, locale50);
//        org.joda.time.DurationField durationField52 = skipUndoDateTimeField48.getDurationField();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology53 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField54 = buddhistChronology53.millis();
//        org.joda.time.DateTimeField dateTimeField55 = buddhistChronology53.hourOfHalfday();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology56 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField57 = buddhistChronology56.millis();
//        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology56);
//        org.joda.time.DateTimeField dateTimeField59 = buddhistChronology56.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField61 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology53, dateTimeField59, (int) ' ');
//        boolean boolean62 = skipUndoDateTimeField61.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone63 = null;
//        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime(dateTimeZone63);
//        org.joda.time.ReadablePeriod readablePeriod65 = null;
//        org.joda.time.DateTime dateTime66 = dateTime64.plus(readablePeriod65);
//        org.joda.time.LocalDateTime localDateTime67 = dateTime66.toLocalDateTime();
//        java.util.Locale locale68 = null;
//        java.lang.String str69 = skipUndoDateTimeField61.getAsShortText((org.joda.time.ReadablePartial) localDateTime67, locale68);
//        org.joda.time.chrono.GregorianChronology gregorianChronology70 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology70.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTime dateTime74 = org.joda.time.DateTime.now(dateTimeZone73);
//        long long77 = dateTimeZone73.adjustOffset((long) (byte) -1, true);
//        org.joda.time.DateTimeZone dateTimeZone79 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTimeZone dateTimeZone80 = null;
//        org.joda.time.DateTime dateTime81 = new org.joda.time.DateTime(dateTimeZone80);
//        org.joda.time.ReadablePeriod readablePeriod82 = null;
//        org.joda.time.DateTime dateTime83 = dateTime81.plus(readablePeriod82);
//        org.joda.time.LocalDateTime localDateTime84 = dateTime83.toLocalDateTime();
//        boolean boolean85 = dateTimeZone79.isLocalDateTimeGap(localDateTime84);
//        boolean boolean86 = dateTimeZone73.isLocalDateTimeGap(localDateTime84);
//        int[] intArray88 = gregorianChronology70.get((org.joda.time.ReadablePartial) localDateTime84, 110L);
//        int int89 = skipUndoDateTimeField48.getMaximumValue((org.joda.time.ReadablePartial) localDateTime67, intArray88);
//        try {
//            int[] intArray91 = skipUndoDateTimeField8.set((org.joda.time.ReadablePartial) localDateTime32, 0, intArray88, 13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 13 for hourOfHalfday must be in the range [0,11]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(buddhistChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(buddhistChronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(gregorianChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(localDateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(intArray36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + (-15574240367643L) + "'", long38 == (-15574240367643L));
//        org.junit.Assert.assertNotNull(buddhistChronology40);
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(buddhistChronology43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTimeField46);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "0" + "'", str51.equals("0"));
//        org.junit.Assert.assertNotNull(durationField52);
//        org.junit.Assert.assertNotNull(buddhistChronology53);
//        org.junit.Assert.assertNotNull(durationField54);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(buddhistChronology56);
//        org.junit.Assert.assertNotNull(durationField57);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(localDateTime67);
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "6" + "'", str69.equals("6"));
//        org.junit.Assert.assertNotNull(gregorianChronology70);
//        org.junit.Assert.assertNotNull(dateTimeField71);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + (-1L) + "'", long77 == (-1L));
//        org.junit.Assert.assertNotNull(dateTimeZone79);
//        org.junit.Assert.assertNotNull(dateTime83);
//        org.junit.Assert.assertNotNull(localDateTime84);
//        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertNotNull(intArray88);
//        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 11 + "'", int89 == 11);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        int int11 = skipUndoDateTimeField8.getDifference((long) 12, (long) ' ');
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField8.getAsShortText((int) (short) -1, locale13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField8.getAsText(0L, locale16);
        try {
            long long20 = skipUndoDateTimeField8.set(0L, "GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[America/Los_Angeles]\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1" + "'", str14.equals("-1"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4" + "'", str17.equals("4"));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime4.toMutableDateTime();
        int int10 = dateTimeFormatter2.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime7, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime7.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime12 = property11.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime13 = property11.roundCeiling();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField15 = buddhistChronology14.millis();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.hourOfHalfday();
        org.joda.time.DurationField durationField17 = buddhistChronology14.weekyears();
        org.joda.time.DurationField durationField18 = buddhistChronology14.weeks();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
        org.joda.time.Chronology chronology22 = buddhistChronology14.withZone(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone20);
        mutableDateTime13.setZone(dateTimeZone20);
        org.joda.time.Chronology chronology25 = gregorianChronology0.withZone(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(chronology25);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(12, (-8), 365, (int) (short) 10, 381, 11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 381 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (-10));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
        try {
            org.joda.time.DateTime dateTime7 = dateTime3.withWeekOfWeekyear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        long long6 = dateTimeZone2.adjustOffset((long) (byte) -1, true);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
        org.joda.time.LocalDateTime localDateTime13 = dateTime12.toLocalDateTime();
        boolean boolean14 = dateTimeZone8.isLocalDateTimeGap(localDateTime13);
        boolean boolean15 = dateTimeZone2.isLocalDateTimeGap(localDateTime13);
        java.util.TimeZone timeZone16 = dateTimeZone2.toTimeZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = dateTimeFormatter0.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1L) + "'", long6 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology4, dateTimeZone10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withZone(dateTimeZone10);
        long long17 = dateTimeZone10.adjustOffset((long) '#', false);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 35L + "'", long17 == 35L);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        java.util.Date date9 = mutableDateTime5.toDate();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime5.hourOfDay();
        mutableDateTime5.setMinuteOfHour(24);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 365, dateTimeZone1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (byte) 0);
        org.joda.time.MutableDateTime.Property property2 = mutableDateTime1.weekOfWeekyear();
        java.lang.String str3 = property2.getAsText();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1" + "'", str3.equals("1"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, dateTimeZone9);
        org.joda.time.DurationField durationField12 = zonedChronology11.eras();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology16, locale17, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
        org.joda.time.LocalDateTime localDateTime25 = dateTime24.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime28 = dateTime24.withDurationAdded(readableDuration26, (int) 'a');
        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((-10));
        boolean boolean31 = dateTimeParserBucket20.restoreState((java.lang.Object) dateTime28);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTimeParserBucket20.getZone();
        java.lang.String str33 = dateTimeZone32.getID();
        org.joda.time.Chronology chronology34 = zonedChronology11.withZone(dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone35);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.DateTime dateTime38 = dateTime36.plus(readablePeriod37);
        org.joda.time.LocalDateTime localDateTime39 = dateTime38.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration40 = null;
        org.joda.time.DateTime dateTime42 = dateTime38.withDurationAdded(readableDuration40, (int) 'a');
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology43.hourOfHalfday();
        org.joda.time.DateTime dateTime45 = dateTime42.toDateTime((org.joda.time.Chronology) gregorianChronology43);
        org.joda.time.DateTime.Property property46 = dateTime45.monthOfYear();
        boolean boolean47 = zonedChronology11.equals((java.lang.Object) dateTime45);
        org.joda.time.DateTime dateTime49 = dateTime45.minusDays(18);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00:00.001" + "'", str33.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(localDateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dateTime49);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime.Property property9 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
//        java.util.Locale locale7 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
//        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
//        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
//        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
//        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone35);
//        org.joda.time.ReadablePeriod readablePeriod37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime36.plus(readablePeriod37);
//        org.joda.time.LocalDateTime localDateTime39 = dateTime38.toLocalDateTime();
//        java.lang.String str40 = dateTimeFormatter34.print((org.joda.time.ReadablePartial) localDateTime39);
//        boolean boolean41 = dateTimeFormatter34.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone42);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter34.withChronology((org.joda.time.Chronology) julianChronology43);
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider45 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider45);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49);
//        java.util.Locale locale51 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket54 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology50, locale51, (java.lang.Integer) 4, (int) 'a');
//        java.lang.Integer int55 = dateTimeParserBucket54.getOffsetInteger();
//        boolean boolean57 = dateTimeParserBucket54.restoreState((java.lang.Object) 4);
//        int int58 = dateTimeParserBucket54.getOffset();
//        java.util.Locale locale59 = dateTimeParserBucket54.getLocale();
//        java.lang.String str62 = defaultNameProvider45.getShortName(locale59, "2019-W24-3", "2019163T061308.342");
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket64 = new org.joda.time.format.DateTimeParserBucket((long) 2000, (org.joda.time.Chronology) julianChronology43, locale59, (java.lang.Integer) (-8));
//        java.lang.String str65 = delegatedDateTimeField29.getAsText(10799999L, locale59);
//        org.joda.time.DurationField durationField66 = delegatedDateTimeField29.getLeapDurationField();
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(localDateTime39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019163T061415.705" + "'", str40.equals("2019163T061415.705"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(julianChronology43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNull(int55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(locale59);
//        org.junit.Assert.assertNull(str62);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "6" + "'", str65.equals("6"));
//        org.junit.Assert.assertNull(durationField66);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        mutableDateTime0.addMillis(100);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        mutableDateTime0.add(readablePeriod4);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour(18);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology5.getZone();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime(dateTimeZone6);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime13 = property9.add(0L);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.secondOfDay();
        java.lang.Object obj15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(obj15);
        mutableDateTime13.setTime((org.joda.time.ReadableInstant) mutableDateTime16);
        try {
            mutableDateTime13.setWeekOfWeekyear(381);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 381 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        java.lang.String str1 = gregorianChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str1.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField2 = buddhistChronology1.millis();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
//        int int4 = instant0.get(dateTimeField3);
//        org.joda.time.Instant instant6 = instant0.minus(0L);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.Instant instant9 = instant6.withDurationAdded(readableDuration7, 12);
//        org.joda.time.Instant instant10 = new org.joda.time.Instant((java.lang.Object) readableDuration7);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(instant9);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("-1");
        org.joda.time.DateTimeField dateTimeField2 = mutableDateTime1.getRoundingField();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNull(dateTimeField2);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField5 = buddhistChronology4.millis();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField7, (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = buddhistChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology1.clockhourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField11);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder14.clear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) 'a');
        org.joda.time.DateTime.Property property24 = dateTime19.centuryOfEra();
        org.joda.time.DateTime.Property property25 = dateTime19.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder14.appendSignedDecimal(dateTimeFieldType26, 411, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32);
        java.util.Locale locale34 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket37 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology33, locale34, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39);
        org.joda.time.chrono.ZonedChronology zonedChronology41 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology33, dateTimeZone39);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone44);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime47 = dateTime45.plus(readablePeriod46);
        org.joda.time.LocalDateTime localDateTime48 = dateTime47.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration49 = null;
        org.joda.time.DateTime dateTime51 = dateTime47.withDurationAdded(readableDuration49, (int) 'a');
        org.joda.time.DateTime.Property property52 = dateTime47.centuryOfEra();
        org.joda.time.DateTime.Property property53 = dateTime47.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property53.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField43, dateTimeFieldType54);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder14.appendSignedDecimal(dateTimeFieldType54, 1, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType54, (int) '4');
        org.joda.time.DurationField durationField61 = offsetDateTimeField60.getDurationField();
        org.joda.time.DurationField durationField62 = offsetDateTimeField60.getRangeDurationField();
        int int63 = offsetDateTimeField60.getMaximumValue();
        org.joda.time.DurationField durationField64 = offsetDateTimeField60.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(zonedChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDateTime48);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNull(durationField62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 292279588 + "'", int63 == 292279588);
        org.junit.Assert.assertNotNull(durationField64);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        boolean boolean9 = gJChronology3.equals((java.lang.Object) "0");
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfEra(100);
        org.joda.time.DateTime dateTime14 = dateTime10.withYear(87);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear(2);
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
        try {
            org.joda.time.DateTime dateTime13 = dateTime9.withDate((-8), (-292268459), 41);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292268459 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "2019-W24-3T06:14:06.942-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime1.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, dateTimeZone9);
        org.joda.time.DurationField durationField12 = zonedChronology11.eras();
        org.joda.time.Chronology chronology13 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology11.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendHourOfHalfday(5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = property5.roundFloor();
        org.joda.time.MutableDateTime mutableDateTime7 = property5.roundHalfCeiling();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology4, dateTimeZone10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime((long) 11, dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.LocalDateTime localDateTime5 = dateTime4.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime8 = dateTime4.withDurationAdded(readableDuration6, (int) 'a');
        org.joda.time.DateTime.Property property9 = dateTime4.centuryOfEra();
        org.joda.time.DateTime dateTime10 = property9.roundFloorCopy();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gJChronology11);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        int int11 = skipUndoDateTimeField8.getDifference((long) 12, (long) ' ');
        int int13 = skipUndoDateTimeField8.getMaximumValue((long) 24);
        long long15 = skipUndoDateTimeField8.roundHalfFloor(0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        int int11 = skipUndoDateTimeField8.getDifference((long) 12, (long) ' ');
        int int13 = skipUndoDateTimeField8.getMinimumValue(10L);
        org.joda.time.DateTimeField dateTimeField14 = skipUndoDateTimeField8.getWrappedField();
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField8.getAsText((-14400000L), locale16);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
        org.joda.time.DateTime dateTime10 = property8.withMaximumValue();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
        int int13 = dateTime10.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 292278919 + "'", int13 == 292278919);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("061319-0700");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("061319-0700");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        jodaTimePermission1.checkGuard((java.lang.Object) "1970");
        java.lang.String str7 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "061319-0700" + "'", str7.equals("061319-0700"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, dateTimeZone9);
        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withChronology(chronology1);
        java.lang.String str4 = dateTimeFormatter0.print((long) (-7102));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1969-365T15:59:52-08:00" + "'", str4.equals("1969-365T15:59:52-08:00"));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        java.lang.Integer int8 = dateTimeParserBucket7.getOffsetInteger();
        java.lang.Object obj9 = dateTimeParserBucket7.saveState();
        java.lang.Integer int10 = dateTimeParserBucket7.getOffsetInteger();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNull(int8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(int10);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
//        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
//        mutableDateTime0.addMillis(100);
//        int int4 = mutableDateTime0.getDayOfWeek();
//        org.junit.Assert.assertNotNull(mutableDateTime0);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
//        java.util.Locale locale5 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 4, (int) 'a');
//        org.joda.time.DurationField durationField9 = gJChronology4.days();
//        long long14 = gJChronology4.getDateTimeMillis(19, 10, 3, 2019);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
//        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
//        java.lang.String str21 = dateTimeFormatter15.print((org.joda.time.ReadablePartial) localDateTime20);
//        int[] intArray23 = gJChronology4.get((org.joda.time.ReadablePartial) localDateTime20, 0L);
//        try {
//            org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) dateTimeFormatter0, (org.joda.time.Chronology) gJChronology4);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatter");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gJChronology4);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-61544015997982L) + "'", long14 == (-61544015997982L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter15);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(localDateTime20);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "2019163T061417.790" + "'", str21.equals("2019163T061417.790"));
//        org.junit.Assert.assertNotNull(intArray23);
//    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTimeZone dateTimeZone3 = null;
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
//        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
//        boolean boolean8 = dateTimeZone2.isLocalDateTimeGap(localDateTime7);
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime7);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "06:14:17.816" + "'", str9.equals("06:14:17.816"));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        mutableDateTime4.setMonthOfYear((int) (byte) 1);
        try {
            mutableDateTime4.setMillisOfSecond((-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime3.toMutableDateTime();
        int int9 = dateTimeFormatter1.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime6, "hi!", (int) (byte) 0);
        try {
            org.joda.time.MutableDateTime mutableDateTime10 = org.joda.time.MutableDateTime.parse("era", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"era\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField5 = buddhistChronology4.millis();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField7, (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = buddhistChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology1.clockhourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField11);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology0.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder14.clear();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) 'a');
        org.joda.time.DateTime.Property property24 = dateTime19.centuryOfEra();
        org.joda.time.DateTime.Property property25 = dateTime19.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder14.appendSignedDecimal(dateTimeFieldType26, 411, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone32);
        java.util.Locale locale34 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket37 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology33, locale34, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology40 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone39);
        org.joda.time.chrono.ZonedChronology zonedChronology41 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology33, dateTimeZone39);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime(dateTimeZone44);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime47 = dateTime45.plus(readablePeriod46);
        org.joda.time.LocalDateTime localDateTime48 = dateTime47.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration49 = null;
        org.joda.time.DateTime dateTime51 = dateTime47.withDurationAdded(readableDuration49, (int) 'a');
        org.joda.time.DateTime.Property property52 = dateTime47.centuryOfEra();
        org.joda.time.DateTime.Property property53 = dateTime47.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = property53.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField55 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField43, dateTimeFieldType54);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder14.appendSignedDecimal(dateTimeFieldType54, 1, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType54, (int) '4');
        org.joda.time.DurationField durationField61 = offsetDateTimeField60.getDurationField();
        org.joda.time.DurationField durationField62 = offsetDateTimeField60.getRangeDurationField();
        int int63 = offsetDateTimeField60.getMaximumValue();
        long long66 = offsetDateTimeField60.add(1560387600000L, (long) 4);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(gJChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(gJChronology40);
        org.junit.Assert.assertNotNull(zonedChronology41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDateTime48);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNull(durationField62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 292279588 + "'", int63 == 292279588);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1686618000000L + "'", long66 == 1686618000000L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        java.lang.Class<?> wildcardClass6 = mutableDateTime4.getClass();
        try {
            mutableDateTime4.setDateTime((int) (byte) 0, 1, 174, 115, (int) (byte) 1, 115, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 115 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        try {
            long long2 = dateTimeFormatter0.parseMillis("2019163T061410.826");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019163T061410.826\" is malformed at \"1410.826\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(readableDuration13, (int) 'a');
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths((-10));
        boolean boolean18 = dateTimeParserBucket7.restoreState((java.lang.Object) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime15.plusMonths(18);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology4, dateTimeZone10);
        org.joda.time.DurationField durationField13 = zonedChronology12.weekyears();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) zonedChronology12);
        try {
            long long19 = zonedChronology12.getDateTimeMillis(0, 10, (int) (short) 0, 41);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number4 = illegalFieldValueException2.getIllegalNumberValue();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(durationFieldType5);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(31507200115L);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone4.getUncachedZone();
        long long9 = cachedDateTimeZone4.nextTransition((-98250L));
        int int11 = cachedDateTimeZone4.getStandardOffset(1560345223292L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-98250L) + "'", long9 == (-98250L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded(readableDuration9, (int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime7.centuryOfEra();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType14, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendDayOfMonth(0);
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatterBuilder19.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeParser20);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((int) (short) 0, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField8.getDurationField();
        long long14 = skipUndoDateTimeField8.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560345258436L + "'", long1 == 1560345258436L);
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths((-10));
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (byte) 0);
        org.joda.time.DateTime dateTime13 = dateTime7.withDayOfMonth(4);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        try {
            long long12 = gJChronology3.getDateTimeMillis(19, 381, 5, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 381 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
//        java.util.Locale locale7 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
//        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
//        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
//        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
//        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone35);
//        org.joda.time.ReadablePeriod readablePeriod37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime36.plus(readablePeriod37);
//        org.joda.time.LocalDateTime localDateTime39 = dateTime38.toLocalDateTime();
//        java.lang.String str40 = dateTimeFormatter34.print((org.joda.time.ReadablePartial) localDateTime39);
//        boolean boolean41 = dateTimeFormatter34.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone42);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter34.withChronology((org.joda.time.Chronology) julianChronology43);
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider45 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider45);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49);
//        java.util.Locale locale51 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket54 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology50, locale51, (java.lang.Integer) 4, (int) 'a');
//        java.lang.Integer int55 = dateTimeParserBucket54.getOffsetInteger();
//        boolean boolean57 = dateTimeParserBucket54.restoreState((java.lang.Object) 4);
//        int int58 = dateTimeParserBucket54.getOffset();
//        java.util.Locale locale59 = dateTimeParserBucket54.getLocale();
//        java.lang.String str62 = defaultNameProvider45.getShortName(locale59, "2019-W24-3", "2019163T061308.342");
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket64 = new org.joda.time.format.DateTimeParserBucket((long) 2000, (org.joda.time.Chronology) julianChronology43, locale59, (java.lang.Integer) (-8));
//        java.lang.String str65 = delegatedDateTimeField29.getAsText(10799999L, locale59);
//        org.joda.time.DateTimeZone dateTimeZone67 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.DateTimeZone dateTimeZone68 = null;
//        org.joda.time.DateTime dateTime69 = new org.joda.time.DateTime(dateTimeZone68);
//        org.joda.time.ReadablePeriod readablePeriod70 = null;
//        org.joda.time.DateTime dateTime71 = dateTime69.plus(readablePeriod70);
//        org.joda.time.LocalDateTime localDateTime72 = dateTime71.toLocalDateTime();
//        boolean boolean73 = dateTimeZone67.isLocalDateTimeGap(localDateTime72);
//        int[] intArray75 = new int[] {};
//        try {
//            int[] intArray77 = delegatedDateTimeField29.addWrapPartial((org.joda.time.ReadablePartial) localDateTime72, 22403, intArray75, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 22403");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(localDateTime39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019163T061418.544" + "'", str40.equals("2019163T061418.544"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(julianChronology43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNull(int55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(locale59);
//        org.junit.Assert.assertNull(str62);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "6" + "'", str65.equals("6"));
//        org.junit.Assert.assertNotNull(dateTimeZone67);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(localDateTime72);
//        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
//        org.junit.Assert.assertNotNull(intArray75);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.withDurationAdded(readableDuration7, (int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime5.centuryOfEra();
        org.joda.time.DateTime.Property property11 = dateTime5.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType12, 411, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        java.util.Locale locale20 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology19, locale20, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology19, dateTimeZone25);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
        org.joda.time.LocalDateTime localDateTime34 = dateTime33.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime37 = dateTime33.withDurationAdded(readableDuration35, (int) 'a');
        org.joda.time.DateTime.Property property38 = dateTime33.centuryOfEra();
        org.joda.time.DateTime.Property property39 = dateTime33.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29, dateTimeFieldType40);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType40, 1, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder0.appendYearOfEra((int) ' ', 14);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
//        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
//        java.lang.String str10 = property9.toString();
//        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfEven();
//        java.lang.String str12 = property9.toString();
//        org.joda.time.DurationField durationField13 = property9.getLeapDurationField();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology16 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField17 = buddhistChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology16.hourOfHalfday();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField20 = buddhistChronology19.millis();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology19);
//        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology19.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology16, dateTimeField22, (int) ' ');
//        org.joda.time.DateTimeZone dateTimeZone25 = buddhistChronology16.getZone();
//        org.joda.time.DateTimeField dateTimeField26 = buddhistChronology16.clockhourOfHalfday();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField26);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology28 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField29 = buddhistChronology28.millis();
//        org.joda.time.DateTimeField dateTimeField30 = buddhistChronology28.hourOfHalfday();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField32 = buddhistChronology31.millis();
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology31);
//        org.joda.time.DateTimeField dateTimeField34 = buddhistChronology31.hourOfHalfday();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology28, dateTimeField34, (int) ' ');
//        boolean boolean37 = skipUndoDateTimeField36.isSupported();
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime(dateTimeZone38);
//        org.joda.time.ReadablePeriod readablePeriod40 = null;
//        org.joda.time.DateTime dateTime41 = dateTime39.plus(readablePeriod40);
//        org.joda.time.LocalDateTime localDateTime42 = dateTime41.toLocalDateTime();
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = skipUndoDateTimeField36.getAsShortText((org.joda.time.ReadablePartial) localDateTime42, locale43);
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone48);
//        java.util.Locale locale50 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket53 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology49, locale50, (java.lang.Integer) 4, (int) 'a');
//        java.lang.Integer int54 = dateTimeParserBucket53.getOffsetInteger();
//        boolean boolean56 = dateTimeParserBucket53.restoreState((java.lang.Object) 4);
//        int int57 = dateTimeParserBucket53.getOffset();
//        java.util.Locale locale58 = dateTimeParserBucket53.getLocale();
//        java.lang.String str59 = skipDateTimeField27.getAsText((org.joda.time.ReadablePartial) localDateTime42, 0, locale58);
//        try {
//            org.joda.time.MutableDateTime mutableDateTime60 = property9.set("secondOfDay", locale58);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"secondOfDay\" for secondOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[secondOfDay]" + "'", str12.equals("Property[secondOfDay]"));
//        org.junit.Assert.assertNull(durationField13);
//        org.junit.Assert.assertNotNull(buddhistChronology15);
//        org.junit.Assert.assertNotNull(buddhistChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(buddhistChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(buddhistChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(buddhistChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(localDateTime42);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "6" + "'", str44.equals("6"));
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(gJChronology49);
//        org.junit.Assert.assertNull(int54);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNotNull(locale58);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "0" + "'", str59.equals("0"));
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology11.dayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.withDurationAdded(readableDuration7, (int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime5.centuryOfEra();
        org.joda.time.DateTime.Property property11 = dateTime5.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType12, 411, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        java.util.Locale locale20 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology19, locale20, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology19, dateTimeZone25);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
        org.joda.time.LocalDateTime localDateTime34 = dateTime33.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime37 = dateTime33.withDurationAdded(readableDuration35, (int) 'a');
        org.joda.time.DateTime.Property property38 = dateTime33.centuryOfEra();
        org.joda.time.DateTime.Property property39 = dateTime33.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29, dateTimeFieldType40);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType40, 1, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder44.appendMillisOfSecond(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder46.appendTimeZoneName();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder46.appendPattern("2019-W24-3T06:14:06.942-07:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: W");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
        org.joda.time.Chronology chronology3 = instant0.getChronology();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant6 = instant0.withDurationAdded(readableDuration4, 292278919);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        boolean boolean71 = dividedDateTimeField69.isLenient();
        long long74 = dividedDateTimeField69.getDifferenceAsLong((-61544015997982L), 43200100L);
        java.lang.String str76 = dividedDateTimeField69.getAsShortText((long) (short) -1);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField77 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        long long79 = remainderDateTimeField77.roundCeiling((long) 19);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-98250L) + "'", long74 == (-98250L));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "0" + "'", str76.equals("0"));
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 3600000L + "'", long79 == 3600000L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMonthOfYear((int) (short) 10);
        int int7 = dateTime3.getCenturyOfEra();
        try {
            org.joda.time.DateTime dateTime9 = dateTime3.withYearOfEra((-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 11, (-4320000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -47520000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime9.minus(readablePeriod11);
        try {
            org.joda.time.DateTime dateTime16 = dateTime9.withDate(0, (-98), 22);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -98 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField71 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        long long73 = remainderDateTimeField71.roundCeiling(1566436413691L);
        int int76 = remainderDateTimeField71.getDifference((long) 173, (long) 411);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1566439200000L + "'", long73 == 1566439200000L);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((-10L), (org.joda.time.Chronology) julianChronology1, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology5 = julianChronology1.withZone(dateTimeZone4);
        try {
            org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone4, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 13");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime3.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMillis(10);
        org.joda.time.DateTime dateTime10 = dateTime3.plusMinutes(0);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfDay(41);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        java.lang.String str4 = property3.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Property[weekyear]" + "'", str4.equals("Property[weekyear]"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException7.getSuppressed();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Number number10 = illegalFieldValueException7.getLowerBound();
        java.lang.String str11 = illegalFieldValueException7.getIllegalValueAsString();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        boolean boolean10 = property9.isLeap();
        org.joda.time.DateTimeField dateTimeField11 = property9.getField();
        java.lang.String str12 = property9.toString();
        int int13 = property9.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[secondOfDay]" + "'", str12.equals("Property[secondOfDay]"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendLiteral(' ');
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendWeekyear((-292268459), 3395);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        try {
            long long6 = julianChronology0.getDateTimeMillis(41, 87, (int) (byte) 1, 3);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 87 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        int int11 = skipUndoDateTimeField8.getDifference((long) 12, (long) ' ');
        int int13 = skipUndoDateTimeField8.getMinimumValue(10L);
        org.joda.time.DateTimeField dateTimeField14 = skipUndoDateTimeField8.getWrappedField();
        try {
            long long17 = skipUndoDateTimeField8.set((long) (-2), "GregorianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"GregorianChronology[America/Los_Angeles]\" for hourOfHalfday is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfEven();
        java.lang.String str12 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime14 = property9.add(0);
        org.joda.time.Interval interval15 = property9.toInterval();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[secondOfDay]" + "'", str12.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(interval15);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder6.clear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(readableDuration13, (int) 'a');
        org.joda.time.DateTime.Property property16 = dateTime11.centuryOfEra();
        org.joda.time.DateTime.Property property17 = dateTime11.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType18, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType18, (int) (short) 0, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder5.appendYear(100, 41);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder5.appendDayOfYear((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        int int11 = skipUndoDateTimeField8.getDifference((long) 12, (long) ' ');
        java.util.Locale locale13 = null;
        java.lang.String str14 = skipUndoDateTimeField8.getAsShortText((int) (short) -1, locale13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField8.getAsText((long) 20, locale16);
        long long20 = skipUndoDateTimeField8.addWrapField((long) (short) 10, (int) '#');
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-1" + "'", str14.equals("-1"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "4" + "'", str17.equals("4"));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-3599990L) + "'", long20 == (-3599990L));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime();
        org.joda.time.DateTime dateTime13 = dateTime9.minusMinutes(3);
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded(10799999L, (int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        java.util.Locale locale6 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket9 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology5, locale6, (java.lang.Integer) 4, (int) 'a');
        java.lang.Integer int10 = dateTimeParserBucket9.getOffsetInteger();
        boolean boolean12 = dateTimeParserBucket9.restoreState((java.lang.Object) 4);
        int int13 = dateTimeParserBucket9.getOffset();
        java.util.Locale locale14 = dateTimeParserBucket9.getLocale();
        java.lang.String str17 = defaultNameProvider0.getShortName(locale14, "2019-W24-3", "2019163T061308.342");
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
        java.util.Locale locale22 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology21, locale22, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology26 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField27 = buddhistChronology26.millis();
        org.joda.time.DateTimeField dateTimeField28 = buddhistChronology26.hourOfHalfday();
        org.joda.time.DurationField durationField29 = buddhistChronology26.weekyears();
        org.joda.time.DurationField durationField30 = buddhistChronology26.weeks();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone32);
        org.joda.time.Chronology chronology34 = buddhistChronology26.withZone(dateTimeZone32);
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone32);
        dateTimeParserBucket25.setZone(dateTimeZone32);
        java.util.Locale locale37 = dateTimeParserBucket25.getLocale();
        java.lang.String str40 = defaultNameProvider0.getName(locale37, "1969-365T15:59:52-08:00", "2564");
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNull(int10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(locale14);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(buddhistChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(locale37);
        org.junit.Assert.assertNull(str40);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField3 = gJChronology2.seconds();
        org.joda.time.DateTimeField dateTimeField4 = gJChronology2.clockhourOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray7 = gJChronology2.get(readablePeriod5, 1560297600782L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(readableDuration13, (int) 'a');
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths((-10));
        boolean boolean18 = dateTimeParserBucket7.restoreState((java.lang.Object) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeParserBucket7.getZone();
        java.lang.Integer int20 = dateTimeParserBucket7.getOffsetInteger();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNull(int20);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        int int4 = julianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology3.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfSecond(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendFractionOfDay(2922789, (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendCenturyOfEra(115, 10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(31507200115L);
        long long8 = cachedDateTimeZone4.nextTransition((-61553555613431L));
        int int10 = cachedDateTimeZone4.getStandardOffset((-7200000L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-61553555613431L) + "'", long8 == (-61553555613431L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField3 = buddhistChronology2.millis();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField6 = buddhistChronology5.millis();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology5.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField8, (int) ' ');
        boolean boolean11 = skipUndoDateTimeField10.isSupported();
        java.lang.String str12 = skipUndoDateTimeField10.toString();
        long long14 = skipUndoDateTimeField10.roundFloor((long) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        boolean boolean22 = dateTimeZone16.isLocalDateTimeGap(localDateTime21);
        int[] intArray23 = null;
        int int24 = skipUndoDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDateTime21, intArray23);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDateTime21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str12.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        boolean boolean71 = dividedDateTimeField69.isLenient();
        long long74 = dividedDateTimeField69.add((-61553555613431L), (-1));
        long long77 = dividedDateTimeField69.add(3600002L, (long) 13);
        int int78 = dividedDateTimeField69.getDivisor();
        org.joda.time.DateTimeFieldType dateTimeFieldType79 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField80 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField69, dateTimeFieldType79);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-61554182013431L) + "'", long74 == (-61554182013431L));
        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 8146800002L + "'", long77 == 8146800002L);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 174 + "'", int78 == 174);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.weekyears();
        org.joda.time.Chronology chronology2 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        org.joda.time.Interval interval10 = property9.toInterval();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundCeiling();
        org.joda.time.MutableDateTime mutableDateTime12 = property9.roundCeiling();
        org.joda.time.MutableDateTime mutableDateTime14 = property9.add(0L);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.yearOfCentury();
        org.joda.time.DurationField durationField16 = property15.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(interval10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime dateTime11 = dateTime9.toDateTime();
        org.joda.time.DateTime dateTime13 = dateTime11.plusSeconds((-7102));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.hourOfHalfday();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(0, 3, (int) (byte) 1, 20, (-7102), 7, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -7102 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
//        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
//        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.Chronology chronology11 = julianChronology10.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime12 = org.joda.time.MutableDateTime.now(chronology11);
//        long long13 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime12);
//        int int14 = property9.get();
//        org.joda.time.MutableDateTime mutableDateTime15 = property9.roundHalfEven();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(julianChronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 22463 + "'", int14 == 22463);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
//        java.util.Locale locale7 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
//        org.joda.time.DateTimeZone dateTimeZone17 = null;
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
//        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
//        org.joda.time.ReadableDuration readableDuration22 = null;
//        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
//        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
//        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
//        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone35);
//        org.joda.time.ReadablePeriod readablePeriod37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime36.plus(readablePeriod37);
//        org.joda.time.LocalDateTime localDateTime39 = dateTime38.toLocalDateTime();
//        java.lang.String str40 = dateTimeFormatter34.print((org.joda.time.ReadablePartial) localDateTime39);
//        boolean boolean41 = dateTimeFormatter34.isOffsetParsed();
//        org.joda.time.DateTimeZone dateTimeZone42 = null;
//        org.joda.time.chrono.JulianChronology julianChronology43 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone42);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter34.withChronology((org.joda.time.Chronology) julianChronology43);
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider45 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider45);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis(1);
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49);
//        java.util.Locale locale51 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket54 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology50, locale51, (java.lang.Integer) 4, (int) 'a');
//        java.lang.Integer int55 = dateTimeParserBucket54.getOffsetInteger();
//        boolean boolean57 = dateTimeParserBucket54.restoreState((java.lang.Object) 4);
//        int int58 = dateTimeParserBucket54.getOffset();
//        java.util.Locale locale59 = dateTimeParserBucket54.getLocale();
//        java.lang.String str62 = defaultNameProvider45.getShortName(locale59, "2019-W24-3", "2019163T061308.342");
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket64 = new org.joda.time.format.DateTimeParserBucket((long) 2000, (org.joda.time.Chronology) julianChronology43, locale59, (java.lang.Integer) (-8));
//        java.lang.String str65 = delegatedDateTimeField29.getAsText(10799999L, locale59);
//        long long67 = delegatedDateTimeField29.roundFloor(31507200010L);
//        org.junit.Assert.assertNotNull(buddhistChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(gJChronology13);
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(localDateTime21);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(localDateTime39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "2019163T061424.117" + "'", str40.equals("2019163T061424.117"));
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(julianChronology43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNull(int55);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
//        org.junit.Assert.assertNotNull(locale59);
//        org.junit.Assert.assertNull(str62);
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "6" + "'", str65.equals("6"));
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 31507200000L + "'", long67 == 31507200000L);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMonthOfYear((int) (short) 10);
        int int7 = dateTime3.getCenturyOfEra();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(readableDuration13, (int) 'a');
        org.joda.time.DateTime.Property property16 = dateTime11.centuryOfEra();
        org.joda.time.DateTime dateTime17 = property16.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
        org.joda.time.DateTime dateTime20 = dateTime17.withHourOfDay(0);
        org.joda.time.DateTime dateTime22 = dateTime20.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = dateTime22.toDateTimeISO();
        org.joda.time.DateTime dateTime24 = dateTime22.withTimeAtStartOfDay();
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime3, (org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.DateTime.Property property26 = dateTime3.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(property26);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
//        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
//        int int5 = dateTime3.getDayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone6 = null;
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
//        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        boolean boolean12 = dateTime9.isSupported(dateTimeFieldType11);
//        org.joda.time.DateTime dateTime13 = dateTime9.withLaterOffsetAtOverlap();
//        boolean boolean14 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
//        org.joda.time.DateTime dateTime17 = dateTime13.minusMonths(0);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(localDateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(localDateTime10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded(readableDuration9, (int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime7.centuryOfEra();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType14, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder18.clear();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.plus(readablePeriod22);
        org.joda.time.LocalDateTime localDateTime24 = dateTime23.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.DateTime dateTime27 = dateTime23.withDurationAdded(readableDuration25, (int) 'a');
        org.joda.time.DateTime.Property property28 = dateTime23.centuryOfEra();
        org.joda.time.DateTime.Property property29 = dateTime23.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder18.appendSignedDecimal(dateTimeFieldType30, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType30, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder3.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DurationField durationField5 = buddhistChronology1.hours();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("12", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder5.setStandardOffset((int) '4');
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder5.addRecurringSavings("Property[secondOfDay]", (-8), (int) (byte) -1, (int) (short) 100, '4', 115, 19, (int) (short) 1, true, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfEven();
        java.lang.String str12 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime14 = property9.add(0);
        org.joda.time.MutableDateTime mutableDateTime15 = property9.roundFloor();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[secondOfDay]" + "'", str12.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime14);
        org.junit.Assert.assertNotNull(mutableDateTime15);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-10));
        org.joda.time.Chronology chronology3 = dateTimeFormatter2.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology1.era();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        java.lang.String str71 = dividedDateTimeField69.getName();
        long long73 = dividedDateTimeField69.roundHalfCeiling((long) 12);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "dayOfMonth" + "'", str71.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-14400000L) + "'", long73 == (-14400000L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.DateTimeUtils.getPeriodType(periodType10);
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) mutableDateTime5, (java.lang.Object) periodType11);
        org.joda.time.ReadableDuration readableDuration13 = null;
        mutableDateTime5.add(readableDuration13);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.plus(readablePeriod17);
        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.withDurationAdded(readableDuration20, (int) 'a');
        org.joda.time.DateTime.Property property23 = dateTime18.centuryOfEra();
        org.joda.time.DateTime.Property property24 = dateTime18.era();
        mutableDateTime5.setMillis((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = null;
        try {
            int int27 = dateTime18.get(dateTimeFieldType26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant0.plus(readableDuration3);
        org.joda.time.Instant instant5 = instant0.toInstant();
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.minus(readableDuration6);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime dateTime9 = dateTime3.minusYears(0);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField11 = buddhistChronology10.millis();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology10.hourOfHalfday();
        org.joda.time.DurationField durationField13 = buddhistChronology10.weekyears();
        org.joda.time.DurationField durationField14 = buddhistChronology10.weeks();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        org.joda.time.Chronology chronology18 = buddhistChronology10.withZone(dateTimeZone16);
        org.joda.time.DateTime dateTime19 = dateTime3.toDateTime((org.joda.time.Chronology) buddhistChronology10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime dateTime12 = dateTime9.withHourOfDay(0);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime.Property property15 = dateTime12.dayOfWeek();
        org.joda.time.DateTime dateTime17 = property15.addToCopy((long) (byte) 1);
        org.joda.time.DateTime dateTime18 = property15.getDateTime();
        long long19 = property15.remainder();
        java.lang.String str20 = property15.getName();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "dayOfWeek" + "'", str20.equals("dayOfWeek"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField71 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        long long73 = remainderDateTimeField71.roundHalfFloor((long) 292279588);
        boolean boolean74 = remainderDateTimeField71.isLenient();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 291600000L + "'", long73 == 291600000L);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime13 = property9.add(0L);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.secondOfDay();
        java.lang.Object obj15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(obj15);
        mutableDateTime13.setTime((org.joda.time.ReadableInstant) mutableDateTime16);
        org.joda.time.ReadableDuration readableDuration18 = null;
        mutableDateTime16.add(readableDuration18, 22436442);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        boolean boolean71 = dividedDateTimeField69.isLenient();
        long long73 = dividedDateTimeField69.roundFloor((long) 41);
        int int76 = dividedDateTimeField69.getDifference(0L, (-1L));
        long long79 = dividedDateTimeField69.add(10799999L, 0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-14400000L) + "'", long73 == (-14400000L));
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 10799999L + "'", long79 == 10799999L);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
//        org.joda.time.DurationField durationField2 = buddhistChronology1.millis();
//        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
//        int int4 = instant0.get(dateTimeField3);
//        org.joda.time.Instant instant6 = instant0.minus(0L);
//        org.joda.time.Instant instant7 = instant0.toInstant();
//        org.joda.time.DateTime dateTime8 = instant7.toDateTimeISO();
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(buddhistChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertNotNull(instant7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime3.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMillis(10);
        org.joda.time.DateTime.Property property9 = dateTime8.hourOfDay();
        org.joda.time.Instant instant10 = dateTime8.toInstant();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology4, dateTimeZone10);
        org.joda.time.DurationField durationField13 = zonedChronology12.weekyears();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) zonedChronology12);
        java.lang.String str15 = zonedChronology12.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ZonedChronology[GJChronology[UTC], +00:00:00.001]" + "'", str15.equals("ZonedChronology[GJChronology[UTC], +00:00:00.001]"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, dateTimeZone9);
        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone16 = dateTimeZoneBuilder13.toDateTimeZone("12", false);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        org.joda.time.Chronology chronology18 = zonedChronology11.withZone(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(chronology18);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        boolean boolean9 = gJChronology3.equals((java.lang.Object) "0");
        org.joda.time.DurationField durationField10 = gJChronology3.weekyears();
        org.joda.time.DateTimeField dateTimeField11 = gJChronology3.weekyear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.lang.Object obj0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
        mutableDateTime1.setYear((int) (byte) 100);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.dayOfWeek();
        org.joda.time.MutableDateTime mutableDateTime6 = property4.add(960);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime6);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-99L), 70171164L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-70171263L) + "'", long2 == (-70171263L));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        try {
            org.joda.time.DateTime dateTime10 = property8.setCopy((-292268459));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -292268459 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
        int int4 = instant0.get(dateTimeField3);
        org.joda.time.Instant instant6 = instant0.minus(0L);
        org.joda.time.Instant instant7 = instant0.toInstant();
        org.joda.time.Instant instant10 = instant0.withDurationAdded((-99L), 14);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        long long4 = durationField1.subtract((long) (-10), 0);
        long long7 = durationField1.subtract((-15588346022000L), (long) 4);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-10L) + "'", long4 == (-10L));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-15588346022004L) + "'", long7 == (-15588346022004L));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter0.parseLocalDateTime("2019163T061410.826");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019163T061410.826\" is malformed at \"T061410.826\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("dayOfWeek");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"dayOfWeek\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(31507200115L);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone4.getUncachedZone();
        long long9 = cachedDateTimeZone4.nextTransition((-98250L));
        boolean boolean10 = cachedDateTimeZone4.isFixed();
        long long12 = cachedDateTimeZone4.previousTransition(35L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-98250L) + "'", long9 == (-98250L));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 35L + "'", long12 == 35L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfEven();
        java.lang.String str12 = property9.toString();
        org.joda.time.chrono.BuddhistChronology buddhistChronology14 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField15 = buddhistChronology14.millis();
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology14.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField18 = buddhistChronology17.millis();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology17);
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology17.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology14, dateTimeField20, (int) ' ');
        boolean boolean23 = skipUndoDateTimeField22.isSupported();
        java.lang.String str24 = skipUndoDateTimeField22.toString();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28);
        java.util.Locale locale30 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket33 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology29, locale30, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField35 = buddhistChronology34.millis();
        org.joda.time.DateTimeField dateTimeField36 = buddhistChronology34.hourOfHalfday();
        org.joda.time.DurationField durationField37 = buddhistChronology34.weekyears();
        org.joda.time.DurationField durationField38 = buddhistChronology34.weeks();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now(dateTimeZone40);
        org.joda.time.Chronology chronology42 = buddhistChronology34.withZone(dateTimeZone40);
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone40);
        dateTimeParserBucket33.setZone(dateTimeZone40);
        java.util.Locale locale45 = dateTimeParserBucket33.getLocale();
        java.lang.String str46 = skipUndoDateTimeField22.getAsShortText((int) (short) 0, locale45);
        try {
            org.joda.time.MutableDateTime mutableDateTime47 = property9.set("ZonedChronology[GJChronology[UTC], +00:00:00.001]", locale45);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ZonedChronology[GJChronology[UTC], +00:00:00.001]\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[secondOfDay]" + "'", str12.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(buddhistChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str24.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(locale45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "0" + "'", str46.equals("0"));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfSecond(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        dateTimeFormatterBuilder6.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = delegatedDateTimeField29.getType();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        java.lang.String str10 = dateTimeZone8.getName((long) (short) 10);
        try {
            org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((int) '4', 7, 292278919, (int) (short) 1, 14, 0, 411, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278919 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("061319-0700");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"061319-0700\" is malformed at \"0\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, dateTimeZone9);
        org.joda.time.DurationField durationField12 = zonedChronology11.eras();
        org.joda.time.Chronology chronology13 = zonedChronology11.withUTC();
        java.lang.String str14 = zonedChronology11.toString();
        try {
            long long22 = zonedChronology11.getDateTimeMillis(2019, 13, 1, (int) 'a', 0, 10, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ZonedChronology[GJChronology[UTC], +00:00:00.001]" + "'", str14.equals("ZonedChronology[GJChronology[UTC], +00:00:00.001]"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfMinute(0, (int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendPattern("5");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 6, "507");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DurationField durationField8 = gJChronology3.days();
        long long13 = gJChronology3.getDateTimeMillis(19, 10, 3, 2019);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.plus(readablePeriod17);
        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
        java.lang.String str20 = dateTimeFormatter14.print((org.joda.time.ReadablePartial) localDateTime19);
        int[] intArray22 = gJChronology3.get((org.joda.time.ReadablePartial) localDateTime19, 0L);
        try {
            long long27 = gJChronology3.getDateTimeMillis(0, 5, (int) '4', 411);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-61544015997982L) + "'", long13 == (-61544015997982L));
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1969365T160000.000" + "'", str20.equals("1969365T160000.000"));
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        mutableDateTime0.setSecondOfMinute(12);
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime0.add(readableDuration4, 12);
        mutableDateTime0.setMillis((long) 18);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField11 = buddhistChronology10.millis();
        org.joda.time.DateTimeField dateTimeField12 = buddhistChronology10.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology13 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField14 = buddhistChronology13.millis();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology13);
        org.joda.time.DateTimeField dateTimeField16 = buddhistChronology13.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology10, dateTimeField16, (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone19 = buddhistChronology10.getZone();
        org.joda.time.DateTimeField dateTimeField20 = buddhistChronology10.clockhourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField21 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology9, dateTimeField20);
        org.joda.time.DateTimeField dateTimeField22 = buddhistChronology9.year();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder23.clear();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime26.plus(readablePeriod27);
        org.joda.time.LocalDateTime localDateTime29 = dateTime28.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration30 = null;
        org.joda.time.DateTime dateTime32 = dateTime28.withDurationAdded(readableDuration30, (int) 'a');
        org.joda.time.DateTime.Property property33 = dateTime28.centuryOfEra();
        org.joda.time.DateTime.Property property34 = dateTime28.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder23.appendSignedDecimal(dateTimeFieldType35, 411, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41);
        java.util.Locale locale43 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology42, locale43, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone48);
        org.joda.time.chrono.ZonedChronology zonedChronology50 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology42, dateTimeZone48);
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
        org.joda.time.DateTimeField dateTimeField52 = iSOChronology51.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone53 = null;
        org.joda.time.DateTime dateTime54 = new org.joda.time.DateTime(dateTimeZone53);
        org.joda.time.ReadablePeriod readablePeriod55 = null;
        org.joda.time.DateTime dateTime56 = dateTime54.plus(readablePeriod55);
        org.joda.time.LocalDateTime localDateTime57 = dateTime56.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration58 = null;
        org.joda.time.DateTime dateTime60 = dateTime56.withDurationAdded(readableDuration58, (int) 'a');
        org.joda.time.DateTime.Property property61 = dateTime56.centuryOfEra();
        org.joda.time.DateTime.Property property62 = dateTime56.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = property62.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField64 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField52, dateTimeFieldType63);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder23.appendSignedDecimal(dateTimeFieldType63, 1, 4);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField69 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, dateTimeFieldType63, (int) '4');
        org.joda.time.DurationField durationField70 = offsetDateTimeField69.getDurationField();
        try {
            mutableDateTime0.setRounding((org.joda.time.DateTimeField) offsetDateTimeField69, (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal rounding mode: -2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(buddhistChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(gJChronology49);
        org.junit.Assert.assertNotNull(zonedChronology50);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(localDateTime57);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(dateTimeFieldType63);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException7.getSuppressed();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.Number number10 = illegalFieldValueException7.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType14 = illegalFieldValueException13.getDurationFieldType();
        java.lang.Number number15 = illegalFieldValueException13.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.Throwable[] throwableArray19 = illegalFieldValueException18.getSuppressed();
        illegalFieldValueException13.addSuppressed((java.lang.Throwable) illegalFieldValueException18);
        illegalFieldValueException7.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        java.lang.String str22 = illegalFieldValueException13.getFieldName();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertNull(durationFieldType14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = mutableDateTime0.getRoundingField();
        int int3 = mutableDateTime0.getMillisOfSecond();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.centuryOfEra();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime3.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMillis(10);
        org.joda.time.DateTime dateTime10 = dateTime3.plusMinutes(0);
        org.joda.time.DateTime dateTime12 = dateTime3.withMinuteOfHour(19);
        org.joda.time.DateTime dateTime14 = dateTime3.minusMonths(10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology0.weekyears();
        org.joda.time.DurationField durationField4 = buddhistChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.Chronology chronology8 = buddhistChronology0.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime((java.lang.Object) dateTime9);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (-2));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology4, dateTimeZone10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology13.hourOfHalfday();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((java.lang.Object) (-98250L), (org.joda.time.Chronology) iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
        int int4 = instant0.get(dateTimeField3);
        org.joda.time.Instant instant6 = instant0.minus(0L);
        org.joda.time.Instant instant7 = instant0.toInstant();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant10 = instant7.withDurationAdded(readableDuration8, 292279588);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int int0 = org.joda.time.MutableDateTime.ROUND_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfEven();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField13 = buddhistChronology12.millis();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology12.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17);
        java.util.Locale locale19 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology18, locale19, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology18, dateTimeZone24);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime30.plus(readablePeriod31);
        org.joda.time.LocalDateTime localDateTime33 = dateTime32.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.DateTime dateTime36 = dateTime32.withDurationAdded(readableDuration34, (int) 'a');
        org.joda.time.DateTime.Property property37 = dateTime32.centuryOfEra();
        org.joda.time.DateTime.Property property38 = dateTime32.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28, dateTimeFieldType39);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType39);
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime11.property(dateTimeFieldType39);
        org.joda.time.MutableDateTime.Property property43 = mutableDateTime11.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(zonedChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(property43);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        java.util.GregorianCalendar gregorianCalendar8 = dateTime3.toGregorianCalendar();
        try {
            org.joda.time.DateTime dateTime10 = dateTime3.withYearOfEra((-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(gregorianCalendar8);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime3.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMillis(10);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillisOfDay((int) (byte) 0);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths(2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        mutableDateTime0.addMillis(100);
        mutableDateTime0.setTime(0, 6, (int) (short) 1, (int) '4');
        mutableDateTime0.setMillisOfDay((int) (byte) 100);
        boolean boolean11 = mutableDateTime0.isBeforeNow();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        boolean boolean4 = dateTimeZone1.isStandardOffset(100L);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("061319-0700");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("061319-0700");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        jodaTimePermission1.checkGuard((java.lang.Object) "1970");
        java.lang.String str7 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection8 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str9 = jodaTimePermission1.getActions();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"061319-0700\")" + "'", str7.equals("(\"org.joda.time.JodaTimePermission\" \"061319-0700\")"));
        org.junit.Assert.assertNotNull(permissionCollection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(0L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstance();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket3 = new org.joda.time.format.DateTimeParserBucket((-10L), (org.joda.time.Chronology) julianChronology1, locale2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.Chronology chronology5 = julianChronology1.withZone(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology1.getZone();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        mutableDateTime4.setMonthOfYear((int) (byte) 1);
        mutableDateTime4.addMinutes((int) (byte) 10);
        int int10 = mutableDateTime4.getHourOfDay();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology11.hourOfHalfday();
        org.joda.time.DurationField durationField14 = buddhistChronology11.weekyears();
        org.joda.time.DurationField durationField15 = buddhistChronology11.weeks();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.Chronology chronology19 = buddhistChronology11.withZone(dateTimeZone17);
        mutableDateTime4.setZoneRetainFields(dateTimeZone17);
        mutableDateTime4.addYears((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfEven();
        java.lang.String str12 = property9.toString();
        long long13 = property9.remainder();
        int int14 = property9.get();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Property[secondOfDay]" + "'", str12.equals("Property[secondOfDay]"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 20, (-292268459), 22463);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfEven();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField13 = buddhistChronology12.millis();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology12.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17);
        java.util.Locale locale19 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology18, locale19, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology18, dateTimeZone24);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime30.plus(readablePeriod31);
        org.joda.time.LocalDateTime localDateTime33 = dateTime32.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.DateTime dateTime36 = dateTime32.withDurationAdded(readableDuration34, (int) 'a');
        org.joda.time.DateTime.Property property37 = dateTime32.centuryOfEra();
        org.joda.time.DateTime.Property property38 = dateTime32.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28, dateTimeFieldType39);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType39);
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime11.property(dateTimeFieldType39);
        mutableDateTime11.setMinuteOfHour(12);
        org.joda.time.DurationFieldType durationFieldType45 = null;
        try {
            mutableDateTime11.add(durationFieldType45, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(zonedChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(property42);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean6 = cachedDateTimeZone4.equals((java.lang.Object) "June 12, 2019 6:13:21 AM PDT");
        int int8 = cachedDateTimeZone4.getOffset((long) 22403);
        java.lang.String str10 = cachedDateTimeZone4.getName(11L);
        int int12 = cachedDateTimeZone4.getOffset(36L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.plus(readablePeriod16);
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime15.toMutableDateTime();
        int int21 = dateTimeFormatter13.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime18, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime18.secondOfDay();
        java.lang.String str23 = property22.toString();
        org.joda.time.MutableDateTime mutableDateTime25 = property22.add(43200100L);
        boolean boolean26 = cachedDateTimeZone4.equals((java.lang.Object) mutableDateTime25);
        mutableDateTime25.setWeekyear(11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[secondOfDay]" + "'", str23.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        try {
            org.joda.time.LocalDateTime localDateTime3 = dateTimeFormatter0.parseLocalDateTime("2019163T061308.688");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019163T061308.688\" is malformed at \"T061308.688\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundFloorCopy();
        org.joda.time.DateTime.Property property10 = dateTime9.year();
        org.joda.time.DateTime dateTime12 = property10.addToCopy((long) 5);
        org.joda.time.DateTime dateTime14 = property10.setCopy("6");
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime dateTime12 = dateTime9.withHourOfDay(0);
        org.joda.time.DateTime.Property property13 = dateTime9.year();
        java.lang.String str14 = property13.getName();
        java.lang.String str15 = property13.getAsShortText();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "year" + "'", str14.equals("year"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "2000" + "'", str15.equals("2000"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        boolean boolean9 = gJChronology3.equals((java.lang.Object) "0");
        org.joda.time.DurationField durationField10 = gJChronology3.weekyears();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField12 = new org.joda.time.field.DecoratedDurationField(durationField10, durationFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour(18);
        int int5 = dateTime2.getWeekyear();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        mutableDateTime0.addMonths((int) (short) 10);
        mutableDateTime0.setMillisOfSecond((int) '#');
        java.lang.String str7 = mutableDateTime0.toString("1970");
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime0.millisOfDay();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970" + "'", str7.equals("1970"));
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear(10);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime dateTime12 = dateTime9.withHourOfDay(0);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime.Property property15 = dateTime12.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime19.withZoneRetainFields(dateTimeZone24);
        int int26 = dateTime25.getDayOfWeek();
        int int27 = property15.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime dateTime28 = dateTime25.toDateTime();
        try {
            org.joda.time.DateTime dateTime30 = dateTime28.withEra(10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10957 + "'", int27 == 10957);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField71 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        int int73 = remainderDateTimeField71.get(0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime dateTime12 = dateTime9.withHourOfDay(0);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime.Property property15 = dateTime12.dayOfWeek();
        org.joda.time.DateTime dateTime17 = property15.addToCopy((long) (byte) 1);
        org.joda.time.DateTime dateTime19 = dateTime17.withHourOfDay(22);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.io.Writer writer1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField3 = buddhistChronology2.millis();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField6 = buddhistChronology5.millis();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology5.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField8, (int) ' ');
        boolean boolean11 = skipUndoDateTimeField10.isSupported();
        java.lang.String str12 = skipUndoDateTimeField10.toString();
        long long14 = skipUndoDateTimeField10.roundHalfEven(0L);
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField16 = buddhistChronology15.millis();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology15.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField19 = buddhistChronology18.millis();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology18);
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology18.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField21, (int) ' ');
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField23.getAsShortText((int) (short) 0, locale25);
        java.lang.String str28 = skipUndoDateTimeField23.getAsShortText((long) (byte) 10);
        boolean boolean30 = skipUndoDateTimeField23.isLeap((long) 3);
        org.joda.time.chrono.BuddhistChronology buddhistChronology31 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField32 = buddhistChronology31.millis();
        org.joda.time.DateTimeField dateTimeField33 = buddhistChronology31.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology34 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField35 = buddhistChronology34.millis();
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology34);
        org.joda.time.DateTimeField dateTimeField37 = buddhistChronology34.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField39 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology31, dateTimeField37, (int) ' ');
        boolean boolean40 = skipUndoDateTimeField39.isSupported();
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime(dateTimeZone41);
        org.joda.time.ReadablePeriod readablePeriod43 = null;
        org.joda.time.DateTime dateTime44 = dateTime42.plus(readablePeriod43);
        org.joda.time.LocalDateTime localDateTime45 = dateTime44.toLocalDateTime();
        java.util.Locale locale46 = null;
        java.lang.String str47 = skipUndoDateTimeField39.getAsShortText((org.joda.time.ReadablePartial) localDateTime45, locale46);
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology48.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now(dateTimeZone51);
        long long55 = dateTimeZone51.adjustOffset((long) (byte) -1, true);
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.DateTime dateTime59 = new org.joda.time.DateTime(dateTimeZone58);
        org.joda.time.ReadablePeriod readablePeriod60 = null;
        org.joda.time.DateTime dateTime61 = dateTime59.plus(readablePeriod60);
        org.joda.time.LocalDateTime localDateTime62 = dateTime61.toLocalDateTime();
        boolean boolean63 = dateTimeZone57.isLocalDateTimeGap(localDateTime62);
        boolean boolean64 = dateTimeZone51.isLocalDateTimeGap(localDateTime62);
        int[] intArray66 = gregorianChronology48.get((org.joda.time.ReadablePartial) localDateTime62, 110L);
        int int67 = skipUndoDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) localDateTime45, intArray66);
        org.joda.time.DateTimeZone dateTimeZone70 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone70);
        java.util.Locale locale72 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket75 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology71, locale72, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DurationField durationField76 = gJChronology71.days();
        long long81 = gJChronology71.getDateTimeMillis(19, 10, 3, 2019);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter82 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone83 = null;
        org.joda.time.DateTime dateTime84 = new org.joda.time.DateTime(dateTimeZone83);
        org.joda.time.ReadablePeriod readablePeriod85 = null;
        org.joda.time.DateTime dateTime86 = dateTime84.plus(readablePeriod85);
        org.joda.time.LocalDateTime localDateTime87 = dateTime86.toLocalDateTime();
        java.lang.String str88 = dateTimeFormatter82.print((org.joda.time.ReadablePartial) localDateTime87);
        int[] intArray90 = gJChronology71.get((org.joda.time.ReadablePartial) localDateTime87, 0L);
        int int91 = skipUndoDateTimeField10.getMinimumValue((org.joda.time.ReadablePartial) localDateTime45, intArray90);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) localDateTime45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str12.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "0" + "'", str26.equals("0"));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "0" + "'", str28.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(buddhistChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(buddhistChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(localDateTime45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "11" + "'", str47.equals("11"));
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-1L) + "'", long55 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(localDateTime62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone70);
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(durationField76);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + (-61544015997982L) + "'", long81 == (-61544015997982L));
        org.junit.Assert.assertNotNull(dateTimeFormatter82);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(localDateTime87);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "1969365T235959.999" + "'", str88.equals("1969365T235959.999"));
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        java.lang.Integer int8 = dateTimeParserBucket7.getOffsetInteger();
        boolean boolean10 = dateTimeParserBucket7.restoreState((java.lang.Object) 4);
        int int11 = dateTimeParserBucket7.getOffset();
        java.util.Locale locale12 = dateTimeParserBucket7.getLocale();
        dateTimeParserBucket7.setOffset((java.lang.Integer) 19);
        long long15 = dateTimeParserBucket7.computeMillis();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        java.util.Locale locale20 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology19, locale20, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime25.plus(readablePeriod26);
        org.joda.time.LocalDateTime localDateTime28 = dateTime27.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration29 = null;
        org.joda.time.DateTime dateTime31 = dateTime27.withDurationAdded(readableDuration29, (int) 'a');
        org.joda.time.DateTime dateTime33 = dateTime31.minusMonths((-10));
        boolean boolean34 = dateTimeParserBucket23.restoreState((java.lang.Object) dateTime31);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37);
        java.util.Locale locale39 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket42 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology38, locale39, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology45 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone44);
        org.joda.time.chrono.ZonedChronology zonedChronology46 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology38, dateTimeZone44);
        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField48 = iSOChronology47.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.DateTime dateTime50 = new org.joda.time.DateTime(dateTimeZone49);
        org.joda.time.ReadablePeriod readablePeriod51 = null;
        org.joda.time.DateTime dateTime52 = dateTime50.plus(readablePeriod51);
        org.joda.time.LocalDateTime localDateTime53 = dateTime52.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration54 = null;
        org.joda.time.DateTime dateTime56 = dateTime52.withDurationAdded(readableDuration54, (int) 'a');
        org.joda.time.DateTime.Property property57 = dateTime52.centuryOfEra();
        org.joda.time.DateTime.Property property58 = dateTime52.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType59 = property58.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField60 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48, dateTimeFieldType59);
        java.util.Locale locale62 = null;
        dateTimeParserBucket23.saveField(dateTimeFieldType59, "32", locale62);
        java.util.Locale locale65 = null;
        dateTimeParserBucket7.saveField(dateTimeFieldType59, "year", locale65);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNull(int8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(locale12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-29L) + "'", long15 == (-29L));
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(localDateTime28);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(gJChronology45);
        org.junit.Assert.assertNotNull(zonedChronology46);
        org.junit.Assert.assertNotNull(iSOChronology47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(localDateTime53);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(dateTimeFieldType59);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology0.weekyears();
        org.joda.time.DurationField durationField4 = buddhistChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.Chronology chronology8 = buddhistChronology0.withZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.secondOfDay();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        java.lang.String str7 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) localDateTime6);
        boolean boolean8 = dateTimeFormatter1.isOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) julianChronology10);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider12 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology17, locale18, (java.lang.Integer) 4, (int) 'a');
        java.lang.Integer int22 = dateTimeParserBucket21.getOffsetInteger();
        boolean boolean24 = dateTimeParserBucket21.restoreState((java.lang.Object) 4);
        int int25 = dateTimeParserBucket21.getOffset();
        java.util.Locale locale26 = dateTimeParserBucket21.getLocale();
        java.lang.String str29 = defaultNameProvider12.getShortName(locale26, "2019-W24-3", "2019163T061308.342");
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 2000, (org.joda.time.Chronology) julianChronology10, locale26, (java.lang.Integer) (-8));
        org.joda.time.DurationField durationField32 = julianChronology10.months();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969365T235959.999" + "'", str7.equals("1969365T235959.999"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNull(int22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(locale26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(durationField32);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        long long5 = dateTimeZone1.adjustOffset((long) (byte) -1, true);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        mutableDateTime6.setSecondOfDay((int) (byte) 10);
        mutableDateTime6.addMonths((int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime6.copy();
        mutableDateTime6.addYears(22403);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        mutableDateTime4.setMonthOfYear((int) (byte) 1);
        try {
            mutableDateTime4.setWeekOfWeekyear(2922789);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("061319-0700");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("061319-0700");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.security.PermissionCollection permissionCollection5 = jodaTimePermission3.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(permissionCollection5);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        boolean boolean71 = dividedDateTimeField69.isLenient();
        long long74 = dividedDateTimeField69.getDifferenceAsLong((-61544015997982L), 43200100L);
        java.lang.String str76 = dividedDateTimeField69.getAsShortText((long) (short) -1);
        long long79 = dividedDateTimeField69.getDifferenceAsLong((-99L), (long) 41);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-98250L) + "'", long74 == (-98250L));
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "0" + "'", str76.equals("0"));
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 0L + "'", long79 == 0L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime3.minusWeeks((-10));
        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
        try {
            org.joda.time.DateTime dateTime11 = dateTime8.withYearOfEra(292279588);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292279588 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6047999998L + "'", long9 == 6047999998L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property9.getAsText(locale11);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.roundHalfEven();
        java.lang.String str14 = mutableDateTime13.toString();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "86399" + "'", str12.equals("86399"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970-01-01T00:00:00.000+00:00:00.001" + "'", str14.equals("1970-01-01T00:00:00.000+00:00:00.001"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime.Property property9 = dateTime3.era();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime3.plus(readableDuration10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        int int4 = julianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.LocalDateTime localDateTime7 = dateTimeFormatter5.parseLocalDateTime("4");
        long long9 = julianChronology3.set((org.joda.time.ReadablePartial) localDateTime7, (-61544015997982L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1137599999L + "'", long9 == 1137599999L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) '#', (-2), 6, 411, (-292268459));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 411 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        long long72 = delegatedDateTimeField29.add((-4320000000L), (long) (short) 10);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + (-4284000000L) + "'", long72 == (-4284000000L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.minusYears(24);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        mutableDateTime4.setMonthOfYear((int) (byte) 1);
        mutableDateTime4.addMinutes((int) (byte) 10);
        int int10 = mutableDateTime4.getHourOfDay();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime4.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        long long5 = dateTimeZone1.adjustOffset((long) (byte) -1, true);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField7 = mutableDateTime6.getRoundingField();
        mutableDateTime6.setMinuteOfHour((int) (byte) 0);
        mutableDateTime6.setWeekyear(24);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNull(dateTimeField7);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTime.Property property3 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property3.addWrapFieldToCopy((-10));
        org.joda.time.DateTime dateTime6 = property3.roundHalfEvenCopy();
        java.lang.String str7 = property3.getAsText();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "999" + "'", str7.equals("999"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime3.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMillis(10);
        org.joda.time.DateTime dateTime10 = dateTime3.withMillisOfSecond((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        java.util.Date date9 = mutableDateTime5.toDate();
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime5.hourOfDay();
        int int11 = mutableDateTime5.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology0.weekyears();
        org.joda.time.DurationField durationField4 = buddhistChronology0.weeks();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded(readableDuration9, (int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime7.centuryOfEra();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType14, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder19.appendEraText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendDayOfWeek(87);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime.Property property7 = dateTime3.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        boolean boolean71 = dividedDateTimeField69.isLenient();
        long long73 = dividedDateTimeField69.roundFloor((long) 41);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        try {
            long long77 = dividedDateTimeField69.set(31507200010L, 22436442);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 22436442 for dayOfMonth must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-1L) + "'", long73 == (-1L));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException7.getSuppressed();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.String str10 = illegalFieldValueException2.getIllegalValueAsString();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfSecond(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendMonthOfYear(59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.toDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime3.withPeriodAdded(readablePeriod7, (-10));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology13, locale14, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone19);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology13, dateTimeZone19);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
        org.joda.time.MutableDateTime mutableDateTime23 = dateTime9.toMutableDateTime(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(mutableDateTime23);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setMillisOfDay(4);
        int int3 = mutableDateTime0.getRoundingMode();
        try {
            mutableDateTime0.setTime(41, 22463, 22403, 59);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 41 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        illegalFieldValueException2.prependMessage("12");
        java.lang.String str6 = illegalFieldValueException2.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.withDurationAdded(readableDuration7, (int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime5.centuryOfEra();
        org.joda.time.DateTime.Property property11 = dateTime5.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType12, 411, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        java.util.Locale locale20 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology19, locale20, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology19, dateTimeZone25);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
        org.joda.time.LocalDateTime localDateTime34 = dateTime33.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime37 = dateTime33.withDurationAdded(readableDuration35, (int) 'a');
        org.joda.time.DateTime.Property property38 = dateTime33.centuryOfEra();
        org.joda.time.DateTime.Property property39 = dateTime33.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29, dateTimeFieldType40);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType40, 1, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder0.appendDayOfMonth(5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.Chronology chronology48 = dateTimeFormatter47.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter50 = dateTimeFormatter47.withPivotYear((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder0.append(dateTimeFormatter47);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder54 = dateTimeFormatterBuilder0.appendFractionOfSecond((int) (byte) 100, (int) (byte) 100);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap55 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder56 = dateTimeFormatterBuilder54.appendTimeZoneShortName(strMap55);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeFormatter47);
        org.junit.Assert.assertNull(chronology48);
        org.junit.Assert.assertNotNull(dateTimeFormatter50);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder54);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder56);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property9.getAsText(locale11);
        try {
            org.joda.time.MutableDateTime mutableDateTime14 = property9.set("June 12, 2019 6:13:21 AM PDT");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"June 12, 2019 6:13:21 AM PDT\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "86399" + "'", str12.equals("86399"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("061323-0700");
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((int) (short) 0, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField8.getDurationField();
        int int15 = skipUndoDateTimeField8.getDifference(43200100L, (-99L));
        long long17 = skipUndoDateTimeField8.roundFloor(11L);
        long long19 = skipUndoDateTimeField8.remainder(31507200000L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1L + "'", long19 == 1L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Instant instant4 = instant0.plus(readableDuration3);
        org.joda.time.Instant instant5 = instant0.toInstant();
        boolean boolean7 = instant0.isAfter((long) (-8));
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, dateTimeZone9);
        org.joda.time.DurationField durationField12 = zonedChronology11.eras();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology16, locale17, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
        org.joda.time.LocalDateTime localDateTime25 = dateTime24.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime28 = dateTime24.withDurationAdded(readableDuration26, (int) 'a');
        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((-10));
        boolean boolean31 = dateTimeParserBucket20.restoreState((java.lang.Object) dateTime28);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTimeParserBucket20.getZone();
        java.lang.String str33 = dateTimeZone32.getID();
        org.joda.time.Chronology chronology34 = zonedChronology11.withZone(dateTimeZone32);
        java.lang.String str35 = dateTimeZone32.toString();
        int int37 = dateTimeZone32.getOffsetFromLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00:00.001" + "'", str33.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "+00:00:00.001" + "'", str35.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths((-10));
        org.joda.time.DateTime dateTime11 = dateTime7.withMillis((long) (byte) 0);
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((java.lang.Object) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(7, 24, 2, (int) (byte) 100, (int) (short) 100, 22403, 22457);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        mutableDateTime0.setSecondOfMinute(12);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.DateTime dateTime9 = dateTime7.toDateTime();
        mutableDateTime0.setMillis((org.joda.time.ReadableInstant) dateTime7);
        mutableDateTime0.addDays((int) (short) 10);
        mutableDateTime0.setMinuteOfDay(0);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withSecondOfMinute(0);
        org.joda.time.DateTime.Property property6 = dateTime3.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = dateTime3.getDayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime9.isSupported(dateTimeFieldType11);
        org.joda.time.DateTime dateTime13 = dateTime9.withLaterOffsetAtOverlap();
        boolean boolean14 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        org.joda.time.DateTime dateTime16 = dateTime13.toDateTimeISO();
        org.joda.time.DateTime dateTime18 = dateTime13.plusDays(6);
        org.joda.time.DateTime dateTime20 = dateTime13.minusHours(0);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (byte) 0);
        mutableDateTime1.addMinutes((int) (short) 0);
        int int4 = mutableDateTime1.getRoundingMode();
        mutableDateTime1.setHourOfDay(0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.Instant instant3 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant3.minus(readableDuration4);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.withDurationAdded(readableDuration11, (int) 'a');
        org.joda.time.DateTime.Property property14 = dateTime9.centuryOfEra();
        org.joda.time.DateTime dateTime15 = property14.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.DateTime dateTime18 = dateTime15.withHourOfDay(0);
        org.joda.time.DateTime dateTime20 = dateTime18.plusMinutes((int) (byte) 0);
        boolean boolean21 = instant5.isBefore((org.joda.time.ReadableInstant) dateTime20);
        try {
            dateTimeFormatter0.printTo(stringBuffer2, (org.joda.time.ReadableInstant) instant5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.getMutableDateTime();
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.yearOfCentury();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime11.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        boolean boolean71 = dividedDateTimeField69.isLenient();
        java.lang.String str72 = dividedDateTimeField69.toString();
        try {
            long long75 = dividedDateTimeField69.set((-15588346022000L), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str72.equals("DateTimeField[dayOfMonth]"));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((int) (short) 0, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField8.getDurationField();
        int int15 = skipUndoDateTimeField8.getDifference(43200100L, (-99L));
        long long17 = skipUndoDateTimeField8.roundFloor(11L);
        int int18 = skipUndoDateTimeField8.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 22457, (int) '#', 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone12 = zonedChronology11.getZone();
        org.joda.time.DateTimeZone dateTimeZone13 = zonedChronology11.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology7, locale8, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DurationField durationField12 = gJChronology7.days();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology7.clockhourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(92234312172022403L, 2440588L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 92234312172022403 * 2440588");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime3.minusWeeks((-10));
        org.joda.time.DateTime.Property property9 = dateTime8.year();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        java.lang.String str10 = skipUndoDateTimeField8.toString();
        long long12 = skipUndoDateTimeField8.roundFloor((long) (byte) 100);
        int int13 = skipUndoDateTimeField8.getMinimumValue();
        long long16 = skipUndoDateTimeField8.getDifferenceAsLong(1566436413691L, 3600000L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str10.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 435120L + "'", long16 == 435120L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        long long5 = dateTimeZone1.adjustOffset((long) (byte) -1, true);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        mutableDateTime6.setSecondOfDay((int) (byte) 10);
        mutableDateTime6.addMonths((int) (byte) -1);
        org.joda.time.MutableDateTime mutableDateTime11 = mutableDateTime6.copy();
        try {
            mutableDateTime6.setDateTime(0, 115, 292279588, 22463, 6, (int) (byte) -1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 22463 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        java.lang.Object obj0 = null;
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime(obj0);
        try {
            mutableDateTime1.setDateTime(1970, 1970, 0, (-10), 24, 365, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -10 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime10 = property8.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime10.withZone(dateTimeZone12);
        org.joda.time.DateTime.Property property15 = dateTime14.minuteOfHour();
        org.joda.time.DateTime dateTime17 = dateTime14.withMillisOfDay(5);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusHours(0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property9.roundHalfFloor();
        java.lang.String str11 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime13 = property9.set(12);
        org.joda.time.MutableDateTime mutableDateTime14 = property9.roundHalfFloor();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[secondOfDay]" + "'", str11.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(mutableDateTime14);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setMillisOfDay(4);
        mutableDateTime0.setTime(92234312172022403L);
        org.junit.Assert.assertNotNull(mutableDateTime0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime3.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMillis(10);
        org.joda.time.DateTime dateTime10 = dateTime3.plusMinutes(0);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        java.util.Locale locale15 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket18 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology14, locale15, (java.lang.Integer) 4, (int) 'a');
        boolean boolean20 = gJChronology14.equals((java.lang.Object) "0");
        long long24 = gJChronology14.add((long) 2019, (long) 2922789, 2);
        org.joda.time.DateTime dateTime25 = dateTime3.toDateTime((org.joda.time.Chronology) gJChronology14);
        try {
            org.joda.time.DateTime dateTime27 = dateTime25.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 5847597L + "'", long24 == 5847597L);
        org.junit.Assert.assertNotNull(dateTime25);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        mutableDateTime4.setMonthOfYear((int) (byte) 1);
        mutableDateTime4.addMinutes((int) (byte) 10);
        int int10 = mutableDateTime4.getCenturyOfEra();
        mutableDateTime4.setMillis((long) (byte) 10);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField4 = julianChronology3.days();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology3.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.Chronology chronology1 = gregorianChronology0.withUTC();
        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(chronology1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        int int11 = skipUndoDateTimeField8.getDifference((long) 12, (long) ' ');
        int int13 = skipUndoDateTimeField8.getMinimumValue(10L);
        java.lang.String str15 = skipUndoDateTimeField8.getAsText(8146800002L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "7" + "'", str15.equals("7"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfSecond(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        boolean boolean8 = dateTimeFormatter7.isOffsetParsed();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.append(dateTimeFormatter7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(365, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone3);
        try {
            long long14 = gregorianChronology0.getDateTimeMillis(0, (int) (short) 1, 11, (int) ' ', 19, 24, (-10));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) buddhistChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter0.withZone(dateTimeZone7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withPivotYear(0);
        try {
            org.joda.time.LocalTime localTime13 = dateTimeFormatter11.parseLocalTime("2019163T061421.038");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"2019163T061421.038\" is malformed at \"3T061421.038\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology4, dateTimeZone10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.Chronology chronology14 = iSOChronology13.withUTC();
        org.joda.time.DateTimeZone dateTimeZone15 = iSOChronology13.getZone();
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) '4', (org.joda.time.Chronology) iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        java.lang.Number number4 = illegalFieldValueException2.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("hi!", "");
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException7.getSuppressed();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.String str10 = illegalFieldValueException2.toString();
        java.lang.Number number11 = illegalFieldValueException2.getIllegalNumberValue();
        java.lang.String str12 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertNull(durationFieldType3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported" + "'", str10.equals("org.joda.time.IllegalFieldValueException: Value \"\" for hi! is not supported"));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        boolean boolean9 = gJChronology3.equals((java.lang.Object) "0");
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DurationField durationField11 = gJChronology3.weekyears();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField8.getAsShortText((org.joda.time.ReadablePartial) localDateTime14, locale15);
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField18 = buddhistChronology17.millis();
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology20 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField21 = buddhistChronology20.millis();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology20);
        org.joda.time.DateTimeField dateTimeField23 = buddhistChronology20.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology17, dateTimeField23, (int) ' ');
        boolean boolean26 = skipUndoDateTimeField25.isSupported();
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime(dateTimeZone27);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.DateTime dateTime30 = dateTime28.plus(readablePeriod29);
        org.joda.time.LocalDateTime localDateTime31 = dateTime30.toLocalDateTime();
        java.util.Locale locale32 = null;
        java.lang.String str33 = skipUndoDateTimeField25.getAsShortText((org.joda.time.ReadablePartial) localDateTime31, locale32);
        boolean boolean34 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime31);
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology36.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now(dateTimeZone39);
        long long43 = dateTimeZone39.adjustOffset((long) (byte) -1, true);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTimeZone dateTimeZone46 = null;
        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime(dateTimeZone46);
        org.joda.time.ReadablePeriod readablePeriod48 = null;
        org.joda.time.DateTime dateTime49 = dateTime47.plus(readablePeriod48);
        org.joda.time.LocalDateTime localDateTime50 = dateTime49.toLocalDateTime();
        boolean boolean51 = dateTimeZone45.isLocalDateTimeGap(localDateTime50);
        boolean boolean52 = dateTimeZone39.isLocalDateTimeGap(localDateTime50);
        int[] intArray54 = gregorianChronology36.get((org.joda.time.ReadablePartial) localDateTime50, 110L);
        try {
            int[] intArray56 = skipUndoDateTimeField8.addWrapPartial((org.joda.time.ReadablePartial) localDateTime31, (-2), intArray54, 2922789);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "11" + "'", str16.equals("11"));
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(buddhistChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(localDateTime31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "11" + "'", str33.equals("11"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + (-1L) + "'", long43 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(localDateTime50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(intArray54);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(10L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean6 = cachedDateTimeZone4.equals((java.lang.Object) "June 12, 2019 6:13:21 AM PDT");
        int int8 = cachedDateTimeZone4.getOffset((long) 22403);
        java.lang.String str10 = cachedDateTimeZone4.getName(11L);
        int int12 = cachedDateTimeZone4.getOffset(36L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.plus(readablePeriod16);
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime15.toMutableDateTime();
        int int21 = dateTimeFormatter13.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime18, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime18.secondOfDay();
        java.lang.String str23 = property22.toString();
        org.joda.time.MutableDateTime mutableDateTime25 = property22.add(43200100L);
        boolean boolean26 = cachedDateTimeZone4.equals((java.lang.Object) mutableDateTime25);
        long long28 = cachedDateTimeZone4.previousTransition((long) 7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[secondOfDay]" + "'", str23.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 7L + "'", long28 == 7L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime6.withWeekyear(2);
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
        org.joda.time.DateTime.Property property10 = dateTime8.minuteOfHour();
        org.joda.time.DateTime dateTime11 = property10.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime dateTime9 = dateTime3.minusYears(0);
        boolean boolean10 = dateTime9.isAfterNow();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology6.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(dateTimeZone10);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.plus(readablePeriod12);
        org.joda.time.LocalDateTime localDateTime14 = dateTime13.toLocalDateTime();
        boolean boolean15 = dateTimeZone9.isLocalDateTimeGap(localDateTime14);
        org.joda.time.Chronology chronology16 = gregorianChronology6.withZone(dateTimeZone9);
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((-8), 24, (-1), (int) (short) 1, (int) (byte) 10, 115, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 115 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(localDateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone4 = buddhistChronology3.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendEraText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.withDurationAdded(readableDuration7, (int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime5.centuryOfEra();
        org.joda.time.DateTime.Property property11 = dateTime5.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType12, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder0.appendPattern("");
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime.Property property4 = dateTime3.millisOfDay();
        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
        int int6 = property4.get();
        long long7 = property4.remainder();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 86399999 + "'", int6 == 86399999);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = buddhistChronology0.monthOfYear();
        java.lang.String str2 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[+00:00:00.001]" + "'", str2.equals("BuddhistChronology[+00:00:00.001]"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        boolean boolean71 = dividedDateTimeField69.isLenient();
        java.lang.String str72 = dividedDateTimeField69.toString();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField73 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str72.equals("DateTimeField[dayOfMonth]"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfEven();
        org.joda.time.MutableDateTime mutableDateTime13 = property9.add(0L);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.secondOfDay();
        java.lang.Object obj15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(obj15);
        mutableDateTime13.setTime((org.joda.time.ReadableInstant) mutableDateTime16);
        org.joda.time.Instant instant18 = mutableDateTime13.toInstant();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(instant18);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((int) (short) 0, locale10);
        java.lang.String str13 = skipUndoDateTimeField8.getAsShortText((long) (byte) 10);
        boolean boolean15 = skipUndoDateTimeField8.isLeap((long) 3);
        java.lang.String str17 = skipUndoDateTimeField8.getAsText(1L);
        int int18 = skipUndoDateTimeField8.getMaximumValue();
        try {
            long long21 = skipUndoDateTimeField8.set((long) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for hourOfHalfday must be in the range [1,11]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 11 + "'", int18 == 11);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        boolean boolean71 = dividedDateTimeField69.isLenient();
        long long73 = dividedDateTimeField69.roundFloor((long) 41);
        long long76 = dividedDateTimeField69.getDifferenceAsLong((long) 100, (-15588346022000L));
        try {
            long long79 = dividedDateTimeField69.set((long) 22436442, (-7102));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -7102 for dayOfMonth must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-1L) + "'", long73 == (-1L));
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 24885L + "'", long76 == 24885L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime.Property property9 = dateTime3.era();
        org.joda.time.DateTime dateTime10 = property9.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        java.lang.String str10 = skipUndoDateTimeField8.toString();
        long long12 = skipUndoDateTimeField8.roundFloor((long) (byte) 100);
        org.joda.time.DurationField durationField13 = skipUndoDateTimeField8.getLeapDurationField();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17);
        java.util.Locale locale19 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology18, locale19, (java.lang.Integer) 4, (int) 'a');
        java.lang.Integer int23 = dateTimeParserBucket22.getOffsetInteger();
        boolean boolean25 = dateTimeParserBucket22.restoreState((java.lang.Object) 4);
        int int26 = dateTimeParserBucket22.getOffset();
        java.util.Locale locale27 = dateTimeParserBucket22.getLocale();
        java.lang.String str28 = skipUndoDateTimeField8.getAsText(2000, locale27);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[hourOfHalfday]" + "'", str10.equals("DateTimeField[hourOfHalfday]"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-1L) + "'", long12 == (-1L));
        org.junit.Assert.assertNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNull(int23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2000" + "'", str28.equals("2000"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(readableDuration13, (int) 'a');
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths((-10));
        boolean boolean18 = dateTimeParserBucket7.restoreState((java.lang.Object) dateTime15);
        org.joda.time.DateTime dateTime20 = dateTime15.withDayOfMonth((int) (short) 1);
        org.joda.time.DateTime dateTime22 = dateTime20.withYearOfEra(11);
        org.joda.time.DateTime dateTime24 = dateTime22.minusMonths(19);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        int int11 = skipUndoDateTimeField8.getDifference((long) 12, (long) ' ');
        java.lang.String str12 = skipUndoDateTimeField8.getName();
        int int13 = skipUndoDateTimeField8.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hourOfHalfday" + "'", str12.equals("hourOfHalfday"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = property3.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(31507200115L);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone4.getUncachedZone();
        long long9 = cachedDateTimeZone4.nextTransition((-98250L));
        boolean boolean10 = cachedDateTimeZone4.isFixed();
        int int12 = cachedDateTimeZone4.getStandardOffset(612000000L);
        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone4.getUncachedZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-98250L) + "'", long9 == (-98250L));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        boolean boolean9 = skipUndoDateTimeField8.isSupported();
        org.joda.time.DurationField durationField10 = skipUndoDateTimeField8.getRangeDurationField();
        int int11 = skipUndoDateTimeField8.getMaximumValue();
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField8.getLeapDurationField();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder3.appendTimeZoneOffset("061352-0700", "22450", false, 18, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.withDurationAdded(readableDuration7, (int) 'a');
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((-10));
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14);
        java.util.Locale locale16 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket19 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology15, locale16, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.plus(readablePeriod22);
        org.joda.time.LocalDateTime localDateTime24 = dateTime23.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.DateTime dateTime27 = dateTime23.withDurationAdded(readableDuration25, (int) 'a');
        org.joda.time.DateTime dateTime29 = dateTime27.minusMonths((-10));
        boolean boolean30 = dateTimeParserBucket19.restoreState((java.lang.Object) dateTime27);
        org.joda.time.DateTimeZone dateTimeZone31 = dateTimeParserBucket19.getZone();
        java.lang.String str32 = dateTimeZone31.getID();
        org.joda.time.DateTime dateTime33 = dateTime11.withZoneRetainFields(dateTimeZone31);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "+00:00:00.001" + "'", str32.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(dateTime33);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("0", (java.lang.Number) 43200100L, (java.lang.Number) (-1.0f), (java.lang.Number) 22);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 43200100L + "'", number5.equals(43200100L));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        java.util.Locale locale8 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket11 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology7, locale8, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.chrono.ZonedChronology zonedChronology15 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology7, dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone16 = zonedChronology15.getZone();
        org.joda.time.Chronology chronology17 = buddhistChronology0.withZone(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = buddhistChronology0.era();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(zonedChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = buddhistChronology0.withZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (byte) 0);
        mutableDateTime1.addMinutes((int) (short) 0);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = property4.roundHalfEven();
        mutableDateTime5.setYear((int) (short) 100);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.LocalDateTime localDateTime5 = dateTime4.toLocalDateTime();
        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime5);
        boolean boolean7 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        java.lang.String str12 = dateTimeFormatter10.print(readableInstant11);
        try {
            org.joda.time.LocalDate localDate14 = dateTimeFormatter10.parseLocalDate("22441");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"22441\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969365T235959.999" + "'", str6.equals("1969365T235959.999"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1969352T235959.999+0000" + "'", str12.equals("1969352T235959.999+0000"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, dateTimeZone9);
        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
        try {
            long long18 = zonedChronology11.getDateTimeMillis((long) 13, 24, 0, 22457, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 24 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField71 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        int int72 = remainderDateTimeField71.getDivisor();
        long long74 = remainderDateTimeField71.roundHalfFloor((long) 5);
        long long76 = remainderDateTimeField71.roundHalfEven((long) 411);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 174 + "'", int72 == 174);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-1L) + "'", long74 == (-1L));
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-1L) + "'", long76 == (-1L));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime3.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMillis(10);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillisOfDay((int) (byte) 0);
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 24885L, (java.lang.Number) 100.0d, (java.lang.Number) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        long long1 = instant0.getMillis();
        org.joda.time.DateTime dateTime2 = instant0.toDateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.plus((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2L) + "'", long1 == (-2L));
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("22426", "secondOfDay");
        org.joda.time.IllegalInstantException illegalInstantException5 = new org.joda.time.IllegalInstantException((long) (byte) 0, "32");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalInstantException5);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        java.lang.String str71 = dividedDateTimeField69.getName();
        long long73 = dividedDateTimeField69.remainder((long) 19);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "dayOfMonth" + "'", str71.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 19L + "'", long73 == 19L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("12", false);
        java.util.TimeZone timeZone4 = dateTimeZone3.toTimeZone();
        java.lang.String str5 = dateTimeZone3.getID();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(timeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "12" + "'", str5.equals("12"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        int int11 = skipUndoDateTimeField8.getDifference((long) 12, (long) ' ');
        int int13 = skipUndoDateTimeField8.getMinimumValue(10L);
        org.joda.time.DateTimeField dateTimeField14 = skipUndoDateTimeField8.getWrappedField();
        boolean boolean16 = skipUndoDateTimeField8.isLeap((-70171263L));
        long long18 = skipUndoDateTimeField8.remainder(0L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1L + "'", long18 == 1L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(chronology1);
        org.joda.time.DateTime dateTime4 = dateTime2.withMinuteOfHour(18);
        org.joda.time.DateTime dateTime6 = dateTime2.plusDays((-292268459));
        org.joda.time.DateTime dateTime8 = dateTime2.plusSeconds(19);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((int) (short) 100, 2000, 0, (int) (short) 0, 2000, 11, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfSecond(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundHalfEven();
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField13 = buddhistChronology12.millis();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology12.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17);
        java.util.Locale locale19 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket22 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology18, locale19, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology18, dateTimeZone24);
        org.joda.time.chrono.ISOChronology iSOChronology27 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField28 = iSOChronology27.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(dateTimeZone29);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime32 = dateTime30.plus(readablePeriod31);
        org.joda.time.LocalDateTime localDateTime33 = dateTime32.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.DateTime dateTime36 = dateTime32.withDurationAdded(readableDuration34, (int) 'a');
        org.joda.time.DateTime.Property property37 = dateTime32.centuryOfEra();
        org.joda.time.DateTime.Property property38 = dateTime32.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = property38.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField28, dateTimeFieldType39);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField14, dateTimeFieldType39);
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime11.property(dateTimeFieldType39);
        mutableDateTime11.setMinuteOfHour(12);
        org.joda.time.MutableDateTime.Property property45 = mutableDateTime11.millisOfDay();
        int int46 = property45.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(zonedChronology26);
        org.junit.Assert.assertNotNull(iSOChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(localDateTime33);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 86399999 + "'", int46 == 86399999);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        boolean boolean71 = dividedDateTimeField69.isLenient();
        long long74 = dividedDateTimeField69.add((-61553555613431L), (-1));
        int int77 = dividedDateTimeField69.getDifference((long) (byte) -1, 24L);
        long long79 = dividedDateTimeField69.roundHalfEven((-3599990L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-61554182013431L) + "'", long74 == (-61554182013431L));
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-43200001L) + "'", long79 == (-43200001L));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime12 = property9.add(43200100L);
        mutableDateTime12.setMinuteOfDay(0);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime12.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(property15);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder2.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTwoDigitWeekyear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder5.appendLiteral(' ');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendLiteral('4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder9.appendMillisOfSecond(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendTwoDigitYear(100, false);
        boolean boolean17 = iSOChronology0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        java.lang.String str4 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+00:00:00.001" + "'", str4.equals("+00:00:00.001"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        boolean boolean71 = dividedDateTimeField69.isLenient();
        long long73 = dividedDateTimeField69.roundFloor((long) 41);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        long long76 = remainderDateTimeField74.roundHalfEven((long) (-8));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + (-1L) + "'", long73 == (-1L));
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + (-1L) + "'", long76 == (-1L));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.LocalDateTime localDateTime5 = dateTime4.toLocalDateTime();
        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime5);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        java.lang.String str13 = dateTimeFormatter7.print((org.joda.time.ReadablePartial) localDateTime12);
        java.lang.String str14 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime12);
        org.joda.time.Chronology chronology15 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969365T235959.999" + "'", str6.equals("1969365T235959.999"));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1969365T235959.999" + "'", str13.equals("1969365T235959.999"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969365T235959.999" + "'", str14.equals("1969365T235959.999"));
        org.junit.Assert.assertNull(chronology15);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime dateTime12 = dateTime9.withHourOfDay(0);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime.Property property15 = dateTime12.dayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withDurationAdded(readableDuration21, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = dateTime19.withZoneRetainFields(dateTimeZone24);
        int int26 = dateTime25.getDayOfWeek();
        int int27 = property15.getDifference((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTimeField dateTimeField28 = property15.getField();
        org.joda.time.DateTime dateTime29 = property15.roundHalfEvenCopy();
        int int30 = dateTime29.getDayOfYear();
        org.joda.time.DateTime dateTime31 = dateTime29.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 3 + "'", int26 == 3);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10957 + "'", int27 == 10957);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(dateTime31);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        boolean boolean9 = gJChronology3.equals((java.lang.Object) "0");
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) gJChronology3);
        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfEra(100);
        org.joda.time.DateTime dateTime14 = dateTime12.minus(1560345223292L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 100);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019163T061308.342", (java.lang.Number) 3, (java.lang.Number) 10799999L, (java.lang.Number) 173);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 59, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24L + "'", long2 == 24L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("dayOfMonth", "", 1, (-1));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, dateTimeZone9);
        org.joda.time.DurationField durationField12 = zonedChronology11.eras();
        org.joda.time.Chronology chronology13 = zonedChronology11.withUTC();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology11.millisOfDay();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        try {
            int[] intArray17 = zonedChronology11.get(readablePeriod15, (-7200100L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        java.lang.Class<?> wildcardClass6 = mutableDateTime4.getClass();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.era();
        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundFloor();
        mutableDateTime8.setSecondOfMinute(5);
        mutableDateTime8.setMinuteOfHour((int) ' ');
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime8.hourOfDay();
        org.joda.time.MutableDateTime mutableDateTime15 = property13.add(0);
        mutableDateTime15.setDate((-11L));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(mutableDateTime15);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.MutableDateTime mutableDateTime1 = new org.joda.time.MutableDateTime((long) (byte) 0);
        mutableDateTime1.addMinutes((int) (short) 0);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime1.minuteOfDay();
        org.joda.time.MutableDateTime mutableDateTime5 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.dayOfYear();
        mutableDateTime5.addMillis(100);
        mutableDateTime5.setTime(0, 6, (int) (short) 1, (int) '4');
        java.lang.String str14 = mutableDateTime5.toString();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.plus(readablePeriod17);
        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.withDurationAdded(readableDuration20, (int) 'a');
        org.joda.time.DateTime.Property property23 = dateTime18.centuryOfEra();
        org.joda.time.DateTime dateTime24 = property23.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone25 = dateTime24.getZone();
        mutableDateTime5.setZone(dateTimeZone25);
        mutableDateTime1.setZoneRetainFields(dateTimeZone25);
        mutableDateTime1.setMillisOfSecond(411);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1970-01-01T00:06:01.052+00:00:00.001" + "'", str14.equals("1970-01-01T00:06:01.052+00:00:00.001"));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        int int8 = gJChronology3.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime3.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime8 = dateTime3.minusMillis(10);
        org.joda.time.DateTime dateTime10 = dateTime3.plusMinutes(0);
        int int11 = dateTime3.getMinuteOfHour();
        org.joda.time.DateTime dateTime13 = dateTime3.withWeekyear(0);
        org.joda.time.DateTime.Property property14 = dateTime3.centuryOfEra();
        org.joda.time.DateTime.Property property15 = dateTime3.millisOfSecond();
        org.joda.time.DateTime.Property property16 = dateTime3.era();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 59 + "'", int11 == 59);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatterBuilder0.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTwoDigitYear(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder6.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendTwoDigitWeekyear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder12.clear();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.plus(readablePeriod16);
        org.joda.time.LocalDateTime localDateTime18 = dateTime17.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime21 = dateTime17.withDurationAdded(readableDuration19, (int) 'a');
        org.joda.time.DateTime.Property property22 = dateTime17.centuryOfEra();
        org.joda.time.DateTime.Property property23 = dateTime17.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder12.appendSignedDecimal(dateTimeFieldType24, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder11.appendSignedDecimal(dateTimeFieldType24, (int) (short) 0, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder5.appendFixedDecimal(dateTimeFieldType24, 411);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder5.appendWeekyear((-2), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.LocalDateTime localDateTime5 = dateTime4.toLocalDateTime();
        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime5);
        boolean boolean7 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969365T235959.999" + "'", str6.equals("1969365T235959.999"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.Instant instant7 = org.joda.time.Instant.now();
        org.joda.time.chrono.BuddhistChronology buddhistChronology8 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField9 = buddhistChronology8.millis();
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology8.hourOfHalfday();
        int int11 = instant7.get(dateTimeField10);
        org.joda.time.Instant instant13 = instant7.minus(0L);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.Instant instant16 = instant13.withDurationAdded(readableDuration14, 12);
        org.joda.time.Chronology chronology17 = instant16.getChronology();
        try {
            org.joda.time.MutableDateTime mutableDateTime18 = new org.joda.time.MutableDateTime(0, 11, 411, 3, 3395, 411, 0, chronology17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3395 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(buddhistChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 11 + "'", int11 == 11);
        org.junit.Assert.assertNotNull(instant13);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMillisOfSecond(2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        boolean boolean8 = dateTimeFormatter7.isOffsetParsed();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.append(dateTimeFormatter7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology11.hourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter10.withOffsetParsed();
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter10.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder17.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendTimeZoneId();
        org.joda.time.format.DateTimeParser dateTimeParser20 = dateTimeFormatterBuilder17.toParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter16, dateTimeParser20);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder9.append(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeParser20);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.LocalDateTime localDateTime5 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime.Property property6 = dateTime4.secondOfDay();
        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime4);
        try {
            org.joda.time.LocalTime localTime9 = dateTimeFormatter0.parseLocalTime("22431");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"22431\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "December 31, 1969 11:59:59 PM +00:00:00.001" + "'", str7.equals("December 31, 1969 11:59:59 PM +00:00:00.001"));
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        mutableDateTime0.setMillisOfDay(4);
        int int3 = mutableDateTime0.getRoundingMode();
        mutableDateTime0.addDays(292279588);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        mutableDateTime0.setSecondOfMinute(12);
        org.joda.time.ReadableDuration readableDuration4 = null;
        mutableDateTime0.add(readableDuration4, 12);
        mutableDateTime0.setMillis((long) 18);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime0.centuryOfEra();
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("061319-0700");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("061319-0700");
        boolean boolean4 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        jodaTimePermission1.checkGuard((java.lang.Object) "1970");
        java.lang.String str7 = jodaTimePermission1.toString();
        java.lang.String str8 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"061319-0700\")" + "'", str7.equals("(\"org.joda.time.JodaTimePermission\" \"061319-0700\")"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "061319-0700" + "'", str8.equals("061319-0700"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
        org.joda.time.LocalDateTime localDateTime13 = dateTime12.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime16 = dateTime12.withDurationAdded(readableDuration14, (int) 'a');
        org.joda.time.DateTime dateTime18 = dateTime16.minusMonths((-10));
        boolean boolean19 = dateTimeParserBucket8.restoreState((java.lang.Object) dateTime16);
        org.joda.time.DateTimeZone dateTimeZone20 = dateTimeParserBucket8.getZone();
        java.lang.String str21 = dateTimeZone20.getID();
        java.util.TimeZone timeZone22 = dateTimeZone20.toTimeZone();
        org.joda.time.MutableDateTime mutableDateTime23 = new org.joda.time.MutableDateTime((long) 1, dateTimeZone20);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime23.minuteOfHour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone26 = null;
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.MutableDateTime mutableDateTime30 = dateTime27.toMutableDateTime();
        int int33 = dateTimeFormatter25.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime30, "hi!", (int) (byte) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone35);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.DateTime dateTime38 = dateTime36.plus(readablePeriod37);
        org.joda.time.MutableDateTime mutableDateTime39 = dateTime36.toMutableDateTime();
        int int42 = dateTimeFormatter34.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime39, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property43 = mutableDateTime39.secondOfDay();
        java.lang.String str44 = property43.toString();
        org.joda.time.MutableDateTime mutableDateTime45 = property43.roundHalfEven();
        org.joda.time.chrono.BuddhistChronology buddhistChronology46 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField47 = buddhistChronology46.millis();
        org.joda.time.DateTimeField dateTimeField48 = buddhistChronology46.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone51);
        java.util.Locale locale53 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket56 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology52, locale53, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology59 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone58);
        org.joda.time.chrono.ZonedChronology zonedChronology60 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology52, dateTimeZone58);
        org.joda.time.chrono.ISOChronology iSOChronology61 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.DateTimeField dateTimeField62 = iSOChronology61.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.DateTime dateTime64 = new org.joda.time.DateTime(dateTimeZone63);
        org.joda.time.ReadablePeriod readablePeriod65 = null;
        org.joda.time.DateTime dateTime66 = dateTime64.plus(readablePeriod65);
        org.joda.time.LocalDateTime localDateTime67 = dateTime66.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration68 = null;
        org.joda.time.DateTime dateTime70 = dateTime66.withDurationAdded(readableDuration68, (int) 'a');
        org.joda.time.DateTime.Property property71 = dateTime66.centuryOfEra();
        org.joda.time.DateTime.Property property72 = dateTime66.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType73 = property72.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField74 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField62, dateTimeFieldType73);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField75 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField48, dateTimeFieldType73);
        org.joda.time.MutableDateTime.Property property76 = mutableDateTime45.property(dateTimeFieldType73);
        mutableDateTime30.set(dateTimeFieldType73, (int) (byte) 10);
        int int79 = mutableDateTime23.get(dateTimeFieldType73);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localDateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+00:00:00.001" + "'", str21.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Property[secondOfDay]" + "'", str44.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime45);
        org.junit.Assert.assertNotNull(buddhistChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(dateTimeField48);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(gJChronology52);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(gJChronology59);
        org.junit.Assert.assertNotNull(zonedChronology60);
        org.junit.Assert.assertNotNull(iSOChronology61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(localDateTime67);
        org.junit.Assert.assertNotNull(dateTime70);
        org.junit.Assert.assertNotNull(property71);
        org.junit.Assert.assertNotNull(property72);
        org.junit.Assert.assertNotNull(dateTimeFieldType73);
        org.junit.Assert.assertNotNull(property76);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        java.util.Locale locale10 = null;
        java.lang.String str11 = skipUndoDateTimeField8.getAsShortText((int) (short) 0, locale10);
        org.joda.time.DurationField durationField12 = skipUndoDateTimeField8.getDurationField();
        int int15 = skipUndoDateTimeField8.getDifference(43200100L, (-99L));
        long long18 = skipUndoDateTimeField8.set((long) 2, 6);
        int int20 = skipUndoDateTimeField8.get(3600000L);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 18000002L + "'", long18 == 18000002L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField71 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        long long73 = remainderDateTimeField71.roundFloor((long) 22436442);
        long long75 = remainderDateTimeField71.roundFloor((long) 2000);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 21599999L + "'", long73 == 21599999L);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + (-1L) + "'", long75 == (-1L));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        java.lang.Class<?> wildcardClass6 = mutableDateTime4.getClass();
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.era();
        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundFloor();
        mutableDateTime8.setSecondOfMinute(5);
        try {
            mutableDateTime8.setTime((int) (byte) 1, (-7102), (int) ' ', 411);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -7102 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology6 = gregorianChronology0.withZone(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(dateTimeZone4);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.plus(readablePeriod6);
        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.withDurationAdded(readableDuration9, (int) 'a');
        org.joda.time.DateTime.Property property12 = dateTime7.centuryOfEra();
        org.joda.time.DateTime.Property property13 = dateTime7.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = property13.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder3.appendSignedDecimal(dateTimeFieldType14, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder18.clear();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.plus(readablePeriod22);
        org.joda.time.LocalDateTime localDateTime24 = dateTime23.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.DateTime dateTime27 = dateTime23.withDurationAdded(readableDuration25, (int) 'a');
        org.joda.time.DateTime.Property property28 = dateTime23.centuryOfEra();
        org.joda.time.DateTime.Property property29 = dateTime23.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder18.appendSignedDecimal(dateTimeFieldType30, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder3.appendFixedDecimal(dateTimeFieldType30, 2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder35.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeField dateTimeField8 = gJChronology3.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField9 = gJChronology3.halfdayOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean6 = cachedDateTimeZone4.equals((java.lang.Object) "June 12, 2019 6:13:21 AM PDT");
        int int8 = cachedDateTimeZone4.getOffset((long) 22403);
        java.lang.String str10 = cachedDateTimeZone4.getName(11L);
        int int12 = cachedDateTimeZone4.getOffset(36L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.plus(readablePeriod16);
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime15.toMutableDateTime();
        int int21 = dateTimeFormatter13.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime18, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property22 = mutableDateTime18.secondOfDay();
        java.lang.String str23 = property22.toString();
        org.joda.time.MutableDateTime mutableDateTime25 = property22.add(43200100L);
        boolean boolean26 = cachedDateTimeZone4.equals((java.lang.Object) mutableDateTime25);
        int int28 = cachedDateTimeZone4.getOffset(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.001" + "'", str10.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(mutableDateTime18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Property[secondOfDay]" + "'", str23.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        org.joda.time.DateTime dateTime7 = property5.addToCopy((long) 18);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder6.clear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(readableDuration13, (int) 'a');
        org.joda.time.DateTime.Property property16 = dateTime11.centuryOfEra();
        org.joda.time.DateTime.Property property17 = dateTime11.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType18, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType18, (int) (short) 0, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder24.appendMillisOfSecond(292279588);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder26.appendFixedSignedDecimal(dateTimeFieldType27, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime3.withSecondOfMinute(0);
        org.joda.time.DateTime dateTime7 = dateTime5.plusMinutes(20);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.LocalDateTime localDateTime5 = dateTime4.toLocalDateTime();
        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime5);
        boolean boolean7 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology9);
        org.joda.time.DurationField durationField11 = julianChronology9.millis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(localDateTime5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969365T235959.999" + "'", str6.equals("1969365T235959.999"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime dateTime12 = dateTime9.withHourOfDay(0);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTimeISO();
        org.joda.time.DateTime.Property property16 = dateTime15.weekyear();
        org.joda.time.DateTime dateTime17 = dateTime15.toDateTimeISO();
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.plus(readablePeriod20);
        org.joda.time.LocalDateTime localDateTime22 = dateTime21.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime21.withDurationAdded(readableDuration23, (int) 'a');
        org.joda.time.DateTime dateTime27 = dateTime25.minusMonths((-10));
        org.joda.time.DateTime dateTime28 = dateTime27.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime29 = dateTime27.toDateTimeISO();
        boolean boolean30 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime29);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime3.minusWeeks((-10));
        org.joda.time.DateTime dateTime10 = dateTime3.plusMonths((int) (byte) 10);
        org.joda.time.DateTime dateTime12 = dateTime3.withWeekOfWeekyear(24);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime3.minusWeeks((-10));
        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
        try {
            org.joda.time.DateTime dateTime11 = dateTime8.withMinuteOfHour(22463);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 22463 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6047999998L + "'", long9 == 6047999998L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        boolean boolean6 = dateTime3.isSupported(dateTimeFieldType5);
        org.joda.time.DateTime dateTime7 = dateTime3.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime3.minusSeconds((-8));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        java.util.Locale locale14 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket17 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology13, locale14, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.plus(readablePeriod20);
        org.joda.time.LocalDateTime localDateTime22 = dateTime21.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime25 = dateTime21.withDurationAdded(readableDuration23, (int) 'a');
        org.joda.time.DateTime dateTime27 = dateTime25.minusMonths((-10));
        boolean boolean28 = dateTimeParserBucket17.restoreState((java.lang.Object) dateTime25);
        org.joda.time.DateTime dateTime30 = dateTime25.withDayOfMonth((int) (short) 1);
        boolean boolean31 = dateTime9.isEqual((org.joda.time.ReadableInstant) dateTime30);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("22426", "secondOfDay");
        illegalFieldValueException2.prependMessage("");
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = dateTime3.withZoneRetainFields(dateTimeZone8);
        int int10 = dateTime9.getDayOfWeek();
        int int11 = dateTime9.getYear();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime13 = dateTime9.plus(readablePeriod12);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(dateTimeZone14);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.DateTime dateTime17 = dateTime15.plus(readablePeriod16);
        org.joda.time.LocalDateTime localDateTime18 = dateTime17.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.DateTime dateTime21 = dateTime17.withDurationAdded(readableDuration19, (int) 'a');
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime21);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(localDateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.DateTime dateTime5 = dateTime1.plusMillis((int) (short) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now();
        org.joda.time.Chronology chronology7 = mutableDateTime6.getChronology();
        mutableDateTime6.addWeekyears(24);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField12 = buddhistChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology11.hourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) buddhistChronology11);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = dateTimeFormatter10.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone17);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter10.withZone(dateTimeZone17);
        mutableDateTime6.setZoneRetainFields(dateTimeZone17);
        org.joda.time.DateTime dateTime21 = dateTime5.withZoneRetainFields(dateTimeZone17);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime(dateTimeZone23);
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime24.plus(readablePeriod25);
        org.joda.time.MutableDateTime mutableDateTime27 = dateTime24.toMutableDateTime();
        int int30 = dateTimeFormatter22.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime27, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime27.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime32 = property31.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime33 = property31.roundCeiling();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime(dateTimeZone35);
        org.joda.time.ReadablePeriod readablePeriod37 = null;
        org.joda.time.DateTime dateTime38 = dateTime36.plus(readablePeriod37);
        org.joda.time.MutableDateTime mutableDateTime39 = dateTime36.toMutableDateTime();
        int int42 = dateTimeFormatter34.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime39, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property43 = mutableDateTime39.secondOfDay();
        org.joda.time.Interval interval44 = property43.toInterval();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider45 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider45);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49);
        java.util.Locale locale51 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket54 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology50, locale51, (java.lang.Integer) 4, (int) 'a');
        java.lang.Integer int55 = dateTimeParserBucket54.getOffsetInteger();
        boolean boolean57 = dateTimeParserBucket54.restoreState((java.lang.Object) 4);
        int int58 = dateTimeParserBucket54.getOffset();
        java.util.Locale locale59 = dateTimeParserBucket54.getLocale();
        java.lang.String str62 = defaultNameProvider45.getShortName(locale59, "2019-W24-3", "2019163T061308.342");
        java.lang.String str63 = property43.getAsShortText(locale59);
        int int64 = property31.getMaximumTextLength(locale59);
        java.util.Calendar calendar65 = dateTime21.toCalendar(locale59);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(buddhistChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTimeFormatter19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(mutableDateTime27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(mutableDateTime32);
        org.junit.Assert.assertNotNull(mutableDateTime33);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(mutableDateTime39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(interval44);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNull(int55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(locale59);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "86399" + "'", str63.equals("86399"));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 5 + "'", int64 == 5);
        org.junit.Assert.assertNotNull(calendar65);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, dateTimeZone9);
        org.joda.time.DurationField durationField12 = zonedChronology11.weekyears();
        java.lang.String str13 = zonedChronology11.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ZonedChronology[GJChronology[UTC], +00:00:00.001]" + "'", str13.equals("ZonedChronology[GJChronology[UTC], +00:00:00.001]"));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology3.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField6, (int) ' ');
        int int11 = skipUndoDateTimeField8.getDifference((long) 12, (long) ' ');
        int int13 = skipUndoDateTimeField8.getMinimumValue(10L);
        java.util.Locale locale15 = null;
        java.lang.String str16 = skipUndoDateTimeField8.getAsShortText((int) ' ', locale15);
        long long18 = skipUndoDateTimeField8.roundCeiling((long) (-7102));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "32" + "'", str16.equals("32"));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-1L) + "'", long18 == (-1L));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.withDurationAdded(readableDuration7, (int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime5.centuryOfEra();
        org.joda.time.DateTime.Property property11 = dateTime5.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType12, 411, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        java.util.Locale locale20 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket23 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology19, locale20, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology19, dateTimeZone25);
        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone30 = null;
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(dateTimeZone30);
        org.joda.time.ReadablePeriod readablePeriod32 = null;
        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
        org.joda.time.LocalDateTime localDateTime34 = dateTime33.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration35 = null;
        org.joda.time.DateTime dateTime37 = dateTime33.withDurationAdded(readableDuration35, (int) 'a');
        org.joda.time.DateTime.Property property38 = dateTime33.centuryOfEra();
        org.joda.time.DateTime.Property property39 = dateTime33.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField29, dateTimeFieldType40);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder0.appendSignedDecimal(dateTimeFieldType40, 1, 4);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder0.appendDayOfMonth(5);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49);
        java.util.Locale locale51 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket54 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology50, locale51, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone56);
        org.joda.time.chrono.ZonedChronology zonedChronology58 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology50, dateTimeZone56);
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone56);
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(dateTimeZone61);
        org.joda.time.ReadablePeriod readablePeriod63 = null;
        org.joda.time.DateTime dateTime64 = dateTime62.plus(readablePeriod63);
        org.joda.time.LocalDateTime localDateTime65 = dateTime64.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration66 = null;
        org.joda.time.DateTime dateTime68 = dateTime64.withDurationAdded(readableDuration66, (int) 'a');
        org.joda.time.DateTime.Property property69 = dateTime64.centuryOfEra();
        org.joda.time.DateTime.Property property70 = dateTime64.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType71 = property70.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField72 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField60, dateTimeFieldType71);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder73 = dateTimeFormatterBuilder0.appendText(dateTimeFieldType71);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder74 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeFieldType12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(iSOChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localDateTime34);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(gJChronology50);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(zonedChronology58);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(localDateTime65);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(dateTimeFieldType71);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder73);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder74);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = julianChronology0.withUTC();
        org.joda.time.DurationField durationField2 = julianChronology0.weekyears();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField5 = buddhistChronology4.millis();
        org.joda.time.DateTimeField dateTimeField6 = buddhistChronology4.hourOfHalfday();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DurationField durationField8 = buddhistChronology4.days();
        org.joda.time.DateTimeField dateTimeField9 = buddhistChronology4.halfdayOfDay();
        boolean boolean10 = julianChronology0.equals((java.lang.Object) dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int6 = gregorianChronology5.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(3, 59, 31, 3395, (int) (byte) 1, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3395 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology0.weekyears();
        org.joda.time.DurationField durationField4 = buddhistChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.Chronology chronology8 = buddhistChronology0.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder11.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder11.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.plus(readablePeriod17);
        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.withDurationAdded(readableDuration20, (int) 'a');
        org.joda.time.DateTime.Property property23 = dateTime18.centuryOfEra();
        org.joda.time.DateTime.Property property24 = dateTime18.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder14.appendSignedDecimal(dateTimeFieldType25, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder29.clear();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(dateTimeZone31);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.DateTime dateTime34 = dateTime32.plus(readablePeriod33);
        org.joda.time.LocalDateTime localDateTime35 = dateTime34.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration36 = null;
        org.joda.time.DateTime dateTime38 = dateTime34.withDurationAdded(readableDuration36, (int) 'a');
        org.joda.time.DateTime.Property property39 = dateTime34.centuryOfEra();
        org.joda.time.DateTime.Property property40 = dateTime34.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property40.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder29.appendSignedDecimal(dateTimeFieldType41, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder14.appendFixedDecimal(dateTimeFieldType41, 2);
        boolean boolean47 = dateTime9.isSupported(dateTimeFieldType41);
        try {
            org.joda.time.DateTime dateTime48 = new org.joda.time.DateTime((java.lang.Object) boolean47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(localDateTime35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeFieldType41);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField3 = buddhistChronology2.millis();
        org.joda.time.DateTimeField dateTimeField4 = buddhistChronology2.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField6 = buddhistChronology5.millis();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology5);
        org.joda.time.DateTimeField dateTimeField8 = buddhistChronology5.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField10 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology2, dateTimeField8, (int) ' ');
        java.util.Locale locale12 = null;
        java.lang.String str13 = skipUndoDateTimeField10.getAsShortText((int) (short) 0, locale12);
        org.joda.time.DurationField durationField14 = skipUndoDateTimeField10.getDurationField();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField16 = buddhistChronology15.millis();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology15.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology18 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField19 = buddhistChronology18.millis();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology18);
        org.joda.time.DateTimeField dateTimeField21 = buddhistChronology18.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology15, dateTimeField21, (int) ' ');
        boolean boolean24 = skipUndoDateTimeField23.isSupported();
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime26.plus(readablePeriod27);
        org.joda.time.LocalDateTime localDateTime29 = dateTime28.toLocalDateTime();
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipUndoDateTimeField23.getAsShortText((org.joda.time.ReadablePartial) localDateTime29, locale30);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now(dateTimeZone35);
        long long39 = dateTimeZone35.adjustOffset((long) (byte) -1, true);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime(dateTimeZone42);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.DateTime dateTime45 = dateTime43.plus(readablePeriod44);
        org.joda.time.LocalDateTime localDateTime46 = dateTime45.toLocalDateTime();
        boolean boolean47 = dateTimeZone41.isLocalDateTimeGap(localDateTime46);
        boolean boolean48 = dateTimeZone35.isLocalDateTimeGap(localDateTime46);
        int[] intArray50 = gregorianChronology32.get((org.joda.time.ReadablePartial) localDateTime46, 110L);
        int int51 = skipUndoDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localDateTime29, intArray50);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDateTime29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(buddhistChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "11" + "'", str31.equals("11"));
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-1L) + "'", long39 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(localDateTime46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 11 + "'", int51 == 11);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        mutableDateTime4.setMonthOfYear((int) (byte) 1);
        mutableDateTime4.addMinutes((int) (byte) 10);
        java.lang.Object obj10 = mutableDateTime4.clone();
        org.joda.time.ReadableDuration readableDuration11 = null;
        mutableDateTime4.add(readableDuration11);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        boolean boolean71 = dividedDateTimeField69.isLenient();
        long long74 = dividedDateTimeField69.add((-61553555613431L), (-1));
        int int75 = dividedDateTimeField69.getMaximumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + long74 + "' != '" + (-61554182013431L) + "'", long74 == (-61554182013431L));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.toString();
        org.joda.time.MutableDateTime mutableDateTime12 = property9.add(43200100L);
        org.joda.time.MutableDateTime mutableDateTime13 = property9.roundFloor();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Property[secondOfDay]" + "'", str10.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        boolean boolean9 = gJChronology3.equals((java.lang.Object) "0");
        long long13 = gJChronology3.add((-7200000L), (long) 1, (int) (short) 0);
        org.joda.time.DurationField durationField14 = gJChronology3.halfdays();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-7200000L) + "'", long13 == (-7200000L));
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.millisOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField2 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField1);
        java.lang.String str3 = delegatedDateTimeField2.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTimeField[millisOfDay]" + "'", str3.equals("DateTimeField[millisOfDay]"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField5 = buddhistChronology4.millis();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField7, (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = buddhistChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology1.clockhourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField11);
        long long15 = skipDateTimeField12.set((long) (-1), 3);
        long long17 = skipDateTimeField12.roundCeiling((long) (byte) 100);
        int int18 = skipDateTimeField12.getMinimumValue();
        int int19 = skipDateTimeField12.getMinimumValue();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10799999L + "'", long15 == 10799999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 3599999L + "'", long17 == 3599999L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology0.weekyears();
        org.joda.time.DurationField durationField4 = buddhistChronology0.weeks();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.Chronology chronology8 = buddhistChronology0.withZone(dateTimeZone6);
        org.joda.time.DurationField durationField9 = buddhistChronology0.halfdays();
        org.joda.time.Chronology chronology10 = buddhistChronology0.withUTC();
        org.joda.time.DurationField durationField11 = buddhistChronology0.months();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField11);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology10, locale11, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime(dateTimeZone15);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.DateTime dateTime18 = dateTime16.plus(readablePeriod17);
        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration20 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.withDurationAdded(readableDuration20, (int) 'a');
        org.joda.time.DateTime dateTime24 = dateTime22.minusMonths((-10));
        boolean boolean25 = dateTimeParserBucket14.restoreState((java.lang.Object) dateTime22);
        org.joda.time.DateTimeZone dateTimeZone26 = dateTimeParserBucket14.getZone();
        java.lang.String str27 = dateTimeZone26.getID();
        java.lang.String str29 = dateTimeZone26.getName((long) (-8));
        try {
            org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(0, 0, 41, 115, (-10), 7, 3395, dateTimeZone26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 115 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDateTime19);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.001" + "'", str27.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+00:00:00.001" + "'", str29.equals("+00:00:00.001"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        mutableDateTime4.setMonthOfYear((int) (byte) 1);
        java.util.Date date8 = mutableDateTime4.toDate();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime.Property property9 = dateTime3.dayOfMonth();
        org.joda.time.DateTime dateTime11 = dateTime3.withMillis(2L);
        org.joda.time.DateTime dateTime13 = dateTime3.plusSeconds(22463);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("Property[weekyear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'Property[weekyear]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime10 = property8.withMinimumValue();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime13 = dateTime10.withDurationAdded(readableDuration11, 0);
        org.joda.time.DateTime dateTime14 = dateTime10.toDateTime();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((org.joda.time.Chronology) buddhistChronology2);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(dateTimeZone5);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.plus(readablePeriod7);
        org.joda.time.LocalDateTime localDateTime9 = dateTime8.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime8.withDurationAdded(readableDuration10, (int) 'a');
        java.util.GregorianCalendar gregorianCalendar13 = dateTime8.toGregorianCalendar();
        org.joda.time.DateTime dateTime15 = dateTime8.plusHours(292278919);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
        java.util.Locale locale22 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket25 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology21, locale22, (java.lang.Integer) 4, (int) 'a');
        boolean boolean27 = gJChronology21.equals((java.lang.Object) "0");
        long long31 = gJChronology21.add((long) 2019, (long) 2922789, 2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.plus(readablePeriod35);
        org.joda.time.MutableDateTime mutableDateTime37 = dateTime34.toMutableDateTime();
        int int40 = dateTimeFormatter32.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime37, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property41 = mutableDateTime37.secondOfDay();
        org.joda.time.Interval interval42 = property41.toInterval();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider43 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider43);
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology48 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone47);
        java.util.Locale locale49 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket52 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology48, locale49, (java.lang.Integer) 4, (int) 'a');
        java.lang.Integer int53 = dateTimeParserBucket52.getOffsetInteger();
        boolean boolean55 = dateTimeParserBucket52.restoreState((java.lang.Object) 4);
        int int56 = dateTimeParserBucket52.getOffset();
        java.util.Locale locale57 = dateTimeParserBucket52.getLocale();
        java.lang.String str60 = defaultNameProvider43.getShortName(locale57, "2019-W24-3", "2019163T061308.342");
        java.lang.String str61 = property41.getAsShortText(locale57);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket63 = new org.joda.time.format.DateTimeParserBucket((-4320000000L), (org.joda.time.Chronology) gJChronology21, locale57, (java.lang.Integer) (-10));
        java.lang.String str64 = dateTime15.toString("0", locale57);
        try {
            java.lang.String str65 = dateTime3.toString("America/Los_Angeles", locale57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianCalendar13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 5847597L + "'", long31 == 5847597L);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(mutableDateTime37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(interval42);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(gJChronology48);
        org.junit.Assert.assertNull(int53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(locale57);
        org.junit.Assert.assertNull(str60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "86399" + "'", str61.equals("86399"));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "0" + "'", str64.equals("0"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        java.util.Locale locale5 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket8 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology4, locale5, (java.lang.Integer) 4, (int) 'a');
        boolean boolean10 = gJChronology4.equals((java.lang.Object) "0");
        long long14 = gJChronology4.add((long) 2019, (long) 2922789, 2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime19 = dateTime17.plus(readablePeriod18);
        org.joda.time.MutableDateTime mutableDateTime20 = dateTime17.toMutableDateTime();
        int int23 = dateTimeFormatter15.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime20, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property24 = mutableDateTime20.secondOfDay();
        org.joda.time.Interval interval25 = property24.toInterval();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider26 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider26);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone30);
        java.util.Locale locale32 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket35 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology31, locale32, (java.lang.Integer) 4, (int) 'a');
        java.lang.Integer int36 = dateTimeParserBucket35.getOffsetInteger();
        boolean boolean38 = dateTimeParserBucket35.restoreState((java.lang.Object) 4);
        int int39 = dateTimeParserBucket35.getOffset();
        java.util.Locale locale40 = dateTimeParserBucket35.getLocale();
        java.lang.String str43 = defaultNameProvider26.getShortName(locale40, "2019-W24-3", "2019163T061308.342");
        java.lang.String str44 = property24.getAsShortText(locale40);
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket46 = new org.joda.time.format.DateTimeParserBucket((-4320000000L), (org.joda.time.Chronology) gJChronology4, locale40, (java.lang.Integer) (-10));
        org.joda.time.DateTimeZone dateTimeZone47 = dateTimeParserBucket46.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5847597L + "'", long14 == 5847597L);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(mutableDateTime20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(interval25);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNull(int36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(locale40);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "86399" + "'", str44.equals("86399"));
        org.junit.Assert.assertNotNull(dateTimeZone47);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField5 = buddhistChronology4.millis();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField7, (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = buddhistChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology1.clockhourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField11);
        long long15 = skipDateTimeField12.set((long) (-1), 3);
        int int16 = skipDateTimeField12.getMinimumValue();
        int int17 = skipDateTimeField12.getMinimumValue();
        long long19 = skipDateTimeField12.roundHalfCeiling((long) 31);
        int int22 = skipDateTimeField12.getDifference(1560345258436L, (-3599990L));
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 10799999L + "'", long15 == 10799999L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-1L) + "'", long19 == (-1L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 433430 + "'", int22 == 433430);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        int int8 = dateTimeParserBucket7.getOffset();
        java.lang.Integer int9 = dateTimeParserBucket7.getPivotYear();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeParserBucket7.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime13.toMutableDateTime();
        int int19 = dateTimeFormatter11.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime16, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property20 = mutableDateTime16.secondOfDay();
        java.lang.String str21 = property20.getAsText();
        org.joda.time.Interval interval22 = property20.toInterval();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime(dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime27 = dateTime25.plus(readablePeriod26);
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime25.toMutableDateTime();
        int int31 = dateTimeFormatter23.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime28, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property32 = mutableDateTime28.secondOfDay();
        java.lang.String str33 = property32.toString();
        org.joda.time.MutableDateTime mutableDateTime34 = property32.roundHalfEven();
        long long35 = property20.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime34);
        int int36 = dateTimeZone10.getOffset((org.joda.time.ReadableInstant) mutableDateTime34);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9.equals(4));
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "86399" + "'", str21.equals("86399"));
        org.junit.Assert.assertNotNull(interval22);
        org.junit.Assert.assertNotNull(dateTimeFormatter23);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Property[secondOfDay]" + "'", str33.equals("Property[secondOfDay]"));
        org.junit.Assert.assertNotNull(mutableDateTime34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1560345244083L, (java.lang.Number) 381, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, readableInstant2, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 1969");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime1.toMutableDateTime();
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        mutableDateTime4.setMonthOfYear((int) (byte) 1);
        mutableDateTime4.addMinutes((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        long long15 = dateTimeZone11.adjustOffset((long) (byte) -1, true);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime(dateTimeZone18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime19.plus(readablePeriod20);
        org.joda.time.LocalDateTime localDateTime22 = dateTime21.toLocalDateTime();
        boolean boolean23 = dateTimeZone17.isLocalDateTimeGap(localDateTime22);
        boolean boolean24 = dateTimeZone11.isLocalDateTimeGap(localDateTime22);
        java.util.TimeZone timeZone25 = dateTimeZone11.toTimeZone();
        boolean boolean27 = dateTimeZone11.isStandardOffset(0L);
        java.util.TimeZone timeZone28 = dateTimeZone11.toTimeZone();
        org.joda.time.MutableDateTime mutableDateTime29 = mutableDateTime4.toMutableDateTime(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(localDateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(timeZone28);
        org.junit.Assert.assertNotNull(mutableDateTime29);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        java.util.Locale locale11 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket14 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology10, locale11, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField16 = buddhistChronology15.millis();
        org.joda.time.DateTimeField dateTimeField17 = buddhistChronology15.hourOfHalfday();
        org.joda.time.DurationField durationField18 = buddhistChronology15.weekyears();
        org.joda.time.DurationField durationField19 = buddhistChronology15.weeks();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        org.joda.time.Chronology chronology23 = buddhistChronology15.withZone(dateTimeZone21);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone21);
        dateTimeParserBucket14.setZone(dateTimeZone21);
        try {
            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(0, (int) (short) 1, (-7102), (int) (byte) 1, (int) (byte) 1, 3395, 6, dateTimeZone21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3395 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(buddhistChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(87, 22436442, (int) (short) -1, 1970, 2922789, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(julianChronology8);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(readableDuration13, (int) 'a');
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths((-10));
        boolean boolean18 = dateTimeParserBucket7.restoreState((java.lang.Object) dateTime15);
        int int19 = dateTimeParserBucket7.getOffset();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.plus(readablePeriod22);
        org.joda.time.LocalDateTime localDateTime24 = dateTime23.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.DateTime dateTime27 = dateTime23.withDurationAdded(readableDuration25, (int) 'a');
        org.joda.time.DateTime.Property property28 = dateTime23.centuryOfEra();
        org.joda.time.DateTime.Property property29 = dateTime23.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        dateTimeParserBucket7.saveField(dateTimeFieldType30, (int) 'a');
        org.joda.time.Chronology chronology33 = dateTimeParserBucket7.getChronology();
        try {
            long long34 = dateTimeParserBucket7.computeMillis();
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertNotNull(chronology33);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("12", false);
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("65618", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        int int5 = dateTime3.getDayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(dateTimeZone6);
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime9 = dateTime7.plus(readablePeriod8);
        org.joda.time.LocalDateTime localDateTime10 = dateTime9.toLocalDateTime();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        boolean boolean12 = dateTime9.isSupported(dateTimeFieldType11);
        org.joda.time.DateTime dateTime13 = dateTime9.withLaterOffsetAtOverlap();
        boolean boolean14 = dateTime3.isAfter((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfDay();
        org.joda.time.DateTime dateTime16 = dateTime13.toDateTimeISO();
        org.joda.time.chrono.BuddhistChronology buddhistChronology17 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField18 = buddhistChronology17.millis();
        org.joda.time.DateTimeField dateTimeField19 = buddhistChronology17.hourOfHalfday();
        org.joda.time.DurationField durationField20 = buddhistChronology17.weekyears();
        org.joda.time.DurationField durationField21 = buddhistChronology17.weeks();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone23);
        org.joda.time.Chronology chronology25 = buddhistChronology17.withZone(dateTimeZone23);
        org.joda.time.DateTime dateTime26 = dateTime16.toDateTime(chronology25);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDateTime10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(buddhistChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        java.lang.String str10 = property9.getAsShortText();
        int int11 = property9.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "86399" + "'", str10.equals("86399"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime dateTime12 = dateTime9.withHourOfDay(0);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime.Property property15 = dateTime12.dayOfWeek();
        org.joda.time.DateTime dateTime17 = property15.addToCopy((long) (byte) 1);
        org.joda.time.DateTime dateTime18 = property15.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        boolean boolean6 = cachedDateTimeZone4.equals((java.lang.Object) "June 12, 2019 6:13:21 AM PDT");
        int int8 = cachedDateTimeZone4.getOffset((long) 22403);
        org.joda.time.DateTimeZone dateTimeZone9 = cachedDateTimeZone4.getUncachedZone();
        long long11 = cachedDateTimeZone4.previousTransition((long) 22403);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 22403L + "'", long11 == 22403L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology2 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str6 = cachedDateTimeZone4.getNameKey(31507200115L);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone4.getUncachedZone();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(buddhistChronology2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        java.util.Locale locale7 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket10 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology6, locale7, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology6, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone17 = null;
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(dateTimeZone17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
        org.joda.time.LocalDateTime localDateTime21 = dateTime20.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration22 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withDurationAdded(readableDuration22, (int) 'a');
        org.joda.time.DateTime.Property property25 = dateTime20.centuryOfEra();
        org.joda.time.DateTime.Property property26 = dateTime20.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField28 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16, dateTimeFieldType27);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField29 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField2, dateTimeFieldType27);
        long long31 = delegatedDateTimeField29.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder32.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder32.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime(dateTimeZone36);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.DateTime dateTime39 = dateTime37.plus(readablePeriod38);
        org.joda.time.LocalDateTime localDateTime40 = dateTime39.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration41 = null;
        org.joda.time.DateTime dateTime43 = dateTime39.withDurationAdded(readableDuration41, (int) 'a');
        org.joda.time.DateTime.Property property44 = dateTime39.centuryOfEra();
        org.joda.time.DateTime.Property property45 = dateTime39.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder35.appendSignedDecimal(dateTimeFieldType46, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder50.clear();
        org.joda.time.DateTimeZone dateTimeZone52 = null;
        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime(dateTimeZone52);
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        org.joda.time.DateTime dateTime55 = dateTime53.plus(readablePeriod54);
        org.joda.time.LocalDateTime localDateTime56 = dateTime55.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration57 = null;
        org.joda.time.DateTime dateTime59 = dateTime55.withDurationAdded(readableDuration57, (int) 'a');
        org.joda.time.DateTime.Property property60 = dateTime55.centuryOfEra();
        org.joda.time.DateTime.Property property61 = dateTime55.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType62 = property61.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder65 = dateTimeFormatterBuilder50.appendSignedDecimal(dateTimeFieldType62, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder67 = dateTimeFormatterBuilder35.appendFixedDecimal(dateTimeFieldType62, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField69 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField29, dateTimeFieldType62, 174);
        org.joda.time.DurationField durationField70 = dividedDateTimeField69.getRangeDurationField();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField71 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField69);
        long long73 = remainderDateTimeField71.roundCeiling(1566436413691L);
        int int75 = remainderDateTimeField71.getMaximumValue((-7200000L));
        int int77 = remainderDateTimeField71.get(24L);
        int int78 = remainderDateTimeField71.getDivisor();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(localDateTime21);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-1L) + "'", long31 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(localDateTime40);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(localDateTime56);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(property60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(dateTimeFieldType62);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder67);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1566439199999L + "'", long73 == 1566439199999L);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 173 + "'", int75 == 173);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 174 + "'", int78 == 174);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime dateTime12 = dateTime9.withHourOfDay(0);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime.Property property15 = dateTime12.dayOfWeek();
        org.joda.time.DateTime dateTime17 = property15.addToCopy((long) (byte) 1);
        try {
            org.joda.time.Instant instant18 = new org.joda.time.Instant((java.lang.Object) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("5", "22450", 24, (int) (byte) 0);
        long long6 = fixedDateTimeZone4.previousTransition((long) 22463);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        boolean boolean9 = fixedDateTimeZone4.isStandardOffset((long) (-98));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 22463L + "'", long6 == 22463L);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2564", (java.lang.Number) (-4L), (java.lang.Number) 21622403L, (java.lang.Number) 1560345244083L);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("12", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset(0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder5.setStandardOffset((int) '4');
        org.joda.time.DateTimeZone dateTimeZone10 = dateTimeZoneBuilder5.toDateTimeZone("", false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 31, (-292268459), 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(12, 'a', 1, 2000, (int) ' ', false, 411);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("1969-12-31T00:06:01.052-08:00", 6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField2 = julianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField4 = julianChronology0.weeks();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(dateTimeZone2);
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.plus(readablePeriod4);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        java.lang.String str7 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) localDateTime6);
        boolean boolean8 = dateTimeFormatter1.isOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) julianChronology10);
        org.joda.time.tz.DefaultNameProvider defaultNameProvider12 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider12);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        java.util.Locale locale18 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket21 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology17, locale18, (java.lang.Integer) 4, (int) 'a');
        java.lang.Integer int22 = dateTimeParserBucket21.getOffsetInteger();
        boolean boolean24 = dateTimeParserBucket21.restoreState((java.lang.Object) 4);
        int int25 = dateTimeParserBucket21.getOffset();
        java.util.Locale locale26 = dateTimeParserBucket21.getLocale();
        java.lang.String str29 = defaultNameProvider12.getShortName(locale26, "2019-W24-3", "2019163T061308.342");
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket31 = new org.joda.time.format.DateTimeParserBucket((long) 2000, (org.joda.time.Chronology) julianChronology10, locale26, (java.lang.Integer) (-8));
        org.joda.time.DateTimeField dateTimeField32 = julianChronology10.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969365T235959.999" + "'", str7.equals("1969365T235959.999"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNull(int22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(locale26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(dateTimeField32);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(readableDuration13, (int) 'a');
        org.joda.time.DateTime dateTime17 = dateTime15.minusMonths((-10));
        boolean boolean18 = dateTimeParserBucket7.restoreState((java.lang.Object) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone19 = dateTimeParserBucket7.getZone();
        java.lang.String str20 = dateTimeZone19.getID();
        long long24 = dateTimeZone19.convertLocalToUTC(0L, false, (long) 20);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(dateTimeZone25);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime26.plus(readablePeriod27);
        org.joda.time.LocalDateTime localDateTime29 = dateTime28.toLocalDateTime();
        org.joda.time.DateTime dateTime31 = dateTime28.withMonthOfYear((int) (short) 10);
        int int32 = dateTime28.getCenturyOfEra();
        org.joda.time.DateTimeZone dateTimeZone33 = null;
        org.joda.time.DateTime dateTime34 = new org.joda.time.DateTime(dateTimeZone33);
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.plus(readablePeriod35);
        org.joda.time.LocalDateTime localDateTime37 = dateTime36.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime40 = dateTime36.withDurationAdded(readableDuration38, (int) 'a');
        org.joda.time.DateTime.Property property41 = dateTime36.centuryOfEra();
        org.joda.time.DateTime dateTime42 = property41.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone43 = dateTime42.getZone();
        org.joda.time.DateTime dateTime45 = dateTime42.withHourOfDay(0);
        org.joda.time.DateTime dateTime47 = dateTime45.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime dateTime48 = dateTime47.toDateTimeISO();
        org.joda.time.DateTime dateTime49 = dateTime47.withTimeAtStartOfDay();
        org.joda.time.Chronology chronology50 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime28, (org.joda.time.ReadableInstant) dateTime47);
        int int51 = dateTimeZone19.getOffset((org.joda.time.ReadableInstant) dateTime47);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+00:00:00.001" + "'", str20.equals("+00:00:00.001"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1L) + "'", long24 == (-1L));
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(localDateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 19 + "'", int32 == 19);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localDateTime37);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        int int8 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime5, "hi!", (int) (byte) 0);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime5.secondOfDay();
        org.joda.time.MutableDateTime mutableDateTime10 = property9.roundHalfFloor();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.roundCeiling();
        int int12 = mutableDateTime11.getDayOfWeek();
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime11.yearOfEra();
        try {
            mutableDateTime11.setDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(mutableDateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withDurationAdded(readableDuration5, (int) 'a');
        org.joda.time.DateTime.Property property8 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.DateTime dateTime12 = dateTime9.withHourOfDay(0);
        org.joda.time.DateTime dateTime14 = dateTime12.plusMinutes((int) (byte) 0);
        org.joda.time.DateTime.Property property15 = dateTime12.dayOfWeek();
        org.joda.time.DateTime dateTime17 = dateTime12.withCenturyOfEra((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder0.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendHourOfHalfday((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear(3);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder6.clear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.LocalDateTime localDateTime12 = dateTime11.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime15 = dateTime11.withDurationAdded(readableDuration13, (int) 'a');
        org.joda.time.DateTime.Property property16 = dateTime11.centuryOfEra();
        org.joda.time.DateTime.Property property17 = dateTime11.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder6.appendSignedDecimal(dateTimeFieldType18, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType18, (int) (short) 0, 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder5.appendMonthOfYearText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder26.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder26.appendTimeZoneId();
        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatterBuilder26.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder25.appendOptional(dateTimeParser29);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder25.appendLiteral('#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
        org.junit.Assert.assertNotNull(dateTimeParser29);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(0L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        long long5 = dateTimeZone1.adjustOffset((long) (byte) -1, true);
        org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.now(dateTimeZone1);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.era();
        int int8 = property7.getMaximumValueOverall();
        org.joda.time.MutableDateTime mutableDateTime9 = property7.roundHalfEven();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-1L) + "'", long5 == (-1L));
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(mutableDateTime9);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField1 = buddhistChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.hourOfHalfday();
        org.joda.time.DurationField durationField3 = buddhistChronology0.weekyears();
        org.joda.time.DurationField durationField4 = buddhistChronology0.weeks();
        org.joda.time.DurationField durationField5 = buddhistChronology0.weeks();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField2 = buddhistChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = buddhistChronology1.hourOfHalfday();
        org.joda.time.chrono.BuddhistChronology buddhistChronology4 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField5 = buddhistChronology4.millis();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now((org.joda.time.Chronology) buddhistChronology4);
        org.joda.time.DateTimeField dateTimeField7 = buddhistChronology4.hourOfHalfday();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField9 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) buddhistChronology1, dateTimeField7, (int) ' ');
        org.joda.time.DateTimeZone dateTimeZone10 = buddhistChronology1.getZone();
        org.joda.time.DateTimeField dateTimeField11 = buddhistChronology1.clockhourOfHalfday();
        org.joda.time.field.SkipDateTimeField skipDateTimeField12 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology0, dateTimeField11);
        org.joda.time.DateTimeField dateTimeField13 = buddhistChronology0.year();
        org.joda.time.DateTimeField dateTimeField14 = buddhistChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(buddhistChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        java.util.Locale locale4 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket7 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology3, locale4, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.chrono.ZonedChronology zonedChronology11 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology3, dateTimeZone9);
        org.joda.time.DurationField durationField12 = zonedChronology11.eras();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        java.util.Locale locale17 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket20 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology16, locale17, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone21 = null;
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime(dateTimeZone21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.plus(readablePeriod23);
        org.joda.time.LocalDateTime localDateTime25 = dateTime24.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration26 = null;
        org.joda.time.DateTime dateTime28 = dateTime24.withDurationAdded(readableDuration26, (int) 'a');
        org.joda.time.DateTime dateTime30 = dateTime28.minusMonths((-10));
        boolean boolean31 = dateTimeParserBucket20.restoreState((java.lang.Object) dateTime28);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTimeParserBucket20.getZone();
        java.lang.String str33 = dateTimeZone32.getID();
        org.joda.time.Chronology chronology34 = zonedChronology11.withZone(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField35 = zonedChronology11.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(zonedChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(localDateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+00:00:00.001" + "'", str33.equals("+00:00:00.001"));
        org.junit.Assert.assertNotNull(chronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime3 = dateTime1.plus(readablePeriod2);
        org.joda.time.LocalDateTime localDateTime4 = dateTime3.toLocalDateTime();
        org.joda.time.DateTime dateTime6 = dateTime3.withMonthOfYear((int) (short) 10);
        org.joda.time.DateTime dateTime8 = dateTime3.minusWeeks((-10));
        long long9 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.DateTime.Property property10 = dateTime8.hourOfDay();
        boolean boolean12 = dateTime8.isAfter((-99L));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(localDateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 6047999998L + "'", long9 == 6047999998L);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.joda.time.MutableDateTime mutableDateTime0 = org.joda.time.MutableDateTime.now();
        org.joda.time.MutableDateTime.Property property1 = mutableDateTime0.dayOfYear();
        mutableDateTime0.setSecondOfDay(3);
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime0.monthOfYear();
        mutableDateTime0.setHourOfDay(5);
        org.junit.Assert.assertNotNull(mutableDateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(property4);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("061319-0700");
        java.lang.String str2 = jodaTimePermission1.getActions();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.joda.time.DurationField durationField4 = buddhistChronology3.millis();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology3.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        java.util.Locale locale10 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket13 = new org.joda.time.format.DateTimeParserBucket((long) (-10), (org.joda.time.Chronology) gJChronology9, locale10, (java.lang.Integer) 4, (int) 'a');
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetMillis(1);
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gJChronology9, dateTimeZone15);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField19 = iSOChronology18.hourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(dateTimeZone20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        org.joda.time.DateTime dateTime23 = dateTime21.plus(readablePeriod22);
        org.joda.time.LocalDateTime localDateTime24 = dateTime23.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.DateTime dateTime27 = dateTime23.withDurationAdded(readableDuration25, (int) 'a');
        org.joda.time.DateTime.Property property28 = dateTime23.centuryOfEra();
        org.joda.time.DateTime.Property property29 = dateTime23.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField31 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField19, dateTimeFieldType30);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField32 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5, dateTimeFieldType30);
        long long34 = delegatedDateTimeField32.roundHalfEven((long) (-10));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder35.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder35.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(dateTimeZone39);
        org.joda.time.ReadablePeriod readablePeriod41 = null;
        org.joda.time.DateTime dateTime42 = dateTime40.plus(readablePeriod41);
        org.joda.time.LocalDateTime localDateTime43 = dateTime42.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration44 = null;
        org.joda.time.DateTime dateTime46 = dateTime42.withDurationAdded(readableDuration44, (int) 'a');
        org.joda.time.DateTime.Property property47 = dateTime42.centuryOfEra();
        org.joda.time.DateTime.Property property48 = dateTime42.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property48.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder52 = dateTimeFormatterBuilder38.appendSignedDecimal(dateTimeFieldType49, 22403, (int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder53 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder53.clear();
        org.joda.time.DateTimeZone dateTimeZone55 = null;
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime(dateTimeZone55);
        org.joda.time.ReadablePeriod readablePeriod57 = null;
        org.joda.time.DateTime dateTime58 = dateTime56.plus(readablePeriod57);
        org.joda.time.LocalDateTime localDateTime59 = dateTime58.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration60 = null;
        org.joda.time.DateTime dateTime62 = dateTime58.withDurationAdded(readableDuration60, (int) 'a');
        org.joda.time.DateTime.Property property63 = dateTime58.centuryOfEra();
        org.joda.time.DateTime.Property property64 = dateTime58.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = property64.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder68 = dateTimeFormatterBuilder53.appendSignedDecimal(dateTimeFieldType65, 411, (int) '#');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder70 = dateTimeFormatterBuilder38.appendFixedDecimal(dateTimeFieldType65, 2);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField72 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField32, dateTimeFieldType65, 174);
        org.joda.time.DurationField durationField73 = dividedDateTimeField72.getRangeDurationField();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField72);
        long long76 = remainderDateTimeField74.roundHalfFloor((long) 292279588);
        jodaTimePermission1.checkGuard((java.lang.Object) remainderDateTimeField74);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder78 = new org.joda.time.format.DateTimeFormatterBuilder();
        dateTimeFormatterBuilder78.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder81 = dateTimeFormatterBuilder78.appendHourOfHalfday((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone82 = null;
        org.joda.time.DateTime dateTime83 = new org.joda.time.DateTime(dateTimeZone82);
        org.joda.time.ReadablePeriod readablePeriod84 = null;
        org.joda.time.DateTime dateTime85 = dateTime83.plus(readablePeriod84);
        org.joda.time.LocalDateTime localDateTime86 = dateTime85.toLocalDateTime();
        org.joda.time.ReadableDuration readableDuration87 = null;
        org.joda.time.DateTime dateTime89 = dateTime85.withDurationAdded(readableDuration87, (int) 'a');
        org.joda.time.DateTime.Property property90 = dateTime85.centuryOfEra();
        org.joda.time.DateTime.Property property91 = dateTime85.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType92 = property91.getFieldType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder95 = dateTimeFormatterBuilder81.appendSignedDecimal(dateTimeFieldType92, 22403, (int) (short) 10);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField96 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField74, dateTimeFieldType92);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(localDateTime24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-1L) + "'", long34 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(localDateTime43);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTimeFieldType49);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder52);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(localDateTime59);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder68);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder70);
        org.junit.Assert.assertNotNull(durationField73);
        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 291599999L + "'", long76 == 291599999L);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder81);
        org.junit.Assert.assertNotNull(dateTime85);
        org.junit.Assert.assertNotNull(localDateTime86);
        org.junit.Assert.assertNotNull(dateTime89);
        org.junit.Assert.assertNotNull(property90);
        org.junit.Assert.assertNotNull(property91);
        org.junit.Assert.assertNotNull(dateTimeFieldType92);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder95);
    }
}

