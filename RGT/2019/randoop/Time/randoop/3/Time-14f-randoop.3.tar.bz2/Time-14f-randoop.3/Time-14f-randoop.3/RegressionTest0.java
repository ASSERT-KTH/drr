import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.tz.NameProvider nameProvider0 = null;
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) -1, (int) (byte) 100, (-1), (int) '4', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField0, 1, (-1), (int) (short) 10);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.joda.time.chrono.BuddhistChronology.BE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 100, (int) (short) 100, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        try {
            org.joda.time.MonthDay monthDay3 = new org.joda.time.MonthDay((java.lang.Object) julianChronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.JulianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.era();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
        boolean boolean5 = property1.equals((java.lang.Object) dateTimeZone4);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test010");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560630371636L + "'", long0 == 1560630371636L);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTime();
        int int2 = dateTimeFormatter1.getDefaultYear();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTimeField dateTimeField1 = null;
        try {
            org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField3 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (-1), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.io.Writer writer1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(writer1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.era();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(2000, (int) (short) 1, 100, (int) (short) 10, 2000, (org.joda.time.Chronology) julianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        int int0 = org.joda.time.MonthDay.MONTH_OF_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (byte) 10, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11L + "'", long2 == 11L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField5 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType3, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDate();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology1.weekOfWeekyear();
        try {
            org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) (short) 10, (org.joda.time.Chronology) julianChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("AD", (int) (byte) 100, 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for AD must be in the range [1,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.chrono.JulianChronology julianChronology7 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology7.era();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology7.getZone();
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(2000, (int) (byte) 100, 0, 1, 6, (int) (short) 10, (int) 'a', (org.joda.time.Chronology) julianChronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        org.joda.time.DurationField durationField5 = skipUndoDateTimeField4.getDurationField();
        boolean boolean6 = skipUndoDateTimeField4.isLenient();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType7, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        org.joda.time.DurationField durationField5 = skipUndoDateTimeField4.getDurationField();
        boolean boolean6 = skipUndoDateTimeField4.isLenient();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField8 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        org.joda.time.DurationField durationField5 = skipUndoDateTimeField4.getDurationField();
        boolean boolean6 = skipUndoDateTimeField4.isLenient();
        long long9 = skipUndoDateTimeField4.addWrapField(0L, (int) (short) 100);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(2, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.util.Calendar calendar0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromCalendarFields(calendar0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The calendar must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField3 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField1, dateTimeFieldType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime2 = property1.withMaximumValue();
        org.joda.time.DateTime dateTime3 = property1.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = dateTime3.withEra(0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        int int2 = dateTimeFormatter0.getDefaultYear();
        java.lang.StringBuffer stringBuffer3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer3, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withDefaultYear((int) (byte) -1);
        java.lang.Appendable appendable6 = null;
        try {
            dateTimeFormatter5.printTo(appendable6, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = property1.getFieldType();
        try {
            org.joda.time.Interval interval4 = property1.toInterval();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFieldType3);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        boolean boolean6 = skipUndoDateTimeField4.isLeap(9223372036854775807L);
        org.joda.time.DurationField durationField7 = skipUndoDateTimeField4.getDurationField();
        try {
            long long10 = durationField7.subtract(0L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) (short) 10, (int) (short) 10, 1, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.era();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime(1L, dateTimeZone8);
        org.joda.time.LocalDateTime localDateTime10 = null;
        boolean boolean11 = dateTimeZone8.isLocalDateTimeGap(localDateTime10);
        org.joda.time.MonthDay monthDay12 = org.joda.time.MonthDay.now(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(0, (int) (short) 100, (int) '#', 25, (int) (short) -1, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 25 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(monthDay12);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.withSecondOfMinute((int) (short) 10);
        try {
            org.joda.time.DateTime dateTime5 = dateTime3.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (int) (short) -1, 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for  must be in the range [1,35]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DurationField durationField3 = julianChronology0.hours();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField5 = new org.joda.time.field.DecoratedDurationField(durationField3, durationFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.era();
        org.joda.time.DateTimeField dateTimeField3 = property2.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property2.getFieldType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.io.Writer writer3 = null;
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str6 = dateTimeZone5.toString();
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone5, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(dateTimeZone5);
        org.joda.time.Chronology chronology10 = monthDay9.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray11 = monthDay9.getFields();
        try {
            dateTimeFormatter0.printTo(writer3, (org.joda.time.ReadablePartial) monthDay9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+52:00" + "'", str6.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(dateTimeFieldArray11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) '4', 0, (int) (byte) 0, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField10, 2000);
        java.lang.String str13 = skipUndoDateTimeField12.toString();
        int int15 = skipUndoDateTimeField12.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str18 = dateTimeZone17.toString();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone17, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(dateTimeZone17);
        int int22 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) monthDay21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay21, 0, locale24);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str28 = dateTimeZone27.toString();
        boolean boolean30 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone27, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay31 = new org.joda.time.MonthDay(dateTimeZone27);
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = skipUndoDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) monthDay31, (int) (short) 10, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[era]" + "'", str13.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+52:00" + "'", str18.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "BC" + "'", str25.equals("BC"));
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "+52:00" + "'", str28.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        boolean boolean1 = dateTime0.isAfterNow();
        try {
            org.joda.time.DateTime dateTime3 = dateTime0.withDayOfWeek(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        int int2 = dateTimeFormatter0.getDefaultYear();
        try {
            long long4 = dateTimeFormatter0.parseMillis("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        int int2 = dateTime0.getMonthOfYear();
        try {
            org.joda.time.DateTime dateTime4 = dateTime0.withEra(35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField10 = new org.joda.time.field.ScaledDurationField(durationField7, durationFieldType8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.era();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
        org.joda.time.DurationField durationField5 = julianChronology2.hours();
        org.joda.time.DateTime dateTime6 = dateTime0.toDateTime((org.joda.time.Chronology) julianChronology2);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, 2000);
        java.lang.String str12 = skipUndoDateTimeField11.toString();
        int int14 = skipUndoDateTimeField11.get((long) (short) 0);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField17, 2000);
        java.lang.String str20 = skipUndoDateTimeField19.toString();
        int int22 = skipUndoDateTimeField19.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str25 = dateTimeZone24.toString();
        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone24, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(dateTimeZone24);
        int int29 = skipUndoDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) monthDay28);
        java.util.Locale locale31 = null;
        java.lang.String str32 = skipUndoDateTimeField11.getAsText((org.joda.time.ReadablePartial) monthDay28, 0, locale31);
        int[] intArray38 = new int[] { (short) -1, 4, 26, (short) 0, (short) 100 };
        try {
            julianChronology2.validate((org.joda.time.ReadablePartial) monthDay28, intArray38);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[era]" + "'", str12.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[era]" + "'", str20.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+52:00" + "'", str25.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "BC" + "'", str32.equals("BC"));
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long10 = gregorianChronology6.add(11L, (-1L), 10);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((int) (short) 10, (-1), (int) (byte) 0, (int) (short) 1, 0, (int) 'a', (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 9223372036854775807L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str7 = dateTimeZone6.toString();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone6, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(dateTimeZone6);
        org.joda.time.Chronology chronology11 = monthDay10.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray12 = monthDay10.getFields();
        int[] intArray16 = new int[] { (byte) 100, (short) 10 };
        try {
            int[] intArray18 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) monthDay10, (int) (byte) 1, intArray16, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeFieldArray12);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.year();
        try {
            org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(6, (int) (byte) -1, (org.joda.time.Chronology) iSOChronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str9 = dateTimeZone8.toString();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone8);
        try {
            org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(0, (int) (short) -1, (int) (byte) 10, 10, 2000, (int) (byte) -1, (int) (short) 100, dateTimeZone8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+52:00" + "'", str9.equals("+52:00"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        int int2 = dateTime0.getMonthOfYear();
        org.joda.time.DateTime.Property property3 = dateTime0.minuteOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField10, 2000);
        java.lang.String str13 = skipUndoDateTimeField12.toString();
        int int15 = skipUndoDateTimeField12.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str18 = dateTimeZone17.toString();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone17, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(dateTimeZone17);
        int int22 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) monthDay21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay21, 0, locale24);
        java.util.Locale locale27 = null;
        try {
            java.lang.String str28 = skipUndoDateTimeField4.getAsShortText((int) (byte) 10, locale27);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[era]" + "'", str13.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+52:00" + "'", str18.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "BC" + "'", str25.equals("BC"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField10, 2000);
        java.lang.String str13 = skipUndoDateTimeField12.toString();
        int int15 = skipUndoDateTimeField12.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str18 = dateTimeZone17.toString();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone17, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(dateTimeZone17);
        int int22 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) monthDay21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay21, 0, locale24);
        org.joda.time.JodaTimePermission jodaTimePermission27 = new org.joda.time.JodaTimePermission("hi!");
        boolean boolean28 = monthDay21.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[era]" + "'", str13.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+52:00" + "'", str18.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "BC" + "'", str25.equals("BC"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.era();
        org.joda.time.DateTime dateTime4 = dateTime1.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime6 = dateTime1.withHourOfDay(1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
        org.joda.time.DateTime dateTime12 = dateTime6.withField(dateTimeFieldType10, (int) (byte) 0);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.longTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str5 = dateTimeZone4.toString();
        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone4, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay8 = new org.joda.time.MonthDay(dateTimeZone4);
        org.joda.time.Chronology chronology9 = monthDay8.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay8.getFields();
        int int11 = monthDay8.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray12 = monthDay8.getFields();
        int[] intArray14 = iSOChronology2.get((org.joda.time.ReadablePartial) monthDay8, (long) (short) 1);
        try {
            org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(25, 0, (org.joda.time.Chronology) iSOChronology2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 25 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+52:00" + "'", str5.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray12);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("Property[era]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.Instant instant5 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology6 = instant5.getChronology();
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (byte) 0, (int) (short) 1, 0, (int) '#', 100, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = property1.getFieldType();
        int int4 = property1.getMinimumValue();
        try {
            org.joda.time.Interval interval5 = property1.toInterval();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFieldType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        java.lang.String str3 = property1.toString();
        int int4 = property1.get();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Property[era]" + "'", str3.equals("Property[era]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = julianChronology0.add(readablePeriod8, 0L, 4);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        org.joda.time.DurationField durationField5 = skipUndoDateTimeField4.getDurationField();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str9 = dateTimeZone8.toString();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone8, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(dateTimeZone8);
        org.joda.time.Chronology chronology13 = monthDay12.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray14 = monthDay12.getFields();
        int int15 = monthDay12.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray16 = monthDay12.getFields();
        int[] intArray18 = iSOChronology6.get((org.joda.time.ReadablePartial) monthDay12, (long) (short) 1);
        java.util.Locale locale20 = null;
        try {
            java.lang.String str21 = skipUndoDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay12, (int) (byte) 100, locale20);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+52:00" + "'", str9.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeFieldArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray16);
        org.junit.Assert.assertNotNull(intArray18);
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test080");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
//        org.joda.time.DateTime dateTime6 = dateTime0.withDate((int) '4', (int) (short) 10, 6);
//        int int7 = dateTime0.getWeekOfWeekyear();
//        org.joda.time.DateTime.Property property8 = dateTime0.minuteOfDay();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 25 + "'", int7 == 25);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(10);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime4.withFieldAdded(durationFieldType5, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str8 = dateTimeZone7.toString();
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone7, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay11 = new org.joda.time.MonthDay(dateTimeZone7);
        org.joda.time.Chronology chronology12 = monthDay11.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray13 = monthDay11.getFields();
        int int14 = monthDay11.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray15 = monthDay11.getFields();
        int[] intArray17 = iSOChronology5.get((org.joda.time.ReadablePartial) monthDay11, (long) (short) 1);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) ' ', 19, 0, 97, 0, (org.joda.time.Chronology) iSOChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+52:00" + "'", str8.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeFieldArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray15);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) ' ', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must not be larger than 12");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DurationField durationField4 = julianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology1.weekOfWeekyear();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(obj0, (org.joda.time.Chronology) julianChronology1);
        try {
            long long12 = julianChronology1.getDateTimeMillis((long) 84381, 6, 19, (int) (byte) 1, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        java.lang.Appendable appendable2 = null;
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.withFields(readablePartial6);
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 0, 2580, 0, 97, (int) '4', 4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.util.Date date0 = null;
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.fromDateFields(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The date must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-97) + "'", int1 == (-97));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("2019", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 2019");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
//        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.era();
//        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(1L, dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
//        int int13 = dateTime11.getMonthOfYear();
//        boolean boolean14 = dateTime11.isEqualNow();
//        int int15 = dateTime11.getMillisOfDay();
//        int int16 = property6.getDifference((org.joda.time.ReadableInstant) dateTime11);
//        try {
//            org.joda.time.DateTime dateTime18 = dateTime11.withWeekOfWeekyear((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2580 + "'", int16 == 2580);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.year();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology5);
        java.util.Locale locale10 = null;
        try {
            java.lang.String str11 = dateTime4.toString("UTC", locale10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: U");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray5 = copticChronology0.get(readablePeriod2, 11L, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((java.lang.Object) '#', (org.joda.time.DateTimeZone) fixedDateTimeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Character");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay5.plus(readablePeriod6);
        org.joda.time.MonthDay monthDay9 = monthDay7.minusDays((int) (byte) 0);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology11 = dateTime10.getChronology();
        org.joda.time.DateTime.Property property12 = dateTime10.yearOfCentury();
        org.joda.time.DateTime dateTime16 = dateTime10.withDate((int) '4', (int) (short) 10, 6);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property18 = dateTime17.era();
        org.joda.time.DateTime dateTime20 = dateTime17.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime22 = dateTime17.withHourOfDay(1);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTimeField dateTimeField25 = property24.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property24.getFieldType();
        org.joda.time.DateTime dateTime28 = dateTime22.withField(dateTimeFieldType26, (int) (byte) 0);
        boolean boolean29 = dateTime10.isSupported(dateTimeFieldType26);
        try {
            org.joda.time.MonthDay.Property property30 = monthDay7.property(dateTimeFieldType26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.era();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        long long12 = julianChronology6.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField13 = julianChronology6.hours();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology6.millisOfDay();
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((int) '#', (-97), (int) (byte) -1, 2, (int) (byte) 100, 1, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-34L) + "'", long12 == (-34L));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMonths((int) (byte) 0);
//        try {
//            org.joda.time.DateTime dateTime8 = dateTime0.withMinuteOfHour((int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 26 + "'", int4 == 26);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number7 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 1 + "'", number7.equals((byte) 1));
    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test103");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) '4');
//        org.joda.time.DateTime dateTime8 = dateTime6.plusHours(1);
//        int int9 = mutableDateTime3.compareTo((org.joda.time.ReadableInstant) dateTime6);
//        int int10 = dateTime6.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 26 + "'", int10 == 26);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.hourOfHalfday();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology10 = dateTime9.getChronology();
        org.joda.time.DateTime.Property property11 = dateTime9.yearOfCentury();
        int int12 = property11.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, dateTimeFieldType13, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 99 + "'", int12 == 99);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test106");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime0.toDateMidnight();
//        boolean boolean8 = dateTime0.isBefore((long) (-1));
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        try {
            org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(julianChronology6);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        long long4 = dateTime3.getMillis();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560626784922L + "'", long4 == 1560626784922L);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DurationField durationField8 = julianChronology0.days();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DurationField durationField8 = julianChronology0.weekyears();
        long long11 = durationField8.subtract((long) (short) 10, (int) '4');
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1640822399990L) + "'", long11 == (-1640822399990L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime2 = property1.withMaximumValue();
        java.lang.String str3 = property1.getAsText();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AD" + "'", str3.equals("AD"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, 6, 0, (int) 'a');
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        try {
            long long6 = buddhistChronology0.getDateTimeMillis(100, (-1), 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.year();
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        try {
            org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) iSOChronology0, dateTimeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[era]" + "'", str7.equals("Property[era]"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        java.lang.String str3 = property1.getAsShortText();
        int int4 = property1.getMaximumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AD" + "'", str3.equals("AD"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        try {
            org.joda.time.DateTimeField dateTimeField10 = monthDay5.getField(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(2580, 25, (int) '#', 6, 10, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 25 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
//        try {
//            long long10 = offsetDateTimeField5.remainder(9223372036854775807L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Adding time zone offset caused overflow");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test124");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
//        java.lang.Appendable appendable1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property3 = dateTime2.era();
//        org.joda.time.DateTime dateTime5 = dateTime2.plusHours((int) (byte) -1);
//        int int6 = dateTime2.getMinuteOfHour();
//        org.joda.time.DateTime dateTime8 = dateTime2.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property10 = dateTime9.era();
//        org.joda.time.DateTime dateTime12 = dateTime9.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime14 = dateTime9.withHourOfDay(1);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property16 = dateTime15.era();
//        org.joda.time.DateTimeField dateTimeField17 = property16.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
//        org.joda.time.DateTime dateTime20 = dateTime14.withField(dateTimeFieldType18, (int) (byte) 0);
//        boolean boolean21 = dateTime2.isSupported(dateTimeFieldType18);
//        try {
//            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 26 + "'", int6 == 26);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.withFields(readablePartial5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str9 = dateTimeZone8.toString();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone8, (java.lang.Object) (-1.0f));
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone8);
        org.joda.time.Chronology chronology13 = buddhistChronology0.withZone(dateTimeZone8);
        org.joda.time.chrono.JulianChronology julianChronology14 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology14.era();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology14.getZone();
        org.joda.time.DurationField durationField17 = julianChronology14.hours();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology14.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology14.minuteOfDay();
        boolean boolean20 = buddhistChronology0.equals((java.lang.Object) dateTimeField19);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+52:00" + "'", str9.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(julianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("002620.820+5200");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 002620.820+5200");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (byte) 0, (long) (-97));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.withFields(readablePartial6);
        boolean boolean8 = dateTime5.isEqualNow();
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.era();
        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology9.getZone();
        org.joda.time.DurationField durationField12 = julianChronology9.hours();
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.era();
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology13.getZone();
        long long19 = julianChronology13.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField20 = julianChronology13.hours();
        boolean boolean21 = julianChronology9.equals((java.lang.Object) julianChronology13);
        try {
            org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay((java.lang.Object) boolean8, (org.joda.time.Chronology) julianChronology13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-34L) + "'", long19 == (-34L));
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.DateTime dateTime7 = dateTime3.withCenturyOfEra((int) (byte) 0);
        int int8 = dateTime7.getCenturyOfEra();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        int int6 = fixedDateTimeZone4.getStandardOffset((long) 6);
        long long8 = fixedDateTimeZone4.previousTransition((long) (short) 10);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(4);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours(1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str7 = dateTimeZone6.toString();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone6, (java.lang.Object) (-1.0f));
        org.joda.time.DateTime dateTime10 = dateTime4.withZone(dateTimeZone6);
        try {
            org.joda.time.DateTime dateTime14 = dateTime4.withDate(0, (-97), 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -97 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay5.plus(readablePeriod6);
        org.joda.time.MonthDay monthDay9 = monthDay7.minusDays((int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str12 = dateTimeZone11.toString();
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone11, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(dateTimeZone11);
        org.joda.time.Chronology chronology16 = monthDay15.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray17 = monthDay15.getFields();
        org.joda.time.MonthDay.Property property18 = monthDay15.monthOfYear();
        org.joda.time.MonthDay monthDay19 = property18.getMonthDay();
        org.joda.time.MonthDay monthDay20 = property18.getMonthDay();
        boolean boolean21 = monthDay7.isBefore((org.joda.time.ReadablePartial) monthDay20);
        try {
            int int23 = monthDay7.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+52:00" + "'", str12.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeFieldArray17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long4 = dateTimeZone2.convertUTCToLocal((-34L));
        try {
            org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone2, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-34L) + "'", long4 == (-34L));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.minusWeeks((int) '4');
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime11 = dateTime9.plusHours(1);
        int int12 = mutableDateTime6.compareTo((org.joda.time.ReadableInstant) dateTime9);
        int int13 = property1.compareTo((org.joda.time.ReadableInstant) dateTime9);
        boolean boolean14 = property1.isLeap();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.withFields(readablePartial6);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withHourOfDay(25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 25 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.MonthDay monthDay0 = new org.joda.time.MonthDay();
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test141");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property2 = dateTime1.era();
//        org.joda.time.DateTime dateTime4 = dateTime1.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.Chronology chronology8 = dateTime7.getChronology();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfCentury();
//        int int10 = property9.getMaximumValueOverall();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        int int12 = dateTime6.get(dateTimeFieldType11);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField13 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType11);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 99 + "'", int10 == 99);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 70 + "'", int12 == 70);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        long long9 = skipUndoDateTimeField4.roundHalfCeiling((long) 'a');
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str12 = dateTimeZone11.toString();
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone11, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(dateTimeZone11);
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        org.joda.time.MonthDay monthDay17 = monthDay15.plus(readablePeriod16);
        org.joda.time.MonthDay monthDay19 = monthDay17.minusDays((int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str22 = dateTimeZone21.toString();
        boolean boolean24 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone21, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay25 = new org.joda.time.MonthDay(dateTimeZone21);
        org.joda.time.Chronology chronology26 = monthDay25.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray27 = monthDay25.getFields();
        org.joda.time.MonthDay.Property property28 = monthDay25.monthOfYear();
        org.joda.time.MonthDay monthDay29 = property28.getMonthDay();
        org.joda.time.MonthDay monthDay30 = property28.getMonthDay();
        boolean boolean31 = monthDay17.isBefore((org.joda.time.ReadablePartial) monthDay30);
        int[] intArray35 = new int[] { 2, 4 };
        try {
            int[] intArray37 = skipUndoDateTimeField4.addWrapField((org.joda.time.ReadablePartial) monthDay30, (int) 'a', intArray35, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62105356800000L) + "'", long9 == (-62105356800000L));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+52:00" + "'", str12.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(monthDay17);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+52:00" + "'", str22.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeFieldArray27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(intArray35);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(1L, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfCentury();
        java.util.Locale locale6 = null;
        java.lang.String str7 = property5.getAsText(locale6);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "70" + "'", str7.equals("70"));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        try {
            long long7 = skipUndoDateTimeField4.add(187200000L, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        java.util.Locale locale6 = null;
        java.lang.String str7 = dateTime4.toString("������.000", locale6);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "������.000" + "'", str7.equals("������.000"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("Property[monthOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("UTC", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"UTC/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter0.printTo(appendable3, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: ");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.Instant instant3 = instant1.minus(0L);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        org.joda.time.MonthDay monthDay9 = property8.getMonthDay();
        org.joda.time.MonthDay monthDay10 = property8.getMonthDay();
        try {
            int int12 = monthDay10.getValue(10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay10);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        org.joda.time.TimeOfDay timeOfDay6 = dateTime0.toTimeOfDay();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(timeOfDay6);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        org.joda.time.DateTime dateTime5 = dateTime4.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.clockhourOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        long long7 = dateTimeZone1.adjustOffset((long) (byte) 10, true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test158");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
//        org.joda.time.DateTime dateTime7 = dateTime3.withYearOfCentury(0);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str11 = dateTimeZone10.toString();
//        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone10, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(dateTimeZone10);
//        org.joda.time.Chronology chronology15 = monthDay14.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray16 = monthDay14.getFields();
//        int int17 = property8.compareTo((org.joda.time.ReadablePartial) monthDay14);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+52:00" + "'", str11.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime0.withDate((int) '4', (int) (short) 10, 6);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField10, 2000);
        java.lang.String str13 = skipUndoDateTimeField12.toString();
        int int15 = skipUndoDateTimeField12.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str18 = dateTimeZone17.toString();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone17, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(dateTimeZone17);
        int int22 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) monthDay21);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str25 = dateTimeZone24.toString();
        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone24, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(dateTimeZone24);
        org.joda.time.ReadablePeriod readablePeriod29 = null;
        org.joda.time.MonthDay monthDay30 = monthDay28.plus(readablePeriod29);
        org.joda.time.MonthDay monthDay32 = monthDay30.minusDays((int) (byte) 0);
        int[] intArray38 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int39 = skipUndoDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) monthDay32, intArray38);
        try {
            int int40 = property7.compareTo((org.joda.time.ReadablePartial) monthDay32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[era]" + "'", str13.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+52:00" + "'", str18.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+52:00" + "'", str25.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(10);
        int int5 = dateTime4.getWeekOfWeekyear();
        try {
            java.lang.String str7 = dateTime4.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long7 = offsetDateTimeField5.roundFloor(187200011L);
        int int8 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.JodaTimePermission jodaTimePermission10 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property12 = dateTime11.era();
        org.joda.time.DateTime dateTime14 = dateTime11.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime16 = dateTime11.withHourOfDay(1);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property18 = dateTime17.era();
        org.joda.time.DateTimeField dateTimeField19 = property18.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.DateTime dateTime22 = dateTime16.withField(dateTimeFieldType20, (int) (byte) 0);
        jodaTimePermission10.checkGuard((java.lang.Object) dateTimeFieldType20);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType20, 2);
        java.lang.Object obj26 = null;
        org.joda.time.chrono.JulianChronology julianChronology27 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField28 = julianChronology27.era();
        org.joda.time.DateTimeZone dateTimeZone29 = julianChronology27.getZone();
        org.joda.time.DurationField durationField30 = julianChronology27.hours();
        org.joda.time.DateTimeField dateTimeField31 = julianChronology27.weekOfWeekyear();
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay(obj26, (org.joda.time.Chronology) julianChronology27);
        org.joda.time.ReadablePeriod readablePeriod33 = null;
        org.joda.time.MonthDay monthDay35 = monthDay32.withPeriodAdded(readablePeriod33, 25);
        java.util.Locale locale36 = null;
        try {
            java.lang.String str37 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) monthDay32, locale36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 187200000L + "'", long7 == 187200000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1438 + "'", int8 == 1438);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(julianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(monthDay35);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        org.joda.time.MonthDay monthDay9 = property8.getMonthDay();
        org.joda.time.MonthDay monthDay10 = property8.getMonthDay();
        java.util.Locale locale12 = null;
        try {
            org.joda.time.MonthDay monthDay13 = property8.setCopy("", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay10);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.Chronology chronology3 = julianChronology0.withUTC();
        java.lang.String str4 = julianChronology0.toString();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = julianChronology0.add(readablePeriod5, (long) (short) 0, 19);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "JulianChronology[UTC]" + "'", str4.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        int int6 = fixedDateTimeZone4.getOffsetFromLocal(10L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(1L, dateTimeZone3);
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone3.isLocalDateTimeGap(localDateTime5);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.withFields(readablePartial3);
        int int5 = dateTime0.getMinuteOfHour();
        org.joda.time.DateTime dateTime7 = dateTime0.withMillisOfSecond(35);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter2.printTo(writer3, (long) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        boolean boolean6 = skipUndoDateTimeField4.isLeap(9223372036854775807L);
        java.lang.Object obj7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.era();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.DurationField durationField11 = julianChronology8.hours();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology8.weekOfWeekyear();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(obj7, (org.joda.time.Chronology) julianChronology8);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.MonthDay monthDay16 = monthDay13.withPeriodAdded(readablePeriod14, 25);
        java.util.Locale locale17 = null;
        try {
            java.lang.String str18 = skipUndoDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay16, locale17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(monthDay16);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        int int10 = offsetDateTimeField5.getLeapAmount(100L);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.era();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str15 = dateTimeZone14.toString();
        boolean boolean17 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone14, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay18 = new org.joda.time.MonthDay(dateTimeZone14);
        org.joda.time.Chronology chronology19 = monthDay18.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray20 = monthDay18.getFields();
        int int21 = monthDay18.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray22 = monthDay18.getFields();
        int[] intArray24 = gregorianChronology11.get((org.joda.time.ReadablePartial) monthDay18, (long) 84381);
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str29 = dateTimeZone28.toString();
        boolean boolean31 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone28, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay(dateTimeZone28);
        org.joda.time.Chronology chronology33 = monthDay32.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray34 = monthDay32.getFields();
        int int35 = monthDay32.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray36 = monthDay32.getFields();
        int[] intArray38 = iSOChronology26.get((org.joda.time.ReadablePartial) monthDay32, (long) (short) 1);
        java.util.Locale locale40 = null;
        try {
            int[] intArray41 = offsetDateTimeField5.set((org.joda.time.ReadablePartial) monthDay18, (int) '4', intArray38, "DateTimeField[era]", locale40);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[era]\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+52:00" + "'", str15.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertNotNull(dateTimeFieldArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+52:00" + "'", str29.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTimeFieldArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray36);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.era();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
        org.joda.time.DurationField durationField5 = julianChronology2.hours();
        org.joda.time.DateTime dateTime6 = dateTime0.toDateTime((org.joda.time.Chronology) julianChronology2);
        boolean boolean8 = dateTime0.isAfter((long) 35);
        try {
            org.joda.time.DateTime dateTime10 = dateTime0.withYearOfEra(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDate();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getStandardOffset((long) (-1));
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        int int1 = gJChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = org.joda.time.format.DateTimeFormat.patternForStyle("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        long long10 = skipUndoDateTimeField4.addWrapField((long) 25, (int) (short) -1);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str13 = dateTimeZone12.toString();
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone12, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(dateTimeZone12);
        org.joda.time.ReadablePeriod readablePeriod17 = null;
        org.joda.time.MonthDay monthDay18 = monthDay16.plus(readablePeriod17);
        org.joda.time.MonthDay monthDay20 = monthDay18.minusDays((int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str23 = dateTimeZone22.toString();
        boolean boolean25 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone22, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(dateTimeZone22);
        org.joda.time.Chronology chronology27 = monthDay26.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray28 = monthDay26.getFields();
        org.joda.time.MonthDay.Property property29 = monthDay26.monthOfYear();
        org.joda.time.MonthDay monthDay30 = property29.getMonthDay();
        org.joda.time.MonthDay monthDay31 = property29.getMonthDay();
        boolean boolean32 = monthDay18.isBefore((org.joda.time.ReadablePartial) monthDay31);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField38 = new org.joda.time.field.SkipUndoDateTimeField(chronology34, dateTimeField36, 2000);
        java.lang.String str39 = skipUndoDateTimeField38.toString();
        int int41 = skipUndoDateTimeField38.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str44 = dateTimeZone43.toString();
        boolean boolean46 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone43, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay47 = new org.joda.time.MonthDay(dateTimeZone43);
        int int48 = skipUndoDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) monthDay47);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str51 = dateTimeZone50.toString();
        boolean boolean53 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone50, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay54 = new org.joda.time.MonthDay(dateTimeZone50);
        org.joda.time.ReadablePeriod readablePeriod55 = null;
        org.joda.time.MonthDay monthDay56 = monthDay54.plus(readablePeriod55);
        org.joda.time.MonthDay monthDay58 = monthDay56.minusDays((int) (byte) 0);
        int[] intArray64 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int65 = skipUndoDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) monthDay58, intArray64);
        try {
            int[] intArray67 = skipUndoDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) monthDay31, (int) (short) -1, intArray64, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-124273871999975L) + "'", long10 == (-124273871999975L));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+52:00" + "'", str23.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(monthDay30);
        org.junit.Assert.assertNotNull(monthDay31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTimeField[era]" + "'", str39.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "+52:00" + "'", str44.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "+52:00" + "'", str51.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(monthDay56);
        org.junit.Assert.assertNotNull(monthDay58);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        long long6 = skipUndoDateTimeField4.roundCeiling(100L);
        try {
            long long9 = skipUndoDateTimeField4.set((long) 100, 26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 26 for era must be in the range [1,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("CopticChronology[+52:00]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"CopticChronology[+52:00]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        int int15 = skipUndoDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField5.getAsShortText((long) 19, locale7);
//        long long10 = offsetDateTimeField5.roundHalfEven((long) (short) 1);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "239" + "'", str8.equals("239"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter3.getParser();
        org.joda.time.Chronology chronology5 = dateTimeFormatter3.getChronolgy();
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter3.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter2, dateTimeParser6);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.Chronology chronology2 = dateTimeFormatter1.getChronolgy();
        java.util.Locale locale3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter1.withLocale(locale3);
        try {
            org.joda.time.Instant instant5 = org.joda.time.Instant.parse("Property[era]", dateTimeFormatter4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[era]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int6 = skipUndoDateTimeField4.getMinimumValue();
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = skipUndoDateTimeField4.getAsText(25, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 25");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        long long6 = skipUndoDateTimeField4.roundCeiling(100L);
        java.lang.Object obj7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.era();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.DurationField durationField11 = julianChronology8.hours();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology8.weekOfWeekyear();
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(obj7, (org.joda.time.Chronology) julianChronology8);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField(chronology15, dateTimeField17, 2000);
        java.lang.String str20 = skipUndoDateTimeField19.toString();
        int int22 = skipUndoDateTimeField19.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str25 = dateTimeZone24.toString();
        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone24, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(dateTimeZone24);
        int int29 = skipUndoDateTimeField19.getMinimumValue((org.joda.time.ReadablePartial) monthDay28);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str32 = dateTimeZone31.toString();
        boolean boolean34 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone31, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay(dateTimeZone31);
        org.joda.time.ReadablePeriod readablePeriod36 = null;
        org.joda.time.MonthDay monthDay37 = monthDay35.plus(readablePeriod36);
        org.joda.time.MonthDay monthDay39 = monthDay37.minusDays((int) (byte) 0);
        int[] intArray45 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int46 = skipUndoDateTimeField19.getMaximumValue((org.joda.time.ReadablePartial) monthDay39, intArray45);
        try {
            int[] intArray48 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) monthDay13, 10800, intArray45, 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DateTimeField[era]" + "'", str20.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+52:00" + "'", str25.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "+52:00" + "'", str32.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(monthDay37);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.minusWeeks((int) '4');
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime11 = dateTime9.plusHours(1);
        int int12 = mutableDateTime6.compareTo((org.joda.time.ReadableInstant) dateTime9);
        int int13 = property1.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime15 = dateTime9.plusDays(2000);
        try {
            org.joda.time.DateTime dateTime19 = dateTime15.withDate((int) (byte) 10, 2580, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2580 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test189");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[+52:00]" + "'", str1.equals("ISOChronology[+52:00]"));
//    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.Chronology chronology7 = dateTime6.getChronology();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfCentury();
//        int int9 = property8.getMaximumValueOverall();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
//        int int11 = dateTime5.get(dateTimeFieldType10);
//        try {
//            org.joda.time.DateTime dateTime13 = dateTime5.withYearOfCentury((int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for yearOfCentury must be in the range [0,99]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 99 + "'", int9 == 99);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 70 + "'", int11 == 70);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withLocale(locale2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 35);
        java.lang.StringBuffer stringBuffer6 = null;
        try {
            dateTimeFormatter5.printTo(stringBuffer6, 3L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        try {
            long long8 = gJChronology0.getDateTimeMillis((int) (byte) 100, (int) (short) 100, (int) (byte) -1, (int) (byte) 10, 6, (-97), (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        try {
            int int4 = org.joda.time.field.FieldUtils.getWrappedValue(1, (-1), 25, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        int int10 = property8.getMinimumValueOverall();
        java.util.Locale locale11 = null;
        int int12 = property8.getMaximumTextLength(locale11);
        int int13 = property8.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekOfWeekyear();
        try {
            long long10 = julianChronology0.getDateTimeMillis(9, 2000, 0, (int) (byte) -1, 100, (int) (byte) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 1, 12);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 12L + "'", long2 == 12L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        try {
            org.joda.time.Instant instant1 = new org.joda.time.Instant((java.lang.Object) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.withFields(readablePartial5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str9 = dateTimeZone8.toString();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone8, (java.lang.Object) (-1.0f));
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone8);
        org.joda.time.Chronology chronology13 = gregorianChronology0.withZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+52:00" + "'", str9.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.era();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
        long long8 = julianChronology2.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField9 = julianChronology2.hours();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology2.millisOfDay();
        boolean boolean12 = julianChronology2.equals((java.lang.Object) 4);
        org.joda.time.DateTime dateTime13 = dateTime0.withChronology((org.joda.time.Chronology) julianChronology2);
        try {
            org.joda.time.DateTime dateTime15 = dateTime13.withEra((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-34L) + "'", long8 == (-34L));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) 10800);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime0.withDate((int) '4', (int) (short) 10, 6);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime dateTime10 = dateTime7.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime7.withHourOfDay(1);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property14 = dateTime13.era();
        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
        org.joda.time.DateTime dateTime18 = dateTime12.withField(dateTimeFieldType16, (int) (byte) 0);
        boolean boolean19 = dateTime0.isSupported(dateTimeFieldType16);
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) (short) 1, (java.lang.Number) 10.0f, (java.lang.Number) (short) 100);
        java.lang.String str24 = illegalFieldValueException23.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1" + "'", str24.equals("1"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 0, (long) 12);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-12L) + "'", long2 == (-12L));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((long) 26);
        long long9 = fixedDateTimeZone4.previousTransition((long) (byte) -1);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((long) (-1));
        long long14 = fixedDateTimeZone4.convertLocalToUTC((-124273871999975L), true);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-124273872000072L) + "'", long14 == (-124273872000072L));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.era();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        long long12 = julianChronology6.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField13 = julianChronology6.hours();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology6.millisOfDay();
        boolean boolean16 = julianChronology6.equals((java.lang.Object) 4);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str19 = dateTimeZone18.toString();
        org.joda.time.Chronology chronology20 = julianChronology6.withZone(dateTimeZone18);
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(0, 19, 0, (int) (short) 10, 84381, 10800, chronology20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 84381 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-34L) + "'", long12 == (-34L));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+52:00" + "'", str19.equals("+52:00"));
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long7 = offsetDateTimeField5.roundFloor(187200011L);
        java.util.Locale locale8 = null;
        int int9 = offsetDateTimeField5.getMaximumShortTextLength(locale8);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField5, 26, 25, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 26 for minuteOfDay must be in the range [25,19]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 187200000L + "'", long7 == 187200000L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        java.lang.String str1 = copticChronology0.toString();
//        try {
//            long long6 = copticChronology0.getDateTimeMillis((int) 'a', (int) '4', 6, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,13]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CopticChronology[+52:00]" + "'", str1.equals("CopticChronology[+52:00]"));
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfEra(84381);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withFieldAdded(durationFieldType5, 25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DurationField durationField4 = julianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology1.weekOfWeekyear();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(obj0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, 25);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str12 = dateTimeZone11.toString();
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone11, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(dateTimeZone11);
        org.joda.time.chrono.JulianChronology julianChronology16 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField17 = julianChronology16.millisOfSecond();
        boolean boolean18 = monthDay9.equals((java.lang.Object) dateTimeField17);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property20 = dateTime19.era();
        org.joda.time.DateTime dateTime22 = dateTime19.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration23 = null;
        org.joda.time.DateTime dateTime24 = dateTime22.minus(readableDuration23);
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology26 = dateTime25.getChronology();
        org.joda.time.DateTime.Property property27 = dateTime25.yearOfCentury();
        int int28 = property27.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        int int30 = dateTime24.get(dateTimeFieldType29);
        try {
            org.joda.time.MonthDay monthDay32 = monthDay9.withField(dateTimeFieldType29, 1438);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'yearOfCentury' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+52:00" + "'", str12.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(julianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 99 + "'", int28 == 99);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 19 + "'", int30 == 19);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.withFields(readablePartial3);
        org.joda.time.DateTime dateTime6 = dateTime0.minusMinutes((int) (short) 10);
        boolean boolean7 = dateTime0.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.withFields(readablePartial3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str7 = dateTimeZone6.toString();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone6, (java.lang.Object) (-1.0f));
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime0.toMutableDateTime(dateTimeZone6);
        int int11 = mutableDateTime10.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 19 + "'", int11 == 19);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        org.joda.time.DateTime dateTime7 = dateTime0.withHourOfDay((int) (byte) 0);
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime0.plus(readablePeriod8);
//        try {
//            org.joda.time.DateTime dateTime11 = dateTime9.withSecondOfMinute((-97));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -97 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime12 = dateTime7.withHourOfDay(1);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.era();
//        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
//        org.joda.time.DateTime dateTime18 = dateTime12.withField(dateTimeFieldType16, (int) (byte) 0);
//        boolean boolean19 = dateTime0.isSupported(dateTimeFieldType16);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType16, 0, 1438, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for era must be in the range [1438,0]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 26 + "'", int4 == 26);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        boolean boolean2 = dateTime0.isAfterNow();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortTime();
        try {
            long long2 = dateTimeFormatter0.parseMillis("Property[monthOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[monthOfYear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.secondOfMinute();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField6, 2000);
        org.joda.time.DurationField durationField9 = skipUndoDateTimeField8.getDurationField();
        boolean boolean10 = skipUndoDateTimeField8.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField8);
        java.lang.String str13 = skipUndoDateTimeField8.getAsShortText((long) 2);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AD" + "'", str13.equals("AD"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        boolean boolean6 = skipUndoDateTimeField4.isLeap(9223372036854775807L);
        long long8 = skipUndoDateTimeField4.roundHalfCeiling(1560626784922L);
        java.lang.String str10 = skipUndoDateTimeField4.getAsShortText(11L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62105356800000L) + "'", long8 == (-62105356800000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "AD" + "'", str10.equals("AD"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 12, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24L + "'", long2 == 24L);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = julianChronology0.add(readablePeriod1, (long) (short) 100, 19);
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.year();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime7 = dateTime0.withDurationAdded((long) 6, (int) (byte) 1);
//        org.joda.time.DateTime dateTime9 = dateTime7.minusDays(19);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 26 + "'", int4 == 26);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
//        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
//        org.joda.time.chrono.JulianChronology julianChronology38 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField39 = julianChronology38.era();
//        org.joda.time.DateTimeZone dateTimeZone40 = julianChronology38.getZone();
//        long long44 = julianChronology38.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DurationField durationField45 = julianChronology38.hours();
//        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField47 = julianChronology46.era();
//        org.joda.time.DateTimeZone dateTimeZone48 = julianChronology46.getZone();
//        long long52 = julianChronology46.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DurationField durationField53 = julianChronology46.hours();
//        org.joda.time.DurationField durationField54 = julianChronology46.weekyears();
//        try {
//            org.joda.time.field.PreciseDateTimeField preciseDateTimeField55 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType32, durationField45, durationField54);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range duration field must be precise");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 26 + "'", int20 == 26);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(julianChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + (-34L) + "'", long44 == (-34L));
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertNotNull(julianChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-34L) + "'", long52 == (-34L));
//        org.junit.Assert.assertNotNull(durationField53);
//        org.junit.Assert.assertNotNull(durationField54);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test229");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.minusWeeks((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTimeISO();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks((int) '4');
//        org.joda.time.DateTime dateTime11 = dateTime9.plusHours(1);
//        int int12 = mutableDateTime6.compareTo((org.joda.time.ReadableInstant) dateTime9);
//        int int13 = property1.compareTo((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime9.minus(readableDuration14);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear(26);
        org.joda.time.format.DateTimeParser dateTimeParser6 = dateTimeFormatter5.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeParser6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(1L, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfCentury();
        int int6 = dateTime4.getMonthOfYear();
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.LocalDateTime localDateTime8 = dateTime4.toLocalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.DateTimeFormat.shortDateTime();
        java.lang.String str10 = localDateTime8.toString(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1/1/70 12:00 AM" + "'", str10.equals("1/1/70 12:00 AM"));
    }

//    @Test
//    public void test232() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test232");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        java.lang.String str2 = property1.toString();
//        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.year();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology5);
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.era();
//        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology9.getZone();
//        long long15 = julianChronology9.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField16 = julianChronology9.era();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property18 = dateTime17.era();
//        org.joda.time.DateTime dateTime20 = dateTime17.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime20.minus(readableDuration21);
//        org.joda.time.DateTime dateTime24 = dateTime20.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime dateTime28 = dateTime25.plusHours((int) (byte) -1);
//        int int29 = dateTime25.getMinuteOfHour();
//        org.joda.time.DateTime dateTime31 = dateTime25.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property33 = dateTime32.era();
//        org.joda.time.DateTime dateTime35 = dateTime32.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime37 = dateTime32.withHourOfDay(1);
//        org.joda.time.DateTime dateTime38 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property39 = dateTime38.era();
//        org.joda.time.DateTimeField dateTimeField40 = property39.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property39.getFieldType();
//        org.joda.time.DateTime dateTime43 = dateTime37.withField(dateTimeFieldType41, (int) (byte) 0);
//        boolean boolean44 = dateTime25.isSupported(dateTimeFieldType41);
//        boolean boolean45 = dateTime24.isSupported(dateTimeFieldType41);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField46 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField16, dateTimeFieldType41);
//        boolean boolean47 = dateTime4.isSupported(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-34L) + "'", long15 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 26 + "'", int29 == 26);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
//    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        try {
            long long8 = gregorianChronology2.getDateTimeMillis((int) (short) 0, 10, 100, 2580);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        java.lang.String str15 = skipUndoDateTimeField4.getName();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "era" + "'", str15.equals("era"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfYear();
        org.joda.time.DurationField durationField4 = gregorianChronology2.weekyears();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        int int3 = property1.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withDefaultYear((int) (byte) -1);
        long long7 = dateTimeFormatter0.parseMillis("-1");
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62198755200000L) + "'", long7 == (-62198755200000L));
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test239");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime5.withFields(readablePartial6);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property8.getAsShortText(locale9);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "17" + "'", str10.equals("17"));
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 2, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104L + "'", long2 == 104L);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
//        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
//        try {
//            long long40 = zeroIsMaxDateTimeField37.add((long) 10800, 84381);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 26 + "'", int20 == 26);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField5.getAsShortText((long) 19, locale7);
//        int int9 = offsetDateTimeField5.getMaximumValue();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "239" + "'", str8.equals("239"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1438 + "'", int9 == 1438);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(10);
//        int int5 = dateTime4.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime7 = dateTime4.withYearOfCentury((int) ' ');
//        int int8 = dateTime4.getMinuteOfHour();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 25 + "'", int5 == 25);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 26 + "'", int8 == 26);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfYear();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        long long8 = dateTimeZone6.convertUTCToLocal((-1L));
        org.joda.time.Chronology chronology9 = gregorianChronology2.withZone(dateTimeZone6);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DurationField durationField3 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray9 = julianChronology0.get(readablePeriod6, (long) 6, (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.chrono.CopticChronology copticChronology5 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(copticChronology5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.year();
        org.joda.time.DurationField durationField3 = iSOChronology0.weeks();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone8 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        int int10 = fixedDateTimeZone8.getStandardOffset((long) (short) 10);
        long long14 = fixedDateTimeZone8.convertLocalToUTC(100L, true, (long) 4);
        org.joda.time.Chronology chronology15 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone8);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 3L + "'", long14 == 3L);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("2019", "JulianChronology[UTC]");
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        boolean boolean6 = skipUndoDateTimeField4.isLeap(9223372036854775807L);
        int int8 = skipUndoDateTimeField4.get((-1L));
        org.joda.time.DateTimeField dateTimeField9 = skipUndoDateTimeField4.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str12 = dateTimeZone11.toString();
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone11, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(dateTimeZone11);
        org.joda.time.Chronology chronology16 = monthDay15.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray17 = monthDay15.getFields();
        org.joda.time.MonthDay.Property property18 = monthDay15.monthOfYear();
        org.joda.time.MonthDay monthDay19 = property18.getMonthDay();
        org.joda.time.MonthDay monthDay20 = property18.getMonthDay();
        int int21 = monthDay20.getMonthOfYear();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField(chronology23, dateTimeField25, 2000);
        java.lang.String str28 = skipUndoDateTimeField27.toString();
        int int30 = skipUndoDateTimeField27.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str33 = dateTimeZone32.toString();
        boolean boolean35 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone32, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay(dateTimeZone32);
        int int37 = skipUndoDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) monthDay36);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str40 = dateTimeZone39.toString();
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone39, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(dateTimeZone39);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.MonthDay monthDay45 = monthDay43.plus(readablePeriod44);
        org.joda.time.MonthDay monthDay47 = monthDay45.minusDays((int) (byte) 0);
        int[] intArray53 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int54 = skipUndoDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) monthDay47, intArray53);
        java.util.Locale locale56 = null;
        try {
            int[] intArray57 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) monthDay20, 9, intArray53, "-1", locale56);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+52:00" + "'", str12.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTimeFieldArray17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(monthDay19);
        org.junit.Assert.assertNotNull(monthDay20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[era]" + "'", str28.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+52:00" + "'", str33.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "+52:00" + "'", str40.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField5.getAsShortText((long) 19, locale7);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str11 = dateTimeZone10.toString();
//        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone10, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(dateTimeZone10);
//        org.joda.time.Chronology chronology15 = monthDay14.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray16 = monthDay14.getFields();
//        org.joda.time.MonthDay.Property property17 = monthDay14.monthOfYear();
//        java.lang.String str18 = property17.getName();
//        org.joda.time.MonthDay monthDay20 = property17.addToCopy(97);
//        java.util.Locale locale21 = null;
//        try {
//            java.lang.String str22 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay20, locale21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "239" + "'", str8.equals("239"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+52:00" + "'", str11.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "monthOfYear" + "'", str18.equals("monthOfYear"));
//        org.junit.Assert.assertNotNull(monthDay20);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay(dateTimeZone0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.withFields(readablePartial6);
        try {
            org.joda.time.DateTime dateTime9 = dateTime7.withDayOfMonth(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.DateTime dateTime7 = dateTime3.withYearOfCentury(0);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillisOfSecond(0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.withFields(readablePartial6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime7.withMillisOfDay(9);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
//        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str40 = dateTimeZone39.toString();
//        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone39, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(dateTimeZone39);
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.MonthDay monthDay45 = monthDay43.plus(readablePeriod44);
//        org.joda.time.MonthDay monthDay47 = monthDay45.minusDays((int) (byte) 0);
//        int int48 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay47);
//        try {
//            long long51 = zeroIsMaxDateTimeField37.add(0L, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 26 + "'", int20 == 26);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "+52:00" + "'", str40.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(monthDay45);
//        org.junit.Assert.assertNotNull(monthDay47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(10, 84381, (int) (short) 100, 0, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 84381 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        int int9 = property8.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        try {
            long long2 = dateTimeFormatter0.parseMillis("1/1/70 12:00 AM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1/1/70 12:00 AM\" is malformed at \"/1/70 12:00 AM\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.era();
        org.joda.time.DateTime dateTime4 = dateTime1.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology8 = dateTime7.getChronology();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfCentury();
        int int10 = property9.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
        int int12 = dateTime6.get(dateTimeFieldType11);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField13 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 99 + "'", int10 == 99);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str17 = dateTimeZone16.toString();
        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone16, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.plus(readablePeriod21);
        org.joda.time.MonthDay monthDay24 = monthDay22.minusDays((int) (byte) 0);
        int[] intArray30 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int31 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
        try {
            long long34 = skipUndoDateTimeField4.getDifferenceAsLong(31449599996L, 11L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+52:00" + "'", str17.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime.Property property7 = dateTime0.era();
//        java.util.Locale locale8 = null;
//        int int9 = property7.getMaximumTextLength(locale8);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.DateTime dateTime7 = dateTime3.withMinuteOfHour(0);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime3);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone6 = fixedDateTimeZone5.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone12 = fixedDateTimeZone11.toTimeZone();
        int int14 = fixedDateTimeZone11.getOffsetFromLocal((long) 26);
        long long16 = fixedDateTimeZone11.previousTransition((long) (byte) -1);
        int int18 = fixedDateTimeZone11.getOffsetFromLocal((long) (-1));
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime21 = dateTime19.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial22 = null;
        org.joda.time.DateTime dateTime23 = dateTime19.withFields(readablePartial22);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str26 = dateTimeZone25.toString();
        boolean boolean28 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone25, (java.lang.Object) (-1.0f));
        org.joda.time.MutableDateTime mutableDateTime29 = dateTime19.toMutableDateTime(dateTimeZone25);
        long long31 = dateTimeZone25.convertUTCToLocal(11L);
        long long33 = fixedDateTimeZone11.getMillisKeepLocal(dateTimeZone25, (long) 35);
        boolean boolean34 = fixedDateTimeZone5.equals((java.lang.Object) dateTimeZone25);
        org.joda.time.chrono.JulianChronology julianChronology35 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField36 = julianChronology35.era();
        org.joda.time.DateTimeZone dateTimeZone37 = julianChronology35.getZone();
        org.joda.time.DurationField durationField38 = julianChronology35.hours();
        org.joda.time.DateTimeField dateTimeField39 = julianChronology35.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField40 = julianChronology35.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField40);
        boolean boolean42 = fixedDateTimeZone5.equals((java.lang.Object) dateTimeField40);
        org.joda.time.Chronology chronology43 = gJChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(timeZone12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 97 + "'", int14 == 97);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1L) + "'", long16 == (-1L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 97 + "'", int18 == 97);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "+52:00" + "'", str26.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(mutableDateTime29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 187200011L + "'", long31 == 187200011L);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-187199868L) + "'", long33 == (-187199868L));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(julianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(chronology43);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMonths((int) (byte) 0);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime0.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        org.joda.time.DateTime dateTime10 = dateTime0.withPeriodAdded(readablePeriod8, 10);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str13 = dateTimeZone12.toString();
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.era();
//        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(1L, dateTimeZone17);
//        org.joda.time.DateTime.Property property19 = dateTime18.yearOfCentury();
//        java.util.GregorianCalendar gregorianCalendar20 = dateTime18.toGregorianCalendar();
//        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) dateTime18);
//        boolean boolean22 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime.Property property23 = dateTime0.millisOfSecond();
//        org.joda.time.DateTime.Property property24 = dateTime0.era();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 26 + "'", int4 == 26);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(gregorianCalendar20);
//        org.junit.Assert.assertNotNull(gJChronology21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
//        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
//        long long39 = zeroIsMaxDateTimeField37.roundHalfFloor(12L);
//        org.joda.time.DurationField durationField40 = zeroIsMaxDateTimeField37.getLeapDurationField();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 26 + "'", int20 == 26);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62105356800000L) + "'", long39 == (-62105356800000L));
//        org.junit.Assert.assertNull(durationField40);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str4 = dateTimeZone3.toString();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone3, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(dateTimeZone3);
        org.joda.time.Chronology chronology8 = monthDay7.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray9 = monthDay7.getFields();
        int int10 = monthDay7.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray11 = monthDay7.getFields();
        int[] intArray13 = gregorianChronology0.get((org.joda.time.ReadablePartial) monthDay7, (long) 84381);
        java.util.Locale locale15 = null;
        java.lang.String str16 = monthDay7.toString("17", locale15);
        try {
            int int18 = monthDay7.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+52:00" + "'", str4.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeFieldArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "17" + "'", str16.equals("17"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str4 = dateTimeZone3.toString();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone3, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(dateTimeZone3);
        org.joda.time.Chronology chronology8 = monthDay7.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray9 = monthDay7.getFields();
        int int10 = monthDay7.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray11 = monthDay7.getFields();
        int[] intArray13 = gregorianChronology0.get((org.joda.time.ReadablePartial) monthDay7, (long) 84381);
        java.util.Locale locale15 = null;
        java.lang.String str16 = monthDay7.toString("17", locale15);
        try {
            java.lang.String str18 = monthDay7.toString("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+52:00" + "'", str4.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeFieldArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "17" + "'", str16.equals("17"));
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
//        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
//        try {
//            long long40 = zeroIsMaxDateTimeField37.getDifferenceAsLong((long) 100, 0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 26 + "'", int20 == 26);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        long long9 = skipUndoDateTimeField4.roundHalfCeiling((long) 'a');
        long long11 = skipUndoDateTimeField4.roundHalfCeiling(0L);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 0L, chronology12);
        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes(0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62105356800000L) + "'", long9 == (-62105356800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62105356800000L) + "'", long11 == (-62105356800000L));
        org.junit.Assert.assertNotNull(dateTime15);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField5.getAsText((long) 'a', locale7);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField5.getMaximumShortTextLength(locale9);
//        org.joda.time.ReadablePartial readablePartial11 = null;
//        java.util.Locale locale12 = null;
//        try {
//            java.lang.String str13 = offsetDateTimeField5.getAsShortText(readablePartial11, locale12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "239" + "'", str8.equals("239"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        try {
            org.joda.time.Instant instant7 = new org.joda.time.Instant((java.lang.Object) chronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test273");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
//        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
//        boolean boolean2 = dateTimeFormatter0.isPrinter();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
//        org.joda.time.DateTime.Property property5 = dateTime3.yearOfCentury();
//        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime();
//        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeParser1);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "12:26:55 AM" + "'", str7.equals("12:26:55 AM"));
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.millisOfDay();
        boolean boolean10 = julianChronology0.equals((java.lang.Object) 4);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str13 = dateTimeZone12.toString();
        org.joda.time.Chronology chronology14 = julianChronology0.withZone(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone15 = julianChronology0.getZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfYear();
        org.joda.time.DurationField durationField4 = gregorianChronology2.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.hourOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMonths((int) (byte) 0);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime0.toMutableDateTime();
//        int int8 = dateTime0.getWeekyear();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 26 + "'", int4 == 26);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime0.withDate((int) '4', (int) (short) 10, 6);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime dateTime10 = dateTime7.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime7.withHourOfDay(1);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property14 = dateTime13.era();
        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
        org.joda.time.DateTime dateTime18 = dateTime12.withField(dateTimeFieldType16, (int) (byte) 0);
        boolean boolean19 = dateTime0.isSupported(dateTimeFieldType16);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime0.plus(readablePeriod20);
        org.joda.time.TimeOfDay timeOfDay22 = dateTime0.toTimeOfDay();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(timeOfDay22);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.junit.Assert.assertNotNull(instant0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours(1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str7 = dateTimeZone6.toString();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone6, (java.lang.Object) (-1.0f));
        org.joda.time.DateTime dateTime10 = dateTime4.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime12 = dateTime4.plusDays(35);
        org.joda.time.DateTime dateTime14 = dateTime12.withSecondOfMinute(10);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        org.joda.time.MonthDay monthDay11 = property8.addToCopy(97);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        boolean boolean14 = property8.equals((java.lang.Object) copticChronology12);
        int int15 = property8.getMaximumValueOverall();
        org.joda.time.MonthDay monthDay17 = property8.addToCopy((int) '4');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
        org.junit.Assert.assertNotNull(monthDay17);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        long long4 = dateTimeZone1.convertUTCToLocal((long) 84381);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 187284381L + "'", long4 == 187284381L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime12 = dateTime7.withHourOfDay(1);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.era();
//        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
//        org.joda.time.DateTime dateTime18 = dateTime12.withField(dateTimeFieldType16, (int) (byte) 0);
//        boolean boolean19 = dateTime0.isSupported(dateTimeFieldType16);
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTime dateTime21 = dateTime0.toDateTime((org.joda.time.Chronology) gregorianChronology20);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 26 + "'", int4 == 26);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTime21);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.util.Collection<org.joda.time.DateTimeFieldType> dateTimeFieldTypeCollection0 = null;
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = org.joda.time.format.ISODateTimeFormat.forFields(dateTimeFieldTypeCollection0, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The fields must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime2 = property1.withMaximumValue();
        try {
            org.joda.time.DateTime dateTime4 = property1.addToCopy((long) 1612);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone11 = fixedDateTimeZone10.toTimeZone();
        int int13 = fixedDateTimeZone10.getOffsetFromLocal((long) 26);
        long long15 = fixedDateTimeZone10.previousTransition((long) (byte) -1);
        int int17 = fixedDateTimeZone10.getOffsetFromLocal((long) (-1));
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.withFields(readablePartial21);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str25 = dateTimeZone24.toString();
        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone24, (java.lang.Object) (-1.0f));
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime18.toMutableDateTime(dateTimeZone24);
        long long30 = dateTimeZone24.convertUTCToLocal(11L);
        long long32 = fixedDateTimeZone10.getMillisKeepLocal(dateTimeZone24, (long) 35);
        boolean boolean33 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeZone24);
        java.util.TimeZone timeZone34 = dateTimeZone24.toTimeZone();
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+52:00" + "'", str25.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 187200011L + "'", long30 == 187200011L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-187199868L) + "'", long32 == (-187199868L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeZone34);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        org.joda.time.MonthDay monthDay11 = property8.addToCopy(97);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        boolean boolean14 = property8.equals((java.lang.Object) copticChronology12);
        java.util.Locale locale15 = null;
        java.lang.String str16 = property8.getAsShortText(locale15);
        try {
            org.joda.time.MonthDay monthDay18 = property8.setCopy((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Jun" + "'", str16.equals("Jun"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        int int10 = property8.getMinimumValueOverall();
        java.lang.String str11 = property8.toString();
        int int12 = property8.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[monthOfYear]" + "'", str11.equals("Property[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 12 + "'", int12 == 12);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.Number number7 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number8 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str9 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0f + "'", number7.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (byte) 1 + "'", number8.equals((byte) 1));
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone11 = fixedDateTimeZone10.toTimeZone();
        int int13 = fixedDateTimeZone10.getOffsetFromLocal((long) 26);
        long long15 = fixedDateTimeZone10.previousTransition((long) (byte) -1);
        int int17 = fixedDateTimeZone10.getOffsetFromLocal((long) (-1));
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.withFields(readablePartial21);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str25 = dateTimeZone24.toString();
        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone24, (java.lang.Object) (-1.0f));
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime18.toMutableDateTime(dateTimeZone24);
        long long30 = dateTimeZone24.convertUTCToLocal(11L);
        long long32 = fixedDateTimeZone10.getMillisKeepLocal(dateTimeZone24, (long) 35);
        boolean boolean33 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeZone24);
        try {
            org.joda.time.chrono.CopticChronology copticChronology35 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+52:00" + "'", str25.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 187200011L + "'", long30 == 187200011L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-187199868L) + "'", long32 == (-187199868L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.era();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = julianChronology5.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField12 = julianChronology5.hours();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology5.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone19 = fixedDateTimeZone18.toTimeZone();
        long long21 = fixedDateTimeZone18.nextTransition(0L);
        long long23 = dateTimeZone13.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone18, (long) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        try {
            org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime(97, (int) (byte) 100, 100, 1615, 35, (org.joda.time.DateTimeZone) fixedDateTimeZone18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1615 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-34L) + "'", long11 == (-34L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-98L) + "'", long23 == (-98L));
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(gJChronology25);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("2019");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "ISOChronology[+52:00]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
//        long long2 = instant0.getMillis();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime5 = dateTime3.minusWeeks((int) '4');
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.withFields(readablePartial6);
//        boolean boolean8 = instant0.isBefore((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.Instant instant10 = instant0.withMillis((long) 1438);
//        org.junit.Assert.assertNotNull(mutableDateTime1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560630417822L + "'", long2 == 1560630417822L);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(instant10);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0, 84381);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 84381");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(187200011L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (-98L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime7 = dateTime0.withDurationAdded((long) 6, (int) (byte) 1);
//        org.joda.time.DateTime.Property property8 = dateTime0.weekOfWeekyear();
//        int int9 = property8.getMaximumValue();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 26 + "'", int4 == 26);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
//    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("12:26:55 AM");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: 12:26:55 AM");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(187200000L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        int int2 = dateTimeFormatter0.getDefaultYear();
        try {
            org.joda.time.LocalDateTime localDateTime4 = dateTimeFormatter0.parseLocalDateTime("Property[era]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[era]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("Jun");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: Jun");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DurationField durationField3 = julianChronology0.hours();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        long long10 = julianChronology4.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField11 = julianChronology4.hours();
        boolean boolean12 = julianChronology0.equals((java.lang.Object) julianChronology4);
        org.joda.time.DateTimeField dateTimeField13 = julianChronology4.secondOfDay();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-34L) + "'", long10 == (-34L));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime0.withDate((int) '4', (int) (short) 10, 6);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        try {
            org.joda.time.DateTime dateTime9 = property7.setCopy("002623.702+5200");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"002623.702+5200\" for secondOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone11 = fixedDateTimeZone10.toTimeZone();
        int int13 = fixedDateTimeZone10.getOffsetFromLocal((long) 26);
        long long15 = fixedDateTimeZone10.previousTransition((long) (byte) -1);
        int int17 = fixedDateTimeZone10.getOffsetFromLocal((long) (-1));
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.withFields(readablePartial21);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str25 = dateTimeZone24.toString();
        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone24, (java.lang.Object) (-1.0f));
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime18.toMutableDateTime(dateTimeZone24);
        long long30 = dateTimeZone24.convertUTCToLocal(11L);
        long long32 = fixedDateTimeZone10.getMillisKeepLocal(dateTimeZone24, (long) 35);
        boolean boolean33 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeZone24);
        java.lang.String str35 = fixedDateTimeZone4.getNameKey((long) 9);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+52:00" + "'", str25.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 187200011L + "'", long30 == 187200011L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-187199868L) + "'", long32 == (-187199868L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfCentury((int) (byte) 1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.DateTimeFormat.shortDateTime();
//        java.lang.String str5 = dateTime3.toString(dateTimeFormatter4);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1/5/01 8:00 AM" + "'", str5.equals("1/5/01 8:00 AM"));
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException4.prependMessage("JulianChronology[UTC]");
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException13.prependMessage("JulianChronology[UTC]");
        java.lang.String str16 = illegalFieldValueException13.toString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        java.lang.String str18 = illegalFieldValueException4.toString();
        java.lang.Number number19 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number20 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str16.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str18.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1.0f + "'", number19.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (byte) 10 + "'", number20.equals((byte) 10));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException9.prependMessage("JulianChronology[UTC]");
        java.lang.Number number12 = illegalFieldValueException9.getIllegalNumberValue();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException9);
        illegalFieldValueException4.prependMessage("(\"org.joda.time.JodaTimePermission\" \"hi!\")");
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (byte) 1 + "'", number12.equals((byte) 1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        int int4 = dateTime0.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime0.plusWeeks(0);
        int int7 = dateTime6.getEra();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-2071231199L), (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2071231200L) + "'", long2 == (-2071231200L));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.DateTime dateTime7 = dateTime3.withYearOfCentury(0);
        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths((int) (short) 10);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("002620.820+5200", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"002620.820+5200\" is malformed at \"2620.820+5200\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withDefaultYear((int) (byte) -1);
        java.io.Writer writer6 = null;
        try {
            dateTimeFormatter5.printTo(writer6, (long) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
        int int20 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
        try {
            long long40 = zeroIsMaxDateTimeField37.set((long) (-1), 26);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 26 for era must be in the range [1,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 1 + "'", number6.equals((byte) 1));
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DurationField durationField3 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str9 = dateTimeZone8.toString();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone8, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay14 = monthDay12.plus(readablePeriod13);
        org.joda.time.MonthDay monthDay16 = monthDay14.minusDays((int) (byte) 0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, dateTimeField19, 2000);
        java.lang.String str22 = skipUndoDateTimeField21.toString();
        int int24 = skipUndoDateTimeField21.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str27 = dateTimeZone26.toString();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone26, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone26);
        int int31 = skipUndoDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str34 = dateTimeZone33.toString();
        boolean boolean36 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone33, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay(dateTimeZone33);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.MonthDay monthDay39 = monthDay37.plus(readablePeriod38);
        org.joda.time.MonthDay monthDay41 = monthDay39.minusDays((int) (byte) 0);
        int[] intArray47 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int48 = skipUndoDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) monthDay41, intArray47);
        int int49 = delegatedDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) monthDay16, intArray47);
        int[] intArray50 = monthDay16.getValues();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+52:00" + "'", str9.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTimeField[era]" + "'", str22.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+52:00" + "'", str27.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+52:00" + "'", str34.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1439 + "'", int49 == 1439);
        org.junit.Assert.assertNotNull(intArray50);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime6 = dateTime0.minusMonths((int) (byte) 0);
//        org.joda.time.MutableDateTime mutableDateTime7 = dateTime0.toMutableDateTime();
//        int int8 = mutableDateTime7.getSecondOfDay();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 28800 + "'", int8 == 28800);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        java.lang.Class<?> wildcardClass2 = dateTime1.getClass();
        org.joda.time.DateTime dateTime4 = dateTime1.plusMonths((int) ' ');
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readableDuration5);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.Chronology chronology3 = julianChronology0.withUTC();
        try {
            long long8 = julianChronology0.getDateTimeMillis(2, (-1), 0, 2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone14 = fixedDateTimeZone13.toTimeZone();
        long long16 = fixedDateTimeZone13.nextTransition(0L);
        long long18 = dateTimeZone8.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone13, (long) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.DateTimeField dateTimeField21 = gJChronology20.yearOfEra();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-98L) + "'", long18 == (-98L));
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test325");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField5.getAsShortText((long) 19, locale7);
//        java.util.Locale locale11 = null;
//        try {
//            long long12 = offsetDateTimeField5.set((-34L), "������.000", locale11);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"������.000\" for minuteOfDay is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "239" + "'", str8.equals("239"));
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        org.joda.time.DurationField durationField5 = skipUndoDateTimeField4.getDurationField();
        boolean boolean6 = skipUndoDateTimeField4.isLenient();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField(chronology7, dateTimeField9, 2000);
        java.lang.String str12 = skipUndoDateTimeField11.toString();
        int int14 = skipUndoDateTimeField11.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str17 = dateTimeZone16.toString();
        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone16, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone16);
        int int21 = skipUndoDateTimeField11.getMinimumValue((org.joda.time.ReadablePartial) monthDay20);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.era();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str27 = dateTimeZone26.toString();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone26, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone26);
        org.joda.time.Chronology chronology31 = monthDay30.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray32 = monthDay30.getFields();
        int int33 = monthDay30.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray34 = monthDay30.getFields();
        int[] intArray36 = gregorianChronology23.get((org.joda.time.ReadablePartial) monthDay30, (long) 84381);
        try {
            int[] intArray38 = skipUndoDateTimeField4.add((org.joda.time.ReadablePartial) monthDay20, 28800, intArray36, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 28800");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTimeField[era]" + "'", str12.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+52:00" + "'", str17.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+52:00" + "'", str27.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTimeFieldArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray34);
        org.junit.Assert.assertNotNull(intArray36);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        java.lang.String str3 = property1.getAsShortText();
        try {
            org.joda.time.Interval interval4 = property1.toInterval();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AD" + "'", str3.equals("AD"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        int int4 = dateTime0.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMonths((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime0.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime0.withPeriodAdded(readablePeriod8, 10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str13 = dateTimeZone12.toString();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.era();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(1L, dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar20 = dateTime18.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) dateTime18);
        boolean boolean22 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property23 = dateTime0.millisOfSecond();
        org.joda.time.DateTime.Property property24 = dateTime0.millisOfSecond();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime27 = dateTime25.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime29 = dateTime27.plusHours(1);
        long long30 = property24.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.LocalDate localDate31 = dateTime27.toLocalDate();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(gregorianCalendar20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31449600000L + "'", long30 == 31449600000L);
        org.junit.Assert.assertNotNull(localDate31);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        int int10 = property8.getMinimumValueOverall();
        org.joda.time.DurationField durationField11 = property8.getDurationField();
        long long14 = durationField11.subtract(9223372036854775807L, (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 9223371952701175807L + "'", long14 == 9223371952701175807L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
        int int20 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
        long long39 = zeroIsMaxDateTimeField37.roundHalfFloor(12L);
        long long41 = zeroIsMaxDateTimeField37.roundHalfFloor((-1640816579990L));
        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property43 = dateTime42.era();
        org.joda.time.DateTime dateTime45 = dateTime42.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime47 = dateTime42.withHourOfDay(1);
        org.joda.time.LocalDateTime localDateTime48 = dateTime47.toLocalDateTime();
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.chrono.JulianChronology julianChronology51 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField52 = julianChronology51.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField54 = new org.joda.time.field.SkipUndoDateTimeField(chronology50, dateTimeField52, 2000);
        java.lang.String str55 = skipUndoDateTimeField54.toString();
        int int57 = skipUndoDateTimeField54.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str60 = dateTimeZone59.toString();
        boolean boolean62 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone59, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay(dateTimeZone59);
        int int64 = skipUndoDateTimeField54.getMinimumValue((org.joda.time.ReadablePartial) monthDay63);
        java.util.Locale locale66 = null;
        java.lang.String str67 = skipUndoDateTimeField54.getAsText((long) (byte) 100, locale66);
        boolean boolean68 = skipUndoDateTimeField54.isSupported();
        org.joda.time.chrono.GregorianChronology gregorianChronology69 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField70 = gregorianChronology69.era();
        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str73 = dateTimeZone72.toString();
        boolean boolean75 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone72, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay76 = new org.joda.time.MonthDay(dateTimeZone72);
        org.joda.time.Chronology chronology77 = monthDay76.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray78 = monthDay76.getFields();
        int int79 = monthDay76.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray80 = monthDay76.getFields();
        int[] intArray82 = gregorianChronology69.get((org.joda.time.ReadablePartial) monthDay76, (long) 84381);
        org.joda.time.chrono.ISOChronology iSOChronology83 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone85 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str86 = dateTimeZone85.toString();
        boolean boolean88 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone85, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay89 = new org.joda.time.MonthDay(dateTimeZone85);
        org.joda.time.Chronology chronology90 = monthDay89.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray91 = monthDay89.getFields();
        int int92 = monthDay89.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray93 = monthDay89.getFields();
        int[] intArray95 = iSOChronology83.get((org.joda.time.ReadablePartial) monthDay89, (long) (short) 1);
        int int96 = skipUndoDateTimeField54.getMaximumValue((org.joda.time.ReadablePartial) monthDay76, intArray95);
        try {
            int[] intArray98 = zeroIsMaxDateTimeField37.set((org.joda.time.ReadablePartial) localDateTime48, 4, intArray95, 239);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 239 for era must be in the range [1,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62105356800000L) + "'", long39 == (-62105356800000L));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-62105356800000L) + "'", long41 == (-62105356800000L));
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(localDateTime48);
        org.junit.Assert.assertNotNull(julianChronology51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "DateTimeField[era]" + "'", str55.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2 + "'", int57 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "+52:00" + "'", str60.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "AD" + "'", str67.equals("AD"));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(gregorianChronology69);
        org.junit.Assert.assertNotNull(dateTimeField70);
        org.junit.Assert.assertNotNull(dateTimeZone72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "+52:00" + "'", str73.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(chronology77);
        org.junit.Assert.assertNotNull(dateTimeFieldArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray80);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(iSOChronology83);
        org.junit.Assert.assertNotNull(dateTimeZone85);
        org.junit.Assert.assertTrue("'" + str86 + "' != '" + "+52:00" + "'", str86.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertNotNull(chronology90);
        org.junit.Assert.assertNotNull(dateTimeFieldArray91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1 + "'", int92 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray93);
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 1 + "'", int96 == 1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        int int0 = org.joda.time.MonthDay.DAY_OF_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.withFields(readablePartial6);
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear((int) (short) 1);
        int int10 = dateTime7.getDayOfWeek();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        java.lang.String str3 = property1.toString();
        org.joda.time.DateTimeField dateTimeField4 = property1.getField();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Property[era]" + "'", str3.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.era();
        org.joda.time.DateTimeZone dateTimeZone5 = julianChronology3.getZone();
        long long9 = julianChronology3.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField10 = julianChronology3.hours();
        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology3.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone17 = fixedDateTimeZone16.toTimeZone();
        long long19 = fixedDateTimeZone16.nextTransition(0L);
        long long21 = dateTimeZone11.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone16, (long) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology22 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        try {
            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((java.lang.Object) property2, (org.joda.time.Chronology) buddhistChronology22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-34L) + "'", long9 == (-34L));
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-98L) + "'", long21 == (-98L));
        org.junit.Assert.assertNotNull(buddhistChronology22);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.era();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
        org.joda.time.DurationField durationField5 = julianChronology2.hours();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology2.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology2.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField8 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField7);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str11 = dateTimeZone10.toString();
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone10, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(dateTimeZone10);
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.MonthDay monthDay16 = monthDay14.plus(readablePeriod15);
        org.joda.time.MonthDay monthDay18 = monthDay16.minusDays((int) (byte) 0);
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.chrono.JulianChronology julianChronology20 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField21 = julianChronology20.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology19, dateTimeField21, 2000);
        java.lang.String str24 = skipUndoDateTimeField23.toString();
        int int26 = skipUndoDateTimeField23.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str29 = dateTimeZone28.toString();
        boolean boolean31 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone28, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay32 = new org.joda.time.MonthDay(dateTimeZone28);
        int int33 = skipUndoDateTimeField23.getMinimumValue((org.joda.time.ReadablePartial) monthDay32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str36 = dateTimeZone35.toString();
        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone35, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(dateTimeZone35);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.MonthDay monthDay41 = monthDay39.plus(readablePeriod40);
        org.joda.time.MonthDay monthDay43 = monthDay41.minusDays((int) (byte) 0);
        int[] intArray49 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int50 = skipUndoDateTimeField23.getMaximumValue((org.joda.time.ReadablePartial) monthDay43, intArray49);
        int int51 = delegatedDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) monthDay18, intArray49);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+52:00" + "'", str11.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(julianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "DateTimeField[era]" + "'", str24.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "+52:00" + "'", str29.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+52:00" + "'", str36.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(monthDay43);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1439 + "'", int51 == 1439);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DurationField durationField4 = julianChronology1.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        try {
            long long10 = julianChronology1.getDateTimeMillis((int) (byte) 10, 0, (int) (short) 1, 12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(10);
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        try {
            org.joda.time.DateTime dateTime10 = dateTime4.withTime(2, 239, 2, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 239 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException4.prependMessage("JulianChronology[UTC]");
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException13.prependMessage("JulianChronology[UTC]");
        java.lang.String str16 = illegalFieldValueException13.toString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        java.lang.String str18 = illegalFieldValueException4.toString();
        java.lang.Number number19 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType20 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str16.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str18.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1.0f + "'", number19.equals(1.0f));
        org.junit.Assert.assertNull(durationFieldType20);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = julianChronology0.days();
        org.joda.time.DateTimeField dateTimeField4 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField5 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology0, dateTimeField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        long long10 = offsetDateTimeField5.roundHalfFloor((long) 1);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.era();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology11.getZone();
        org.joda.time.DurationField durationField14 = julianChronology11.hours();
        org.joda.time.DateTimeField dateTimeField15 = julianChronology11.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology11.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str20 = dateTimeZone19.toString();
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone19, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone19);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.MonthDay monthDay25 = monthDay23.plus(readablePeriod24);
        org.joda.time.MonthDay monthDay27 = monthDay25.minusDays((int) (byte) 0);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.chrono.JulianChronology julianChronology29 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField30 = julianChronology29.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField(chronology28, dateTimeField30, 2000);
        java.lang.String str33 = skipUndoDateTimeField32.toString();
        int int35 = skipUndoDateTimeField32.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str38 = dateTimeZone37.toString();
        boolean boolean40 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone37, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay(dateTimeZone37);
        int int42 = skipUndoDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) monthDay41);
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str45 = dateTimeZone44.toString();
        boolean boolean47 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone44, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay(dateTimeZone44);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.MonthDay monthDay50 = monthDay48.plus(readablePeriod49);
        org.joda.time.MonthDay monthDay52 = monthDay50.minusDays((int) (byte) 0);
        int[] intArray58 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int59 = skipUndoDateTimeField32.getMaximumValue((org.joda.time.ReadablePartial) monthDay52, intArray58);
        int int60 = delegatedDateTimeField17.getMaximumValue((org.joda.time.ReadablePartial) monthDay27, intArray58);
        int int61 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) monthDay27);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+52:00" + "'", str20.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertNotNull(monthDay27);
        org.junit.Assert.assertNotNull(julianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DateTimeField[era]" + "'", str33.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2 + "'", int35 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+52:00" + "'", str38.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "+52:00" + "'", str45.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(monthDay50);
        org.junit.Assert.assertNotNull(monthDay52);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1439 + "'", int60 == 1439);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1438 + "'", int61 == 1438);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.fullTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("������.000", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"������.000\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology0.getZone();
        java.lang.String str8 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "JulianChronology[UTC]" + "'", str8.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.io.Writer writer1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology3.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField6 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField4, 2000);
        java.lang.String str7 = skipUndoDateTimeField6.toString();
        int int9 = skipUndoDateTimeField6.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str12 = dateTimeZone11.toString();
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone11, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay(dateTimeZone11);
        int int16 = skipUndoDateTimeField6.getMinimumValue((org.joda.time.ReadablePartial) monthDay15);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField6.getAsText((long) (byte) 100, locale18);
        boolean boolean20 = skipUndoDateTimeField6.isSupported();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.era();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str25 = dateTimeZone24.toString();
        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone24, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay28 = new org.joda.time.MonthDay(dateTimeZone24);
        org.joda.time.Chronology chronology29 = monthDay28.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray30 = monthDay28.getFields();
        int int31 = monthDay28.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray32 = monthDay28.getFields();
        int[] intArray34 = gregorianChronology21.get((org.joda.time.ReadablePartial) monthDay28, (long) 84381);
        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str38 = dateTimeZone37.toString();
        boolean boolean40 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone37, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay41 = new org.joda.time.MonthDay(dateTimeZone37);
        org.joda.time.Chronology chronology42 = monthDay41.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray43 = monthDay41.getFields();
        int int44 = monthDay41.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray45 = monthDay41.getFields();
        int[] intArray47 = iSOChronology35.get((org.joda.time.ReadablePartial) monthDay41, (long) (short) 1);
        int int48 = skipUndoDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) monthDay28, intArray47);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadablePartial) monthDay28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTimeField[era]" + "'", str7.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+52:00" + "'", str12.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "AD" + "'", str19.equals("AD"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+52:00" + "'", str25.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeFieldArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray32);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(iSOChronology35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "+52:00" + "'", str38.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(dateTimeFieldArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException4.prependMessage("JulianChronology[UTC]");
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = illegalFieldValueException4.getDateTimeFieldType();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
        org.junit.Assert.assertNull(dateTimeFieldType9);
        org.junit.Assert.assertNull(dateTimeFieldType10);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        int int8 = monthDay5.getMonthOfYear();
        org.joda.time.MonthDay monthDay10 = monthDay5.withMonthOfYear((int) (short) 1);
        java.lang.String str11 = monthDay5.toString();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.MonthDay monthDay14 = monthDay5.withFieldAdded(durationFieldType12, (-26010446));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "--01-05" + "'", str11.equals("--01-05"));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.DateTime dateTime7 = dateTime3.withYearOfCentury(0);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        org.joda.time.DateTime.Property property9 = dateTime7.minuteOfHour();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DurationField durationField4 = julianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology1.weekOfWeekyear();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(obj0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.MonthDay.Property property7 = monthDay6.monthOfYear();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        int int14 = dateTime13.getSecondOfDay();
        boolean boolean15 = dateTime13.isAfterNow();
        boolean boolean16 = property7.equals((java.lang.Object) dateTime13);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 25200 + "'", int14 == 25200);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology0.secondOfMinute();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField8 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField6, 2000);
        org.joda.time.DurationField durationField9 = skipUndoDateTimeField8.getDurationField();
        boolean boolean10 = skipUndoDateTimeField8.isLenient();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField11 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField8);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str14 = dateTimeZone13.toString();
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone13, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay17 = new org.joda.time.MonthDay(dateTimeZone13);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.MonthDay monthDay19 = monthDay17.plus(readablePeriod18);
        java.util.Locale locale21 = null;
        try {
            java.lang.String str22 = skipUndoDateTimeField8.getAsText((org.joda.time.ReadablePartial) monthDay17, 19, locale21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 19");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+52:00" + "'", str14.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(monthDay19);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str17 = dateTimeZone16.toString();
        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone16, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.plus(readablePeriod21);
        org.joda.time.MonthDay monthDay24 = monthDay22.minusDays((int) (byte) 0);
        int[] intArray30 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int31 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
        int int33 = skipUndoDateTimeField4.get((long) 10800);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+52:00" + "'", str17.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        java.util.Locale locale15 = null;
        int int16 = skipUndoDateTimeField4.getMaximumTextLength(locale15);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        boolean boolean6 = skipUndoDateTimeField4.isLeap(9223372036854775807L);
        long long8 = skipUndoDateTimeField4.roundHalfCeiling(1560626784922L);
        int int10 = skipUndoDateTimeField4.getMinimumValue(1560630417822L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62105356800000L) + "'", long8 == (-62105356800000L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        org.joda.time.MonthDay monthDay9 = property8.getMonthDay();
        org.joda.time.MonthDay monthDay10 = property8.getMonthDay();
        int int11 = monthDay10.getMonthOfYear();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        try {
            org.joda.time.MonthDay monthDay14 = monthDay10.withFieldAdded(durationFieldType12, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology7.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.DateTime dateTime11 = dateTime5.toDateTime(dateTimeZone10);
        long long15 = dateTimeZone10.convertLocalToUTC((long) 1438, true, (long) 12);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-187198562L) + "'", long15 == (-187198562L));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        try {
            long long8 = gJChronology0.getDateTimeMillis(2580, 0, 2019, (int) (byte) 100, 1615, 0, 28800);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimePrinter dateTimePrinter2 = dateTimeFormatter0.getPrinter();
        int int3 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimePrinter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 187200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.ReadableInterval readableInterval4 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(readableInterval4);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.withFields(readablePartial3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str7 = dateTimeZone6.toString();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone6, (java.lang.Object) (-1.0f));
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime0.toMutableDateTime(dateTimeZone6);
        long long12 = dateTimeZone6.convertUTCToLocal(11L);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 187200011L + "'", long12 == 187200011L);
        org.junit.Assert.assertNotNull(iSOChronology13);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = julianChronology0.getZone();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        boolean boolean6 = skipUndoDateTimeField4.isLeap(9223372036854775807L);
        int int8 = skipUndoDateTimeField4.get((-1L));
        try {
            long long11 = skipUndoDateTimeField4.add((-124273871999975L), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours(1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str7 = dateTimeZone6.toString();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone6, (java.lang.Object) (-1.0f));
        org.joda.time.DateTime dateTime10 = dateTime4.withZone(dateTimeZone6);
        int int11 = dateTime4.getEra();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.Instant instant4 = instant0.withDurationAdded((long) 100, 2000);
        org.joda.time.Instant instant7 = instant0.withDurationAdded(1L, 35);
        long long8 = instant0.getMillis();
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 187200000L + "'", long8 == 187200000L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        int int4 = dateTime0.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMonths((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime0.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime0.withPeriodAdded(readablePeriod8, 10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str13 = dateTimeZone12.toString();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.era();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(1L, dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar20 = dateTime18.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) dateTime18);
        boolean boolean22 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property23 = dateTime0.millisOfSecond();
        org.joda.time.DateTime.Property property24 = dateTime0.millisOfSecond();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime27 = dateTime25.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime29 = dateTime27.plusHours(1);
        long long30 = property24.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime32 = dateTime27.minusDays(0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(gregorianCalendar20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31449600000L + "'", long30 == 31449600000L);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019", (java.lang.Number) 10L, (java.lang.Number) (short) 10, (java.lang.Number) 4);
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        long long11 = offsetDateTimeField5.add((long) (byte) 0, 0L);
        long long14 = offsetDateTimeField5.add((-124273871999996L), (long) (-97));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-124273877819996L) + "'", long14 == (-124273877819996L));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
        int int20 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.era();
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str46 = dateTimeZone45.toString();
        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone45, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(dateTimeZone45);
        org.joda.time.Chronology chronology50 = monthDay49.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray51 = monthDay49.getFields();
        int int52 = monthDay49.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray53 = monthDay49.getFields();
        int[] intArray55 = gregorianChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) 84381);
        int int56 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
        java.lang.Object obj57 = null;
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField59 = julianChronology58.era();
        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology58.getZone();
        org.joda.time.DurationField durationField61 = julianChronology58.hours();
        org.joda.time.DateTimeField dateTimeField62 = julianChronology58.weekOfWeekyear();
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay(obj57, (org.joda.time.Chronology) julianChronology58);
        org.joda.time.ReadablePeriod readablePeriod64 = null;
        org.joda.time.MonthDay monthDay66 = monthDay63.withPeriodAdded(readablePeriod64, 25);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str70 = dateTimeZone69.toString();
        boolean boolean72 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone69, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay73 = new org.joda.time.MonthDay(dateTimeZone69);
        org.joda.time.Chronology chronology74 = monthDay73.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray75 = monthDay73.getFields();
        int int76 = monthDay73.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray77 = monthDay73.getFields();
        int[] intArray79 = iSOChronology67.get((org.joda.time.ReadablePartial) monthDay73, (long) (short) 1);
        int int80 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay66, intArray79);
        try {
            long long83 = zeroIsMaxDateTimeField37.getDifferenceAsLong((-11L), 1560630411317L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+52:00" + "'", str46.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTimeFieldArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(monthDay66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeZone69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "+52:00" + "'", str70.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(chronology74);
        org.junit.Assert.assertNotNull(dateTimeFieldArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray77);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((int) (short) 10, locale10);
        long long13 = offsetDateTimeField5.roundCeiling(9223371952701175807L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 9223371952701180000L + "'", long13 == 9223371952701180000L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        org.joda.time.DateTime dateTime12 = dateTime9.plusHours((int) (byte) -1);
        int int13 = dateTime9.getDayOfWeek();
        boolean boolean14 = property8.equals((java.lang.Object) int13);
        int int15 = property8.getMinimumValue();
        int int16 = property8.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.year();
        org.joda.time.MonthDay monthDay3 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(monthDay3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
        int int20 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.era();
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str46 = dateTimeZone45.toString();
        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone45, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(dateTimeZone45);
        org.joda.time.Chronology chronology50 = monthDay49.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray51 = monthDay49.getFields();
        int int52 = monthDay49.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray53 = monthDay49.getFields();
        int[] intArray55 = gregorianChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) 84381);
        int int56 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
        java.lang.Object obj57 = null;
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField59 = julianChronology58.era();
        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology58.getZone();
        org.joda.time.DurationField durationField61 = julianChronology58.hours();
        org.joda.time.DateTimeField dateTimeField62 = julianChronology58.weekOfWeekyear();
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay(obj57, (org.joda.time.Chronology) julianChronology58);
        org.joda.time.ReadablePeriod readablePeriod64 = null;
        org.joda.time.MonthDay monthDay66 = monthDay63.withPeriodAdded(readablePeriod64, 25);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str70 = dateTimeZone69.toString();
        boolean boolean72 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone69, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay73 = new org.joda.time.MonthDay(dateTimeZone69);
        org.joda.time.Chronology chronology74 = monthDay73.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray75 = monthDay73.getFields();
        int int76 = monthDay73.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray77 = monthDay73.getFields();
        int[] intArray79 = iSOChronology67.get((org.joda.time.ReadablePartial) monthDay73, (long) (short) 1);
        int int80 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay66, intArray79);
        int int81 = zeroIsMaxDateTimeField37.getMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+52:00" + "'", str46.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTimeFieldArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(monthDay66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeZone69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "+52:00" + "'", str70.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(chronology74);
        org.junit.Assert.assertNotNull(dateTimeFieldArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray77);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 2 + "'", int81 == 2);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(chronology9);
        java.util.Locale locale11 = null;
        try {
            java.lang.String str12 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay10, locale11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str17 = dateTimeZone16.toString();
        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone16, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.plus(readablePeriod21);
        org.joda.time.MonthDay monthDay24 = monthDay22.minusDays((int) (byte) 0);
        int[] intArray30 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int31 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
        int int32 = skipUndoDateTimeField4.getMinimumValue();
        int int34 = skipUndoDateTimeField4.getLeapAmount(1560626816923L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+52:00" + "'", str17.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        try {
            long long7 = copticChronology0.getDateTimeMillis(0, 0, 52, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str17 = dateTimeZone16.toString();
        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone16, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.plus(readablePeriod21);
        org.joda.time.MonthDay monthDay24 = monthDay22.minusDays((int) (byte) 0);
        int[] intArray30 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int31 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = skipUndoDateTimeField4.getType();
        org.joda.time.chrono.CopticChronology copticChronology33 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone34 = copticChronology33.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.dayOfYear();
        org.joda.time.DurationField durationField37 = gregorianChronology35.weekyears();
        long long40 = durationField37.subtract(104L, (long) 239);
        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology42 = iSOChronology41.withUTC();
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology41.year();
        org.joda.time.DurationField durationField44 = iSOChronology41.weeks();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField45 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType32, durationField37, durationField44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+52:00" + "'", str17.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(copticChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-7541855999896L) + "'", long40 == (-7541855999896L));
        org.junit.Assert.assertNotNull(iSOChronology41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = dateTime0.withWeekyear(2000);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.era();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = julianChronology5.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField12 = julianChronology5.hours();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology5.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone19 = fixedDateTimeZone18.toTimeZone();
        long long21 = fixedDateTimeZone18.nextTransition(0L);
        long long23 = dateTimeZone13.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone18, (long) (byte) -1);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) dateTime4, (org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-34L) + "'", long11 == (-34L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-98L) + "'", long23 == (-98L));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        org.joda.time.MonthDay monthDay11 = property8.addToCopy(97);
        java.util.Locale locale12 = null;
        java.lang.String str13 = property8.getAsText(locale12);
        java.lang.String str14 = property8.getName();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "January" + "'", str13.equals("January"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "monthOfYear" + "'", str14.equals("monthOfYear"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(1L, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfCentury();
        int int6 = dateTime4.getMonthOfYear();
        boolean boolean7 = dateTime4.isEqualNow();
        org.joda.time.LocalDateTime localDateTime8 = dateTime4.toLocalDateTime();
        org.joda.time.DateTime dateTime10 = dateTime4.plusMillis(2);
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.era();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology11.getZone();
        long long17 = julianChronology11.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField18 = julianChronology11.hours();
        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology11.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone24 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone25 = fixedDateTimeZone24.toTimeZone();
        long long27 = fixedDateTimeZone24.nextTransition(0L);
        long long29 = dateTimeZone19.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone24, (long) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology30 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone24);
        org.joda.time.DateTime dateTime32 = dateTime4.toDateTime(dateTimeZone31);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(localDateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-34L) + "'", long17 == (-34L));
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-98L) + "'", long29 == (-98L));
        org.junit.Assert.assertNotNull(buddhistChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(10);
        int int5 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfYear(26);
        org.joda.time.DateMidnight dateMidnight8 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime10 = dateTime4.minusWeeks((int) (byte) 10);
        org.joda.time.DateTime.Property property11 = dateTime4.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.Chronology chronology3 = dateTimeFormatter1.getChronolgy();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.withSecondOfMinute((int) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime0.withYearOfEra((int) ' ');
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        int int10 = offsetDateTimeField5.getLeapAmount(100L);
        int int12 = offsetDateTimeField5.getLeapAmount((long) (byte) -1);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        org.joda.time.MonthDay monthDay9 = property8.getMonthDay();
        org.joda.time.MonthDay monthDay10 = property8.getMonthDay();
        int int11 = monthDay10.getMonthOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.DateTimeFormat.shortTime();
        java.util.Locale locale13 = dateTimeFormatter12.getLocale();
        java.lang.String str14 = monthDay10.toString(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNull(locale13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "�:�� �" + "'", str14.equals("�:�� �"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        try {
            org.joda.time.DateTime dateTime4 = property1.addToCopy((long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime2 = property1.withMaximumValue();
        org.joda.time.DateTime dateTime3 = property1.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime5 = dateTime3.minusSeconds(2000);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.era();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(1L, dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        int int13 = dateTime11.getMonthOfYear();
        boolean boolean14 = dateTime11.isEqualNow();
        int int15 = dateTime11.getMillisOfDay();
        int int16 = property6.getDifference((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime18 = dateTime11.plusHours((int) (byte) 0);
        org.joda.time.chrono.CopticChronology copticChronology19 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone20 = copticChronology19.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.minuteOfDay();
        org.joda.time.DateTime dateTime23 = dateTime11.toDateTime((org.joda.time.Chronology) gregorianChronology21);
        boolean boolean25 = dateTime23.isEqual((-62105356800000L));
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(copticChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime2 = property1.withMaximumValue();
        org.joda.time.DateTime dateTime3 = property1.roundHalfCeilingCopy();
        int int4 = property1.getMinimumValue();
        org.joda.time.DurationField durationField5 = property1.getRangeDurationField();
        org.joda.time.DateTime dateTime6 = property1.roundCeilingCopy();
        int int7 = dateTime6.getMinuteOfHour();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long7 = offsetDateTimeField5.roundFloor(187200011L);
        int int8 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str11 = dateTimeZone10.toString();
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone10, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay14 = new org.joda.time.MonthDay(dateTimeZone10);
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField5.getAsShortText((org.joda.time.ReadablePartial) monthDay14, 97, locale16);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 187200000L + "'", long7 == 187200000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1438 + "'", int8 == 1438);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+52:00" + "'", str11.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "97" + "'", str17.equals("97"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime0.withDate((int) '4', (int) (short) 10, 6);
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime6.getZone();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((long) 26);
        boolean boolean8 = fixedDateTimeZone4.isFixed();
        java.lang.String str10 = fixedDateTimeZone4.getNameKey((long) 0);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField10, 2000);
        java.lang.String str13 = skipUndoDateTimeField12.toString();
        int int15 = skipUndoDateTimeField12.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str18 = dateTimeZone17.toString();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone17, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(dateTimeZone17);
        int int22 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) monthDay21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay21, 0, locale24);
        java.lang.String str26 = skipUndoDateTimeField4.toString();
        long long28 = skipUndoDateTimeField4.roundFloor(24L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[era]" + "'", str13.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+52:00" + "'", str18.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "BC" + "'", str25.equals("BC"));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DateTimeField[era]" + "'", str26.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-62105356800000L) + "'", long28 == (-62105356800000L));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField4.getAsText((long) (byte) 100, locale16);
        boolean boolean18 = skipUndoDateTimeField4.isSupported();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.era();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str23 = dateTimeZone22.toString();
        boolean boolean25 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone22, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(dateTimeZone22);
        org.joda.time.Chronology chronology27 = monthDay26.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray28 = monthDay26.getFields();
        int int29 = monthDay26.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray30 = monthDay26.getFields();
        int[] intArray32 = gregorianChronology19.get((org.joda.time.ReadablePartial) monthDay26, (long) 84381);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str36 = dateTimeZone35.toString();
        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone35, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(dateTimeZone35);
        org.joda.time.Chronology chronology40 = monthDay39.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray41 = monthDay39.getFields();
        int int42 = monthDay39.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray43 = monthDay39.getFields();
        int[] intArray45 = iSOChronology33.get((org.joda.time.ReadablePartial) monthDay39, (long) (short) 1);
        int int46 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay26, intArray45);
        org.joda.time.chrono.BuddhistChronology buddhistChronology47 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str48 = buddhistChronology47.toString();
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology47);
        java.util.Locale locale50 = null;
        try {
            java.lang.String str51 = skipUndoDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay49, locale50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AD" + "'", str17.equals("AD"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+52:00" + "'", str23.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+52:00" + "'", str36.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTimeFieldArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(buddhistChronology47);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "BuddhistChronology[UTC]" + "'", str48.equals("BuddhistChronology[UTC]"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property2.getFieldType();
        org.joda.time.DateTime dateTime6 = property2.addToCopy(2580);
        java.util.Locale locale8 = null;
        try {
            org.joda.time.DateTime dateTime9 = property2.setCopy("239", locale8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 239 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 99 + "'", int3 == 99);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.withFields(readablePartial3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str7 = dateTimeZone6.toString();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone6, (java.lang.Object) (-1.0f));
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime0.toMutableDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime12 = dateTime0.plusMillis((int) (short) 100);
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.DateTime dateTime14 = dateTime0.plus(readableDuration13);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime17 = dateTime15.minusWeeks((int) '4');
        boolean boolean18 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime17);
        int int19 = dateTime0.getSecondOfDay();
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology20, dateTimeField22, 2000);
        java.lang.String str25 = skipUndoDateTimeField24.toString();
        int int27 = skipUndoDateTimeField24.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str30 = dateTimeZone29.toString();
        boolean boolean32 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone29, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay(dateTimeZone29);
        int int34 = skipUndoDateTimeField24.getMinimumValue((org.joda.time.ReadablePartial) monthDay33);
        java.util.Locale locale36 = null;
        java.lang.String str37 = skipUndoDateTimeField24.getAsText((long) (byte) 100, locale36);
        boolean boolean38 = skipUndoDateTimeField24.isSupported();
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.era();
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str43 = dateTimeZone42.toString();
        boolean boolean45 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone42, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay46 = new org.joda.time.MonthDay(dateTimeZone42);
        org.joda.time.Chronology chronology47 = monthDay46.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray48 = monthDay46.getFields();
        int int49 = monthDay46.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray50 = monthDay46.getFields();
        int[] intArray52 = gregorianChronology39.get((org.joda.time.ReadablePartial) monthDay46, (long) 84381);
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str56 = dateTimeZone55.toString();
        boolean boolean58 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone55, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay(dateTimeZone55);
        org.joda.time.Chronology chronology60 = monthDay59.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray61 = monthDay59.getFields();
        int int62 = monthDay59.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray63 = monthDay59.getFields();
        int[] intArray65 = iSOChronology53.get((org.joda.time.ReadablePartial) monthDay59, (long) (short) 1);
        int int66 = skipUndoDateTimeField24.getMaximumValue((org.joda.time.ReadablePartial) monthDay46, intArray65);
        int int67 = dateTime0.get((org.joda.time.DateTimeField) skipUndoDateTimeField24);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 28800 + "'", int19 == 28800);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DateTimeField[era]" + "'", str25.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+52:00" + "'", str30.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "AD" + "'", str37.equals("AD"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "+52:00" + "'", str43.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(dateTimeFieldArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "+52:00" + "'", str56.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(chronology60);
        org.junit.Assert.assertNotNull(dateTimeFieldArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray63);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2 + "'", int67 == 2);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        org.joda.time.MonthDay monthDay9 = property8.getMonthDay();
        java.lang.String str10 = property8.getAsText();
        org.joda.time.DurationField durationField11 = property8.getRangeDurationField();
        org.joda.time.DurationField durationField12 = property8.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January" + "'", str10.equals("January"));
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (-187198562L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(1, (-97));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-97) + "'", int2 == (-97));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTimeField dateTimeField2 = property1.getField();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime5 = dateTime3.minusWeeks((int) '4');
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime9 = dateTime7.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime11 = dateTime9.plusHours(1);
        int int12 = mutableDateTime6.compareTo((org.joda.time.ReadableInstant) dateTime9);
        int int13 = property1.compareTo((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.DateTime dateTime15 = dateTime9.plusDays(2000);
        int int16 = dateTime15.getMinuteOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 480 + "'", int16 == 480);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long7 = offsetDateTimeField5.roundFloor(187200011L);
        int int8 = offsetDateTimeField5.getMaximumValue();
        org.joda.time.DateTimeField dateTimeField9 = offsetDateTimeField5.getWrappedField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 187200000L + "'", long7 == 187200000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1438 + "'", int8 == 1438);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime2 = property1.withMaximumValue();
        org.joda.time.DateTime dateTime3 = property1.roundHalfCeilingCopy();
        int int4 = property1.getMinimumValue();
        org.joda.time.DurationField durationField5 = property1.getRangeDurationField();
        org.joda.time.DateTime dateTime6 = property1.roundCeilingCopy();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime6.minus(readableDuration7);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        int int10 = property8.getMinimumValueOverall();
        java.lang.String str11 = property8.toString();
        org.joda.time.DurationField durationField12 = property8.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[monthOfYear]" + "'", str11.equals("Property[monthOfYear]"));
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        boolean boolean9 = skipUndoDateTimeField4.isLeap(1L);
        try {
            long long12 = skipUndoDateTimeField4.getDifferenceAsLong((-124273871999975L), 187200000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(1L, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfCentury();
        int int6 = property5.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.Chronology chronology3 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        int int4 = dateTime0.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMonths((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime0.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime0.withPeriodAdded(readablePeriod8, 10);
        int int11 = dateTime0.getSecondOfDay();
        org.joda.time.DateTime.Property property12 = dateTime0.dayOfWeek();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 28800 + "'", int11 == 28800);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
        int int20 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
        long long39 = zeroIsMaxDateTimeField37.roundHalfFloor(12L);
        int int40 = zeroIsMaxDateTimeField37.getMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-62105356800000L) + "'", long39 == (-62105356800000L));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2 + "'", int40 == 2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.minuteOfHour();
        java.lang.String str4 = gregorianChronology0.toString();
        try {
            long long12 = gregorianChronology0.getDateTimeMillis(100, 99, 10800, (int) ' ', 1615, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str3 = dateTimeZone2.toString();
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone2, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.Chronology chronology7 = monthDay6.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray8 = monthDay6.getFields();
        int int9 = monthDay6.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay6.getFields();
        int[] intArray12 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay6, (long) (short) 1);
        org.joda.time.Chronology chronology13 = monthDay6.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = copticChronology14.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) (short) -1);
        long long21 = offsetDateTimeField19.roundFloor(187200011L);
        int int22 = offsetDateTimeField19.getMaximumValue();
        org.joda.time.JodaTimePermission jodaTimePermission24 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property26 = dateTime25.era();
        org.joda.time.DateTime dateTime28 = dateTime25.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime30 = dateTime25.withHourOfDay(1);
        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property32 = dateTime31.era();
        org.joda.time.DateTimeField dateTimeField33 = property32.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property32.getFieldType();
        org.joda.time.DateTime dateTime36 = dateTime30.withField(dateTimeFieldType34, (int) (byte) 0);
        jodaTimePermission24.checkGuard((java.lang.Object) dateTimeFieldType34);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField19, dateTimeFieldType34, 2);
        try {
            int int40 = monthDay6.get(dateTimeFieldType34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+52:00" + "'", str3.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeFieldArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 187200000L + "'", long21 == 187200000L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1438 + "'", int22 == 1438);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeFieldType34);
        org.junit.Assert.assertNotNull(dateTime36);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(10);
        boolean boolean6 = dateTime0.isBefore((long) 25);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        org.joda.time.MonthDay monthDay9 = property8.getMonthDay();
        org.joda.time.MonthDay monthDay10 = property8.getMonthDay();
        java.util.Locale locale11 = null;
        int int12 = property8.getMaximumTextLength(locale11);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1L, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology12 = dateTime11.getChronology();
        org.joda.time.DateTime dateTime14 = dateTime11.withYearOfCentury((int) (byte) 1);
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology10, (org.joda.time.ReadableDateTime) dateTime14, readableDateTime15);
        try {
            long long21 = limitChronology16.getDateTimeMillis(2000, 1438, 239, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1438 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology16);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        org.joda.time.MonthDay monthDay11 = property8.addToCopy(97);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, 4);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property16 = dateTime15.era();
        org.joda.time.DateTimeField dateTimeField17 = property16.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property16.getFieldType();
        try {
            org.joda.time.MonthDay.Property property19 = monthDay14.property(dateTimeFieldType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.halfdays();
        try {
            long long7 = gregorianChronology0.getDateTimeMillis(187200000L, 0, 1438, 239, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1438 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.millisOfDay();
        boolean boolean10 = julianChronology0.equals((java.lang.Object) 4);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str13 = dateTimeZone12.toString();
        org.joda.time.Chronology chronology14 = julianChronology0.withZone(dateTimeZone12);
        long long18 = julianChronology0.add((long) (-1), (-1L), (int) (short) 10);
        org.joda.time.DateTimeField dateTimeField19 = julianChronology0.era();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-11L) + "'", long18 == (-11L));
        org.junit.Assert.assertNotNull(dateTimeField19);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology3 = gregorianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.centuryOfEra();
        try {
            long long9 = gregorianChronology2.getDateTimeMillis(0, 480, (int) (short) 100, 1615);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 480 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("002623.702+5200");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"002623.702+5200\" is malformed at \".702+5200\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        boolean boolean12 = cachedDateTimeZone11.isFixed();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("Jun", false);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone3.getShortName((long) (-97), locale5);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+00:00" + "'", str6.equals("+00:00"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime2 = property1.withMaximumValue();
        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
        boolean boolean4 = property1.isLeap();
        org.joda.time.DurationField durationField5 = property1.getDurationField();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("+52:00", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("January", 1612);
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder0.writeTo("UTC", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException4.prependMessage("JulianChronology[UTC]");
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException13.prependMessage("JulianChronology[UTC]");
        java.lang.String str16 = illegalFieldValueException13.toString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        java.lang.String str18 = illegalFieldValueException4.toString();
        java.lang.String str19 = illegalFieldValueException4.toString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str16.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str18.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str19.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("Jun");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Jun/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("org.joda.time.IllegalFieldValueException: : Value 1 for Property[era] must be in the range [1.0,10]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.dayOfYear();
        org.joda.time.DurationField durationField4 = gregorianChronology2.weekyears();
        long long7 = durationField4.subtract(104L, (long) 239);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField9 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-7541855999896L) + "'", long7 == (-7541855999896L));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1L, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property12 = dateTime11.era();
        org.joda.time.DateTime dateTime14 = dateTime11.plusHours((int) (byte) -1);
        int int15 = dateTime11.getMinuteOfHour();
        org.joda.time.DateTime dateTime17 = dateTime11.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property19 = dateTime18.era();
        org.joda.time.DateTime dateTime21 = dateTime18.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime23 = dateTime18.withHourOfDay(1);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property25 = dateTime24.era();
        org.joda.time.DateTimeField dateTimeField26 = property25.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property25.getFieldType();
        org.joda.time.DateTime dateTime29 = dateTime23.withField(dateTimeFieldType27, (int) (byte) 0);
        boolean boolean30 = dateTime11.isSupported(dateTimeFieldType27);
        boolean boolean31 = dateTime7.isSupported(dateTimeFieldType27);
        org.joda.time.DateTime.Property property32 = dateTime7.yearOfEra();
        org.joda.time.DateTime.Property property33 = dateTime7.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(property33);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        int int4 = dateTime0.getDayOfWeek();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime0.minus(readablePeriod5);
        org.joda.time.Instant instant7 = dateTime0.toInstant();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Instant instant9 = instant7.plus(readableDuration8);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withDefaultYear(2019);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        int int10 = offsetDateTimeField5.getLeapAmount(100L);
        long long12 = offsetDateTimeField5.roundHalfFloor(11L);
        int int15 = offsetDateTimeField5.getDifference((long) (short) 100, (long) 1439);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsShortText((int) (byte) 0, locale17);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str21 = dateTimeZone20.toString();
        boolean boolean23 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone20, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay24 = new org.joda.time.MonthDay(dateTimeZone20);
        org.joda.time.Chronology chronology25 = monthDay24.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray26 = monthDay24.getFields();
        int int27 = monthDay24.getMonthOfYear();
        org.joda.time.MonthDay monthDay29 = monthDay24.withMonthOfYear((int) (short) 1);
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField5.getAsText((org.joda.time.ReadablePartial) monthDay29, 0, locale31);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "+52:00" + "'", str21.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(dateTimeFieldArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "0" + "'", str32.equals("0"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(97, 2580, 26, 0, 2019, 6, (-26010446));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.io.Writer writer1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology3 = dateTime2.getChronology();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime2.withWeekyear(2000);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfCentury((int) (byte) 1);
        org.joda.time.DateTime dateTime5 = dateTime0.plusWeeks(12);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.withFields(readablePartial6);
        org.joda.time.DateTime dateTime9 = dateTime7.withWeekyear((int) (short) 1);
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.minus(readablePeriod10);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 28800, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = dateTime0.withWeekyear(2000);
        try {
            org.joda.time.DateTime dateTime6 = dateTime0.withMinuteOfHour(1439);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1439 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
        int int20 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
        int int43 = zeroIsMaxDateTimeField37.getMinimumValue(0L);
        int int45 = zeroIsMaxDateTimeField37.getLeapAmount((long) ' ');
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        try {
            long long9 = copticChronology0.getDateTimeMillis(0, 6, 19, (int) ' ', 480, 84381, 70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "1/1/70 12:00 AM", "1/1/70 12:00 AM");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.DateTime dateTime7 = dateTime3.withYearOfCentury(0);
        org.joda.time.DateTime dateTime8 = dateTime7.toDateTimeISO();
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException4.prependMessage("JulianChronology[UTC]");
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str10 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
        org.junit.Assert.assertNull(dateTimeFieldType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property7 = dateTime6.era();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
        org.joda.time.DateTime dateTime11 = dateTime5.withField(dateTimeFieldType9, (int) (byte) 0);
        org.joda.time.DateTime.Property property12 = dateTime11.dayOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.DateTime dateTime15 = dateTime11.withChronology((org.joda.time.Chronology) gregorianChronology13);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = monthDay5.toString("era", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: r");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours(1);
        org.joda.time.DateTime dateTime6 = dateTime2.withDayOfYear(10);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str3 = dateTimeZone2.toString();
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone2, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(dateTimeZone2);
        org.joda.time.Chronology chronology7 = monthDay6.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray8 = monthDay6.getFields();
        int int9 = monthDay6.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray10 = monthDay6.getFields();
        int[] intArray12 = iSOChronology0.get((org.joda.time.ReadablePartial) monthDay6, (long) (short) 1);
        long long16 = iSOChronology0.add(3L, (long) 1, (int) (byte) -1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+52:00" + "'", str3.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeFieldArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray10);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 2L + "'", long16 == 2L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException4.prependMessage("JulianChronology[UTC]");
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str10 = illegalFieldValueException4.getIllegalStringValue();
        org.joda.time.DurationFieldType durationFieldType11 = illegalFieldValueException4.getDurationFieldType();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
        org.junit.Assert.assertNull(dateTimeFieldType9);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(durationFieldType11);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime2 = property1.withMaximumValue();
        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property1.getAsText(locale4);
        boolean boolean6 = property1.isLeap();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AD" + "'", str5.equals("AD"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField5.getAsText((long) 'a', locale7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((int) (byte) -1, locale10);
        int int12 = offsetDateTimeField5.getMinimumValue();
        org.joda.time.DurationField durationField13 = offsetDateTimeField5.getLeapDurationField();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "239" + "'", str8.equals("239"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNull(durationField13);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime.Property property3 = dateTime0.weekyear();
        java.lang.String str4 = property3.getName();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "weekyear" + "'", str4.equals("weekyear"));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.withFields(readablePartial3);
        int int5 = dateTime4.getYearOfCentury();
        int int6 = dateTime4.getYear();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 70 + "'", int5 == 70);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int6 = skipUndoDateTimeField4.getMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str9 = dateTimeZone8.toString();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone8, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(dateTimeZone8);
        org.joda.time.Chronology chronology13 = monthDay12.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray14 = monthDay12.getFields();
        org.joda.time.MonthDay.Property property15 = monthDay12.monthOfYear();
        java.lang.String str16 = property15.getName();
        org.joda.time.MonthDay monthDay18 = property15.addToCopy(97);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.MonthDay monthDay21 = monthDay18.withPeriodAdded(readablePeriod19, 4);
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.chrono.JulianChronology julianChronology24 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField25 = julianChronology24.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField(chronology23, dateTimeField25, 2000);
        java.lang.String str28 = skipUndoDateTimeField27.toString();
        int int30 = skipUndoDateTimeField27.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str33 = dateTimeZone32.toString();
        boolean boolean35 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone32, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay36 = new org.joda.time.MonthDay(dateTimeZone32);
        int int37 = skipUndoDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) monthDay36);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str40 = dateTimeZone39.toString();
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone39, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(dateTimeZone39);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.MonthDay monthDay45 = monthDay43.plus(readablePeriod44);
        org.joda.time.MonthDay monthDay47 = monthDay45.minusDays((int) (byte) 0);
        int[] intArray53 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int54 = skipUndoDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) monthDay47, intArray53);
        try {
            int[] intArray56 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) monthDay18, 0, intArray53, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+52:00" + "'", str9.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeFieldArray14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "monthOfYear" + "'", str16.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(monthDay18);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(julianChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTimeField[era]" + "'", str28.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "+52:00" + "'", str33.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "+52:00" + "'", str40.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.Instant instant1 = new org.joda.time.Instant(187284381L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1L, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology10.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        int int18 = fixedDateTimeZone16.getStandardOffset((long) 6);
        boolean boolean19 = fixedDateTimeZone16.isFixed();
        org.joda.time.Chronology chronology20 = gJChronology10.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone16);
        int int22 = fixedDateTimeZone16.getOffsetFromLocal((-7541855999896L));
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 35 + "'", int18 == 35);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 97 + "'", int22 == 97);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfDay();
        int int3 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("ISOChronology[+52:00]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ISOChronology[+52:00]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        try {
            int[] intArray4 = gregorianChronology1.get(readablePeriod2, 31449600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(dateTimeFieldType6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.era();
        org.joda.time.DateTimeField dateTimeField3 = property2.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property2.getFieldType();
        org.joda.time.DurationField durationField5 = property2.getRangeDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = property2.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeFieldType6);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("ISOChronology[+52:00]", 70, 52, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for ISOChronology[+52:00] must be in the range [52,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        boolean boolean6 = skipUndoDateTimeField4.isLeap(9223372036854775807L);
        org.joda.time.DurationField durationField7 = skipUndoDateTimeField4.getDurationField();
        long long9 = skipUndoDateTimeField4.roundHalfCeiling((-7541855999896L));
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62105356800000L) + "'", long9 == (-62105356800000L));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.millisOfSecond();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(0L);
        int int10 = property7.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        int int10 = offsetDateTimeField5.getLeapAmount(100L);
        long long12 = offsetDateTimeField5.roundHalfFloor(11L);
        int int15 = offsetDateTimeField5.getDifference((long) (short) 100, (long) 1439);
        org.joda.time.DurationField durationField16 = offsetDateTimeField5.getLeapDurationField();
        long long18 = offsetDateTimeField5.roundHalfCeiling((long) 70);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(durationField16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("Jun", 12, 4, 10, 'a', (int) (byte) 10, 1615, 480, true, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        int int4 = dateTime0.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMonths((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime0.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime0.withPeriodAdded(readablePeriod8, 10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str13 = dateTimeZone12.toString();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.era();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(1L, dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar20 = dateTime18.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) dateTime18);
        boolean boolean22 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property23 = dateTime0.millisOfSecond();
        org.joda.time.DateTime.Property property24 = dateTime0.millisOfSecond();
        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime27 = dateTime25.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime29 = dateTime27.plusHours(1);
        long long30 = property24.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime27);
        org.joda.time.DateTime dateTime32 = dateTime27.withMillisOfDay(25200);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(gregorianCalendar20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31449600000L + "'", long30 == 31449600000L);
        org.junit.Assert.assertNotNull(dateTime32);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "DateTimeField[era]", (int) (byte) 100, (int) ' ');
        int int6 = fixedDateTimeZone4.getStandardOffset((-62105356800000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(70, (-97), 10800);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 70 + "'", int3 == 70);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        boolean boolean9 = skipUndoDateTimeField4.isLeap(1L);
        org.joda.time.DurationField durationField10 = skipUndoDateTimeField4.getRangeDurationField();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(durationField10);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        boolean boolean9 = skipUndoDateTimeField4.isLeap(1L);
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str13 = dateTimeZone12.toString();
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone12, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(dateTimeZone12);
        org.joda.time.Chronology chronology17 = monthDay16.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray18 = monthDay16.getFields();
        int int19 = monthDay16.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray20 = monthDay16.getFields();
        int[] intArray22 = iSOChronology10.get((org.joda.time.ReadablePartial) monthDay16, (long) (short) 1);
        org.joda.time.MonthDay monthDay23 = org.joda.time.MonthDay.now((org.joda.time.Chronology) iSOChronology10);
        java.util.Locale locale24 = null;
        try {
            java.lang.String str25 = skipUndoDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay23, locale24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeFieldArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(monthDay23);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        java.lang.Object obj0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property2 = dateTime1.era();
        org.joda.time.DateTime dateTime3 = property2.withMaximumValue();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTime3);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 100, 52, (int) 'a', 239, (int) (byte) 100, 84381, (-97));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 239 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        java.util.Locale locale4 = null;
        java.lang.String str5 = dateTimeZone1.getName((long) (byte) -1, locale4);
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField7 = copticChronology6.clockhourOfHalfday();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        java.util.Locale locale12 = null;
        java.lang.String str13 = dateTimeZone9.getName((long) (byte) -1, locale12);
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone9);
        try {
            org.joda.time.MonthDay monthDay15 = new org.joda.time.MonthDay((java.lang.Object) copticChronology6, (org.joda.time.Chronology) copticChronology14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.CopticChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+52:00" + "'", str5.equals("+52:00"));
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
        org.junit.Assert.assertNotNull(copticChronology14);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.withSecondOfMinute((int) (short) 10);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime7 = dateTime4.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime9 = dateTime4.withHourOfDay(1);
        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology11.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology13.getZone();
        org.joda.time.DateTime dateTime15 = dateTime9.toDateTime(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime3.withZoneRetainFields(dateTimeZone14);
        org.joda.time.DateTime dateTime18 = dateTime16.withCenturyOfEra(1970);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        java.util.Locale locale10 = null;
        java.lang.String str11 = property8.getAsText(locale10);
        try {
            org.joda.time.MonthDay monthDay13 = property8.setCopy(2580);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2580 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "January" + "'", str11.equals("January"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
        java.lang.Class<?> wildcardClass3 = dateTime2.getClass();
        org.joda.time.DateTime dateTime5 = dateTime2.plusMonths((int) ' ');
        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "08" + "'", str7.equals("08"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
        int int20 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
        long long43 = zeroIsMaxDateTimeField37.roundCeiling((long) '#');
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 9223372036854775807L + "'", long43 == 9223372036854775807L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.fullTime();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("-1", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-1\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
        int int20 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.era();
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str46 = dateTimeZone45.toString();
        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone45, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(dateTimeZone45);
        org.joda.time.Chronology chronology50 = monthDay49.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray51 = monthDay49.getFields();
        int int52 = monthDay49.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray53 = monthDay49.getFields();
        int[] intArray55 = gregorianChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) 84381);
        int int56 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
        try {
            long long59 = zeroIsMaxDateTimeField37.add((long) 32, 1546288017822L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+52:00" + "'", str46.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTimeFieldArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        try {
            long long7 = gregorianChronology1.getDateTimeMillis((long) 84381, 1438, 1612, 0, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1438 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.getAsShortText();
        org.joda.time.DateTime dateTime3 = property1.roundFloorCopy();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "AD" + "'", str2.equals("AD"));
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        int int5 = property1.getMinimumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException4.prependMessage("JulianChronology[UTC]");
        java.lang.Number number7 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str8 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 1 + "'", number7.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Property[era]" + "'", str8.equals("Property[era]"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DurationField durationField4 = julianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology1.weekOfWeekyear();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(obj0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay6.withPeriodAdded(readablePeriod7, 25);
        int int10 = monthDay6.getDayOfMonth();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 21 + "'", int10 == 21);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        int int8 = monthDay5.getMonthOfYear();
        org.joda.time.MonthDay monthDay10 = monthDay5.withMonthOfYear((int) (short) 1);
        java.lang.String str11 = monthDay5.toString();
        java.lang.String str13 = monthDay5.toString("�:�� �");
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "--01-05" + "'", str11.equals("--01-05"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "�:�� �" + "'", str13.equals("�:�� �"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        int int8 = monthDay5.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray9 = monthDay5.getFields();
        java.lang.String str11 = monthDay5.toString("--01-05");
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "--01-05" + "'", str11.equals("--01-05"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        org.joda.time.MonthDay monthDay9 = property8.getMonthDay();
        java.lang.String str10 = property8.getAsText();
        org.joda.time.MonthDay monthDay12 = property8.addWrapFieldToCopy((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "January" + "'", str10.equals("January"));
        org.junit.Assert.assertNotNull(monthDay12);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.withFields(readablePartial3);
        org.joda.time.DateTime dateTime6 = dateTime0.minusMinutes((int) (short) 10);
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.joda.time.DateTime dateTime9 = dateTime6.minusMonths((int) (short) -1);
        org.joda.time.DateTime.Property property10 = dateTime9.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.withFields(readablePartial3);
        int int5 = dateTime0.getMinuteOfHour();
        long long6 = dateTime0.getMillis();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 187200000L + "'", long6 == 187200000L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        org.joda.time.Instant instant1 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime2 = instant1.toMutableDateTime();
        int int5 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime2, "97", (int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(mutableDateTime2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-3) + "'", int5 == (-3));
    }
}

