import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
//        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
//        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
//        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.era();
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str46 = dateTimeZone45.toString();
//        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone45, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(dateTimeZone45);
//        org.joda.time.Chronology chronology50 = monthDay49.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray51 = monthDay49.getFields();
//        int int52 = monthDay49.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray53 = monthDay49.getFields();
//        int[] intArray55 = gregorianChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) 84381);
//        int int56 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
//        java.lang.Object obj57 = null;
//        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField59 = julianChronology58.era();
//        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology58.getZone();
//        org.joda.time.DurationField durationField61 = julianChronology58.hours();
//        org.joda.time.DateTimeField dateTimeField62 = julianChronology58.weekOfWeekyear();
//        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay(obj57, (org.joda.time.Chronology) julianChronology58);
//        org.joda.time.ReadablePeriod readablePeriod64 = null;
//        org.joda.time.MonthDay monthDay66 = monthDay63.withPeriodAdded(readablePeriod64, 25);
//        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str70 = dateTimeZone69.toString();
//        boolean boolean72 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone69, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay73 = new org.joda.time.MonthDay(dateTimeZone69);
//        org.joda.time.Chronology chronology74 = monthDay73.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray75 = monthDay73.getFields();
//        int int76 = monthDay73.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray77 = monthDay73.getFields();
//        int[] intArray79 = iSOChronology67.get((org.joda.time.ReadablePartial) monthDay73, (long) (short) 1);
//        int int80 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay66, intArray79);
//        try {
//            int int83 = zeroIsMaxDateTimeField37.getDifference((long) (-97), 0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+52:00" + "'", str46.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(julianChronology58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertNotNull(monthDay66);
//        org.junit.Assert.assertNotNull(iSOChronology67);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "+52:00" + "'", str70.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(chronology74);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray77);
//        org.junit.Assert.assertNotNull(intArray79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
//        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
//        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
//        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.era();
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str46 = dateTimeZone45.toString();
//        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone45, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(dateTimeZone45);
//        org.joda.time.Chronology chronology50 = monthDay49.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray51 = monthDay49.getFields();
//        int int52 = monthDay49.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray53 = monthDay49.getFields();
//        int[] intArray55 = gregorianChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) 84381);
//        int int56 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
//        java.lang.Object obj57 = null;
//        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField59 = julianChronology58.era();
//        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology58.getZone();
//        org.joda.time.DurationField durationField61 = julianChronology58.hours();
//        org.joda.time.DateTimeField dateTimeField62 = julianChronology58.weekOfWeekyear();
//        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay(obj57, (org.joda.time.Chronology) julianChronology58);
//        org.joda.time.ReadablePeriod readablePeriod64 = null;
//        org.joda.time.MonthDay monthDay66 = monthDay63.withPeriodAdded(readablePeriod64, 25);
//        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str70 = dateTimeZone69.toString();
//        boolean boolean72 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone69, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay73 = new org.joda.time.MonthDay(dateTimeZone69);
//        org.joda.time.Chronology chronology74 = monthDay73.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray75 = monthDay73.getFields();
//        int int76 = monthDay73.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray77 = monthDay73.getFields();
//        int[] intArray79 = iSOChronology67.get((org.joda.time.ReadablePartial) monthDay73, (long) (short) 1);
//        int int80 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay66, intArray79);
//        org.joda.time.DateTimeField dateTimeField81 = zeroIsMaxDateTimeField37.getWrappedField();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+52:00" + "'", str46.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNotNull(julianChronology58);
//        org.junit.Assert.assertNotNull(dateTimeField59);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(durationField61);
//        org.junit.Assert.assertNotNull(dateTimeField62);
//        org.junit.Assert.assertNotNull(monthDay66);
//        org.junit.Assert.assertNotNull(iSOChronology67);
//        org.junit.Assert.assertNotNull(dateTimeZone69);
//        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "+52:00" + "'", str70.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertNotNull(chronology74);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray77);
//        org.junit.Assert.assertNotNull(intArray79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//        org.junit.Assert.assertNotNull(dateTimeField81);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.era();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(84381, (int) '4', 1439, 2, 52, (org.joda.time.Chronology) julianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
//        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) (short) 10);
//        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime12 = dateTime8.minusHours(10800);
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology13.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (short) -1);
//        long long21 = offsetDateTimeField18.add((-1640822399990L), 97);
//        int int22 = offsetDateTimeField18.getOffset();
//        boolean boolean24 = offsetDateTimeField18.isLeap(1560630411317L);
//        org.joda.time.DateTimeField dateTimeField25 = offsetDateTimeField18.getWrappedField();
//        int int26 = dateTime8.get((org.joda.time.DateTimeField) offsetDateTimeField18);
//        java.util.Locale locale28 = null;
//        java.lang.String str29 = offsetDateTimeField18.getAsText((-97), locale28);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(copticChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1640816579990L) + "'", long21 == (-1640816579990L));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 59 + "'", int26 == 59);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "-97" + "'", str29.equals("-97"));
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.hourOfDay();
        int int2 = property1.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 23 + "'", int2 == 23);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DurationField durationField4 = julianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology1.weekOfWeekyear();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(obj0, (org.joda.time.Chronology) julianChronology1);
        try {
            long long12 = julianChronology1.getDateTimeMillis((-124303939199975L), 0, 25, 1438, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1438 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str2 = dateTimeZone1.toString();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
//        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1L, dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
//        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.Chronology chronology12 = dateTime11.getChronology();
//        org.joda.time.DateTime dateTime14 = dateTime11.withYearOfCentury((int) (byte) 1);
//        org.joda.time.ReadableDateTime readableDateTime15 = null;
//        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology10, (org.joda.time.ReadableDateTime) dateTime14, readableDateTime15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str19 = dateTimeZone18.toString();
//        boolean boolean21 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone18, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone18);
//        org.joda.time.Chronology chronology23 = monthDay22.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray24 = monthDay22.getFields();
//        org.joda.time.MonthDay.Property property25 = monthDay22.monthOfYear();
//        java.lang.String str26 = property25.getName();
//        int int27 = property25.getMinimumValueOverall();
//        int int28 = property25.get();
//        boolean boolean29 = limitChronology16.equals((java.lang.Object) property25);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(gregorianCalendar9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(limitChronology16);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+52:00" + "'", str19.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "monthOfYear" + "'", str26.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekOfWeekyear();
//        org.joda.time.DurationField durationField3 = julianChronology0.days();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str6 = dateTimeZone5.toString();
//        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone5, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay9 = new org.joda.time.MonthDay(dateTimeZone5);
//        org.joda.time.Chronology chronology10 = monthDay9.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray11 = monthDay9.getFields();
//        int int12 = monthDay9.getMonthOfYear();
//        long long14 = julianChronology0.set((org.joda.time.ReadablePartial) monthDay9, (-124273871999975L));
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology0);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+52:00" + "'", str6.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
//        org.junit.Assert.assertNotNull(chronology10);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-124303939199975L) + "'", long14 == (-124303939199975L));
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException4.prependMessage("JulianChronology[UTC]");
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.Number number8 = illegalFieldValueException4.getLowerBound();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException13.prependMessage("JulianChronology[UTC]");
        java.lang.String str16 = illegalFieldValueException13.toString();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException13);
        java.lang.String str18 = illegalFieldValueException4.toString();
        java.lang.Number number19 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology21 = dateTime20.getChronology();
        org.joda.time.DateTime.Property property22 = dateTime20.yearOfCentury();
        org.joda.time.DateTime dateTime26 = dateTime20.withDate((int) '4', (int) (short) 10, 6);
        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property28 = dateTime27.era();
        org.joda.time.DateTime dateTime30 = dateTime27.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime32 = dateTime27.withHourOfDay(1);
        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property34 = dateTime33.era();
        org.joda.time.DateTimeField dateTimeField35 = property34.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType36 = property34.getFieldType();
        org.joda.time.DateTime dateTime38 = dateTime32.withField(dateTimeFieldType36, (int) (byte) 0);
        boolean boolean39 = dateTime20.isSupported(dateTimeFieldType36);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType36, (java.lang.Number) (short) 1, (java.lang.Number) 10.0f, (java.lang.Number) (short) 100);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException43);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str16.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]" + "'", str18.equals("org.joda.time.IllegalFieldValueException: JulianChronology[UTC]: Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 1.0f + "'", number19.equals(1.0f));
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeFieldType36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        int int10 = offsetDateTimeField5.getLeapAmount(100L);
        long long12 = offsetDateTimeField5.roundHalfFloor(11L);
        int int15 = offsetDateTimeField5.getDifference((long) (short) 100, (long) 1439);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField5.getAsShortText((int) (byte) 0, locale17);
        int int19 = offsetDateTimeField5.getMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1438 + "'", int19 == 1438);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("CopticChronology[+52:00]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"CopticChronology[+52:00]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime4 = dateTime0.withWeekyear(2000);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property6 = dateTime5.era();
        org.joda.time.DateTimeField dateTimeField7 = property6.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property6.getFieldType();
        int int9 = dateTime4.get(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology2.getZone();
        try {
            long long8 = gregorianChronology2.getDateTimeMillis(23, 99, (int) (short) 10, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        long long9 = skipUndoDateTimeField4.roundHalfCeiling((long) 'a');
        long long11 = skipUndoDateTimeField4.roundHalfCeiling(0L);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 0L, chronology12);
        org.joda.time.DurationFieldType durationFieldType14 = null;
        try {
            org.joda.time.DateTime dateTime16 = dateTime13.withFieldAdded(durationFieldType14, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62105356800000L) + "'", long9 == (-62105356800000L));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-62105356800000L) + "'", long11 == (-62105356800000L));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        org.joda.time.MonthDay monthDay11 = property8.addToCopy(97);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.MonthDay monthDay14 = monthDay11.withPeriodAdded(readablePeriod12, 4);
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology16 = dateTime15.getChronology();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfCentury();
        org.joda.time.DateTime dateTime18 = dateTime15.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        try {
            boolean boolean20 = monthDay14.isEqual((org.joda.time.ReadablePartial) yearMonthDay19);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: ReadablePartial objects must have matching field types");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
//        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
//        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
//        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.era();
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str46 = dateTimeZone45.toString();
//        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone45, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(dateTimeZone45);
//        org.joda.time.Chronology chronology50 = monthDay49.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray51 = monthDay49.getFields();
//        int int52 = monthDay49.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray53 = monthDay49.getFields();
//        int[] intArray55 = gregorianChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) 84381);
//        int int56 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = zeroIsMaxDateTimeField37.getAsText(239, locale58);
//        java.lang.String str60 = zeroIsMaxDateTimeField37.getName();
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+52:00" + "'", str46.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "239" + "'", str59.equals("239"));
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "era" + "'", str60.equals("era"));
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
//        java.lang.String str5 = skipUndoDateTimeField4.toString();
//        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str10 = dateTimeZone9.toString();
//        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
//        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str17 = dateTimeZone16.toString();
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone16, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone16);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.plus(readablePeriod21);
//        org.joda.time.MonthDay monthDay24 = monthDay22.minusDays((int) (byte) 0);
//        int[] intArray30 = new int[] { 4, '4', 97, (short) -1, 35 };
//        int int31 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
//        int int32 = skipUndoDateTimeField4.getMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        org.joda.time.Chronology chronology34 = dateTimeFormatter33.getChronolgy();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime37 = dateTime35.minusWeeks((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime38 = dateTime37.toMutableDateTimeISO();
//        java.lang.String str39 = dateTimeFormatter33.print((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str42 = dateTimeZone41.toString();
//        boolean boolean44 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone41, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay(dateTimeZone41);
//        org.joda.time.Chronology chronology46 = monthDay45.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray47 = monthDay45.getFields();
//        int int48 = monthDay45.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray49 = monthDay45.getFields();
//        java.lang.String str50 = dateTimeFormatter33.print((org.joda.time.ReadablePartial) monthDay45);
//        int int51 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay45);
//        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property53 = dateTime52.era();
//        org.joda.time.DateTime dateTime55 = dateTime52.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime57 = dateTime52.withHourOfDay(1);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property59 = dateTime58.era();
//        org.joda.time.DateTimeField dateTimeField60 = property59.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property59.getFieldType();
//        org.joda.time.DateTime dateTime63 = dateTime57.withField(dateTimeFieldType61, (int) (byte) 0);
//        try {
//            org.joda.time.MonthDay.Property property64 = monthDay45.property(dateTimeFieldType61);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+52:00" + "'", str17.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNull(chronology34);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "080000.000+5200" + "'", str39.equals("080000.000+5200"));
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "+52:00" + "'", str42.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "������.000" + "'", str50.equals("������.000"));
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertNotNull(dateTimeField60);
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertNotNull(dateTime63);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("org.joda.time.IllegalFieldValueException: : Value 1 for Property[era] must be in the range [1.0,10]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("+52:00", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("January", 1612);
        java.io.DataOutput dataOutput8 = null;
        try {
            dateTimeZoneBuilder6.writeTo("June", dataOutput8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
//        int int9 = offsetDateTimeField5.getOffset();
//        boolean boolean11 = offsetDateTimeField5.isLeap(1560630411317L);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str15 = dateTimeZone14.toString();
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.era();
//        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology17.getZone();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(1L, dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        java.util.GregorianCalendar gregorianCalendar22 = dateTime20.toGregorianCalendar();
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property25 = dateTime24.era();
//        org.joda.time.DateTime dateTime27 = dateTime24.plusHours((int) (byte) -1);
//        int int28 = dateTime24.getMinuteOfHour();
//        org.joda.time.DateTime dateTime30 = dateTime24.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property32 = dateTime31.era();
//        org.joda.time.DateTime dateTime34 = dateTime31.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime36 = dateTime31.withHourOfDay(1);
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property38 = dateTime37.era();
//        org.joda.time.DateTimeField dateTimeField39 = property38.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
//        org.joda.time.DateTime dateTime42 = dateTime36.withField(dateTimeFieldType40, (int) (byte) 0);
//        boolean boolean43 = dateTime24.isSupported(dateTimeFieldType40);
//        boolean boolean44 = dateTime20.isSupported(dateTimeFieldType40);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField45 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField12, dateTimeFieldType40);
//        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str48 = dateTimeZone47.toString();
//        boolean boolean50 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone47, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay(dateTimeZone47);
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        org.joda.time.MonthDay monthDay53 = monthDay51.plus(readablePeriod52);
//        org.joda.time.MonthDay monthDay55 = monthDay53.minusDays((int) (byte) 0);
//        java.util.Locale locale56 = null;
//        try {
//            java.lang.String str57 = zeroIsMaxDateTimeField45.getAsText((org.joda.time.ReadablePartial) monthDay55, locale56);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+52:00" + "'", str15.equals("+52:00"));
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(gregorianCalendar22);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "+52:00" + "'", str48.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertNotNull(monthDay53);
//        org.junit.Assert.assertNotNull(monthDay55);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DurationField durationField4 = julianChronology1.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        java.lang.StringBuffer stringBuffer6 = null;
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology8 = dateTime7.getChronology();
        org.joda.time.DateTime.Property property9 = dateTime7.yearOfCentury();
        org.joda.time.DateTime dateTime10 = dateTime7.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime10.toYearMonthDay();
        try {
            dateTimeFormatter0.printTo(stringBuffer6, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(yearMonthDay11);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField12 = new org.joda.time.field.SkipUndoDateTimeField(chronology8, dateTimeField10, 2000);
        java.lang.String str13 = skipUndoDateTimeField12.toString();
        int int15 = skipUndoDateTimeField12.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str18 = dateTimeZone17.toString();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone17, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay21 = new org.joda.time.MonthDay(dateTimeZone17);
        int int22 = skipUndoDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) monthDay21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = skipUndoDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay21, 0, locale24);
        int int26 = skipUndoDateTimeField4.getMaximumValue();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[era]" + "'", str13.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "+52:00" + "'", str18.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "BC" + "'", str25.equals("BC"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str2 = dateTimeZone1.toString();
//        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
//        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
//        java.lang.String str7 = property6.getAsShortText();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "5" + "'", str7.equals("5"));
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField5.getAsText((long) 'a', locale7);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField5.getMaximumShortTextLength(locale9);
//        int int11 = offsetDateTimeField5.getMaximumValue();
//        long long13 = offsetDateTimeField5.roundCeiling((-124274059199996L));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "239" + "'", str8.equals("239"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1438 + "'", int11 == 1438);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-124274059140000L) + "'", long13 == (-124274059140000L));
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(1L, dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.yearOfCentury();
//        java.util.GregorianCalendar gregorianCalendar6 = dateTime4.toGregorianCalendar();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar6);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        int int12 = dateTime8.getMinuteOfHour();
//        org.joda.time.DateTime dateTime14 = dateTime8.minusMonths((int) (byte) 0);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime8.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime8.withPeriodAdded(readablePeriod16, 10);
//        int int19 = dateTime8.getSecondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology20.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (short) -1);
//        long long27 = offsetDateTimeField25.roundFloor(187200011L);
//        int int28 = offsetDateTimeField25.getMaximumValue();
//        org.joda.time.JodaTimePermission jodaTimePermission30 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property32 = dateTime31.era();
//        org.joda.time.DateTime dateTime34 = dateTime31.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime36 = dateTime31.withHourOfDay(1);
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property38 = dateTime37.era();
//        org.joda.time.DateTimeField dateTimeField39 = property38.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
//        org.joda.time.DateTime dateTime42 = dateTime36.withField(dateTimeFieldType40, (int) (byte) 0);
//        jodaTimePermission30.checkGuard((java.lang.Object) dateTimeFieldType40);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField25, dateTimeFieldType40, 2);
//        int int46 = dateTime8.get(dateTimeFieldType40);
//        int int47 = monthDay7.indexOf(dateTimeFieldType40);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException51 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) (short) 10, (java.lang.Number) (-124273871999996L), (java.lang.Number) 31449599996L);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 28800 + "'", int19 == 28800);
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 187200000L + "'", long27 == 187200000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1438 + "'", int28 == 1438);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.DateTime dateTime7 = dateTime3.withYearOfCentury(0);
        org.joda.time.DateTime dateTime8 = dateTime7.toDateTimeISO();
        org.joda.time.Instant instant9 = dateTime7.toInstant();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(instant9);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
//        java.io.Writer writer2 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property4 = dateTime3.era();
//        org.joda.time.DateTime dateTime6 = dateTime3.plusHours((int) (byte) -1);
//        int int7 = dateTime3.getDayOfWeek();
//        org.joda.time.DateTime.Property property8 = dateTime3.year();
//        org.joda.time.DateTime dateTime10 = dateTime3.withHourOfDay((int) (byte) 0);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime3.plus(readablePeriod11);
//        org.joda.time.DateTime dateTime15 = dateTime3.withDurationAdded((long) '#', 99);
//        org.joda.time.DateTime dateTime16 = dateTime3.toDateTime();
//        try {
//            dateTimeFormatter0.printTo(writer2, (org.joda.time.ReadableInstant) dateTime3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(int1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.millisOfDay();
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((org.joda.time.Chronology) julianChronology0);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str2 = dateTimeZone1.toString();
//        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
//        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
//        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property10 = dateTime9.era();
//        org.joda.time.DateTime dateTime12 = dateTime9.plusHours((int) (byte) -1);
//        int int13 = dateTime9.getDayOfWeek();
//        boolean boolean14 = property8.equals((java.lang.Object) int13);
//        int int15 = property8.getMinimumValue();
//        java.lang.String str16 = property8.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Property[monthOfYear]" + "'", str16.equals("Property[monthOfYear]"));
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("org.joda.time.IllegalFieldValueException: : Value 1 for Property[era] must be in the range [1.0,10]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: org.joda.time.IllegalFieldValueException: : Value 1 for Property[era] must be in the range [1.0,10]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("DateTimeField[era]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: DateTimeField[era]");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.withFields(readablePartial6);
        boolean boolean8 = dateTime5.isEqualNow();
        int int9 = dateTime5.getEra();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime5.getZone();
        try {
            org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone10, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 99");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        java.lang.String str2 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.halfdayOfDay();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.year();
        org.joda.time.DurationField durationField3 = iSOChronology0.millis();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.millisOfDay();
        boolean boolean10 = julianChronology0.equals((java.lang.Object) 4);
        org.joda.time.DateTimeField dateTimeField11 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField12 = julianChronology0.eras();
        try {
            long long17 = julianChronology0.getDateTimeMillis(9, 4, (-97), 25);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -97 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("ISOChronology[+52:00]", (java.lang.Number) 187284381L, (java.lang.Number) 23, (java.lang.Number) 1546288017822L);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str4 = dateTimeZone3.toString();
//        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone3, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(dateTimeZone3);
//        org.joda.time.Chronology chronology8 = monthDay7.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray9 = monthDay7.getFields();
//        int int10 = monthDay7.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray11 = monthDay7.getFields();
//        int[] intArray13 = gregorianChronology0.get((org.joda.time.ReadablePartial) monthDay7, (long) 84381);
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.era();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField18 = new org.joda.time.field.SkipUndoDateTimeField(chronology14, dateTimeField16, 2000);
//        java.lang.String str19 = skipUndoDateTimeField18.toString();
//        int int21 = skipUndoDateTimeField18.get((long) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str24 = dateTimeZone23.toString();
//        boolean boolean26 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone23, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay(dateTimeZone23);
//        int int28 = skipUndoDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay27);
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str31 = dateTimeZone30.toString();
//        boolean boolean33 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone30, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay34 = new org.joda.time.MonthDay(dateTimeZone30);
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.MonthDay monthDay36 = monthDay34.plus(readablePeriod35);
//        org.joda.time.MonthDay monthDay38 = monthDay36.minusDays((int) (byte) 0);
//        int[] intArray44 = new int[] { 4, '4', 97, (short) -1, 35 };
//        int int45 = skipUndoDateTimeField18.getMaximumValue((org.joda.time.ReadablePartial) monthDay38, intArray44);
//        int int46 = skipUndoDateTimeField18.getMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        org.joda.time.Chronology chronology48 = dateTimeFormatter47.getChronolgy();
//        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime51 = dateTime49.minusWeeks((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime52 = dateTime51.toMutableDateTimeISO();
//        java.lang.String str53 = dateTimeFormatter47.print((org.joda.time.ReadableInstant) dateTime51);
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str56 = dateTimeZone55.toString();
//        boolean boolean58 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone55, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay(dateTimeZone55);
//        org.joda.time.Chronology chronology60 = monthDay59.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray61 = monthDay59.getFields();
//        int int62 = monthDay59.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray63 = monthDay59.getFields();
//        java.lang.String str64 = dateTimeFormatter47.print((org.joda.time.ReadablePartial) monthDay59);
//        int int65 = skipUndoDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) monthDay59);
//        int int66 = monthDay7.compareTo((org.joda.time.ReadablePartial) monthDay59);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+52:00" + "'", str4.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray11);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertNotNull(julianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DateTimeField[era]" + "'", str19.equals("DateTimeField[era]"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+52:00" + "'", str24.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "+52:00" + "'", str31.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(monthDay36);
//        org.junit.Assert.assertNotNull(monthDay38);
//        org.junit.Assert.assertNotNull(intArray44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter47);
//        org.junit.Assert.assertNull(chronology48);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(mutableDateTime52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "080000.000+5200" + "'", str53.equals("080000.000+5200"));
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "+52:00" + "'", str56.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(chronology60);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray63);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "������.000" + "'", str64.equals("������.000"));
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("2019");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '2019' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "12:26:55 AM");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) -1);
//        long long10 = offsetDateTimeField7.add((-1640822399990L), 97);
//        int int12 = offsetDateTimeField7.getLeapAmount(100L);
//        long long14 = offsetDateTimeField7.roundHalfFloor(11L);
//        int int15 = offsetDateTimeField7.getMinimumValue();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology1, (org.joda.time.DateTimeField) offsetDateTimeField7, 1);
//        int int19 = skipDateTimeField17.get(0L);
//        int int21 = skipDateTimeField17.get((long) 'a');
//        long long23 = skipDateTimeField17.roundHalfEven((long) 2000);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(gregorianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1640816579990L) + "'", long10 == (-1640816579990L));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 239 + "'", int19 == 239);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 239 + "'", int21 == 239);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime0.withDate((int) '4', (int) (short) 10, 6);
        org.joda.time.DateTime dateTime8 = dateTime6.plusYears(97);
        org.joda.time.DateTime dateTime10 = dateTime8.minusMillis(1438);
        org.joda.time.DateMidnight dateMidnight11 = dateTime8.toDateMidnight();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight11);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter1.getParser();
        org.joda.time.Chronology chronology3 = dateTimeFormatter1.getChronolgy();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter1.withPivotYear(26);
        try {
            org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.parse("hi!", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        org.joda.time.MonthDay monthDay9 = property8.getMonthDay();
        org.joda.time.MonthDay monthDay10 = property8.getMonthDay();
        org.joda.time.MonthDay monthDay12 = property8.addToCopy(1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay10);
        org.junit.Assert.assertNotNull(monthDay12);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.hourOfDay();
        org.joda.time.DateTime dateTime3 = dateTime0.minus((long) 28800);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.MonthDay monthDay2 = org.joda.time.MonthDay.now();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) monthDay2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(monthDay2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone1);
        long long7 = dateTimeZone1.convertLocalToUTC((long) (byte) 10, false, (long) (short) 0);
        org.joda.time.MonthDay monthDay8 = org.joda.time.MonthDay.now(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-187199990L) + "'", long7 == (-187199990L));
        org.junit.Assert.assertNotNull(monthDay8);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        int int9 = property8.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((-62105356800000L));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        long long6 = skipUndoDateTimeField4.roundHalfEven(0L);
        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.now();
        int int8 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay7);
        boolean boolean9 = skipUndoDateTimeField4.isLenient();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-62105356800000L) + "'", long6 == (-62105356800000L));
        org.junit.Assert.assertNotNull(monthDay7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekOfWeekyear();
        try {
            long long7 = julianChronology0.getDateTimeMillis(25, 84381, (int) '4', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 84381 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField5.getAsText((long) 'a', locale7);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField5.getMaximumShortTextLength(locale9);
//        int int13 = offsetDateTimeField5.getDifference((long) 2000, 1560626784922L);
//        org.joda.time.DurationField durationField14 = offsetDateTimeField5.getDurationField();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "239" + "'", str8.equals("239"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-26010446) + "'", int13 == (-26010446));
//        org.junit.Assert.assertNotNull(durationField14);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.withFields(readablePartial6);
        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
        java.lang.Object obj9 = null;
        org.joda.time.Instant instant10 = new org.joda.time.Instant(obj9);
        boolean boolean12 = instant10.isAfter((long) 0);
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime7, (org.joda.time.ReadableInstant) instant10);
        org.joda.time.Instant instant15 = instant10.minus((-62198755200000L));
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(instant15);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getMinuteOfHour();
//        org.joda.time.DateTime dateTime7 = dateTime0.withDurationAdded((long) 6, (int) (byte) 1);
//        org.joda.time.LocalDateTime localDateTime8 = dateTime0.toLocalDateTime();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(localDateTime8);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(0);
        org.joda.time.DateTime dateTime12 = dateTime8.minusHours(10800);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology14 = dateTime13.getChronology();
        org.joda.time.DateTime.Property property15 = dateTime13.yearOfCentury();
        org.joda.time.DateTime dateTime19 = dateTime13.withDate((int) '4', (int) (short) 10, 6);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property21 = dateTime20.era();
        org.joda.time.DateTime dateTime23 = dateTime20.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime25 = dateTime20.withHourOfDay(1);
        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property27 = dateTime26.era();
        org.joda.time.DateTimeField dateTimeField28 = property27.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property27.getFieldType();
        org.joda.time.DateTime dateTime31 = dateTime25.withField(dateTimeFieldType29, (int) (byte) 0);
        boolean boolean32 = dateTime13.isSupported(dateTimeFieldType29);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) (short) 1, (java.lang.Number) 10.0f, (java.lang.Number) (short) 100);
        int int37 = dateTime12.get(dateTimeFieldType29);
        org.joda.time.DateTime.Property property38 = dateTime12.hourOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(property38);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(10);
//        int int5 = dateTime4.getWeekOfWeekyear();
//        org.joda.time.DateTime.Property property6 = dateTime4.yearOfCentury();
//        org.joda.time.DateTime dateTime7 = property6.getDateTime();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        int int16 = skipUndoDateTimeField4.getLeapAmount(0L);
        java.util.Locale locale18 = null;
        java.lang.String str19 = skipUndoDateTimeField4.getAsShortText(0L, locale18);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "AD" + "'", str19.equals("AD"));
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        java.lang.String str2 = property1.toString();
//        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str7 = dateTimeZone6.toString();
//        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.era();
//        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology9.getZone();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(1L, dateTimeZone11);
//        org.joda.time.DateTime.Property property13 = dateTime12.yearOfCentury();
//        java.util.GregorianCalendar gregorianCalendar14 = dateTime12.toGregorianCalendar();
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
//        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
//        boolean boolean36 = dateTime12.isSupported(dateTimeFieldType32);
//        int int37 = property1.compareTo((org.joda.time.ReadableInstant) dateTime12);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
//        org.junit.Assert.assertNotNull(julianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gregorianCalendar14);
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(1L, dateTimeZone3);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfCentury();
        int int6 = dateTime4.getMonthOfYear();
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = dateTime4.toString("", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid pattern specification");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.withFields(readablePartial3);
        org.joda.time.DateTime dateTime6 = dateTime4.plusDays(0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime2 = property1.withMaximumValue();
        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
        boolean boolean4 = property1.isLeap();
        org.joda.time.DateTime dateTime5 = property1.getDateTime();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone6 = fixedDateTimeZone5.toTimeZone();
        long long8 = fixedDateTimeZone5.nextTransition(0L);
        int int10 = fixedDateTimeZone5.getOffsetFromLocal((long) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone5);
        long long14 = fixedDateTimeZone5.convertLocalToUTC((long) 10, false);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 97 + "'", int10 == 97);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-87L) + "'", long14 == (-87L));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField4, 10);
        org.joda.time.DateTimeZone dateTimeZone7 = gregorianChronology0.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        long long10 = offsetDateTimeField5.roundHalfFloor((long) 1);
        long long13 = offsetDateTimeField5.getDifferenceAsLong((-124273871999975L), (long) 19);
        int int15 = offsetDateTimeField5.getLeapAmount(9699L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-2071231199L) + "'", long13 == (-2071231199L));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        java.util.Locale locale6 = null;
//        java.lang.String str7 = property5.getAsText(locale6);
//        int int8 = property5.getMinimumValue();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970" + "'", str7.equals("1970"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-292275054) + "'", int8 == (-292275054));
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        org.joda.time.MonthDay monthDay9 = property8.getMonthDay();
        org.joda.time.Chronology chronology10 = monthDay9.getChronology();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str11 = dateTimeZone10.toString();
        java.util.Locale locale13 = null;
        java.lang.String str14 = dateTimeZone10.getName((long) (byte) -1, locale13);
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTime dateTime16 = dateTime8.toDateTime(dateTimeZone10);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+52:00" + "'", str11.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+52:00" + "'", str14.equals("+52:00"));
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.withYearOfEra(84381);
        org.joda.time.DateTime dateTime6 = dateTime4.minusYears(1970);
        java.lang.Class<?> wildcardClass7 = dateTime4.getClass();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str2 = dateTimeZone1.toString();
//        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
//        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
//        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
//        java.lang.String str9 = property8.getName();
//        int int10 = property8.getMinimumValueOverall();
//        java.lang.String str11 = property8.toString();
//        java.lang.String str12 = property8.getAsText();
//        org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology13.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone14);
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology15.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) (short) -1);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = offsetDateTimeField18.getAsShortText((long) 19, locale20);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str24 = dateTimeZone23.toString();
//        boolean boolean26 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone23, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay27 = new org.joda.time.MonthDay(dateTimeZone23);
//        org.joda.time.Chronology chronology28 = monthDay27.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray29 = monthDay27.getFields();
//        org.joda.time.MonthDay.Property property30 = monthDay27.monthOfYear();
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = offsetDateTimeField18.getAsText((org.joda.time.ReadablePartial) monthDay27, 100, locale32);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str36 = dateTimeZone35.toString();
//        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone35, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(dateTimeZone35);
//        org.joda.time.ReadablePeriod readablePeriod40 = null;
//        org.joda.time.MonthDay monthDay41 = monthDay39.plus(readablePeriod40);
//        org.joda.time.MonthDay monthDay43 = monthDay41.minusDays((int) (byte) 0);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str46 = dateTimeZone45.toString();
//        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone45, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(dateTimeZone45);
//        org.joda.time.Chronology chronology50 = monthDay49.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray51 = monthDay49.getFields();
//        org.joda.time.MonthDay.Property property52 = monthDay49.monthOfYear();
//        org.joda.time.MonthDay monthDay53 = property52.getMonthDay();
//        org.joda.time.MonthDay monthDay54 = property52.getMonthDay();
//        boolean boolean55 = monthDay41.isBefore((org.joda.time.ReadablePartial) monthDay54);
//        boolean boolean56 = monthDay27.isEqual((org.joda.time.ReadablePartial) monthDay41);
//        int int57 = property8.compareTo((org.joda.time.ReadablePartial) monthDay41);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[monthOfYear]" + "'", str11.equals("Property[monthOfYear]"));
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "January" + "'", str12.equals("January"));
//        org.junit.Assert.assertNotNull(copticChronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "239" + "'", str21.equals("239"));
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+52:00" + "'", str24.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+52:00" + "'", str36.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(monthDay41);
//        org.junit.Assert.assertNotNull(monthDay43);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+52:00" + "'", str46.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(monthDay53);
//        org.junit.Assert.assertNotNull(monthDay54);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        int int10 = offsetDateTimeField5.getLeapAmount(100L);
        long long12 = offsetDateTimeField5.roundHalfFloor(11L);
        int int13 = offsetDateTimeField5.getMinimumValue();
        int int15 = offsetDateTimeField5.getMaximumValue((-87L));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1438 + "'", int15 == 1438);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
//        java.lang.String str5 = skipUndoDateTimeField4.toString();
//        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str10 = dateTimeZone9.toString();
//        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
//        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str17 = dateTimeZone16.toString();
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone16, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone16);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.plus(readablePeriod21);
//        org.joda.time.MonthDay monthDay24 = monthDay22.minusDays((int) (byte) 0);
//        int[] intArray30 = new int[] { 4, '4', 97, (short) -1, 35 };
//        int int31 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
//        int int32 = skipUndoDateTimeField4.getMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        org.joda.time.Chronology chronology34 = dateTimeFormatter33.getChronolgy();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime37 = dateTime35.minusWeeks((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime38 = dateTime37.toMutableDateTimeISO();
//        java.lang.String str39 = dateTimeFormatter33.print((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str42 = dateTimeZone41.toString();
//        boolean boolean44 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone41, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay(dateTimeZone41);
//        org.joda.time.Chronology chronology46 = monthDay45.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray47 = monthDay45.getFields();
//        int int48 = monthDay45.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray49 = monthDay45.getFields();
//        java.lang.String str50 = dateTimeFormatter33.print((org.joda.time.ReadablePartial) monthDay45);
//        int int51 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay45);
//        long long53 = skipUndoDateTimeField4.roundHalfCeiling(0L);
//        long long56 = skipUndoDateTimeField4.addWrapField((long) 28800, (int) (byte) 100);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+52:00" + "'", str17.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNull(chronology34);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "080000.000+5200" + "'", str39.equals("080000.000+5200"));
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "+52:00" + "'", str42.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "������.000" + "'", str50.equals("������.000"));
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertTrue("'" + long53 + "' != '" + (-62105356800000L) + "'", long53 == (-62105356800000L));
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 28800L + "'", long56 == 28800L);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DurationField durationField7 = julianChronology0.hours();
//        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
//        java.lang.String str10 = dateTimeZone8.getName((long) 35);
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone8, 9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 9");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Coordinated Universal Time" + "'", str10.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        java.lang.String str2 = buddhistChronology0.toString();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "BuddhistChronology[UTC]" + "'", str2.equals("BuddhistChronology[UTC]"));
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str7 = dateTimeZone6.toString();
//        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone6, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay10 = new org.joda.time.MonthDay(dateTimeZone6);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone6);
//        org.joda.time.DateTime dateTime12 = dateTime0.toDateTime((org.joda.time.Chronology) julianChronology11);
//        try {
//            org.joda.time.DateTime dateTime14 = dateTime12.withDayOfMonth(70);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for dayOfMonth must be in the range [1,31]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str2 = dateTimeZone1.toString();
//        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
//        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
//        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
//        java.lang.String str9 = property8.getName();
//        int int10 = property8.getMinimumValueOverall();
//        int int11 = property8.get();
//        org.joda.time.DurationField durationField12 = property8.getRangeDurationField();
//        int int13 = property8.getMaximumValue();
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = property8.getAsText(locale14);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "January" + "'", str15.equals("January"));
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.Chronology chronology3 = gregorianChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.centuryOfEra();
        int int5 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
//        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
//        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.era();
//        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(1L, dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
//        int int13 = dateTime11.getMonthOfYear();
//        boolean boolean14 = dateTime11.isEqualNow();
//        int int15 = dateTime11.getMillisOfDay();
//        int int16 = property6.getDifference((org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DurationField durationField17 = property6.getLeapDurationField();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(julianChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNull(durationField17);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        int int13 = cachedDateTimeZone11.getOffset((-34L));
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property15 = dateTime14.era();
        org.joda.time.DateTime dateTime17 = dateTime14.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime19 = dateTime14.withHourOfDay(1);
        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
        boolean boolean21 = cachedDateTimeZone11.equals((java.lang.Object) dateTime19);
        int int23 = cachedDateTimeZone11.getStandardOffset((long) 19);
        long long25 = cachedDateTimeZone11.previousTransition((long) 26);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 26L + "'", long25 == 26L);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str2 = dateTimeZone1.toString();
//        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
//        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1L, dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
//        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.chrono.BuddhistChronology buddhistChronology11 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
//        java.lang.String str12 = buddhistChronology11.toString();
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology11);
//        long long15 = gJChronology10.set((org.joda.time.ReadablePartial) monthDay13, 1560630417822L);
//        long long19 = gJChronology10.add((long) (byte) -1, (long) (byte) 100, (int) 'a');
//        java.lang.String str20 = gJChronology10.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
//        org.junit.Assert.assertNotNull(julianChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(gregorianCalendar9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(buddhistChronology11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "BuddhistChronology[UTC]" + "'", str12.equals("BuddhistChronology[UTC]"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546288017822L + "'", long15 == 1546288017822L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9699L + "'", long19 == 9699L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "GJChronology[+52:00,cutover=1970-01-01T00:00:00.001Z]" + "'", str20.equals("GJChronology[+52:00,cutover=1970-01-01T00:00:00.001Z]"));
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DurationField durationField4 = julianChronology1.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.Instant instant7 = new org.joda.time.Instant((long) (byte) 0);
        boolean boolean8 = julianChronology1.equals((java.lang.Object) instant7);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        try {
            org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((-1), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must not be smaller than 1");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1L, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology10.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long16 = gregorianChronology12.add(11L, (-1L), 10);
        org.joda.time.DurationField durationField17 = gregorianChronology12.halfdays();
        boolean boolean18 = gJChronology10.equals((java.lang.Object) gregorianChronology12);
        org.joda.time.Chronology chronology19 = gregorianChronology12.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1L + "'", long16 == 1L);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        int int2 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DurationField durationField3 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField6 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str9 = dateTimeZone8.toString();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone8, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(dateTimeZone8);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.MonthDay monthDay14 = monthDay12.plus(readablePeriod13);
        org.joda.time.MonthDay monthDay16 = monthDay14.minusDays((int) (byte) 0);
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.chrono.JulianChronology julianChronology18 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField19 = julianChronology18.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField(chronology17, dateTimeField19, 2000);
        java.lang.String str22 = skipUndoDateTimeField21.toString();
        int int24 = skipUndoDateTimeField21.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str27 = dateTimeZone26.toString();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone26, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone26);
        int int31 = skipUndoDateTimeField21.getMinimumValue((org.joda.time.ReadablePartial) monthDay30);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str34 = dateTimeZone33.toString();
        boolean boolean36 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone33, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay37 = new org.joda.time.MonthDay(dateTimeZone33);
        org.joda.time.ReadablePeriod readablePeriod38 = null;
        org.joda.time.MonthDay monthDay39 = monthDay37.plus(readablePeriod38);
        org.joda.time.MonthDay monthDay41 = monthDay39.minusDays((int) (byte) 0);
        int[] intArray47 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int48 = skipUndoDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) monthDay41, intArray47);
        int int49 = delegatedDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) monthDay16, intArray47);
        org.joda.time.MonthDay monthDay51 = new org.joda.time.MonthDay(24L);
        int[] intArray55 = new int[] { (-1), 2000 };
        java.util.Locale locale57 = null;
        try {
            int[] intArray58 = delegatedDateTimeField6.set((org.joda.time.ReadablePartial) monthDay51, 1970, intArray55, "monthOfYear", locale57);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"monthOfYear\" for minuteOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+52:00" + "'", str9.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(monthDay14);
        org.junit.Assert.assertNotNull(monthDay16);
        org.junit.Assert.assertNotNull(julianChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTimeField[era]" + "'", str22.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2 + "'", int24 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+52:00" + "'", str27.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "+52:00" + "'", str34.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(monthDay39);
        org.junit.Assert.assertNotNull(monthDay41);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1439 + "'", int49 == 1439);
        org.junit.Assert.assertNotNull(intArray55);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        jodaTimePermission1.checkGuard((java.lang.Object) dateTime4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.toString();
        java.util.Locale locale10 = null;
        int int11 = property8.getMaximumTextLength(locale10);
        org.joda.time.MonthDay monthDay13 = property8.addToCopy((int) (short) 1);
        java.util.Locale locale15 = null;
        try {
            org.joda.time.MonthDay monthDay16 = property8.setCopy("CopticChronology[+52:00]", locale15);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"CopticChronology[+52:00]\" for monthOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[monthOfYear]" + "'", str9.equals("Property[monthOfYear]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
        org.junit.Assert.assertNotNull(monthDay13);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        org.joda.time.MonthDay monthDay9 = property8.getMonthDay();
        org.joda.time.MonthDay monthDay10 = property8.getMonthDay();
        try {
            org.joda.time.MonthDay monthDay12 = monthDay10.withDayOfMonth((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        java.lang.Class<?> wildcardClass2 = dateTime1.getClass();
        boolean boolean4 = dateTime1.isAfter(0L);
        org.joda.time.DateTime dateTime6 = dateTime1.withMillisOfDay(19);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
//        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
//        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
//        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.era();
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str46 = dateTimeZone45.toString();
//        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone45, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(dateTimeZone45);
//        org.joda.time.Chronology chronology50 = monthDay49.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray51 = monthDay49.getFields();
//        int int52 = monthDay49.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray53 = monthDay49.getFields();
//        int[] intArray55 = gregorianChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) 84381);
//        int int56 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
//        java.util.Locale locale58 = null;
//        java.lang.String str59 = zeroIsMaxDateTimeField37.getAsText(239, locale58);
//        try {
//            long long62 = zeroIsMaxDateTimeField37.add((-187198562L), (long) 1970);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+52:00" + "'", str46.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "239" + "'", str59.equals("239"));
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        org.joda.time.DateTime.Property property6 = dateTime0.year();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(property6);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(28800, 1615);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 1615");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
//        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
//        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
//        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.era();
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str46 = dateTimeZone45.toString();
//        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone45, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(dateTimeZone45);
//        org.joda.time.Chronology chronology50 = monthDay49.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray51 = monthDay49.getFields();
//        int int52 = monthDay49.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray53 = monthDay49.getFields();
//        int[] intArray55 = gregorianChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) 84381);
//        int int56 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
//        org.joda.time.DurationField durationField57 = zeroIsMaxDateTimeField37.getLeapDurationField();
//        long long59 = zeroIsMaxDateTimeField37.roundFloor((long) 25);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+52:00" + "'", str46.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNull(durationField57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-62105356800000L) + "'", long59 == (-62105356800000L));
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withDefaultYear((int) (byte) -1);
        org.joda.time.Chronology chronology6 = dateTimeFormatter0.getChronology();
        int int7 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2000 + "'", int7 == 2000);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DurationField durationField3 = julianChronology0.hours();
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) julianChronology0, (java.lang.Object) 2019);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1L, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology10.getZone();
        org.joda.time.DurationField durationField12 = gJChronology10.weeks();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.DurationField durationField3 = julianChronology0.centuries();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(84381);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.withSecondOfMinute((int) (short) 10);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        java.lang.String str6 = property5.toString();
        org.joda.time.DateTime dateTime8 = property5.addWrapFieldToCopy(10);
        org.joda.time.DateTime dateTime9 = property5.withMaximumValue();
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime0, (org.joda.time.ReadableInstant) dateTime9);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Property[era]" + "'", str6.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime4 = dateTime2.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.withFields(readablePartial5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str9 = dateTimeZone8.toString();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone8, (java.lang.Object) (-1.0f));
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime2.toMutableDateTime(dateTimeZone8);
        org.joda.time.Chronology chronology13 = buddhistChronology0.withZone(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str16 = dateTimeZone15.toString();
        boolean boolean18 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone15, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay19 = new org.joda.time.MonthDay(dateTimeZone15);
        org.joda.time.Chronology chronology20 = monthDay19.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray21 = monthDay19.getFields();
        org.joda.time.MonthDay.Property property22 = monthDay19.monthOfYear();
        org.joda.time.MonthDay monthDay23 = property22.getMonthDay();
        org.joda.time.MonthDay monthDay25 = monthDay23.plusMonths(0);
        boolean boolean26 = buddhistChronology0.equals((java.lang.Object) 0);
        org.joda.time.Chronology chronology27 = buddhistChronology0.withUTC();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+52:00" + "'", str9.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "+52:00" + "'", str16.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTimeFieldArray21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(monthDay23);
        org.junit.Assert.assertNotNull(monthDay25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(chronology27);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        java.lang.Object obj11 = null;
        boolean boolean12 = iSOChronology10.equals(obj11);
        org.joda.time.DurationField durationField13 = iSOChronology10.halfdays();
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology10.dayOfMonth();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.minusWeeks((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTimeISO();
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter0.withPivotYear(35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "080000.000+5200" + "'", str6.equals("080000.000+5200"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        try {
            java.lang.String str3 = instant0.toString(dateTimeFormatter2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "1/5/01 8:00 AM", "2019");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        org.joda.time.MonthDay monthDay11 = property8.addToCopy(97);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        boolean boolean14 = property8.equals((java.lang.Object) copticChronology12);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property8.getFieldType();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime0.withDate((int) '4', (int) (short) 10, 6);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime dateTime10 = dateTime7.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime7.withHourOfDay(1);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property14 = dateTime13.era();
        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
        org.joda.time.DateTime dateTime18 = dateTime12.withField(dateTimeFieldType16, (int) (byte) 0);
        boolean boolean19 = dateTime0.isSupported(dateTimeFieldType16);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        org.joda.time.DateTime dateTime21 = dateTime0.plus(readablePeriod20);
        org.joda.time.DateTime.Property property22 = dateTime21.minuteOfDay();
        org.joda.time.DateTime dateTime23 = property22.withMaximumValue();
        java.util.Locale locale24 = null;
        int int25 = property22.getMaximumTextLength(locale24);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.yearOfCentury();
        org.joda.time.DurationField durationField2 = gregorianChronology0.centuries();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = dateTime3.withSecondOfMinute((int) (short) 10);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime dateTime10 = dateTime7.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime12 = dateTime7.withHourOfDay(1);
        org.joda.time.DateTime.Property property13 = dateTime12.weekOfWeekyear();
        org.joda.time.chrono.CopticChronology copticChronology14 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone15 = copticChronology14.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = gregorianChronology16.getZone();
        org.joda.time.DateTime dateTime18 = dateTime12.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime6.withZoneRetainFields(dateTimeZone17);
        org.joda.time.Chronology chronology20 = gregorianChronology0.withZone(dateTimeZone17);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(copticChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(chronology20);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("era");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"era\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        java.lang.String str2 = julianChronology0.toString();
        java.lang.String str3 = julianChronology0.toString();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        try {
            int[] intArray6 = julianChronology0.get(readablePeriod4, (long) (-97));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[UTC]" + "'", str2.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
//        int int6 = dateTime5.getDayOfWeek();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
//        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) (short) 10);
//        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(0);
//        int int11 = dateTime8.getMillisOfSecond();
//        java.util.Locale locale13 = null;
//        try {
//            java.lang.String str14 = dateTime8.toString("GJChronology[+52:00,cutover=1970-01-01T00:00:00.001Z]", locale13);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str2 = dateTimeZone1.toString();
//        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
//        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
//        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
//        org.joda.time.MonthDay monthDay9 = property8.getMonthDay();
//        int int10 = monthDay9.getMonthOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(monthDay9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.year();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str11 = buddhistChronology10.toString();
        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology10);
        boolean boolean13 = iSOChronology5.equals((java.lang.Object) buddhistChronology10);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(buddhistChronology10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "BuddhistChronology[UTC]" + "'", str11.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DurationField durationField8 = julianChronology0.weekyears();
        java.lang.String str9 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "JulianChronology[UTC]" + "'", str9.equals("JulianChronology[UTC]"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.MutableDateTime mutableDateTime1 = instant0.toMutableDateTime();
        org.joda.time.Instant instant4 = instant0.withDurationAdded((long) 100, 2000);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.Instant instant6 = instant0.plus(readableDuration5);
        org.junit.Assert.assertNotNull(mutableDateTime1);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        org.joda.time.Chronology chronology3 = julianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = julianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readablePeriod5);
//        boolean boolean7 = dateTime6.isAfterNow();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        boolean boolean10 = offsetDateTimeField5.isLeap(104L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField5.getAsText((long) 'a', locale7);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = offsetDateTimeField5.getAsText((int) (byte) -1, locale10);
//        boolean boolean13 = offsetDateTimeField5.isLeap((-124303939199975L));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "239" + "'", str8.equals("239"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-1" + "'", str11.equals("-1"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        java.lang.String str2 = property1.toString();
//        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
//        long long5 = dateTime4.getMillis();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 187200000L + "'", long5 == 187200000L);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours(1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str7 = dateTimeZone6.toString();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone6, (java.lang.Object) (-1.0f));
        org.joda.time.DateTime dateTime10 = dateTime4.withZone(dateTimeZone6);
        java.lang.String str11 = dateTimeZone6.getID();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+52:00" + "'", str11.equals("+52:00"));
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
//        int int9 = offsetDateTimeField5.getOffset();
//        boolean boolean11 = offsetDateTimeField5.isLeap(1560630411317L);
//        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField5.getWrappedField();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str15 = dateTimeZone14.toString();
//        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.era();
//        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology17.getZone();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(1L, dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        java.util.GregorianCalendar gregorianCalendar22 = dateTime20.toGregorianCalendar();
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property25 = dateTime24.era();
//        org.joda.time.DateTime dateTime27 = dateTime24.plusHours((int) (byte) -1);
//        int int28 = dateTime24.getMinuteOfHour();
//        org.joda.time.DateTime dateTime30 = dateTime24.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property32 = dateTime31.era();
//        org.joda.time.DateTime dateTime34 = dateTime31.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime36 = dateTime31.withHourOfDay(1);
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property38 = dateTime37.era();
//        org.joda.time.DateTimeField dateTimeField39 = property38.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
//        org.joda.time.DateTime dateTime42 = dateTime36.withField(dateTimeFieldType40, (int) (byte) 0);
//        boolean boolean43 = dateTime24.isSupported(dateTimeFieldType40);
//        boolean boolean44 = dateTime20.isSupported(dateTimeFieldType40);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField45 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField12, dateTimeFieldType40);
//        long long47 = zeroIsMaxDateTimeField45.roundHalfEven((long) '#');
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+52:00" + "'", str15.equals("+52:00"));
//        org.junit.Assert.assertNotNull(julianChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(gregorianCalendar22);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 0L + "'", long47 == 0L);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        java.lang.Object obj0 = null;
//        org.joda.time.Instant instant1 = new org.joda.time.Instant(obj0);
//        boolean boolean3 = instant1.isAfter((long) 0);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.Instant instant6 = instant1.withDurationAdded(readableDuration4, 19);
//        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) instant1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertNotNull(instant6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 187200000L + "'", long7 == 187200000L);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone14 = fixedDateTimeZone13.toTimeZone();
        long long16 = fixedDateTimeZone13.nextTransition(0L);
        long long18 = dateTimeZone8.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone13, (long) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.chrono.GJChronology gJChronology20 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.Instant instant21 = gJChronology20.getGregorianCutover();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-98L) + "'", long18 == (-98L));
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(gJChronology20);
        org.junit.Assert.assertNotNull(instant21);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.withFields(readablePartial3);
        org.joda.time.DateTime dateTime6 = dateTime0.minusMinutes((int) (short) 10);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = dateTime0.toDateTime(chronology7);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.year();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField4, 10);
//        long long9 = skipDateTimeField6.set((long) 2580, 4);
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.era();
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology11.getZone();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(1L, dateTimeZone13);
//        org.joda.time.LocalDateTime localDateTime15 = null;
//        boolean boolean16 = dateTimeZone13.isLocalDateTimeGap(localDateTime15);
//        org.joda.time.MonthDay monthDay17 = org.joda.time.MonthDay.now(dateTimeZone13);
//        int[] intArray19 = null;
//        try {
//            int[] intArray21 = skipDateTimeField6.addWrapField((org.joda.time.ReadablePartial) monthDay17, 25200, intArray19, 1970);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62009366397420L) + "'", long9 == (-62009366397420L));
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNotNull(monthDay17);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(52, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        java.lang.Class<?> wildcardClass2 = dateTime1.getClass();
        org.joda.time.DateTime dateTime4 = dateTime1.withWeekOfWeekyear(1);
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.era();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        java.lang.String str8 = dateTimeZone7.toString();
        org.joda.time.DateTime dateTime9 = dateTime1.withZone(dateTimeZone7);
        org.joda.time.TimeOfDay timeOfDay10 = dateTime1.toTimeOfDay();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(timeOfDay10);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours(1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str7 = dateTimeZone6.toString();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone6, (java.lang.Object) (-1.0f));
        org.joda.time.DateTime dateTime10 = dateTime4.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfEra((int) (short) 1);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMonths(480);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.era();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
        long long12 = julianChronology6.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField13 = julianChronology6.hours();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology6.millisOfDay();
        try {
            org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime(100, 26, 2000, (-28801), 0, 19, (org.joda.time.Chronology) julianChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28801 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-34L) + "'", long12 == (-34L));
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = gJChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property3 = dateTime2.era();
//        org.joda.time.DateTime dateTime5 = dateTime2.plusHours((int) (byte) -1);
//        int int6 = dateTime2.getDayOfWeek();
//        org.joda.time.DateTime.Property property7 = dateTime2.year();
//        org.joda.time.DateTime dateTime9 = dateTime2.withHourOfDay((int) (byte) 0);
//        int int10 = dateTime9.getMinuteOfDay();
//        org.joda.time.MutableDateTime mutableDateTime11 = dateTime9.toMutableDateTimeISO();
//        int int14 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime11, "--01-05", 28800);
//        java.lang.Class<?> wildcardClass15 = mutableDateTime11.getClass();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28801) + "'", int14 == (-28801));
//        org.junit.Assert.assertNotNull(wildcardClass15);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        int int6 = fixedDateTimeZone4.getStandardOffset((long) 6);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        int int9 = fixedDateTimeZone4.getStandardOffset(187200011L);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 2580);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 2580");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        int int6 = fixedDateTimeZone4.getStandardOffset((long) (short) 10);
        java.util.TimeZone timeZone7 = fixedDateTimeZone4.toTimeZone();
        java.util.TimeZone timeZone8 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeZone8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = buddhistChronology0.eras();
        try {
            long long4 = durationField1.subtract((long) 0, 26);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
//        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
//        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
//        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
//        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.era();
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str46 = dateTimeZone45.toString();
//        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone45, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(dateTimeZone45);
//        org.joda.time.Chronology chronology50 = monthDay49.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray51 = monthDay49.getFields();
//        int int52 = monthDay49.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray53 = monthDay49.getFields();
//        int[] intArray55 = gregorianChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) 84381);
//        int int56 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
//        org.joda.time.DurationField durationField57 = zeroIsMaxDateTimeField37.getLeapDurationField();
//        long long59 = zeroIsMaxDateTimeField37.roundHalfFloor((long) 480);
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
//        org.junit.Assert.assertNotNull(gregorianChronology42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+52:00" + "'", str46.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray51);
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray53);
//        org.junit.Assert.assertNotNull(intArray55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
//        org.junit.Assert.assertNull(durationField57);
//        org.junit.Assert.assertTrue("'" + long59 + "' != '" + (-62105356800000L) + "'", long59 == (-62105356800000L));
//    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.joda.time.Instant instant0 = new org.joda.time.Instant();
//        org.joda.time.Chronology chronology1 = instant0.getChronology();
//        long long2 = instant0.getMillis();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 187200000L + "'", long2 == 187200000L);
//    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.joda.time.DateTimeZone dateTimeZone1 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime(dateTimeZone1);
//        java.lang.Class<?> wildcardClass3 = dateTime2.getClass();
//        org.joda.time.DateTime dateTime5 = dateTime2.plusMonths((int) ' ');
//        org.joda.time.LocalDate localDate6 = dateTime5.toLocalDate();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str9 = dateTimeZone8.toString();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.era();
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology11.getZone();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime(1L, dateTimeZone13);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
//        java.util.GregorianCalendar gregorianCalendar16 = dateTime14.toGregorianCalendar();
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        org.joda.time.DateTime dateTime21 = dateTime18.plusHours((int) (byte) -1);
//        int int22 = dateTime18.getMinuteOfHour();
//        org.joda.time.DateTime dateTime24 = dateTime18.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime dateTime28 = dateTime25.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime30 = dateTime25.withHourOfDay(1);
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property32 = dateTime31.era();
//        org.joda.time.DateTimeField dateTimeField33 = property32.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType34 = property32.getFieldType();
//        org.joda.time.DateTime dateTime36 = dateTime30.withField(dateTimeFieldType34, (int) (byte) 0);
//        boolean boolean37 = dateTime18.isSupported(dateTimeFieldType34);
//        boolean boolean38 = dateTime14.isSupported(dateTimeFieldType34);
//        int int39 = dateTime5.get(dateTimeFieldType34);
//        boolean boolean40 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 28800, (java.lang.Object) dateTime5);
//        org.joda.time.DateTime dateTime42 = dateTime5.plusSeconds((int) (byte) 100);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+52:00" + "'", str9.equals("+52:00"));
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(gregorianCalendar16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeFieldType34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(dateTime42);
//    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str2 = dateTimeZone1.toString();
//        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
//        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
//        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
//        java.lang.String str9 = property8.getName();
//        org.joda.time.MonthDay monthDay11 = property8.addToCopy(97);
//        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
//        boolean boolean14 = property8.equals((java.lang.Object) copticChronology12);
//        int int15 = property8.getMaximumValueOverall();
//        int int16 = property8.getMaximumValue();
//        java.lang.String str17 = property8.getAsString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
//        org.junit.Assert.assertNotNull(monthDay11);
//        org.junit.Assert.assertNotNull(copticChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 12 + "'", int15 == 12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 12 + "'", int16 == 12);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1" + "'", str17.equals("1"));
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        int int6 = fixedDateTimeZone4.getStandardOffset((long) (short) 10);
        try {
            org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.DateTime dateTime2 = dateTime0.minus(readablePeriod1);
//        org.joda.time.DateMidnight dateMidnight3 = dateTime2.toDateMidnight();
//        int int4 = dateTime2.getYear();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1970 + "'", int4 == 1970);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1L, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology12 = dateTime11.getChronology();
        org.joda.time.DateTime dateTime14 = dateTime11.withYearOfCentury((int) (byte) 1);
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology10, (org.joda.time.ReadableDateTime) dateTime14, readableDateTime15);
        try {
            long long24 = limitChronology16.getDateTimeMillis(70, 12, 10800, 70, 1970, 21, 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology16);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        int int13 = cachedDateTimeZone11.getOffset((-34L));
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property15 = dateTime14.era();
        org.joda.time.DateTime dateTime17 = dateTime14.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime19 = dateTime14.withHourOfDay(1);
        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
        boolean boolean21 = cachedDateTimeZone11.equals((java.lang.Object) dateTime19);
        int int23 = cachedDateTimeZone11.getStandardOffset((long) 19);
        boolean boolean24 = cachedDateTimeZone11.isFixed();
        int int26 = cachedDateTimeZone11.getStandardOffset((long) 12);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readablePeriod5);
//        org.joda.time.DateTime dateTime7 = dateTime0.withEarlierOffsetAtOverlap();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.MonthDay monthDay9 = monthDay5.withPeriodAdded(readablePeriod7, 1);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.MonthDay monthDay12 = monthDay5.withFieldAdded(durationFieldType10, 1439);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(monthDay9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property5 = dateTime4.era();
        org.joda.time.DateTime dateTime7 = dateTime4.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime9 = dateTime4.withHourOfDay(1);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTimeField dateTimeField12 = property11.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property11.getFieldType();
        org.joda.time.DateTime dateTime15 = dateTime9.withField(dateTimeFieldType13, (int) (byte) 0);
        jodaTimePermission3.checkGuard((java.lang.Object) dateTimeFieldType13);
        boolean boolean17 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.Object obj18 = null;
        jodaTimePermission1.checkGuard(obj18);
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime22 = dateTime20.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.DateTime dateTime24 = dateTime20.withFields(readablePartial23);
        java.util.GregorianCalendar gregorianCalendar25 = dateTime24.toGregorianCalendar();
        org.joda.time.LocalDate localDate26 = dateTime24.toLocalDate();
        boolean boolean27 = jodaTimePermission1.equals((java.lang.Object) localDate26);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(gregorianCalendar25);
        org.junit.Assert.assertNotNull(localDate26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime2 = property1.withMaximumValue();
        org.joda.time.DateTimeField dateTimeField3 = property1.getField();
        java.util.Locale locale4 = null;
        java.lang.String str5 = property1.getAsShortText(locale4);
        int int6 = property1.getLeapAmount();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AD" + "'", str5.equals("AD"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(0);
        org.joda.time.DateTime dateTime12 = dateTime8.minusHours(10800);
        int int13 = dateTime8.getEra();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime0.withDate((int) '4', (int) (short) 10, 6);
        org.joda.time.DateTime.Property property7 = dateTime0.centuryOfEra();
        org.joda.time.DateTime dateTime9 = dateTime0.minus(9223372036854775807L);
        boolean boolean10 = dateTime9.isEqualNow();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear(6);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("Jun", false);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder0.setFixedSavings("UTC", 1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.DateTime dateTime7 = dateTime3.withCenturyOfEra((int) (byte) 0);
        org.joda.time.DateTime.Property property8 = dateTime3.dayOfWeek();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        java.lang.String str1 = buddhistChronology0.toString();
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((org.joda.time.Chronology) buddhistChronology0);
        org.joda.time.MonthDay.Property property3 = monthDay2.monthOfYear();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "BuddhistChronology[UTC]" + "'", str1.equals("BuddhistChronology[UTC]"));
        org.junit.Assert.assertNotNull(property3);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str2 = dateTimeZone1.toString();
//        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
//        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
//        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
//        java.lang.String str9 = property8.getName();
//        int int10 = property8.getMinimumValueOverall();
//        java.util.Locale locale11 = null;
//        int int12 = property8.getMaximumTextLength(locale11);
//        java.util.Locale locale13 = null;
//        int int14 = property8.getMaximumTextLength(locale13);
//        java.lang.String str15 = property8.getAsString();
//        org.joda.time.DateTimeField dateTimeField16 = property8.getField();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 9 + "'", int12 == 9);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 9 + "'", int14 == 9);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
//        java.lang.String str5 = skipUndoDateTimeField4.toString();
//        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str10 = dateTimeZone9.toString();
//        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
//        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField4.getAsText((long) (byte) 100, locale16);
//        boolean boolean18 = skipUndoDateTimeField4.isSupported();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.era();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str23 = dateTimeZone22.toString();
//        boolean boolean25 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone22, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(dateTimeZone22);
//        org.joda.time.Chronology chronology27 = monthDay26.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray28 = monthDay26.getFields();
//        int int29 = monthDay26.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray30 = monthDay26.getFields();
//        int[] intArray32 = gregorianChronology19.get((org.joda.time.ReadablePartial) monthDay26, (long) 84381);
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str36 = dateTimeZone35.toString();
//        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone35, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(dateTimeZone35);
//        org.joda.time.Chronology chronology40 = monthDay39.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray41 = monthDay39.getFields();
//        int int42 = monthDay39.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray43 = monthDay39.getFields();
//        int[] intArray45 = iSOChronology33.get((org.joda.time.ReadablePartial) monthDay39, (long) (short) 1);
//        int int46 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay26, intArray45);
//        java.lang.String str48 = skipUndoDateTimeField4.getAsText((-124273871999996L));
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AD" + "'", str17.equals("AD"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+52:00" + "'", str23.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+52:00" + "'", str36.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray43);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "BC" + "'", str48.equals("BC"));
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str2 = dateTimeZone1.toString();
//        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
//        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
//        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
//        java.lang.String str9 = property8.toString();
//        java.util.Locale locale10 = null;
//        int int11 = property8.getMaximumTextLength(locale10);
//        java.lang.String str12 = property8.getAsShortText();
//        java.lang.String str13 = property8.getAsString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[monthOfYear]" + "'", str9.equals("Property[monthOfYear]"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 9 + "'", int11 == 9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Jan" + "'", str12.equals("Jan"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1" + "'", str13.equals("1"));
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone14 = fixedDateTimeZone13.toTimeZone();
        long long16 = fixedDateTimeZone13.nextTransition(0L);
        long long18 = dateTimeZone8.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone13, (long) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology19 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        java.lang.String str22 = dateTimeZone20.getName((long) '#');
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-98L) + "'", long18 == (-98L));
        org.junit.Assert.assertNotNull(buddhistChronology19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+00:00:00.097" + "'", str22.equals("+00:00:00.097"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-14279900L));
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
//        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(1L, dateTimeZone3);
//        org.joda.time.DateTime.Property property5 = dateTime4.yearOfCentury();
//        java.util.GregorianCalendar gregorianCalendar6 = dateTime4.toGregorianCalendar();
//        org.joda.time.MonthDay monthDay7 = org.joda.time.MonthDay.fromCalendarFields((java.util.Calendar) gregorianCalendar6);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        int int12 = dateTime8.getMinuteOfHour();
//        org.joda.time.DateTime dateTime14 = dateTime8.minusMonths((int) (byte) 0);
//        org.joda.time.MutableDateTime mutableDateTime15 = dateTime8.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime8.withPeriodAdded(readablePeriod16, 10);
//        int int19 = dateTime8.getSecondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology20 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology20.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21);
//        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology22.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, (int) (short) -1);
//        long long27 = offsetDateTimeField25.roundFloor(187200011L);
//        int int28 = offsetDateTimeField25.getMaximumValue();
//        org.joda.time.JodaTimePermission jodaTimePermission30 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property32 = dateTime31.era();
//        org.joda.time.DateTime dateTime34 = dateTime31.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime36 = dateTime31.withHourOfDay(1);
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property38 = dateTime37.era();
//        org.joda.time.DateTimeField dateTimeField39 = property38.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property38.getFieldType();
//        org.joda.time.DateTime dateTime42 = dateTime36.withField(dateTimeFieldType40, (int) (byte) 0);
//        jodaTimePermission30.checkGuard((java.lang.Object) dateTimeFieldType40);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField25, dateTimeFieldType40, 2);
//        int int46 = dateTime8.get(dateTimeFieldType40);
//        int int47 = monthDay7.indexOf(dateTimeFieldType40);
//        org.joda.time.DateTimeField[] dateTimeFieldArray48 = monthDay7.getFields();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNotNull(monthDay7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(mutableDateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 120 + "'", int19 == 120);
//        org.junit.Assert.assertNotNull(copticChronology20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(gregorianChronology22);
//        org.junit.Assert.assertNotNull(dateTimeField23);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 187200000L + "'", long27 == 187200000L);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1438 + "'", int28 == 1438);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
//        org.junit.Assert.assertNotNull(dateTimeFieldArray48);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        org.joda.time.MonthDay monthDay7 = monthDay5.minus(readablePeriod6);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(monthDay7);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours(1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str7 = dateTimeZone6.toString();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone6, (java.lang.Object) (-1.0f));
        org.joda.time.DateTime dateTime10 = dateTime4.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfEra((int) (short) 1);
        org.joda.time.DateTime.Property property13 = dateTime10.minuteOfDay();
        org.joda.time.DateTime.Property property14 = dateTime10.monthOfYear();
        org.joda.time.DateTime dateTime16 = property14.addToCopy(1970);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField5.getAsText((long) 'a', locale7);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField5.getMaximumShortTextLength(locale9);
//        int int11 = offsetDateTimeField5.getMaximumValue();
//        org.joda.time.DurationField durationField12 = offsetDateTimeField5.getLeapDurationField();
//        long long14 = offsetDateTimeField5.roundCeiling((-11L));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "239" + "'", str8.equals("239"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1438 + "'", int11 == 1438);
//        org.junit.Assert.assertNull(durationField12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.MonthDay monthDay2 = new org.joda.time.MonthDay((int) (short) 10, 12);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.MonthDay monthDay5 = monthDay2.withPeriodAdded(readablePeriod3, 480);
        org.joda.time.MonthDay.Property property6 = monthDay5.dayOfMonth();
        org.junit.Assert.assertNotNull(monthDay5);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("JulianChronology[UTC]", 35);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.era();
        org.joda.time.DateTime dateTime6 = dateTime3.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime8 = dateTime3.withHourOfDay(1);
        org.joda.time.DateTime.Property property9 = dateTime8.weekOfWeekyear();
        org.joda.time.chrono.CopticChronology copticChronology10 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone11 = copticChronology10.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology12.getZone();
        org.joda.time.DateTime dateTime14 = dateTime8.toDateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime2.withZone(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(copticChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.millisOfDay();
        boolean boolean10 = julianChronology0.equals((java.lang.Object) 4);
        org.joda.time.DateTimeField dateTimeField11 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField12 = julianChronology0.eras();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField14 = new org.joda.time.field.DecoratedDurationField(durationField12, durationFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.era();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
        org.joda.time.DurationField durationField5 = julianChronology2.hours();
        org.joda.time.DateTime dateTime6 = dateTime0.toDateTime((org.joda.time.Chronology) julianChronology2);
        int int7 = dateTime6.getMillisOfSecond();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(104L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str3 = dateTimeZone2.toString();
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTimeZone2.getName((long) (byte) -1, locale5);
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology7.getZone();
        org.joda.time.Chronology chronology9 = julianChronology0.withZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "+52:00" + "'", str3.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+52:00" + "'", str6.equals("+52:00"));
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime.Property property7 = dateTime0.era();
//        org.joda.time.DateTime dateTime9 = dateTime0.minusYears(26);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str15 = dateTimeZone14.toString();
        org.joda.time.chrono.JulianChronology julianChronology17 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField18 = julianChronology17.era();
        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology17.getZone();
        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime(1L, dateTimeZone19);
        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar22 = dateTime20.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14, (org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTimeZone dateTimeZone24 = gJChronology23.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone29 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        int int31 = fixedDateTimeZone29.getStandardOffset((long) 6);
        boolean boolean32 = fixedDateTimeZone29.isFixed();
        org.joda.time.Chronology chronology33 = gJChronology23.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone29);
        long long35 = dateTimeZone8.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone29, (long) 2019);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+52:00" + "'", str15.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(gregorianCalendar22);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 35 + "'", int31 == 35);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1922L + "'", long35 == 1922L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
        int int20 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.era();
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str46 = dateTimeZone45.toString();
        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone45, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(dateTimeZone45);
        org.joda.time.Chronology chronology50 = monthDay49.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray51 = monthDay49.getFields();
        int int52 = monthDay49.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray53 = monthDay49.getFields();
        int[] intArray55 = gregorianChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) 84381);
        int int56 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
        org.joda.time.DurationField durationField57 = zeroIsMaxDateTimeField37.getLeapDurationField();
        org.joda.time.chrono.JulianChronology julianChronology59 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField60 = julianChronology59.era();
        org.joda.time.DateTimeZone dateTimeZone61 = julianChronology59.getZone();
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime(1L, dateTimeZone61);
        org.joda.time.LocalDateTime localDateTime63 = null;
        boolean boolean64 = dateTimeZone61.isLocalDateTimeGap(localDateTime63);
        org.joda.time.MonthDay monthDay65 = org.joda.time.MonthDay.now(dateTimeZone61);
        int int66 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay65);
        java.util.Locale locale67 = null;
        int int68 = zeroIsMaxDateTimeField37.getMaximumTextLength(locale67);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+52:00" + "'", str46.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTimeFieldArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNull(durationField57);
        org.junit.Assert.assertNotNull(julianChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(monthDay65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        int int4 = dateTime0.getMinuteOfHour();
        org.joda.time.DateTime dateTime7 = dateTime0.withDurationAdded((long) 6, (int) (byte) 1);
        org.joda.time.DateTime.Property property8 = dateTime0.weekOfWeekyear();
        int int9 = property8.get();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, (long) (-28801));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test183");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
//        long long11 = offsetDateTimeField5.add((long) (byte) 0, 0L);
//        java.util.Locale locale12 = null;
//        int int13 = offsetDateTimeField5.getMaximumTextLength(locale12);
//        org.joda.time.DurationField durationField14 = offsetDateTimeField5.getRangeDurationField();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property16 = dateTime15.era();
//        org.joda.time.DateTime dateTime18 = dateTime15.plusHours((int) (byte) -1);
//        int int19 = dateTime15.getDayOfWeek();
//        org.joda.time.LocalDateTime localDateTime20 = dateTime15.toLocalDateTime();
//        int int21 = offsetDateTimeField5.getMinimumValue((org.joda.time.ReadablePartial) localDateTime20);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(localDateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
        org.joda.time.Chronology chronology1 = instant0.getChronology();
        org.joda.time.Instant instant3 = instant0.minus(1560630371636L);
        org.joda.time.Instant instant5 = instant3.plus(0L);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant3.plus(readableDuration6);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        long long9 = skipUndoDateTimeField4.roundHalfCeiling((long) 'a');
        java.util.Locale locale12 = null;
        try {
            long long13 = skipUndoDateTimeField4.set(0L, "", locale12);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62105356800000L) + "'", long9 == (-62105356800000L));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.MutableDateTime mutableDateTime3 = dateTime2.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime6 = dateTime4.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.plusHours(1);
        int int9 = mutableDateTime3.compareTo((org.joda.time.ReadableInstant) dateTime6);
        int int10 = dateTime6.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(mutableDateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.millisOfDay();
        boolean boolean10 = julianChronology0.equals((java.lang.Object) 4);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str13 = dateTimeZone12.toString();
        org.joda.time.Chronology chronology14 = julianChronology0.withZone(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField15 = julianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime dateTime3 = dateTime0.withYearOfCentury((int) (byte) 1);
        java.util.Locale locale4 = null;
        java.util.Calendar calendar5 = dateTime0.toCalendar(locale4);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(calendar5);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.joda.time.DateTimeZone dateTimeZone0 = null;
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
//        java.lang.Class<?> wildcardClass2 = dateTime1.getClass();
//        org.joda.time.DateTime dateTime4 = dateTime1.withWeekOfWeekyear(1);
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
//        int int7 = dateTime6.getMonthOfYear();
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        int int1 = copticChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = copticChronology0.millisOfDay();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        try {
            org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((java.lang.Object) copticChronology0, (org.joda.time.Chronology) iSOChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.CopticChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(iSOChronology3);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property2 = dateTime1.era();
//        org.joda.time.DateTime dateTime4 = dateTime1.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.Chronology chronology8 = dateTime7.getChronology();
//        org.joda.time.DateTime.Property property9 = dateTime7.yearOfCentury();
//        int int10 = property9.getMaximumValueOverall();
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = property9.getFieldType();
//        int int12 = dateTime6.get(dateTimeFieldType11);
//        boolean boolean13 = dateTime0.isSupported(dateTimeFieldType11);
//        org.joda.time.DateTime dateTime15 = dateTime0.minusDays(25);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 99 + "'", int10 == 99);
//        org.junit.Assert.assertNotNull(dateTimeFieldType11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 70 + "'", int12 == 70);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime2 = property1.withMaximumValue();
//        org.joda.time.DateTime dateTime3 = property1.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime5 = dateTime3.plus((-62105356800000L));
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime(dateTimeZone6);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfMonth();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.DateTime dateTime9 = dateTime5.withDurationAdded((long) (short) 100, 84381);
        org.joda.time.DateTime.Property property10 = dateTime5.yearOfCentury();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str2 = dateTimeZone1.toString();
//        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
//        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
//        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property10 = dateTime9.era();
//        org.joda.time.DateTime dateTime12 = dateTime9.plusHours((int) (byte) -1);
//        int int13 = dateTime9.getDayOfWeek();
//        boolean boolean14 = property8.equals((java.lang.Object) int13);
//        int int15 = property8.getMinimumValueOverall();
//        java.lang.String str16 = property8.getAsString();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        org.joda.time.Chronology chronology18 = dateTime17.getChronology();
//        org.joda.time.DateTime.Property property19 = dateTime17.yearOfCentury();
//        int int20 = property19.getMaximumValueOverall();
//        boolean boolean21 = property8.equals((java.lang.Object) int20);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(chronology6);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "1" + "'", str16.equals("1"));
//        org.junit.Assert.assertNotNull(chronology18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 99 + "'", int20 == 99);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(0);
        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfSecond(26);
        org.joda.time.DateTime.Property property13 = dateTime12.dayOfMonth();
        int int14 = dateTime12.getMinuteOfDay();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 60 + "'", int14 == 60);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(9, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        org.joda.time.DateTime dateTime5 = property1.withMaximumValue();
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add(26L, 0L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 26L + "'", long8 == 26L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.LocalDate localDate8 = monthDay5.toLocalDate(1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(localDate8);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        long long4 = gregorianChronology0.add(11L, (-1L), 10);
        org.joda.time.DurationField durationField5 = gregorianChronology0.halfdays();
        long long8 = durationField5.subtract((long) 35, (long) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 35L + "'", long8 == 35L);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
//        org.joda.time.DateTime dateTime6 = dateTime0.withDate((int) '4', (int) (short) 10, 6);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property8 = dateTime7.era();
//        org.joda.time.DateTime dateTime10 = dateTime7.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime12 = dateTime7.withHourOfDay(1);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property14 = dateTime13.era();
//        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property14.getFieldType();
//        org.joda.time.DateTime dateTime18 = dateTime12.withField(dateTimeFieldType16, (int) (byte) 0);
//        boolean boolean19 = dateTime0.isSupported(dateTimeFieldType16);
//        int int20 = dateTime0.getMonthOfYear();
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.millisOfSecond();
        java.util.Locale locale8 = null;
        java.lang.String str9 = property7.getAsShortText(locale8);
        org.joda.time.DateTime dateTime10 = property7.roundHalfCeilingCopy();
        int int11 = property7.getMinimumValue();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "104" + "'", str9.equals("104"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long7 = offsetDateTimeField5.roundFloor(187200011L);
        int int8 = offsetDateTimeField5.getMaximumValue();
        java.util.Locale locale9 = null;
        int int10 = offsetDateTimeField5.getMaximumTextLength(locale9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField5.getAsText(0, locale12);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 187200000L + "'", long7 == 187200000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1438 + "'", int8 == 1438);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = julianChronology0.days();
        org.joda.time.DurationField durationField4 = julianChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.Object obj7 = null;
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.era();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        long long14 = julianChronology8.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField15 = julianChronology8.hours();
        org.joda.time.DateTimeZone dateTimeZone16 = julianChronology8.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone22 = fixedDateTimeZone21.toTimeZone();
        long long24 = fixedDateTimeZone21.nextTransition(0L);
        long long26 = dateTimeZone16.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone21, (long) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology27 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        int int29 = fixedDateTimeZone21.getOffset(24L);
        long long31 = fixedDateTimeZone21.previousTransition(12L);
        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime(obj7, (org.joda.time.DateTimeZone) fixedDateTimeZone21);
        try {
            org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime(99, 2, (-97), (int) (byte) 0, (int) (byte) 100, 4, 2, (org.joda.time.DateTimeZone) fixedDateTimeZone21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-34L) + "'", long14 == (-34L));
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-98L) + "'", long26 == (-98L));
        org.junit.Assert.assertNotNull(buddhistChronology27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 97 + "'", int29 == 97);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 12L + "'", long31 == 12L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.util.Locale locale2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withLocale(locale2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(59, 2580);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 2580");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        int int3 = property2.getMaximumValueOverall();
        boolean boolean4 = property2.isLeap();
        try {
            org.joda.time.DateTime dateTime6 = property2.setCopy("org.joda.time.IllegalFieldValueException: : Value 1 for Property[era] must be in the range [1.0,10]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: : Value 1 for Property[era] must be in the range [1.0,10]\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 99 + "'", int3 == 99);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        int int6 = fixedDateTimeZone4.getStandardOffset((long) 6);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        int int9 = fixedDateTimeZone4.getStandardOffset(187200011L);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal(28800L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str17 = dateTimeZone16.toString();
        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone16, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.Chronology chronology21 = monthDay20.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray22 = monthDay20.getFields();
        org.joda.time.MonthDay.Property property23 = monthDay20.monthOfYear();
        java.lang.String str24 = property23.getName();
        org.joda.time.MonthDay monthDay26 = property23.addToCopy(97);
        java.util.Locale locale27 = null;
        java.lang.String str28 = property23.getAsText(locale27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property23.getFieldType();
        boolean boolean30 = monthDay13.isSupported(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+52:00" + "'", str17.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeFieldArray22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "monthOfYear" + "'", str24.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(monthDay26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "January" + "'", str28.equals("January"));
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(10);
        int int5 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfYear(26);
        org.joda.time.DateMidnight dateMidnight8 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime10 = dateTime4.minusWeeks((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime4.withChronology((org.joda.time.Chronology) gregorianChronology12);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded(readableDuration14, 9);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        int int13 = cachedDateTimeZone11.getOffset((-34L));
        boolean boolean14 = cachedDateTimeZone11.isFixed();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime17 = dateTime15.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime19 = dateTime15.plusYears(10);
        int int20 = dateTime19.getWeekOfWeekyear();
        org.joda.time.DateTime.Property property21 = dateTime19.yearOfCentury();
        boolean boolean22 = cachedDateTimeZone11.equals((java.lang.Object) dateTime19);
        java.lang.Object obj23 = null;
        boolean boolean24 = cachedDateTimeZone11.equals(obj23);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((long) 1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property2.getFieldType();
        org.joda.time.chrono.JulianChronology julianChronology5 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField6 = julianChronology5.era();
        org.joda.time.DateTimeZone dateTimeZone7 = julianChronology5.getZone();
        long long11 = julianChronology5.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField12 = julianChronology5.hours();
        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology5.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone19 = fixedDateTimeZone18.toTimeZone();
        long long21 = fixedDateTimeZone18.nextTransition(0L);
        long long23 = dateTimeZone13.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone18, (long) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology24 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        boolean boolean26 = property2.equals((java.lang.Object) fixedDateTimeZone18);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 99 + "'", int3 == 99);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(julianChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-34L) + "'", long11 == (-34L));
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-98L) + "'", long23 == (-98L));
        org.junit.Assert.assertNotNull(buddhistChronology24);
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test215");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime4 = dateTime2.minusWeeks((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime4.toMutableDateTimeISO();
//        java.lang.String str6 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str9 = dateTimeZone8.toString();
//        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone8, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay12 = new org.joda.time.MonthDay(dateTimeZone8);
//        org.joda.time.Chronology chronology13 = monthDay12.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray14 = monthDay12.getFields();
//        int int15 = monthDay12.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray16 = monthDay12.getFields();
//        java.lang.String str17 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) monthDay12);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.MonthDay monthDay20 = monthDay12.withPeriodAdded(readablePeriod18, 1615);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNull(chronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "040000.104+5200" + "'", str6.equals("040000.104+5200"));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+52:00" + "'", str9.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "������.000" + "'", str17.equals("������.000"));
//        org.junit.Assert.assertNotNull(monthDay20);
//    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
//        java.lang.String str5 = skipUndoDateTimeField4.toString();
//        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str10 = dateTimeZone9.toString();
//        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
//        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = skipUndoDateTimeField4.getAsText((long) (byte) 100, locale16);
//        boolean boolean18 = skipUndoDateTimeField4.isSupported();
//        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.era();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str23 = dateTimeZone22.toString();
//        boolean boolean25 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone22, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(dateTimeZone22);
//        org.joda.time.Chronology chronology27 = monthDay26.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray28 = monthDay26.getFields();
//        int int29 = monthDay26.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray30 = monthDay26.getFields();
//        int[] intArray32 = gregorianChronology19.get((org.joda.time.ReadablePartial) monthDay26, (long) 84381);
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str36 = dateTimeZone35.toString();
//        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone35, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(dateTimeZone35);
//        org.joda.time.Chronology chronology40 = monthDay39.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray41 = monthDay39.getFields();
//        int int42 = monthDay39.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray43 = monthDay39.getFields();
//        int[] intArray45 = iSOChronology33.get((org.joda.time.ReadablePartial) monthDay39, (long) (short) 1);
//        int int46 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay26, intArray45);
//        org.joda.time.DateTime dateTime47 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property48 = dateTime47.era();
//        org.joda.time.DateTime dateTime50 = dateTime47.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration51 = null;
//        org.joda.time.DateTime dateTime52 = dateTime50.minus(readableDuration51);
//        org.joda.time.DateTime dateTime53 = new org.joda.time.DateTime();
//        org.joda.time.Chronology chronology54 = dateTime53.getChronology();
//        org.joda.time.DateTime.Property property55 = dateTime53.yearOfCentury();
//        int int56 = property55.getMaximumValueOverall();
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property55.getFieldType();
//        int int58 = dateTime52.get(dateTimeFieldType57);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField60 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField4, dateTimeFieldType57, 70);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AD" + "'", str17.equals("AD"));
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(gregorianChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+52:00" + "'", str23.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(chronology27);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray30);
//        org.junit.Assert.assertNotNull(intArray32);
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+52:00" + "'", str36.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray43);
//        org.junit.Assert.assertNotNull(intArray45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(chronology54);
//        org.junit.Assert.assertNotNull(property55);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 99 + "'", int56 == 99);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 70 + "'", int58 == 70);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        boolean boolean6 = skipUndoDateTimeField4.isLeap(9223372036854775807L);
        long long8 = skipUndoDateTimeField4.roundHalfCeiling(1560626784922L);
        int int9 = skipUndoDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-62105356800000L) + "'", long8 == (-62105356800000L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        boolean boolean6 = skipUndoDateTimeField4.isLeap(9223372036854775807L);
        org.joda.time.DurationField durationField7 = skipUndoDateTimeField4.getDurationField();
        long long9 = skipUndoDateTimeField4.roundFloor((long) 4);
        try {
            long long12 = skipUndoDateTimeField4.add((-187198562L), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62105356800000L) + "'", long9 == (-62105356800000L));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("January");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"January\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str12 = dateTimeZone11.toString();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone11);
        long long15 = dateTimeZone8.getMillisKeepLocal(dateTimeZone11, (-124273871999996L));
        long long19 = dateTimeZone11.convertLocalToUTC(1542417822L, false, (long) (-1));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+52:00" + "'", str12.equals("+52:00"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-124274059199996L) + "'", long15 == (-124274059199996L));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1355217822L + "'", long19 == 1355217822L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DurationField durationField4 = julianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology1.weekOfWeekyear();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(obj0, (org.joda.time.Chronology) julianChronology1);
        try {
            org.joda.time.MonthDay monthDay8 = monthDay6.withDayOfMonth((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str4 = dateTimeZone3.toString();
//        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone3, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(dateTimeZone3);
//        org.joda.time.Chronology chronology8 = monthDay7.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray9 = monthDay7.getFields();
//        int int10 = monthDay7.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray11 = monthDay7.getFields();
//        int[] intArray13 = gregorianChronology0.get((org.joda.time.ReadablePartial) monthDay7, (long) 84381);
//        org.joda.time.ReadablePeriod readablePeriod14 = null;
//        org.joda.time.MonthDay monthDay15 = monthDay7.minus(readablePeriod14);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.MutableDateTime mutableDateTime23 = dateTime16.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime26 = dateTime16.withPeriodAdded(readablePeriod24, 10);
//        int int27 = dateTime16.getSecondOfDay();
//        org.joda.time.chrono.CopticChronology copticChronology28 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone29 = copticChronology28.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) (short) -1);
//        long long35 = offsetDateTimeField33.roundFloor(187200011L);
//        int int36 = offsetDateTimeField33.getMaximumValue();
//        org.joda.time.JodaTimePermission jodaTimePermission38 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property40 = dateTime39.era();
//        org.joda.time.DateTime dateTime42 = dateTime39.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime44 = dateTime39.withHourOfDay(1);
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property46 = dateTime45.era();
//        org.joda.time.DateTimeField dateTimeField47 = property46.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType48 = property46.getFieldType();
//        org.joda.time.DateTime dateTime50 = dateTime44.withField(dateTimeFieldType48, (int) (byte) 0);
//        jodaTimePermission38.checkGuard((java.lang.Object) dateTimeFieldType48);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField33, dateTimeFieldType48, 2);
//        int int54 = dateTime16.get(dateTimeFieldType48);
//        try {
//            org.joda.time.MonthDay monthDay56 = monthDay7.withField(dateTimeFieldType48, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+52:00" + "'", str4.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray11);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertNotNull(monthDay15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(mutableDateTime23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 14400 + "'", int27 == 14400);
//        org.junit.Assert.assertNotNull(copticChronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(gregorianChronology30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 187200000L + "'", long35 == 187200000L);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1438 + "'", int36 == 1438);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertNotNull(dateTimeFieldType48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-124303939199975L), (long) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.millisOfDay();
        boolean boolean10 = julianChronology0.equals((java.lang.Object) 4);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str13 = dateTimeZone12.toString();
        org.joda.time.Chronology chronology14 = julianChronology0.withZone(dateTimeZone12);
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone12);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(julianChronology15);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int6 = skipUndoDateTimeField4.getMinimumValue();
        try {
            int int9 = skipUndoDateTimeField4.getDifference(0L, 1560626816923L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.joda.time.Chronology chronology2 = dateTimeFormatter0.getChronolgy();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withPivotYear(26);
        org.joda.time.Chronology chronology6 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNull(chronology6);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        long long7 = offsetDateTimeField5.roundFloor(187200011L);
//        int int8 = offsetDateTimeField5.getMaximumValue();
//        org.joda.time.JodaTimePermission jodaTimePermission10 = new org.joda.time.JodaTimePermission("hi!");
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property12 = dateTime11.era();
//        org.joda.time.DateTime dateTime14 = dateTime11.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime16 = dateTime11.withHourOfDay(1);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property18 = dateTime17.era();
//        org.joda.time.DateTimeField dateTimeField19 = property18.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
//        org.joda.time.DateTime dateTime22 = dateTime16.withField(dateTimeFieldType20, (int) (byte) 0);
//        jodaTimePermission10.checkGuard((java.lang.Object) dateTimeFieldType20);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType20, 2);
//        long long27 = offsetDateTimeField5.roundHalfFloor(0L);
//        int int29 = offsetDateTimeField5.get((long) 2000);
//        boolean boolean30 = offsetDateTimeField5.isLenient();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 187200000L + "'", long7 == 187200000L);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1438 + "'", int8 == 1438);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 239 + "'", int29 == 239);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        long long6 = skipUndoDateTimeField4.roundCeiling(100L);
        int int7 = skipUndoDateTimeField4.getMinimumValue();
        java.util.Locale locale9 = null;
        try {
            java.lang.String str10 = skipUndoDateTimeField4.getAsText((int) 'a', locale9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 9223372036854775807L + "'", long6 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(10);
        int int5 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime7 = dateTime4.withYearOfCentury((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(0L, 2);
        org.joda.time.DateTime.Property property11 = dateTime7.hourOfDay();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "Jun", "1/1/70 12:00 AM");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.withFields(readablePartial3);
        java.util.GregorianCalendar gregorianCalendar5 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime8 = dateTime4.withMillis((long) 10);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.withPeriodAdded(readablePeriod9, 97);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gregorianCalendar5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology7 = iSOChronology6.withUTC();
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = copticChronology8.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) (short) -1);
        long long16 = offsetDateTimeField13.add((-1640822399990L), 97);
        int int18 = offsetDateTimeField13.getLeapAmount(100L);
        long long20 = offsetDateTimeField13.roundHalfFloor(11L);
        int int21 = offsetDateTimeField13.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField23 = new org.joda.time.field.SkipDateTimeField(chronology7, (org.joda.time.DateTimeField) offsetDateTimeField13, 1);
        try {
            org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((-26010446), 6, (int) (byte) 0, 0, 25, (int) (short) 10, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1640816579990L) + "'", long16 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.joda.time.Chronology chronology1 = gJChronology0.withUTC();
        org.joda.time.Instant instant2 = gJChronology0.getGregorianCutover();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.CopticChronology copticChronology1 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone0);
        try {
            long long6 = copticChronology1.getDateTimeMillis(0, 59, (int) (short) 100, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime0.withDate((int) '4', (int) (short) 10, 6);
        org.joda.time.DateTime dateTime8 = dateTime6.plusYears(97);
        org.joda.time.DateTime dateTime10 = dateTime8.plusDays((int) (short) 0);
        org.joda.time.DateTime dateTime11 = dateTime10.toDateTime();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField5.getAsText((long) 'a', locale7);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField5.getMaximumShortTextLength(locale9);
//        int int13 = offsetDateTimeField5.getDifference((long) 2000, 1560626784922L);
//        java.lang.String str14 = offsetDateTimeField5.getName();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "239" + "'", str8.equals("239"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-26010446) + "'", int13 == (-26010446));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "minuteOfDay" + "'", str14.equals("minuteOfDay"));
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        java.lang.String str3 = dateTimeZone2.toString();
        java.lang.String str4 = dateTimeZone2.toString();
        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        int int9 = offsetDateTimeField5.getOffset();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField12, 2000);
        java.lang.String str15 = skipUndoDateTimeField14.toString();
        int int17 = skipUndoDateTimeField14.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str20 = dateTimeZone19.toString();
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone19, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone19);
        int int24 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str27 = dateTimeZone26.toString();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone26, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay32 = monthDay30.plus(readablePeriod31);
        org.joda.time.MonthDay monthDay34 = monthDay32.minusDays((int) (byte) 0);
        int[] intArray40 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int41 = skipUndoDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        int int42 = skipUndoDateTimeField14.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = skipUndoDateTimeField14.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField44 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[era]" + "'", str15.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+52:00" + "'", str20.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+52:00" + "'", str27.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType43);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(dateTimeZone0);
        java.lang.Class<?> wildcardClass2 = dateTime1.getClass();
        boolean boolean4 = dateTime1.isAfter(0L);
        org.joda.time.DateTime.Property property5 = dateTime1.secondOfMinute();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        int int6 = fixedDateTimeZone4.getStandardOffset((long) 6);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        int int9 = fixedDateTimeZone4.getStandardOffset(187200011L);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal(31449600000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 97 + "'", int11 == 97);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        int int4 = dateTime0.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime0.minusMonths((int) (byte) 0);
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime0.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        org.joda.time.DateTime dateTime10 = dateTime0.withPeriodAdded(readablePeriod8, 10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str13 = dateTimeZone12.toString();
        org.joda.time.chrono.JulianChronology julianChronology15 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField16 = julianChronology15.era();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology15.getZone();
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime(1L, dateTimeZone17);
        org.joda.time.DateTime.Property property19 = dateTime18.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar20 = dateTime18.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) dateTime18);
        boolean boolean22 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime.Property property23 = dateTime0.millisOfSecond();
        int int24 = property23.get();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(gregorianCalendar20);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 104 + "'", int24 == 104);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Property[era]", (java.lang.Number) (byte) 1, (java.lang.Number) 1.0f, (java.lang.Number) (byte) 10);
        illegalFieldValueException4.prependMessage("");
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.String str8 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value 1 for Property[era] must be in the range [1.0,10]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: : Value 1 for Property[era] must be in the range [1.0,10]"));
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.weekOfWeekyear();
        org.joda.time.DurationField durationField3 = julianChronology0.days();
        org.joda.time.DurationField durationField4 = julianChronology0.halfdays();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 60, (long) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 120 + "'", int2 == 120);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField4.getAsText((long) (byte) 100, locale16);
        boolean boolean18 = skipUndoDateTimeField4.isSupported();
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology19.era();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str23 = dateTimeZone22.toString();
        boolean boolean25 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone22, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay26 = new org.joda.time.MonthDay(dateTimeZone22);
        org.joda.time.Chronology chronology27 = monthDay26.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray28 = monthDay26.getFields();
        int int29 = monthDay26.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray30 = monthDay26.getFields();
        int[] intArray32 = gregorianChronology19.get((org.joda.time.ReadablePartial) monthDay26, (long) 84381);
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str36 = dateTimeZone35.toString();
        boolean boolean38 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone35, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay39 = new org.joda.time.MonthDay(dateTimeZone35);
        org.joda.time.Chronology chronology40 = monthDay39.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray41 = monthDay39.getFields();
        int int42 = monthDay39.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray43 = monthDay39.getFields();
        int[] intArray45 = iSOChronology33.get((org.joda.time.ReadablePartial) monthDay39, (long) (short) 1);
        int int46 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay26, intArray45);
        org.joda.time.MonthDay monthDay47 = org.joda.time.MonthDay.now();
        int[] intArray49 = new int[] {};
        try {
            int[] intArray51 = skipUndoDateTimeField4.set((org.joda.time.ReadablePartial) monthDay47, 25, intArray49, 32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AD" + "'", str17.equals("AD"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "+52:00" + "'", str23.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeFieldArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "+52:00" + "'", str36.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTimeFieldArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray43);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(intArray49);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime6 = dateTime0.withDate((int) '4', (int) (short) 10, 6);
        try {
            org.joda.time.DateTime dateTime8 = dateTime0.withYearOfCentury(28800);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28800 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1L, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology10.getZone();
        int int12 = gJChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField13 = gJChronology10.months();
        int int14 = gJChronology10.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("", 0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
//        int int10 = offsetDateTimeField5.getLeapAmount(100L);
//        java.lang.String str12 = offsetDateTimeField5.getAsShortText((long) 0);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, (int) (byte) 100);
//        int int16 = offsetDateTimeField5.getMaximumValue((long) 97);
//        int int17 = offsetDateTimeField5.getMaximumValue();
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "239" + "'", str12.equals("239"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1438 + "'", int16 == 1438);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1438 + "'", int17 == 1438);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.year();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.halfdayOfDay();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField12, 2000);
        java.lang.String str15 = skipUndoDateTimeField14.toString();
        int int17 = skipUndoDateTimeField14.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str20 = dateTimeZone19.toString();
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone19, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone19);
        int int24 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str27 = dateTimeZone26.toString();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone26, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay32 = monthDay30.plus(readablePeriod31);
        org.joda.time.MonthDay monthDay34 = monthDay32.minusDays((int) (byte) 0);
        int[] intArray40 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int41 = skipUndoDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType42, 1438, (int) (short) 100, (int) '4');
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType42, (int) (byte) 1, 9, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for era must be in the range [9,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[era]" + "'", str15.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+52:00" + "'", str20.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+52:00" + "'", str27.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 0);
        org.joda.time.ReadableDuration readableDuration2 = null;
        org.joda.time.Instant instant3 = instant1.plus(readableDuration2);
        org.joda.time.Instant instant5 = instant1.minus((long) (byte) 1);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.minuteOfHour();
        org.joda.time.chrono.JulianChronology julianChronology2 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField3 = julianChronology2.era();
        org.joda.time.DateTimeZone dateTimeZone4 = julianChronology2.getZone();
        long long8 = julianChronology2.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField9 = julianChronology2.hours();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology2.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone16 = fixedDateTimeZone15.toTimeZone();
        long long18 = fixedDateTimeZone15.nextTransition(0L);
        long long20 = dateTimeZone10.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, (long) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology21 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        int int23 = fixedDateTimeZone15.getOffset(24L);
        long long25 = fixedDateTimeZone15.previousTransition(12L);
        org.joda.time.Chronology chronology26 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone15);
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology0.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(julianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-34L) + "'", long8 == (-34L));
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-98L) + "'", long20 == (-98L));
        org.junit.Assert.assertNotNull(buddhistChronology21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 97 + "'", int23 == 97);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 12L + "'", long25 == 12L);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        long long10 = offsetDateTimeField5.roundHalfFloor((long) 1);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str13 = dateTimeZone12.toString();
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone12, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay16 = new org.joda.time.MonthDay(dateTimeZone12);
        org.joda.time.Chronology chronology17 = monthDay16.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray18 = monthDay16.getFields();
        int int19 = monthDay16.getMonthOfYear();
        org.joda.time.MonthDay monthDay21 = monthDay16.withMonthOfYear((int) (short) 1);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology23 = iSOChronology22.withUTC();
        org.joda.time.chrono.CopticChronology copticChronology24 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone25 = copticChronology24.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology26 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology26.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, (int) (short) -1);
        long long32 = offsetDateTimeField29.add((-1640822399990L), 97);
        int int34 = offsetDateTimeField29.getLeapAmount(100L);
        long long36 = offsetDateTimeField29.roundHalfFloor(11L);
        int int37 = offsetDateTimeField29.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField(chronology23, (org.joda.time.DateTimeField) offsetDateTimeField29, 1);
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str42 = dateTimeZone41.toString();
        boolean boolean44 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone41, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay(dateTimeZone41);
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.MonthDay monthDay47 = monthDay45.plus(readablePeriod46);
        org.joda.time.MonthDay monthDay49 = monthDay47.minusDays((int) (byte) 0);
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str52 = dateTimeZone51.toString();
        boolean boolean54 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone51, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay55 = new org.joda.time.MonthDay(dateTimeZone51);
        org.joda.time.Chronology chronology56 = monthDay55.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray57 = monthDay55.getFields();
        org.joda.time.MonthDay.Property property58 = monthDay55.monthOfYear();
        org.joda.time.MonthDay monthDay59 = property58.getMonthDay();
        org.joda.time.MonthDay monthDay60 = property58.getMonthDay();
        boolean boolean61 = monthDay47.isBefore((org.joda.time.ReadablePartial) monthDay60);
        org.joda.time.Chronology chronology62 = null;
        org.joda.time.chrono.JulianChronology julianChronology63 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField64 = julianChronology63.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField66 = new org.joda.time.field.SkipUndoDateTimeField(chronology62, dateTimeField64, 2000);
        java.lang.String str67 = skipUndoDateTimeField66.toString();
        int int69 = skipUndoDateTimeField66.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str72 = dateTimeZone71.toString();
        boolean boolean74 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone71, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay75 = new org.joda.time.MonthDay(dateTimeZone71);
        int int76 = skipUndoDateTimeField66.getMinimumValue((org.joda.time.ReadablePartial) monthDay75);
        org.joda.time.DateTimeZone dateTimeZone78 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str79 = dateTimeZone78.toString();
        boolean boolean81 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone78, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay82 = new org.joda.time.MonthDay(dateTimeZone78);
        org.joda.time.ReadablePeriod readablePeriod83 = null;
        org.joda.time.MonthDay monthDay84 = monthDay82.plus(readablePeriod83);
        org.joda.time.MonthDay monthDay86 = monthDay84.minusDays((int) (byte) 0);
        int[] intArray92 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int93 = skipUndoDateTimeField66.getMaximumValue((org.joda.time.ReadablePartial) monthDay86, intArray92);
        int int94 = offsetDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) monthDay47, intArray92);
        int int95 = offsetDateTimeField5.getMaximumValue((org.joda.time.ReadablePartial) monthDay21, intArray92);
        long long97 = offsetDateTimeField5.roundCeiling((long) (-292275054));
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology17);
        org.junit.Assert.assertNotNull(dateTimeFieldArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(monthDay21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(copticChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gregorianChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1640816579990L) + "'", long32 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "+52:00" + "'", str42.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertNotNull(monthDay49);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "+52:00" + "'", str52.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertNotNull(dateTimeFieldArray57);
        org.junit.Assert.assertNotNull(property58);
        org.junit.Assert.assertNotNull(monthDay59);
        org.junit.Assert.assertNotNull(monthDay60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(julianChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "DateTimeField[era]" + "'", str67.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 2 + "'", int69 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "+52:00" + "'", str72.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone78);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "+52:00" + "'", str79.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(monthDay84);
        org.junit.Assert.assertNotNull(monthDay86);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 1 + "'", int93 == 1);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1438 + "'", int94 == 1438);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1438 + "'", int95 == 1438);
        org.junit.Assert.assertTrue("'" + long97 + "' != '" + (-292260000L) + "'", long97 == (-292260000L));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DurationField durationField4 = julianChronology1.hours();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) julianChronology1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter5.withDefaultYear(100);
        try {
            org.joda.time.LocalDateTime localDateTime9 = dateTimeFormatter5.parseLocalDateTime("Property[monthOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[monthOfYear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        int int16 = skipUndoDateTimeField4.getLeapAmount(0L);
        try {
            int int19 = skipUndoDateTimeField4.getDifference(26L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        org.joda.time.DateTime dateTime3 = dateTime0.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime3.toYearMonthDay();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.minus(readableDuration5);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(yearMonthDay4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.millisOfDay();
        boolean boolean10 = julianChronology0.equals((java.lang.Object) 4);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str13 = dateTimeZone12.toString();
        org.joda.time.Chronology chronology14 = julianChronology0.withZone(dateTimeZone12);
        int int16 = dateTimeZone12.getOffsetFromLocal((-187199990L));
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 187200000 + "'", int16 == 187200000);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 120);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-01-03T04" + "'", str2.equals("1970-01-03T04"));
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.Instant instant2 = new org.joda.time.Instant();
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) instant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forStyle("+00:00:00.097");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid style specification: +00:00:00.097");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        org.joda.time.DateTime dateTime7 = dateTime0.withHourOfDay((int) (byte) 0);
//        org.joda.time.DateTime dateTime9 = dateTime0.plusMinutes(1);
//        org.joda.time.DateMidnight dateMidnight10 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime12 = dateTime0.plusYears((int) '#');
//        org.joda.time.DateTime dateTime14 = dateTime0.withMillisOfDay(59);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        int int8 = fixedDateTimeZone6.getStandardOffset((long) (short) 10);
        long long12 = fixedDateTimeZone6.convertLocalToUTC(100L, true, (long) 4);
        org.joda.time.Chronology chronology13 = gregorianChronology1.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3L + "'", long12 == 3L);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        int int5 = skipUndoDateTimeField4.getMinimumValue();
        java.util.Locale locale6 = null;
        int int7 = skipUndoDateTimeField4.getMaximumTextLength(locale6);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstanceUTC();
        org.joda.time.MonthDay monthDay1 = new org.joda.time.MonthDay((org.joda.time.Chronology) copticChronology0);
        org.junit.Assert.assertNotNull(copticChronology0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        org.joda.time.MonthDay monthDay11 = property8.addToCopy(97);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        boolean boolean14 = property8.equals((java.lang.Object) copticChronology12);
        org.joda.time.DateTimeField dateTimeField15 = copticChronology12.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        org.joda.time.DateTime dateTime5 = property1.withMaximumValue();
        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.toDateTime(chronology7);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.chrono.CopticChronology copticChronology6 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime12 = dateTime10.minusWeeks((int) '4');
        org.joda.time.MutableDateTime mutableDateTime13 = dateTime12.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime16 = dateTime14.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime18 = dateTime16.plusHours(1);
        int int19 = mutableDateTime13.compareTo((org.joda.time.ReadableInstant) dateTime16);
        int int20 = property8.compareTo((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.DateTime dateTime22 = dateTime16.plusDays(2000);
        boolean boolean23 = copticChronology6.equals((java.lang.Object) 2000);
        org.joda.time.DurationField durationField24 = copticChronology6.eras();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(copticChronology6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(mutableDateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(10);
        int int5 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime7 = dateTime4.withDayOfYear(26);
        org.joda.time.DateMidnight dateMidnight8 = dateTime4.toDateMidnight();
        org.joda.time.DateTime dateTime10 = dateTime4.minusWeeks((int) (byte) 10);
        try {
            org.joda.time.DateTime dateTime12 = dateTime10.withEra(9);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1L, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        long long14 = gJChronology10.add(readablePeriod11, (-187199868L), 104);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-187199868L) + "'", long14 == (-187199868L));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        try {
            long long10 = skipUndoDateTimeField4.getDifferenceAsLong(187200011L, (-187199990L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField5.getAsText((long) 'a', locale7);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField5.getMaximumShortTextLength(locale9);
//        int int13 = offsetDateTimeField5.getDifference((long) 2000, 1560626784922L);
//        boolean boolean15 = offsetDateTimeField5.isLeap((long) (-1));
//        long long17 = offsetDateTimeField5.roundHalfCeiling((-124274059140000L));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "239" + "'", str8.equals("239"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-26010446) + "'", int13 == (-26010446));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-124274059140000L) + "'", long17 == (-124274059140000L));
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField5.getAsText((int) (short) 10, locale10);
        long long13 = offsetDateTimeField5.roundHalfCeiling((long) 60);
        long long15 = offsetDateTimeField5.roundCeiling(35L);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10" + "'", str11.equals("10"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 60000L + "'", long15 == 60000L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "AD");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str12 = dateTimeZone11.toString();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone11);
        long long15 = dateTimeZone8.getMillisKeepLocal(dateTimeZone11, (-124273871999996L));
        org.joda.time.MonthDay monthDay16 = org.joda.time.MonthDay.now(dateTimeZone8);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+52:00" + "'", str12.equals("+52:00"));
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-124274059199996L) + "'", long15 == (-124274059199996L));
        org.junit.Assert.assertNotNull(monthDay16);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("hi!");
        java.lang.String str2 = jodaTimePermission1.toString();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str4 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str2.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"hi!\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"hi!\")"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        org.joda.time.MonthDay monthDay11 = property8.addToCopy(97);
        org.joda.time.chrono.CopticChronology copticChronology12 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = copticChronology12.getZone();
        boolean boolean14 = property8.equals((java.lang.Object) copticChronology12);
        java.lang.String str15 = property8.getAsString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(copticChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        long long9 = skipUndoDateTimeField4.roundHalfCeiling((long) 'a');
        long long12 = skipUndoDateTimeField4.addWrapField((long) 4, (-1));
        int int14 = skipUndoDateTimeField4.getMaximumValue((long) 99);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-62105356800000L) + "'", long9 == (-62105356800000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-124273871999996L) + "'", long12 == (-124273871999996L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1L, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology12 = dateTime11.getChronology();
        org.joda.time.DateTime dateTime14 = dateTime11.withYearOfCentury((int) (byte) 1);
        org.joda.time.ReadableDateTime readableDateTime15 = null;
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology10, (org.joda.time.ReadableDateTime) dateTime14, readableDateTime15);
        org.joda.time.Chronology chronology17 = limitChronology16.withUTC();
        try {
            long long22 = limitChronology16.getDateTimeMillis(60, 10, 99, 60);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 99 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertNotNull(chronology17);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        org.joda.time.DateTime dateTime7 = dateTime0.withHourOfDay((int) (byte) 0);
//        org.joda.time.DateTime dateTime9 = dateTime0.plusMinutes(1);
//        org.joda.time.DateMidnight dateMidnight10 = dateTime0.toDateMidnight();
//        int int11 = dateMidnight10.getYear();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateMidnight10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.LocalDateTime localDateTime6 = dateTime5.toLocalDateTime();
        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) (short) 10);
        org.joda.time.DateTime dateTime10 = dateTime8.withYearOfCentury(0);
        org.joda.time.DateTime dateTime12 = dateTime8.withMillisOfSecond(26);
        org.joda.time.DateTime dateTime14 = dateTime8.minus((long) (-26010446));
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(localDateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.withFields(readablePartial3);
        java.util.GregorianCalendar gregorianCalendar5 = dateTime4.toGregorianCalendar();
        org.joda.time.LocalDate localDate6 = dateTime4.toLocalDate();
        org.joda.time.DateTime dateTime7 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime9 = dateTime4.plusYears(0);
        org.joda.time.LocalDate localDate10 = dateTime4.toLocalDate();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gregorianCalendar5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(localDate10);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        org.joda.time.DateTime dateTime7 = dateTime0.withHourOfDay((int) (byte) 0);
//        org.joda.time.DateTime dateTime9 = dateTime0.plusMinutes(1);
//        org.joda.time.DateTime dateTime10 = dateTime0.withEarlierOffsetAtOverlap();
//        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.era();
//        org.joda.time.DateTimeZone dateTimeZone13 = julianChronology11.getZone();
//        long long17 = julianChronology11.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DurationField durationField18 = julianChronology11.hours();
//        org.joda.time.DateTimeZone dateTimeZone19 = julianChronology11.getZone();
//        java.util.TimeZone timeZone20 = dateTimeZone19.toTimeZone();
//        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone19);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone19);
//        int int24 = cachedDateTimeZone22.getOffset((-34L));
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property26 = dateTime25.era();
//        org.joda.time.DateTime dateTime28 = dateTime25.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime30 = dateTime25.withHourOfDay(1);
//        org.joda.time.LocalDateTime localDateTime31 = dateTime30.toLocalDateTime();
//        boolean boolean32 = cachedDateTimeZone22.equals((java.lang.Object) dateTime30);
//        int int34 = cachedDateTimeZone22.getStandardOffset((long) 19);
//        org.joda.time.MutableDateTime mutableDateTime35 = dateTime0.toMutableDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone22);
//        try {
//            org.joda.time.DateTime dateTime37 = dateTime0.withDayOfYear((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfYear must be in the range [1,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(julianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-34L) + "'", long17 == (-34L));
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNotNull(iSOChronology21);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(localDateTime31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(mutableDateTime35);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
        long long10 = offsetDateTimeField5.roundHalfFloor((long) 1);
        org.joda.time.chrono.CopticChronology copticChronology11 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone12 = copticChronology11.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (short) -1);
        long long18 = offsetDateTimeField16.roundFloor(187200011L);
        int int19 = offsetDateTimeField16.getMaximumValue();
        org.joda.time.JodaTimePermission jodaTimePermission21 = new org.joda.time.JodaTimePermission("hi!");
        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property23 = dateTime22.era();
        org.joda.time.DateTime dateTime25 = dateTime22.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime27 = dateTime22.withHourOfDay(1);
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property29 = dateTime28.era();
        org.joda.time.DateTimeField dateTimeField30 = property29.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = property29.getFieldType();
        org.joda.time.DateTime dateTime33 = dateTime27.withField(dateTimeFieldType31, (int) (byte) 0);
        jodaTimePermission21.checkGuard((java.lang.Object) dateTimeFieldType31);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType31, 2);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField37 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType31);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(copticChronology11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 187200000L + "'", long18 == 187200000L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1438 + "'", int19 == 1438);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFieldType31);
        org.junit.Assert.assertNotNull(dateTime33);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
//        java.lang.String str5 = skipUndoDateTimeField4.toString();
//        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str10 = dateTimeZone9.toString();
//        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
//        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str17 = dateTimeZone16.toString();
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone16, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone16);
//        org.joda.time.ReadablePeriod readablePeriod21 = null;
//        org.joda.time.MonthDay monthDay22 = monthDay20.plus(readablePeriod21);
//        org.joda.time.MonthDay monthDay24 = monthDay22.minusDays((int) (byte) 0);
//        int[] intArray30 = new int[] { 4, '4', 97, (short) -1, 35 };
//        int int31 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
//        int int32 = skipUndoDateTimeField4.getMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        org.joda.time.Chronology chronology34 = dateTimeFormatter33.getChronolgy();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime37 = dateTime35.minusWeeks((int) '4');
//        org.joda.time.MutableDateTime mutableDateTime38 = dateTime37.toMutableDateTimeISO();
//        java.lang.String str39 = dateTimeFormatter33.print((org.joda.time.ReadableInstant) dateTime37);
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str42 = dateTimeZone41.toString();
//        boolean boolean44 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone41, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay45 = new org.joda.time.MonthDay(dateTimeZone41);
//        org.joda.time.Chronology chronology46 = monthDay45.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray47 = monthDay45.getFields();
//        int int48 = monthDay45.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray49 = monthDay45.getFields();
//        java.lang.String str50 = dateTimeFormatter33.print((org.joda.time.ReadablePartial) monthDay45);
//        int int51 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay45);
//        org.joda.time.chrono.GregorianChronology gregorianChronology52 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology52.era();
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str56 = dateTimeZone55.toString();
//        boolean boolean58 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone55, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay59 = new org.joda.time.MonthDay(dateTimeZone55);
//        org.joda.time.Chronology chronology60 = monthDay59.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray61 = monthDay59.getFields();
//        int int62 = monthDay59.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray63 = monthDay59.getFields();
//        int[] intArray65 = gregorianChronology52.get((org.joda.time.ReadablePartial) monthDay59, (long) 84381);
//        boolean boolean66 = monthDay45.isBefore((org.joda.time.ReadablePartial) monthDay59);
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+52:00" + "'", str17.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(monthDay22);
//        org.junit.Assert.assertNotNull(monthDay24);
//        org.junit.Assert.assertNotNull(intArray30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNull(chronology34);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(mutableDateTime38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "040000.104+5200" + "'", str39.equals("040000.104+5200"));
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "+52:00" + "'", str42.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(chronology46);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray49);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "������.000" + "'", str50.equals("������.000"));
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "+52:00" + "'", str56.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(chronology60);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray63);
//        org.junit.Assert.assertNotNull(intArray65);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        org.joda.time.MonthDay monthDay9 = property8.getMonthDay();
        org.joda.time.MonthDay monthDay11 = monthDay9.plusMonths(0);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.chrono.JulianChronology julianChronology13 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField14 = julianChronology13.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField16 = new org.joda.time.field.SkipUndoDateTimeField(chronology12, dateTimeField14, 2000);
        java.lang.String str17 = skipUndoDateTimeField16.toString();
        int int19 = skipUndoDateTimeField16.get((long) (short) 0);
        org.joda.time.Chronology chronology20 = null;
        org.joda.time.chrono.JulianChronology julianChronology21 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField22 = julianChronology21.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField24 = new org.joda.time.field.SkipUndoDateTimeField(chronology20, dateTimeField22, 2000);
        java.lang.String str25 = skipUndoDateTimeField24.toString();
        int int27 = skipUndoDateTimeField24.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str30 = dateTimeZone29.toString();
        boolean boolean32 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone29, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay33 = new org.joda.time.MonthDay(dateTimeZone29);
        int int34 = skipUndoDateTimeField24.getMinimumValue((org.joda.time.ReadablePartial) monthDay33);
        java.util.Locale locale36 = null;
        java.lang.String str37 = skipUndoDateTimeField16.getAsText((org.joda.time.ReadablePartial) monthDay33, 0, locale36);
        boolean boolean38 = monthDay9.isAfter((org.joda.time.ReadablePartial) monthDay33);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(monthDay9);
        org.junit.Assert.assertNotNull(monthDay11);
        org.junit.Assert.assertNotNull(julianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "DateTimeField[era]" + "'", str17.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
        org.junit.Assert.assertNotNull(julianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DateTimeField[era]" + "'", str25.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "+52:00" + "'", str30.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "BC" + "'", str37.equals("BC"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(10);
        int int5 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime7 = dateTime4.withYearOfCentury((int) ' ');
        org.joda.time.DateTime dateTime10 = dateTime7.withDurationAdded(0L, 2);
        org.joda.time.DateTime dateTime12 = dateTime7.minusHours((int) '#');
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        long long6 = dateTime5.getMillis();
        org.joda.time.Chronology chronology7 = dateTime5.getChronology();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-3599896L) + "'", long6 == (-3599896L));
        org.junit.Assert.assertNotNull(chronology7);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone2 = copticChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology0.getZone();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        long long10 = julianChronology4.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology4.getZone();
        org.joda.time.Chronology chronology12 = copticChronology0.withZone(dateTimeZone11);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-34L) + "'", long10 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(chronology12);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
//        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(10);
//        int int5 = dateTime0.getYear();
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1970 + "'", int5 == 1970);
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        org.joda.time.DateTime dateTime7 = dateTime0.withHourOfDay((int) (byte) 0);
//        int int8 = dateTime0.getYearOfCentury();
//        try {
//            org.joda.time.DateTime dateTime10 = dateTime0.withMillisOfDay((-3));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -3 for millisOfDay must be in the range [0,86399999]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 70 + "'", int8 == 70);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
        int int20 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str40 = dateTimeZone39.toString();
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone39, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay43 = new org.joda.time.MonthDay(dateTimeZone39);
        org.joda.time.ReadablePeriod readablePeriod44 = null;
        org.joda.time.MonthDay monthDay45 = monthDay43.plus(readablePeriod44);
        org.joda.time.MonthDay monthDay47 = monthDay45.minusDays((int) (byte) 0);
        int int48 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay47);
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        org.joda.time.MonthDay monthDay51 = monthDay47.withPeriodAdded(readablePeriod49, (int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = null;
        java.lang.String str53 = monthDay47.toString(dateTimeFormatter52);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "+52:00" + "'", str40.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(monthDay45);
        org.junit.Assert.assertNotNull(monthDay47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(monthDay51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "--01-03" + "'", str53.equals("--01-03"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.year();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.chrono.JulianChronology julianChronology9 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology9.era();
        org.joda.time.DateTimeZone dateTimeZone11 = julianChronology9.getZone();
        long long15 = julianChronology9.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField16 = julianChronology9.hours();
        org.joda.time.DateTimeZone dateTimeZone17 = julianChronology9.getZone();
        java.util.TimeZone timeZone18 = dateTimeZone17.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone17);
        java.lang.Object obj20 = null;
        boolean boolean21 = iSOChronology19.equals(obj20);
        boolean boolean22 = iSOChronology5.equals(obj20);
        org.joda.time.DurationField durationField23 = iSOChronology5.millis();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(julianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-34L) + "'", long15 == (-34L));
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = copticChronology2.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, (int) (short) -1);
        long long10 = offsetDateTimeField7.add((-1640822399990L), 97);
        int int12 = offsetDateTimeField7.getLeapAmount(100L);
        long long14 = offsetDateTimeField7.roundHalfFloor(11L);
        int int15 = offsetDateTimeField7.getMinimumValue();
        org.joda.time.field.SkipDateTimeField skipDateTimeField17 = new org.joda.time.field.SkipDateTimeField(chronology1, (org.joda.time.DateTimeField) offsetDateTimeField7, 1);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str20 = dateTimeZone19.toString();
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone19, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone19);
        org.joda.time.Chronology chronology24 = monthDay23.getChronology();
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.MonthDay monthDay27 = monthDay23.withPeriodAdded(readablePeriod25, 1);
        java.util.Locale locale28 = null;
        try {
            java.lang.String str29 = skipDateTimeField17.getAsShortText((org.joda.time.ReadablePartial) monthDay23, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'minuteOfDay' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1640816579990L) + "'", long10 == (-1640816579990L));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+52:00" + "'", str20.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(monthDay27);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        int int4 = dateTime0.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime0.plusWeeks(0);
        java.lang.String str8 = dateTime6.toString("002623.702+5200");
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "002623.702+5200" + "'", str8.equals("002623.702+5200"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        org.joda.time.chrono.BuddhistChronology buddhistChronology12 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.Chronology chronology14 = buddhistChronology12.withZone(dateTimeZone13);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(buddhistChronology12);
        org.junit.Assert.assertNotNull(chronology14);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
//        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
//        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology7.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
//        org.joda.time.DateTime dateTime11 = dateTime5.toDateTime(dateTimeZone10);
//        long long13 = dateTimeZone10.convertUTCToLocal((long) 26);
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property15 = dateTime14.era();
//        org.joda.time.DateTime dateTime17 = dateTime14.withSecondOfMinute((int) (short) 10);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property19 = dateTime18.era();
//        org.joda.time.DateTime dateTime21 = dateTime18.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime23 = dateTime18.withHourOfDay(1);
//        org.joda.time.DateTime.Property property24 = dateTime23.weekOfWeekyear();
//        org.joda.time.chrono.CopticChronology copticChronology25 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone26 = copticChronology25.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = gregorianChronology27.getZone();
//        org.joda.time.DateTime dateTime29 = dateTime23.toDateTime(dateTimeZone28);
//        org.joda.time.DateTime dateTime30 = dateTime17.withZoneRetainFields(dateTimeZone28);
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) dateTime17);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(copticChronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gregorianChronology9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 187200026L + "'", long13 == 187200026L);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(copticChronology25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(gJChronology31);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        try {
            org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.forPattern("AD");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
//        int int9 = offsetDateTimeField5.getOffset();
//        java.lang.String str11 = offsetDateTimeField5.getAsShortText((long) 52);
//        int int13 = offsetDateTimeField5.get((long) 1439);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str17 = dateTimeZone16.toString();
//        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone16, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone16);
//        org.joda.time.Chronology chronology21 = monthDay20.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray22 = monthDay20.getFields();
//        int int23 = monthDay20.getMonthOfYear();
//        org.joda.time.DateTimeField[] dateTimeFieldArray24 = monthDay20.getFields();
//        int[] intArray26 = iSOChronology14.get((org.joda.time.ReadablePartial) monthDay20, (long) (short) 1);
//        org.joda.time.chrono.JulianChronology julianChronology28 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = julianChronology28.era();
//        org.joda.time.DateTimeZone dateTimeZone30 = julianChronology28.getZone();
//        org.joda.time.DurationField durationField31 = julianChronology28.hours();
//        org.joda.time.DateTimeField dateTimeField32 = julianChronology28.weekOfWeekyear();
//        org.joda.time.DateTimeField dateTimeField33 = julianChronology28.minuteOfDay();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField34 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField33);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str37 = dateTimeZone36.toString();
//        boolean boolean39 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone36, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay40 = new org.joda.time.MonthDay(dateTimeZone36);
//        org.joda.time.ReadablePeriod readablePeriod41 = null;
//        org.joda.time.MonthDay monthDay42 = monthDay40.plus(readablePeriod41);
//        org.joda.time.MonthDay monthDay44 = monthDay42.minusDays((int) (byte) 0);
//        org.joda.time.Chronology chronology45 = null;
//        org.joda.time.chrono.JulianChronology julianChronology46 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField47 = julianChronology46.era();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField49 = new org.joda.time.field.SkipUndoDateTimeField(chronology45, dateTimeField47, 2000);
//        java.lang.String str50 = skipUndoDateTimeField49.toString();
//        int int52 = skipUndoDateTimeField49.get((long) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str55 = dateTimeZone54.toString();
//        boolean boolean57 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone54, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay58 = new org.joda.time.MonthDay(dateTimeZone54);
//        int int59 = skipUndoDateTimeField49.getMinimumValue((org.joda.time.ReadablePartial) monthDay58);
//        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str62 = dateTimeZone61.toString();
//        boolean boolean64 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone61, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay65 = new org.joda.time.MonthDay(dateTimeZone61);
//        org.joda.time.ReadablePeriod readablePeriod66 = null;
//        org.joda.time.MonthDay monthDay67 = monthDay65.plus(readablePeriod66);
//        org.joda.time.MonthDay monthDay69 = monthDay67.minusDays((int) (byte) 0);
//        int[] intArray75 = new int[] { 4, '4', 97, (short) -1, 35 };
//        int int76 = skipUndoDateTimeField49.getMaximumValue((org.joda.time.ReadablePartial) monthDay69, intArray75);
//        int int77 = delegatedDateTimeField34.getMaximumValue((org.joda.time.ReadablePartial) monthDay44, intArray75);
//        try {
//            int[] intArray79 = offsetDateTimeField5.addWrapField((org.joda.time.ReadablePartial) monthDay20, 2580, intArray75, 70);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2580");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "239" + "'", str11.equals("239"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 239 + "'", int13 == 239);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+52:00" + "'", str17.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(chronology21);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray24);
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertNotNull(julianChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "+52:00" + "'", str37.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertNotNull(monthDay42);
//        org.junit.Assert.assertNotNull(monthDay44);
//        org.junit.Assert.assertNotNull(julianChronology46);
//        org.junit.Assert.assertNotNull(dateTimeField47);
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "DateTimeField[era]" + "'", str50.equals("DateTimeField[era]"));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "+52:00" + "'", str55.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "+52:00" + "'", str62.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
//        org.junit.Assert.assertNotNull(monthDay67);
//        org.junit.Assert.assertNotNull(monthDay69);
//        org.junit.Assert.assertNotNull(intArray75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1439 + "'", int77 == 1439);
//    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime.Property property7 = dateTime0.era();
//        java.lang.String str8 = property7.getAsString();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property7.getFieldType();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(12, 19);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 31 + "'", int2 == 31);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime();
//        org.joda.time.Chronology chronology7 = dateTime6.getChronology();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfCentury();
//        int int9 = property8.getMaximumValueOverall();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property8.getFieldType();
//        int int11 = dateTime5.get(dateTimeFieldType10);
//        org.joda.time.LocalTime localTime12 = dateTime5.toLocalTime();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 99 + "'", int9 == 99);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 70 + "'", int11 == 70);
//        org.junit.Assert.assertNotNull(localTime12);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.year();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.halfdayOfDay();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField12, 2000);
        java.lang.String str15 = skipUndoDateTimeField14.toString();
        int int17 = skipUndoDateTimeField14.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str20 = dateTimeZone19.toString();
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone19, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone19);
        int int24 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str27 = dateTimeZone26.toString();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone26, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay32 = monthDay30.plus(readablePeriod31);
        org.joda.time.MonthDay monthDay34 = monthDay32.minusDays((int) (byte) 0);
        int[] intArray40 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int41 = skipUndoDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType42, 1438, (int) (short) 100, (int) '4');
        org.joda.time.IllegalFieldValueException illegalFieldValueException49 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 10.0f, "");
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[era]" + "'", str15.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+52:00" + "'", str20.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+52:00" + "'", str27.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime0.plusYears(10);
        int int5 = dateTime4.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime7 = dateTime4.withYearOfCentury((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime7.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        java.lang.String str2 = julianChronology0.toString();
        java.lang.String str3 = julianChronology0.toString();
        int int4 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JulianChronology[UTC]" + "'", str2.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "JulianChronology[UTC]" + "'", str3.equals("JulianChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DurationField durationField7 = julianChronology0.hours();
//        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.millisOfDay();
//        boolean boolean10 = julianChronology0.equals((java.lang.Object) 4);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str13 = dateTimeZone12.toString();
//        org.joda.time.Chronology chronology14 = julianChronology0.withZone(dateTimeZone12);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime();
//        org.joda.time.DateTime dateTime17 = dateTime15.minusWeeks((int) '4');
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime15.withFields(readablePartial18);
//        java.util.GregorianCalendar gregorianCalendar20 = dateTime19.toGregorianCalendar();
//        org.joda.time.LocalDate localDate21 = dateTime19.toLocalDate();
//        long long23 = julianChronology0.set((org.joda.time.ReadablePartial) localDate21, 1546288017822L);
//        long long27 = julianChronology0.add(187200011L, (long) 10, (-97));
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+52:00" + "'", str13.equals("+52:00"));
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(gregorianCalendar20);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1369617822L + "'", long23 == 1369617822L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 187199041L + "'", long27 == 187199041L);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("104");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '104' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 1970, number2, (java.lang.Number) 1560630417822L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime0.minus(readablePeriod5);
//        org.joda.time.TimeOfDay timeOfDay7 = dateTime0.toTimeOfDay();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(timeOfDay7);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime.Property property3 = dateTime0.weekyear();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.DateTime.Property property6 = dateTime4.yearOfCentury();
        org.joda.time.DateTime dateTime10 = dateTime4.withDate((int) '4', (int) (short) 10, 6);
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property12 = dateTime11.era();
        org.joda.time.DateTime dateTime14 = dateTime11.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime16 = dateTime11.withHourOfDay(1);
        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property18 = dateTime17.era();
        org.joda.time.DateTimeField dateTimeField19 = property18.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = property18.getFieldType();
        org.joda.time.DateTime dateTime22 = dateTime16.withField(dateTimeFieldType20, (int) (byte) 0);
        boolean boolean23 = dateTime4.isSupported(dateTimeFieldType20);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime25 = dateTime4.plus(readablePeriod24);
        boolean boolean26 = dateTime0.isBefore((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime28 = dateTime4.plusWeeks((int) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = null;
        boolean boolean30 = dateTime28.isSupported(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        int int13 = cachedDateTimeZone11.getOffset((-34L));
        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property15 = dateTime14.era();
        org.joda.time.DateTime dateTime17 = dateTime14.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime19 = dateTime14.withHourOfDay(1);
        org.joda.time.LocalDateTime localDateTime20 = dateTime19.toLocalDateTime();
        boolean boolean21 = cachedDateTimeZone11.equals((java.lang.Object) dateTime19);
        int int23 = cachedDateTimeZone11.getStandardOffset((long) 19);
        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(localDateTime20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        try {
            org.joda.time.MonthDay monthDay1 = org.joda.time.MonthDay.parse("DateTimeField[era]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[era]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test318");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        long long8 = offsetDateTimeField5.add((-1640822399990L), 97);
//        long long11 = offsetDateTimeField5.add((long) (byte) 0, 0L);
//        long long14 = offsetDateTimeField5.set((long) (short) 100, (int) (short) 1);
//        org.joda.time.DateTimeField dateTimeField15 = offsetDateTimeField5.getWrappedField();
//        int int17 = offsetDateTimeField5.getLeapAmount((-124274059199996L));
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1640816579990L) + "'", long8 == (-1640816579990L));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-14279900L) + "'", long14 == (-14279900L));
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str17 = dateTimeZone16.toString();
        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone16, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay20 = new org.joda.time.MonthDay(dateTimeZone16);
        org.joda.time.ReadablePeriod readablePeriod21 = null;
        org.joda.time.MonthDay monthDay22 = monthDay20.plus(readablePeriod21);
        org.joda.time.MonthDay monthDay24 = monthDay22.minusDays((int) (byte) 0);
        int[] intArray30 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int31 = skipUndoDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) monthDay24, intArray30);
        int int32 = skipUndoDateTimeField4.getMinimumValue();
        org.joda.time.chrono.JulianChronology julianChronology33 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField34 = julianChronology33.era();
        org.joda.time.DateTimeZone dateTimeZone35 = julianChronology33.getZone();
        long long39 = julianChronology33.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField40 = julianChronology33.era();
        org.joda.time.DateTime dateTime41 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property42 = dateTime41.era();
        org.joda.time.DateTime dateTime44 = dateTime41.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration45 = null;
        org.joda.time.DateTime dateTime46 = dateTime44.minus(readableDuration45);
        org.joda.time.DateTime dateTime48 = dateTime44.withYearOfCentury(0);
        org.joda.time.DateTime dateTime49 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property50 = dateTime49.era();
        org.joda.time.DateTime dateTime52 = dateTime49.plusHours((int) (byte) -1);
        int int53 = dateTime49.getMinuteOfHour();
        org.joda.time.DateTime dateTime55 = dateTime49.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property57 = dateTime56.era();
        org.joda.time.DateTime dateTime59 = dateTime56.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime61 = dateTime56.withHourOfDay(1);
        org.joda.time.DateTime dateTime62 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property63 = dateTime62.era();
        org.joda.time.DateTimeField dateTimeField64 = property63.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType65 = property63.getFieldType();
        org.joda.time.DateTime dateTime67 = dateTime61.withField(dateTimeFieldType65, (int) (byte) 0);
        boolean boolean68 = dateTime49.isSupported(dateTimeFieldType65);
        boolean boolean69 = dateTime48.isSupported(dateTimeFieldType65);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField70 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField40, dateTimeFieldType65);
        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str73 = dateTimeZone72.toString();
        boolean boolean75 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone72, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay76 = new org.joda.time.MonthDay(dateTimeZone72);
        org.joda.time.ReadablePeriod readablePeriod77 = null;
        org.joda.time.MonthDay monthDay78 = monthDay76.plus(readablePeriod77);
        org.joda.time.MonthDay monthDay80 = monthDay78.minusDays((int) (byte) 0);
        int int81 = zeroIsMaxDateTimeField70.getMinimumValue((org.joda.time.ReadablePartial) monthDay80);
        java.util.Locale locale83 = null;
        java.lang.String str84 = skipUndoDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay80, 0, locale83);
        long long86 = skipUndoDateTimeField4.roundCeiling(1546288017822L);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+52:00" + "'", str17.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(monthDay22);
        org.junit.Assert.assertNotNull(monthDay24);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(julianChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-34L) + "'", long39 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(dateTimeFieldType65);
        org.junit.Assert.assertNotNull(dateTime67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(dateTimeZone72);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "+52:00" + "'", str73.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(monthDay78);
        org.junit.Assert.assertNotNull(monthDay80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "BC" + "'", str84.equals("BC"));
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 9223372036854775807L + "'", long86 == 9223372036854775807L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.millisOfDay();
        boolean boolean10 = julianChronology0.equals((java.lang.Object) 4);
        org.joda.time.DateTimeField dateTimeField11 = julianChronology0.millisOfDay();
        org.joda.time.DurationField durationField12 = julianChronology0.eras();
        try {
            long long15 = durationField12.subtract(1560630411317L, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
//        int int6 = fixedDateTimeZone4.getStandardOffset((long) (short) 10);
//        long long10 = fixedDateTimeZone4.convertLocalToUTC(100L, true, (long) 4);
//        org.joda.time.DateTimeZone dateTimeZone11 = null;
//        long long13 = fixedDateTimeZone4.getMillisKeepLocal(dateTimeZone11, 1L);
//        try {
//            org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (-1L), 239);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 239");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3L + "'", long10 == 3L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-187199902L) + "'", long13 == (-187199902L));
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long7 = offsetDateTimeField5.roundFloor(187200011L);
        int int8 = offsetDateTimeField5.getMaximumValue();
        long long10 = offsetDateTimeField5.roundHalfFloor((-34L));
        int int11 = offsetDateTimeField5.getMaximumValue();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 187200000L + "'", long7 == 187200000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1438 + "'", int8 == 1438);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1438 + "'", int11 == 1438);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str4 = dateTimeZone3.toString();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone3, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(dateTimeZone3);
        org.joda.time.Chronology chronology8 = monthDay7.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray9 = monthDay7.getFields();
        int int10 = monthDay7.getMonthOfYear();
        org.joda.time.MonthDay monthDay12 = monthDay7.withMonthOfYear((int) (short) 1);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.DateTime dateTime14 = monthDay12.toDateTime(readableInstant13);
        java.lang.String str15 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) monthDay12);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+52:00" + "'", str4.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeFieldArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(monthDay12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "��" + "'", str15.equals("��"));
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        org.joda.time.DateTime dateTime7 = dateTime0.withYear((int) ' ');
//        org.joda.time.DateTime dateTime8 = dateTime0.toDateTimeISO();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField5.getAsText((long) 'a', locale7);
//        java.util.Locale locale9 = null;
//        int int10 = offsetDateTimeField5.getMaximumShortTextLength(locale9);
//        int int13 = offsetDateTimeField5.getDifference((long) 2000, 1560626784922L);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField5.getAsShortText(0, locale15);
//        java.lang.String str18 = offsetDateTimeField5.getAsText(0L);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "239" + "'", str8.equals("239"));
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-26010446) + "'", int13 == (-26010446));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "239" + "'", str18.equals("239"));
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime3.minus(readableDuration4);
        org.joda.time.ReadablePartial readablePartial6 = null;
        org.joda.time.DateTime dateTime7 = dateTime5.withFields(readablePartial6);
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfDay();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfMonth();
        org.joda.time.DateTime dateTime11 = dateTime7.plusMillis(1612);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        int int6 = fixedDateTimeZone4.getStandardOffset((long) (short) 10);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        long long9 = fixedDateTimeZone4.previousTransition((long) 35);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 35 + "'", int6 == 35);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.year();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.halfdayOfDay();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField12, 2000);
        java.lang.String str15 = skipUndoDateTimeField14.toString();
        int int17 = skipUndoDateTimeField14.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str20 = dateTimeZone19.toString();
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone19, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone19);
        int int24 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str27 = dateTimeZone26.toString();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone26, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay32 = monthDay30.plus(readablePeriod31);
        org.joda.time.MonthDay monthDay34 = monthDay32.minusDays((int) (byte) 0);
        int[] intArray40 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int41 = skipUndoDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType42, 1438, (int) (short) 100, (int) '4');
        int int47 = offsetDateTimeField46.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField46.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField50 = gregorianChronology49.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField51 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType48, durationField50);
        try {
            long long53 = unsupportedDateTimeField51.roundFloor(1560626784922L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[era]" + "'", str15.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+52:00" + "'", str20.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+52:00" + "'", str27.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1438 + "'", int47 == 1438);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField51);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
        int int20 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology42.era();
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str46 = dateTimeZone45.toString();
        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone45, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(dateTimeZone45);
        org.joda.time.Chronology chronology50 = monthDay49.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray51 = monthDay49.getFields();
        int int52 = monthDay49.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray53 = monthDay49.getFields();
        int[] intArray55 = gregorianChronology42.get((org.joda.time.ReadablePartial) monthDay49, (long) 84381);
        int int56 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay49);
        java.lang.Object obj57 = null;
        org.joda.time.chrono.JulianChronology julianChronology58 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField59 = julianChronology58.era();
        org.joda.time.DateTimeZone dateTimeZone60 = julianChronology58.getZone();
        org.joda.time.DurationField durationField61 = julianChronology58.hours();
        org.joda.time.DateTimeField dateTimeField62 = julianChronology58.weekOfWeekyear();
        org.joda.time.MonthDay monthDay63 = new org.joda.time.MonthDay(obj57, (org.joda.time.Chronology) julianChronology58);
        org.joda.time.ReadablePeriod readablePeriod64 = null;
        org.joda.time.MonthDay monthDay66 = monthDay63.withPeriodAdded(readablePeriod64, 25);
        org.joda.time.chrono.ISOChronology iSOChronology67 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone69 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str70 = dateTimeZone69.toString();
        boolean boolean72 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone69, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay73 = new org.joda.time.MonthDay(dateTimeZone69);
        org.joda.time.Chronology chronology74 = monthDay73.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray75 = monthDay73.getFields();
        int int76 = monthDay73.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray77 = monthDay73.getFields();
        int[] intArray79 = iSOChronology67.get((org.joda.time.ReadablePartial) monthDay73, (long) (short) 1);
        int int80 = zeroIsMaxDateTimeField37.getMinimumValue((org.joda.time.ReadablePartial) monthDay66, intArray79);
        boolean boolean82 = zeroIsMaxDateTimeField37.isLeap((long) 23);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+52:00" + "'", str46.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTimeFieldArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray53);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(julianChronology58);
        org.junit.Assert.assertNotNull(dateTimeField59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(durationField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(monthDay66);
        org.junit.Assert.assertNotNull(iSOChronology67);
        org.junit.Assert.assertNotNull(dateTimeZone69);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "+52:00" + "'", str70.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(chronology74);
        org.junit.Assert.assertNotNull(dateTimeFieldArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray77);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal((long) 26);
        long long9 = fixedDateTimeZone4.previousTransition((long) (byte) -1);
        org.joda.time.chrono.BuddhistChronology buddhistChronology10 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 97 + "'", int7 == 97);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1L) + "'", long9 == (-1L));
        org.junit.Assert.assertNotNull(buddhistChronology10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
        int int20 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
        int int43 = zeroIsMaxDateTimeField37.getMinimumValue(0L);
        long long45 = zeroIsMaxDateTimeField37.roundHalfFloor((long) (-1));
        try {
            long long48 = zeroIsMaxDateTimeField37.add((-2071231199L), 104L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-62105356800000L) + "'", long45 == (-62105356800000L));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property9 = dateTime8.era();
        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.era();
        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
        int int20 = dateTime16.getMinuteOfHour();
        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property24 = dateTime23.era();
        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property30 = dateTime29.era();
        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
        org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) zeroIsMaxDateTimeField37, 21, 2, 480);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.DateTime.Property property2 = dateTime0.yearOfCentury();
        int int3 = property2.getMaximumValueOverall();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = property2.getFieldType();
        org.joda.time.DateTime dateTime6 = property2.addToCopy(2580);
        boolean boolean7 = property2.isLeap();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 99 + "'", int3 == 99);
        org.junit.Assert.assertNotNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField8 = property7.getField();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str5 = skipUndoDateTimeField4.toString();
        int int7 = skipUndoDateTimeField4.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str10 = dateTimeZone9.toString();
        boolean boolean12 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone9, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay13 = new org.joda.time.MonthDay(dateTimeZone9);
        int int14 = skipUndoDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) monthDay13);
        java.util.Locale locale16 = null;
        java.lang.String str17 = skipUndoDateTimeField4.getAsText((long) (byte) 100, locale16);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str20 = dateTimeZone19.toString();
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone19, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone19);
        org.joda.time.Chronology chronology24 = monthDay23.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray25 = monthDay23.getFields();
        org.joda.time.MonthDay.Property property26 = monthDay23.monthOfYear();
        java.lang.String str27 = property26.getName();
        org.joda.time.MonthDay monthDay29 = property26.addToCopy(97);
        org.joda.time.ReadablePeriod readablePeriod30 = null;
        org.joda.time.MonthDay monthDay32 = monthDay29.withPeriodAdded(readablePeriod30, 4);
        int int33 = monthDay29.getMonthOfYear();
        java.util.Locale locale34 = null;
        try {
            java.lang.String str35 = skipUndoDateTimeField4.getAsText((org.joda.time.ReadablePartial) monthDay29, locale34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "DateTimeField[era]" + "'", str5.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AD" + "'", str17.equals("AD"));
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+52:00" + "'", str20.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertNotNull(dateTimeFieldArray25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "monthOfYear" + "'", str27.equals("monthOfYear"));
        org.junit.Assert.assertNotNull(monthDay29);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
//        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
//        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology0.era();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readableDuration12);
//        org.joda.time.DateTime dateTime15 = dateTime11.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property17 = dateTime16.era();
//        org.joda.time.DateTime dateTime19 = dateTime16.plusHours((int) (byte) -1);
//        int int20 = dateTime16.getMinuteOfHour();
//        org.joda.time.DateTime dateTime22 = dateTime16.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property24 = dateTime23.era();
//        org.joda.time.DateTime dateTime26 = dateTime23.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime28 = dateTime23.withHourOfDay(1);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTimeField dateTimeField31 = property30.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType32 = property30.getFieldType();
//        org.joda.time.DateTime dateTime34 = dateTime28.withField(dateTimeFieldType32, (int) (byte) 0);
//        boolean boolean35 = dateTime16.isSupported(dateTimeFieldType32);
//        boolean boolean36 = dateTime15.isSupported(dateTimeFieldType32);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField37 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType32);
//        int int39 = zeroIsMaxDateTimeField37.getLeapAmount(0L);
//        java.lang.String str41 = zeroIsMaxDateTimeField37.getAsShortText((long) 84381);
//        int int43 = zeroIsMaxDateTimeField37.getMinimumValue(0L);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
//        java.lang.String str46 = dateTimeZone45.toString();
//        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone45, (java.lang.Object) (-1.0f));
//        org.joda.time.MonthDay monthDay49 = new org.joda.time.MonthDay(dateTimeZone45);
//        org.joda.time.Chronology chronology50 = monthDay49.getChronology();
//        org.joda.time.DateTimeField[] dateTimeFieldArray51 = monthDay49.getFields();
//        org.joda.time.MonthDay.Property property52 = monthDay49.monthOfYear();
//        java.lang.String str53 = property52.getName();
//        org.joda.time.MonthDay monthDay55 = property52.addToCopy(97);
//        org.joda.time.ReadablePeriod readablePeriod56 = null;
//        org.joda.time.MonthDay monthDay58 = monthDay55.withPeriodAdded(readablePeriod56, 4);
//        int int59 = monthDay55.getMonthOfYear();
//        org.joda.time.chrono.CopticChronology copticChronology60 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone61 = copticChronology60.getZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone61);
//        org.joda.time.DateTimeZone dateTimeZone63 = gregorianChronology62.getZone();
//        org.joda.time.MonthDay monthDay64 = new org.joda.time.MonthDay((org.joda.time.Chronology) gregorianChronology62);
//        int int65 = monthDay55.compareTo((org.joda.time.ReadablePartial) monthDay64);
//        java.util.Locale locale66 = null;
//        try {
//            java.lang.String str67 = zeroIsMaxDateTimeField37.getAsText((org.joda.time.ReadablePartial) monthDay55, locale66);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'era' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(julianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFieldType32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "1" + "'", str41.equals("1"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "+52:00" + "'", str46.equals("+52:00"));
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(chronology50);
//        org.junit.Assert.assertNotNull(dateTimeFieldArray51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "monthOfYear" + "'", str53.equals("monthOfYear"));
//        org.junit.Assert.assertNotNull(monthDay55);
//        org.junit.Assert.assertNotNull(monthDay58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
//        org.junit.Assert.assertNotNull(copticChronology60);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.year();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.halfdayOfDay();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField12, 2000);
        java.lang.String str15 = skipUndoDateTimeField14.toString();
        int int17 = skipUndoDateTimeField14.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str20 = dateTimeZone19.toString();
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone19, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone19);
        int int24 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str27 = dateTimeZone26.toString();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone26, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay32 = monthDay30.plus(readablePeriod31);
        org.joda.time.MonthDay monthDay34 = monthDay32.minusDays((int) (byte) 0);
        int[] intArray40 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int41 = skipUndoDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType42, 1438, (int) (short) 100, (int) '4');
        int int47 = offsetDateTimeField46.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField46.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField50 = gregorianChronology49.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField51 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType48, durationField50);
        org.joda.time.DateTime dateTime52 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime54 = dateTime52.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime56 = dateTime54.plusHours(1);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str59 = dateTimeZone58.toString();
        boolean boolean61 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone58, (java.lang.Object) (-1.0f));
        org.joda.time.DateTime dateTime62 = dateTime56.withZone(dateTimeZone58);
        org.joda.time.LocalDate localDate63 = dateTime56.toLocalDate();
        java.util.Locale locale65 = null;
        try {
            java.lang.String str66 = unsupportedDateTimeField51.getAsShortText((org.joda.time.ReadablePartial) localDate63, (-3), locale65);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[era]" + "'", str15.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+52:00" + "'", str20.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+52:00" + "'", str27.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1438 + "'", int47 == 1438);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField51);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "+52:00" + "'", str59.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(localDate63);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology0.getZone();
        java.util.TimeZone timeZone9 = dateTimeZone8.toTimeZone();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        int int13 = cachedDateTimeZone11.getOffset((-34L));
        boolean boolean14 = cachedDateTimeZone11.isFixed();
        org.joda.time.chrono.BuddhistChronology buddhistChronology15 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone11);
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(buddhistChronology15);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-62198755200000L), (long) 12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -746385062400000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.lang.Object obj0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.DateTimeZone dateTimeZone3 = julianChronology1.getZone();
        org.joda.time.DurationField durationField4 = julianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology1.weekOfWeekyear();
        org.joda.time.MonthDay monthDay6 = new org.joda.time.MonthDay(obj0, (org.joda.time.Chronology) julianChronology1);
        org.joda.time.MonthDay monthDay8 = monthDay6.plusDays(0);
        org.joda.time.MonthDay monthDay10 = monthDay6.minusMonths(2019);
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(monthDay8);
        org.junit.Assert.assertNotNull(monthDay10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone1, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay5 = new org.joda.time.MonthDay(dateTimeZone1);
        org.joda.time.Chronology chronology6 = monthDay5.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray7 = monthDay5.getFields();
        org.joda.time.MonthDay.Property property8 = monthDay5.monthOfYear();
        java.lang.String str9 = property8.getName();
        int int10 = property8.getMinimumValueOverall();
        int int11 = property8.get();
        org.joda.time.DurationField durationField12 = property8.getRangeDurationField();
        int int13 = property8.getMaximumValue();
        java.lang.String str14 = property8.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeFieldArray7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "monthOfYear" + "'", str9.equals("monthOfYear"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Property[monthOfYear]" + "'", str14.equals("Property[monthOfYear]"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone8 = copticChronology7.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.DateTime dateTime11 = dateTime5.toDateTime(dateTimeZone10);
        try {
            org.joda.time.chrono.CopticChronology copticChronology13 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone10, 23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 23");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone2 = julianChronology0.getZone();
        long long6 = julianChronology0.add(1L, (long) (byte) -1, (int) '#');
        org.joda.time.DurationField durationField7 = julianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField8 = julianChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField10 = julianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-34L) + "'", long6 == (-34L));
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.year();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.halfdayOfDay();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField12, 2000);
        java.lang.String str15 = skipUndoDateTimeField14.toString();
        int int17 = skipUndoDateTimeField14.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str20 = dateTimeZone19.toString();
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone19, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone19);
        int int24 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str27 = dateTimeZone26.toString();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone26, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay32 = monthDay30.plus(readablePeriod31);
        org.joda.time.MonthDay monthDay34 = monthDay32.minusDays((int) (byte) 0);
        int[] intArray40 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int41 = skipUndoDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType42, 1438, (int) (short) 100, (int) '4');
        int int47 = offsetDateTimeField46.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField46.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField50 = gregorianChronology49.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField51 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType48, durationField50);
        org.joda.time.DurationField durationField52 = unsupportedDateTimeField51.getRangeDurationField();
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[era]" + "'", str15.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+52:00" + "'", str20.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+52:00" + "'", str27.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1438 + "'", int47 == 1438);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField51);
        org.junit.Assert.assertNull(durationField52);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str2 = dateTimeZone1.toString();
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField5 = julianChronology4.era();
        org.joda.time.DateTimeZone dateTimeZone6 = julianChronology4.getZone();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1L, dateTimeZone6);
        org.joda.time.DateTime.Property property8 = dateTime7.yearOfCentury();
        java.util.GregorianCalendar gregorianCalendar9 = dateTime7.toGregorianCalendar();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTimeZone dateTimeZone11 = gJChronology10.getZone();
        int int12 = gJChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField13 = gJChronology10.months();
        org.joda.time.DateTimeZone dateTimeZone14 = gJChronology10.getZone();
        org.joda.time.Chronology chronology15 = gJChronology10.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+52:00" + "'", str2.equals("+52:00"));
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology1.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField4 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, dateTimeField2, 2000);
        java.lang.String str6 = skipUndoDateTimeField4.getAsShortText((long) 480);
        org.joda.time.ReadablePartial readablePartial7 = null;
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.chrono.JulianChronology julianChronology10 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField11 = julianChronology10.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField13 = new org.joda.time.field.SkipUndoDateTimeField(chronology9, dateTimeField11, 2000);
        java.lang.String str14 = skipUndoDateTimeField13.toString();
        int int16 = skipUndoDateTimeField13.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str19 = dateTimeZone18.toString();
        boolean boolean21 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone18, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay22 = new org.joda.time.MonthDay(dateTimeZone18);
        int int23 = skipUndoDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) monthDay22);
        java.util.Locale locale25 = null;
        java.lang.String str26 = skipUndoDateTimeField13.getAsText((long) (byte) 100, locale25);
        boolean boolean27 = skipUndoDateTimeField13.isSupported();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.era();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str32 = dateTimeZone31.toString();
        boolean boolean34 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone31, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay35 = new org.joda.time.MonthDay(dateTimeZone31);
        org.joda.time.Chronology chronology36 = monthDay35.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray37 = monthDay35.getFields();
        int int38 = monthDay35.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray39 = monthDay35.getFields();
        int[] intArray41 = gregorianChronology28.get((org.joda.time.ReadablePartial) monthDay35, (long) 84381);
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str45 = dateTimeZone44.toString();
        boolean boolean47 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone44, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay48 = new org.joda.time.MonthDay(dateTimeZone44);
        org.joda.time.Chronology chronology49 = monthDay48.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray50 = monthDay48.getFields();
        int int51 = monthDay48.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray52 = monthDay48.getFields();
        int[] intArray54 = iSOChronology42.get((org.joda.time.ReadablePartial) monthDay48, (long) (short) 1);
        int int55 = skipUndoDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) monthDay35, intArray54);
        try {
            int[] intArray57 = skipUndoDateTimeField4.addWrapPartial(readablePartial7, 52, intArray54, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
        org.junit.Assert.assertNotNull(julianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "DateTimeField[era]" + "'", str14.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2 + "'", int16 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "+52:00" + "'", str19.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "AD" + "'", str26.equals("AD"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "+52:00" + "'", str32.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTimeFieldArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "+52:00" + "'", str45.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(dateTimeFieldArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray52);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str4 = dateTimeZone3.toString();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone3, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay7 = new org.joda.time.MonthDay(dateTimeZone3);
        org.joda.time.Chronology chronology8 = monthDay7.getChronology();
        org.joda.time.DateTimeField[] dateTimeFieldArray9 = monthDay7.getFields();
        int int10 = monthDay7.getMonthOfYear();
        org.joda.time.DateTimeField[] dateTimeFieldArray11 = monthDay7.getFields();
        int[] intArray13 = gregorianChronology0.get((org.joda.time.ReadablePartial) monthDay7, (long) 84381);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = gregorianChronology0.add(readablePeriod14, 0L, (-26010446));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "+52:00" + "'", str4.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeFieldArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = copticChronology0.getZone();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.minuteOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) (short) -1);
        long long7 = offsetDateTimeField5.roundFloor(187200011L);
        int int8 = offsetDateTimeField5.getMaximumValue();
        long long10 = offsetDateTimeField5.remainder((long) (byte) 1);
        boolean boolean11 = offsetDateTimeField5.isLenient();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 187200000L + "'", long7 == 187200000L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1438 + "'", int8 == 1438);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test349");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
//        int int4 = dateTime0.getDayOfWeek();
//        org.joda.time.DateTime.Property property5 = dateTime0.year();
//        org.joda.time.DateTime dateTime6 = dateTime0.toDateTime();
//        org.joda.time.DateTime.Property property7 = dateTime0.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours(1);
        org.joda.time.Instant instant5 = dateTime4.toInstant();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime7 = dateTime4.withZoneRetainFields(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test351");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
//        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
//        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.year();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField4, 10);
//        org.joda.time.DurationField durationField7 = skipDateTimeField6.getDurationField();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property9 = dateTime8.era();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusHours((int) (byte) -1);
//        int int12 = dateTime8.getDayOfWeek();
//        org.joda.time.LocalDateTime localDateTime13 = dateTime8.toLocalDateTime();
//        int int14 = skipDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) localDateTime13);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(iSOChronology2);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(dateTimeField4);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(localDateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 292278993 + "'", int14 == 292278993);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.era();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology3 = iSOChronology2.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology2.year();
        org.joda.time.field.SkipDateTimeField skipDateTimeField6 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gregorianChronology0, dateTimeField4, 10);
        java.util.Locale locale8 = null;
        java.lang.String str9 = skipDateTimeField6.getAsShortText(0, locale8);
        int int11 = skipDateTimeField6.getLeapAmount((long) 25200);
        long long14 = skipDateTimeField6.addWrapField((long) (-1), 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-1L) + "'", long14 == (-1L));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours(1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str7 = dateTimeZone6.toString();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone6, (java.lang.Object) (-1.0f));
        org.joda.time.DateTime dateTime10 = dateTime4.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime12 = dateTime10.withYearOfEra((int) (short) 1);
        org.joda.time.DateTime.Property property13 = dateTime10.minuteOfDay();
        org.joda.time.DateTime.Property property14 = dateTime10.monthOfYear();
        int int15 = property14.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        org.joda.time.DateTime dateTime3 = dateTime0.plusHours((int) (byte) -1);
        org.joda.time.DateTime dateTime5 = dateTime0.withHourOfDay(1);
        org.joda.time.DateTime.Property property6 = dateTime5.weekOfWeekyear();
        org.joda.time.DateTime.Property property7 = dateTime5.millisOfSecond();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(0L);
        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) '4');
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("+52:00", "", (int) 'a', (int) '#');
        java.util.TimeZone timeZone11 = fixedDateTimeZone10.toTimeZone();
        int int13 = fixedDateTimeZone10.getOffsetFromLocal((long) 26);
        long long15 = fixedDateTimeZone10.previousTransition((long) (byte) -1);
        int int17 = fixedDateTimeZone10.getOffsetFromLocal((long) (-1));
        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime20 = dateTime18.minusWeeks((int) '4');
        org.joda.time.ReadablePartial readablePartial21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.withFields(readablePartial21);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str25 = dateTimeZone24.toString();
        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone24, (java.lang.Object) (-1.0f));
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime18.toMutableDateTime(dateTimeZone24);
        long long30 = dateTimeZone24.convertUTCToLocal(11L);
        long long32 = fixedDateTimeZone10.getMillisKeepLocal(dateTimeZone24, (long) 35);
        boolean boolean33 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeZone24);
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField35 = julianChronology34.era();
        org.joda.time.DateTimeZone dateTimeZone36 = julianChronology34.getZone();
        org.joda.time.DurationField durationField37 = julianChronology34.hours();
        org.joda.time.DateTimeField dateTimeField38 = julianChronology34.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField39 = julianChronology34.minuteOfDay();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField40 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField39);
        boolean boolean41 = fixedDateTimeZone4.equals((java.lang.Object) dateTimeField39);
        java.lang.String str43 = fixedDateTimeZone4.getNameKey(187200000L);
        org.joda.time.MonthDay monthDay44 = new org.joda.time.MonthDay((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 97 + "'", int13 == 97);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-1L) + "'", long15 == (-1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "+52:00" + "'", str25.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 187200011L + "'", long30 == 187200011L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-187199868L) + "'", long32 == (-187199868L));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime dateTime2 = dateTime0.minusWeeks((int) '4');
        org.joda.time.DateTime dateTime4 = dateTime2.plusHours(1);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str7 = dateTimeZone6.toString();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone6, (java.lang.Object) (-1.0f));
        org.joda.time.DateTime dateTime10 = dateTime4.withZone(dateTimeZone6);
        org.joda.time.DateTime dateTime12 = dateTime4.plusDays(35);
        org.joda.time.DateTime.Property property13 = dateTime4.era();
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+52:00" + "'", str7.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.year();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.halfdayOfDay();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField12, 2000);
        java.lang.String str15 = skipUndoDateTimeField14.toString();
        int int17 = skipUndoDateTimeField14.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str20 = dateTimeZone19.toString();
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone19, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone19);
        int int24 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str27 = dateTimeZone26.toString();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone26, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay32 = monthDay30.plus(readablePeriod31);
        org.joda.time.MonthDay monthDay34 = monthDay32.minusDays((int) (byte) 0);
        int[] intArray40 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int41 = skipUndoDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType42, 1438, (int) (short) 100, (int) '4');
        int int47 = offsetDateTimeField46.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField46.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField50 = gregorianChronology49.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField51 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType48, durationField50);
        try {
            long long53 = unsupportedDateTimeField51.remainder((long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[era]" + "'", str15.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+52:00" + "'", str20.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+52:00" + "'", str27.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1438 + "'", int47 == 1438);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField51);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.era();
        org.joda.time.Chronology chronology2 = julianChronology0.withUTC();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
        org.joda.time.DateTime.Property property1 = dateTime0.era();
        java.lang.String str2 = property1.toString();
        org.joda.time.DateTime dateTime4 = property1.addWrapFieldToCopy(10);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology6 = iSOChronology5.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.year();
        org.joda.time.MutableDateTime mutableDateTime8 = dateTime4.toMutableDateTime((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology5.halfdayOfDay();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.chrono.JulianChronology julianChronology11 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField12 = julianChronology11.era();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField14 = new org.joda.time.field.SkipUndoDateTimeField(chronology10, dateTimeField12, 2000);
        java.lang.String str15 = skipUndoDateTimeField14.toString();
        int int17 = skipUndoDateTimeField14.get((long) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str20 = dateTimeZone19.toString();
        boolean boolean22 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone19, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay23 = new org.joda.time.MonthDay(dateTimeZone19);
        int int24 = skipUndoDateTimeField14.getMinimumValue((org.joda.time.ReadablePartial) monthDay23);
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        java.lang.String str27 = dateTimeZone26.toString();
        boolean boolean29 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTimeZone26, (java.lang.Object) (-1.0f));
        org.joda.time.MonthDay monthDay30 = new org.joda.time.MonthDay(dateTimeZone26);
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.MonthDay monthDay32 = monthDay30.plus(readablePeriod31);
        org.joda.time.MonthDay monthDay34 = monthDay32.minusDays((int) (byte) 0);
        int[] intArray40 = new int[] { 4, '4', 97, (short) -1, 35 };
        int int41 = skipUndoDateTimeField14.getMaximumValue((org.joda.time.ReadablePartial) monthDay34, intArray40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipUndoDateTimeField14.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, dateTimeFieldType42, 1438, (int) (short) 100, (int) '4');
        int int47 = offsetDateTimeField46.getMinimumValue();
        org.joda.time.DateTimeFieldType dateTimeFieldType48 = offsetDateTimeField46.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField50 = gregorianChronology49.halfdays();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField51 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType48, durationField50);
        try {
            int int52 = unsupportedDateTimeField51.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: era field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Property[era]" + "'", str2.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(julianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "DateTimeField[era]" + "'", str15.equals("DateTimeField[era]"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2 + "'", int17 == 2);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "+52:00" + "'", str20.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+52:00" + "'", str27.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(monthDay32);
        org.junit.Assert.assertNotNull(monthDay34);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1438 + "'", int47 == 1438);
        org.junit.Assert.assertNotNull(dateTimeFieldType48);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField51);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("Jun", false);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeZoneBuilder0.toDateTimeZone("12:26:55 AM", false);
        org.joda.time.chrono.JulianChronology julianChronology8 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField9 = julianChronology8.era();
        org.joda.time.DateTimeZone dateTimeZone10 = julianChronology8.getZone();
        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(1L, dateTimeZone10);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        int int13 = dateTime11.getMonthOfYear();
        boolean boolean14 = dateTime11.isEqualNow();
        org.joda.time.LocalDateTime localDateTime15 = dateTime11.toLocalDateTime();
        boolean boolean16 = dateTimeZone6.isLocalDateTimeGap(localDateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(julianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(localDateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        org.joda.time.DateTime dateTime0 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property1 = dateTime0.era();
//        int int2 = dateTime0.getMonthOfYear();
//        boolean boolean3 = dateTime0.isBeforeNow();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime5 = dateTime0.minus(readablePeriod4);
//        org.joda.time.chrono.JulianChronology julianChronology6 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField7 = julianChronology6.era();
//        org.joda.time.DateTimeZone dateTimeZone8 = julianChronology6.getZone();
//        long long12 = julianChronology6.add(1L, (long) (byte) -1, (int) '#');
//        org.joda.time.DateTimeField dateTimeField13 = julianChronology6.era();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property15 = dateTime14.era();
//        org.joda.time.DateTime dateTime17 = dateTime14.plusHours((int) (byte) -1);
//        org.joda.time.ReadableDuration readableDuration18 = null;
//        org.joda.time.DateTime dateTime19 = dateTime17.minus(readableDuration18);
//        org.joda.time.DateTime dateTime21 = dateTime17.withYearOfCentury(0);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property23 = dateTime22.era();
//        org.joda.time.DateTime dateTime25 = dateTime22.plusHours((int) (byte) -1);
//        int int26 = dateTime22.getMinuteOfHour();
//        org.joda.time.DateTime dateTime28 = dateTime22.minusMonths((int) (byte) 0);
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property30 = dateTime29.era();
//        org.joda.time.DateTime dateTime32 = dateTime29.plusHours((int) (byte) -1);
//        org.joda.time.DateTime dateTime34 = dateTime29.withHourOfDay(1);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime();
//        org.joda.time.DateTime.Property property36 = dateTime35.era();
//        org.joda.time.DateTimeField dateTimeField37 = property36.getField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property36.getFieldType();
//        org.joda.time.DateTime dateTime40 = dateTime34.withField(dateTimeFieldType38, (int) (byte) 0);
//        boolean boolean41 = dateTime22.isSupported(dateTimeFieldType38);
//        boolean boolean42 = dateTime21.isSupported(dateTimeFieldType38);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField13, dateTimeFieldType38);
//        int int44 = dateTime0.get(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(property1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(julianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-34L) + "'", long12 == (-34L));
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//    }
//}

