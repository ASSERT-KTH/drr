import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", 1, 365, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for  must be in the range [365,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-7));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendLiteral('#');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        java.util.Locale locale28 = null;
//        try {
//            java.lang.String str29 = unsupportedDateTimeField16.getAsText(0, locale28);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (short) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfHalfday(57600011);
//        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder6.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendClockhourOfHalfday(2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap13 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendTimeZoneShortName(strMap13);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType17 = null;
//        boolean boolean18 = dateTime16.isSupported(dateTimeFieldType17);
//        org.joda.time.DateTime dateTime20 = dateTime16.plusWeeks((int) (byte) 10);
//        org.joda.time.DateTime dateTime22 = dateTime16.minus((long) (short) 1);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property25 = dateTime24.dayOfWeek();
//        int int26 = dateTime24.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime28 = dateTime24.withZone(dateTimeZone27);
//        org.joda.time.DateTime.Property property29 = dateTime28.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property33 = dateTime32.dayOfWeek();
//        int int34 = dateTime32.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime36 = dateTime32.withZone(dateTimeZone35);
//        org.joda.time.DateTime.Property property37 = dateTime36.yearOfCentury();
//        org.joda.time.DurationField durationField38 = property37.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField39 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType30, durationField38);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType30, 31, (int) (byte) 1, 365);
//        org.joda.time.DateTime.Property property44 = dateTime16.property(dateTimeFieldType30);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder12.appendShortText(dateTimeFieldType30);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder6.appendText(dateTimeFieldType30);
//        org.joda.time.format.DateTimePrinter dateTimePrinter47 = null;
//        try {
//            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = dateTimeFormatterBuilder6.append(dateTimePrinter47);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No printer supplied");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeParser7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTimeFieldType30);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(durationField38);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField39);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime dateTime4 = property2.addToCopy(152);
//        org.joda.time.DateTime dateTime6 = property2.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property14 = dateTime13.dayOfWeek();
//        int int15 = dateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime17 = dateTime13.withZone(dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType19, (int) 'a');
//        org.joda.time.DateTime dateTime23 = dateTime8.withField(dateTimeFieldType19, 15);
//        org.joda.time.DateTime.Property property24 = dateTime23.secondOfDay();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("1970-070T16:00:00-08:00", number1, (java.lang.Number) 5, (java.lang.Number) 1000L);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "null" + "'", str5.equals("null"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970-070T16:00:00-08:00" + "'", str6.equals("1970-070T16:00:00-08:00"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = gregorianChronology0.getZone();
        boolean boolean5 = dateTimeZone3.isStandardOffset(97L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfDay((int) (byte) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendDecimal(dateTimeFieldType7, 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        java.lang.String str2 = dateTimeFormatter0.print(1L);
//        boolean boolean3 = dateTimeFormatter0.isPrinter();
//        java.lang.Appendable appendable4 = null;
//        try {
//            dateTimeFormatter0.printTo(appendable4, (long) 12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00:00:00.033" + "'", str2.equals("00:00:00.033"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField16.getLeapDurationField();
//        try {
//            long long29 = unsupportedDateTimeField16.roundCeiling(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNull(durationField27);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.adjustOffset((long) 960, true);
//        java.lang.String str5 = dateTimeZone0.getName((long) (short) 100);
//        long long8 = dateTimeZone0.convertLocalToUTC((long) 'a', true);
//        java.lang.String str10 = dateTimeZone0.getShortName((long) 10);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 960L + "'", long3 == 960L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.032" + "'", str5.equals("+00:00:00.032"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 65L + "'", long8 == 65L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.032" + "'", str10.equals("+00:00:00.032"));
//    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int42 = dividedDateTimeField39.getDifference(1000L, (long) (byte) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        org.joda.time.DurationField durationField44 = dividedDateTimeField39.getDurationField();
//        java.lang.String str45 = dividedDateTimeField39.getName();
//        try {
//            long long47 = dividedDateTimeField39.roundFloor(0L);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfCentury must be in the range [98,150]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "yearOfCentury" + "'", str45.equals("yearOfCentury"));
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) 57600, dateTimeZone1);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime1.withDate(152, (int) (byte) 10, (int) (short) 1);
//        int int7 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        org.joda.time.DateTime.Property property11 = dateTime9.era();
//        org.joda.time.Chronology chronology12 = dateTime9.getChronology();
//        int int13 = dateTime9.getDayOfMonth();
//        org.joda.time.DateTime dateTime15 = dateTime9.plusMinutes(0);
//        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology16.weekOfWeekyear();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property21 = dateTime20.dayOfWeek();
//        int int22 = dateTime20.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime24 = dateTime20.withZone(dateTimeZone23);
//        org.joda.time.DateTime.Property property25 = dateTime24.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = property25.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, dateTimeFieldType26, (int) 'a');
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property31 = dateTime30.dayOfWeek();
//        java.lang.String str32 = property31.getName();
//        org.joda.time.DateTime dateTime33 = property31.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime35 = dateTime33.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass36 = dateTime33.getClass();
//        org.joda.time.YearMonthDay yearMonthDay37 = dateTime33.toYearMonthDay();
//        java.util.Locale locale39 = null;
//        java.lang.String str40 = offsetDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay37, 3, locale39);
//        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField42 = iSOChronology41.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField43 = iSOChronology41.weekOfWeekyear();
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property46 = dateTime45.dayOfWeek();
//        int int47 = dateTime45.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime49 = dateTime45.withZone(dateTimeZone48);
//        org.joda.time.DateTime.Property property50 = dateTime49.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType51 = property50.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, dateTimeFieldType51, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField55 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField28, dateTimeFieldType51, 2000);
//        int int56 = dateTime9.get(dateTimeFieldType51);
//        int int57 = dateTime1.get(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42 + "'", int2 == 42);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(iSOChronology16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "dayOfWeek" + "'", str32.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(yearMonthDay37);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "3" + "'", str40.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology41);
//        org.junit.Assert.assertNotNull(dateTimeField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(dateTimeFieldType51);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 70 + "'", int56 == 70);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 70 + "'", int57 == 70);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime8 = property6.withMaximumValue();
//        int int9 = property6.getMaximumValue();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 99 + "'", int9 == 99);
//    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusDays(0);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder9.appendTwoDigitYear(15, true);
//        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.millisOfDay();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property18 = dateTime17.dayOfWeek();
//        org.joda.time.DateTime dateTime20 = property18.addToCopy(152);
//        org.joda.time.DateTime dateTime22 = property18.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime24 = dateTime22.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.DateTime dateTime39 = dateTime24.withField(dateTimeFieldType35, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField40 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField15, dateTimeFieldType35);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder9.appendFraction(dateTimeFieldType35, (int) (short) 100, 0);
//        org.joda.time.DateTime.Property property44 = dateTime8.property(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(gregorianChronology13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(property44);
//    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        java.lang.Object obj0 = null;
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfWeek();
//        int int4 = dateTime2.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime6 = dateTime2.withZone(dateTimeZone5);
//        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone5);
//        org.joda.time.Chronology chronology8 = gregorianChronology7.withUTC();
//        org.joda.time.DurationField durationField9 = gregorianChronology7.days();
//        java.lang.String str10 = gregorianChronology7.toString();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime(obj0, (org.joda.time.Chronology) gregorianChronology7);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(gregorianChronology7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertNotNull(durationField9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GregorianChronology[+00:00:00.032]" + "'", str10.equals("GregorianChronology[+00:00:00.032]"));
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField16.getLeapDurationField();
//        org.joda.time.DurationField durationField28 = unsupportedDateTimeField16.getRangeDurationField();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property31 = dateTime30.dayOfWeek();
//        org.joda.time.DateTime.Property property32 = dateTime30.era();
//        org.joda.time.ReadableDuration readableDuration33 = null;
//        org.joda.time.DateTime dateTime34 = dateTime30.plus(readableDuration33);
//        org.joda.time.LocalTime localTime35 = dateTime30.toLocalTime();
//        int[] intArray38 = new int[] { 57600011 };
//        try {
//            int[] intArray40 = unsupportedDateTimeField16.addWrapPartial((org.joda.time.ReadablePartial) localTime35, 82800, intArray38, 3);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNull(durationField27);
//        org.junit.Assert.assertNull(durationField28);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(localTime35);
//        org.junit.Assert.assertNotNull(intArray38);
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int42 = dividedDateTimeField39.getDifference(1000L, (long) (byte) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        org.joda.time.DurationField durationField44 = dividedDateTimeField39.getDurationField();
//        int int46 = dividedDateTimeField39.get(5713200L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        java.lang.String str3 = property2.getName();
//        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
//        int int5 = property2.getMaximumValueOverall();
//        int int6 = property2.get();
//        org.joda.time.DateTime dateTime7 = property2.getDateTime();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfWeek" + "'", str3.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime1.era();
        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
//        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfSecond((int) (short) 1);
//        int int6 = dateTime3.getYearOfEra();
//        org.joda.time.DateTime dateTime8 = dateTime3.withYear((int) '#');
//        int int9 = dateTime8.getMillisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        long long17 = dateTimeZone10.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, 1L);
//        org.joda.time.DateTime dateTime18 = dateTime8.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        java.util.TimeZone timeZone19 = fixedDateTimeZone15.toTimeZone();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 33L + "'", long17 == 33L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(timeZone19);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(2);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder4.appendTwoDigitYear(82800010, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTimeISO();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, (int) (short) 100);
//        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
//        java.util.Locale locale11 = null;
//        java.lang.String str12 = property10.getAsText(locale11);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("dayOfWeek");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        boolean boolean7 = dateTime5.isSupported(dateTimeFieldType6);
        org.joda.time.DateTime dateTime9 = dateTime5.plusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime5.minus((long) (short) 1);
        int int12 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.plusSeconds(960);
        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime11.toDateTime();
        org.joda.time.DateTime dateTime18 = dateTime16.withMillis(0L);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime8.minus((long) (short) -1);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusMinutes((int) (byte) 10);
//        int int13 = dateTime12.getDayOfWeek();
//        java.util.GregorianCalendar gregorianCalendar14 = dateTime12.toGregorianCalendar();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
//        org.junit.Assert.assertNotNull(gregorianCalendar14);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField16.getRangeDurationField();
//        try {
//            long long29 = unsupportedDateTimeField16.roundHalfEven(25401600152L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNull(durationField27);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.minus(readablePeriod7);
//        java.lang.String str9 = dateTime8.toString();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusYears(3);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
//        boolean boolean15 = dateTime13.isSupported(dateTimeFieldType14);
//        org.joda.time.DateTime dateTime17 = dateTime13.plusWeeks((int) (byte) 10);
//        org.joda.time.DateTime dateTime19 = dateTime13.minus((long) (short) 1);
//        int int20 = dateTime13.getSecondOfDay();
//        int int21 = dateTime8.compareTo((org.joda.time.ReadableInstant) dateTime13);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-01-01T00:00:00.042+00:00:00.032" + "'", str9.equals("1970-01-01T00:00:00.042+00:00:00.032"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        int int8 = property6.getMinimumValueOverall();
//        org.joda.time.DateTime dateTime9 = property6.roundHalfCeilingCopy();
//        org.joda.time.DateTime dateTime11 = dateTime9.minusSeconds(365);
//        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime11, (java.lang.Object) 100);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int42 = dividedDateTimeField39.getDifference(1000L, (long) (byte) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        long long46 = remainderDateTimeField43.addWrapField(28800097L, 23);
//        try {
//            long long49 = remainderDateTimeField43.set(31532400010L, 59);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for yearOfCentury must be in the range [98,150]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 13939200097L + "'", long46 == 13939200097L);
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
//        java.lang.String str18 = unsupportedDateTimeField16.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = unsupportedDateTimeField16.getType();
//        java.util.Locale locale21 = null;
//        try {
//            java.lang.String str22 = unsupportedDateTimeField16.getAsText((-28799999), locale21);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfCentury" + "'", str18.equals("yearOfCentury"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime1.era();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.plus(readableDuration4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusMonths(31);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMillis((int) (byte) 10);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        int int28 = zeroIsMaxDateTimeField27.getMinimumValue();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = zeroIsMaxDateTimeField27.getAsShortText((long) (-28800000), locale30);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property34 = dateTime33.dayOfWeek();
//        org.joda.time.DateTime.Property property35 = dateTime33.era();
//        org.joda.time.ReadableDuration readableDuration36 = null;
//        org.joda.time.DateTime dateTime37 = dateTime33.plus(readableDuration36);
//        org.joda.time.LocalTime localTime38 = dateTime33.toLocalTime();
//        int int39 = zeroIsMaxDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) localTime38);
//        int int40 = zeroIsMaxDateTimeField27.getMaximumValue();
//        org.joda.time.DurationField durationField41 = zeroIsMaxDateTimeField27.getLeapDurationField();
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = zeroIsMaxDateTimeField27.getAsShortText((long) 100, locale43);
//        long long47 = zeroIsMaxDateTimeField27.addWrapField((-1L), (-28799999));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "57600032" + "'", str31.equals("57600032"));
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(localTime38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 86400000 + "'", int40 == 86400000);
//        org.junit.Assert.assertNull(durationField41);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "132" + "'", str44.equals("132"));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 57600000L + "'", long47 == 57600000L);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime7 = property6.roundFloorCopy();
//        org.joda.time.DateTime dateTime9 = dateTime7.plusMillis((int) (byte) 100);
//        try {
//            org.joda.time.DateTime dateTime11 = dateTime9.withCenturyOfEra(57600011);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600011 for centuryOfEra must be in the range [0,2922789]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.adjustOffset((long) 960, true);
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone6 = dateTimeFormatter5.getZone();
//        int int7 = dateTimeFormatter5.getDefaultYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = dateTimeFormatter5.withPivotYear(1969);
//        java.lang.String str10 = dateTime4.toString(dateTimeFormatter9);
//        java.util.Locale locale11 = dateTimeFormatter9.getLocale();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 960L + "'", long3 == 960L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2000 + "'", int7 == 2000);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
//        org.junit.Assert.assertNull(locale11);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int40 = dividedDateTimeField39.getMaximumValue();
//        int int41 = dividedDateTimeField39.getDivisor();
//        int int43 = dividedDateTimeField39.getLeapAmount((long) 70);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2000 + "'", int41 == 2000);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        org.joda.time.DurationField durationField24 = unsupportedDateTimeField16.getDurationField();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(durationField24);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) ' ', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int40 = dividedDateTimeField39.getMaximumValue();
//        int int41 = dividedDateTimeField39.getDivisor();
//        int int42 = dividedDateTimeField39.getMaximumValue();
//        long long45 = dividedDateTimeField39.getDifferenceAsLong((long) (-28800000), (-259200000L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2000 + "'", int41 == 2000);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        boolean boolean3 = dateTime1.isSupported(dateTimeFieldType2);
//        org.joda.time.DateTime dateTime5 = dateTime1.minusMinutes(960);
//        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
//        int int7 = dateTime5.getSecondOfDay();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 28800 + "'", int7 == 28800);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-1L), (long) 82800010);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-82800011L) + "'", long2 == (-82800011L));
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.convertLocalToUTC((-1L), false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone5 = cachedDateTimeZone4.getUncachedZone();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-33L) + "'", long3 == (-33L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test043");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        boolean boolean5 = dateTime1.isBefore((-28800001L));
//        org.joda.time.LocalTime localTime6 = dateTime1.toLocalTime();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(localTime6);
//    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        java.lang.String str2 = dateTimeFormatter0.print(1L);
//        boolean boolean3 = dateTimeFormatter0.isPrinter();
//        java.io.Writer writer4 = null;
//        try {
//            dateTimeFormatter0.printTo(writer4, 57600000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00:00:00.033" + "'", str2.equals("00:00:00.033"));
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime8 = property6.withMaximumValue();
//        org.joda.time.Interval interval9 = property6.toInterval();
//        org.joda.time.DateTime dateTime10 = property6.roundHalfEvenCopy();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(interval9);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.minus(readablePeriod7);
//        java.lang.String str9 = dateTime8.toString();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusYears(3);
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        org.joda.time.DateTime dateTime13 = dateTime11.minus(readablePeriod12);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1970-01-01T00:00:00.042+00:00:00.032" + "'", str9.equals("1970-01-01T00:00:00.042+00:00:00.032"));
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology5.dayOfWeek();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        int int13 = fixedDateTimeZone11.getOffset((long) (short) 100);
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
//        org.joda.time.DateTime dateTime17 = property16.roundCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (byte) 1);
//        org.joda.time.DateTime dateTime22 = dateTime20.plusDays(0);
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 10);
//        int int25 = dateTime24.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay26 = dateTime24.toTimeOfDay();
//        org.joda.time.DateTime dateTime27 = dateTime22.withFields((org.joda.time.ReadablePartial) timeOfDay26);
//        boolean boolean28 = fixedDateTimeZone11.equals((java.lang.Object) dateTime22);
//        org.joda.time.Chronology chronology29 = gregorianChronology5.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology5.clockhourOfDay();
//        try {
//            org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime(23, 31, 31, 19, 0, (org.joda.time.Chronology) gregorianChronology5);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//        org.junit.Assert.assertNotNull(chronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField16.getLeapDurationField();
//        org.joda.time.DurationField durationField28 = unsupportedDateTimeField16.getRangeDurationField();
//        java.util.Locale locale29 = null;
//        try {
//            int int30 = unsupportedDateTimeField16.getMaximumTextLength(locale29);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNull(durationField27);
//        org.junit.Assert.assertNull(durationField28);
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology7 = gregorianChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology6.days();
//        java.lang.String str9 = gregorianChronology6.toString();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology6.getZone();
//        java.lang.String str11 = dateTimeZone10.toString();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[+00:00:00.032]" + "'", str9.equals("GregorianChronology[+00:00:00.032]"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.032" + "'", str11.equals("+00:00:00.032"));
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        java.lang.String str3 = property2.getName();
        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime4.withYearOfEra(10);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.plus(readablePeriod9);
        org.joda.time.DateTime.Property property11 = dateTime4.weekyear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfWeek" + "'", str3.equals("dayOfWeek"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
//        java.lang.StringBuffer stringBuffer1 = null;
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
//        int int4 = dateTime3.getMinuteOfDay();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.toDateTime(chronology5);
//        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
//        try {
//            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDateTime7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(localDateTime7);
//    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        int int6 = fixedDateTimeZone4.getOffset((long) (short) 100);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) (byte) 1);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusDays(0);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
//        int int18 = dateTime17.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime17.toTimeOfDay();
//        org.joda.time.DateTime dateTime20 = dateTime15.withFields((org.joda.time.ReadablePartial) timeOfDay19);
//        boolean boolean21 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
//        java.util.TimeZone timeZone22 = fixedDateTimeZone4.toTimeZone();
//        java.lang.String str24 = fixedDateTimeZone4.getNameKey(22982400000000L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
//    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime dateTime4 = dateTime1.withMillisOfDay(52);
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology5.weekOfWeekyear();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType15, (int) 'a');
//        java.lang.String str19 = offsetDateTimeField17.getAsShortText(9600L);
//        int int22 = offsetDateTimeField17.getDifference((long) (short) -1, 57600010L);
//        org.joda.time.DurationField durationField23 = offsetDateTimeField17.getLeapDurationField();
//        int int25 = offsetDateTimeField17.getMinimumValue(10L);
//        org.joda.time.DateTimeField dateTimeField26 = offsetDateTimeField17.getWrappedField();
//        int int27 = dateTime4.get(dateTimeField26);
//        int int28 = dateTime4.getWeekyear();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "98" + "'", str19.equals("98"));
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNull(durationField23);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 98 + "'", int25 == 98);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1970 + "'", int28 == 1970);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField16.getLeapDurationField();
//        org.joda.time.DurationField durationField28 = unsupportedDateTimeField16.getRangeDurationField();
//        try {
//            int int30 = unsupportedDateTimeField16.getMinimumValue((long) (-25200000));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNull(durationField27);
//        org.junit.Assert.assertNull(durationField28);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Property[dayOfWeek]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        long long27 = offsetDateTimeField12.getDifferenceAsLong((long) (short) -1, (long) (-25200000));
//        org.joda.time.DurationField durationField28 = offsetDateTimeField12.getLeapDurationField();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property31 = dateTime30.dayOfWeek();
//        int int32 = dateTime30.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone33);
//        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
//        org.joda.time.Chronology chronology36 = gregorianChronology35.withUTC();
//        org.joda.time.DurationField durationField37 = gregorianChronology35.days();
//        java.lang.String str38 = gregorianChronology35.toString();
//        org.joda.time.DateTimeZone dateTimeZone39 = gregorianChronology35.getZone();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology35.halfdayOfDay();
//        org.joda.time.DateTime dateTime42 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property43 = dateTime42.dayOfWeek();
//        java.lang.String str44 = property43.getName();
//        org.joda.time.DateTime dateTime45 = property43.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime47 = dateTime45.withMillis((long) (byte) 0);
//        org.joda.time.LocalDateTime localDateTime48 = dateTime47.toLocalDateTime();
//        long long50 = gregorianChronology35.set((org.joda.time.ReadablePartial) localDateTime48, 0L);
//        int[] intArray53 = new int[] { ' ' };
//        try {
//            int[] intArray55 = offsetDateTimeField12.add((org.joda.time.ReadablePartial) localDateTime48, 365, intArray53, (-25200000));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 365");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNull(durationField28);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(gregorianChronology35);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "GregorianChronology[+00:00:00.032]" + "'", str38.equals("GregorianChronology[+00:00:00.032]"));
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "dayOfWeek" + "'", str44.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(localDateTime48);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertNotNull(intArray53);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(82800010, (int) (short) 0, (int) (short) -1, (int) (short) -1, (-1), (-28799999));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.minus(readablePeriod7);
//        org.joda.time.DateTime dateTime10 = dateTime5.minusMinutes(100);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths((-3600000));
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        int int29 = zeroIsMaxDateTimeField27.getMinimumValue(28799999L);
//        long long31 = zeroIsMaxDateTimeField27.remainder(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = dateTime1.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime dateTime5 = dateTime1.plusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime1.minus((long) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime1.minusMinutes(57600);
        org.joda.time.DateTime dateTime10 = dateTime9.withTimeAtStartOfDay();
        org.joda.time.DateTime dateTime12 = dateTime10.withMillis(69L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
//        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfSecond((int) (short) 1);
//        int int6 = dateTime3.getYearOfEra();
//        org.joda.time.DateTime dateTime8 = dateTime3.withYear((int) '#');
//        int int9 = dateTime8.getMillisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        long long17 = dateTimeZone10.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, 1L);
//        org.joda.time.DateTime dateTime18 = dateTime8.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        org.joda.time.ReadableDuration readableDuration19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.minus(readableDuration19);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
//        int int24 = dateTime22.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime26 = dateTime22.withZone(dateTimeZone25);
//        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone25);
//        org.joda.time.DateTime dateTime28 = dateTime20.withZone(dateTimeZone25);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 33L + "'", long17 == 33L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(gregorianChronology27);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        java.lang.String str3 = property2.getName();
        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) (byte) 0);
        int int7 = dateTime4.getDayOfYear();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime4);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfWeek" + "'", str3.equals("dayOfWeek"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(chronology8);
    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test063");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsShortText(9600L);
//        int int17 = offsetDateTimeField12.getDifference((long) (short) -1, 57600010L);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField12.getLeapDurationField();
//        int int20 = offsetDateTimeField12.getMinimumValue(10L);
//        org.joda.time.DateTimeField dateTimeField21 = offsetDateTimeField12.getWrappedField();
//        long long23 = offsetDateTimeField12.roundHalfFloor((-28800000L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNull(durationField18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 98 + "'", int20 == 98);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-259200000L) + "'", long23 == (-259200000L));
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.plusDays(0);
        try {
            org.joda.time.DateTime dateTime10 = dateTime6.withMonthOfYear(1969);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime5.plusMonths(365);
//        org.joda.time.DateTime.Property property11 = dateTime5.era();
//        int int12 = property11.getMinimumValue();
//        org.joda.time.DurationField durationField13 = property11.getRangeDurationField();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNull(durationField13);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        int int2 = dateTimeFormatter0.getDefaultYear();
        int int3 = dateTimeFormatter0.getDefaultYear();
        java.lang.Appendable appendable4 = null;
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            dateTimeFormatter0.printTo(appendable4, readablePartial5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        long long26 = offsetDateTimeField12.roundHalfCeiling((long) (byte) -1);
//        int int28 = offsetDateTimeField12.get((long) 152);
//        long long31 = offsetDateTimeField12.add((long) 32, 1380);
//        long long34 = offsetDateTimeField12.set(834624000032L, 99);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-259200000L) + "'", long26 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 98 + "'", int28 == 98);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 834624000032L + "'", long31 == 834624000032L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 821318400032L + "'", long34 == 821318400032L);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("16:00:00.100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfHour((int) (byte) 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap9);
        dateTimeFormatterBuilder8.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFixedSignedDecimal(dateTimeFieldType3, 1937);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        long long29 = zeroIsMaxDateTimeField27.roundHalfCeiling((long) 1);
//        int int31 = zeroIsMaxDateTimeField27.getMaximumValue(62135596800042L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 86400000 + "'", int31 == 86400000);
//    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
//        org.joda.time.DateTime dateTime8 = property6.roundHalfFloorCopy();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test073");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
//        int int4 = property2.getMaximumValue();
//        org.joda.time.DurationField durationField5 = property2.getDurationField();
//        java.lang.String str6 = property2.getAsText();
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10);
//        int int9 = dateTime8.getMinuteOfDay();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime8.toDateTime(chronology10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property14 = dateTime13.dayOfWeek();
//        java.lang.String str15 = property14.getName();
//        org.joda.time.DateTime dateTime16 = property14.roundHalfFloorCopy();
//        long long17 = property14.remainder();
//        boolean boolean18 = dateTime11.equals((java.lang.Object) property14);
//        boolean boolean19 = property2.equals((java.lang.Object) property14);
//        org.joda.time.DateTimeField dateTimeField20 = property14.getField();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Thursday" + "'", str6.equals("Thursday"));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfWeek" + "'", str15.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 42L + "'", long17 == 42L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        int int6 = fixedDateTimeZone4.getOffset((long) (short) 100);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) (byte) 1);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusDays(0);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
//        int int18 = dateTime17.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime17.toTimeOfDay();
//        org.joda.time.DateTime dateTime20 = dateTime15.withFields((org.joda.time.ReadablePartial) timeOfDay19);
//        boolean boolean21 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
//        java.util.TimeZone timeZone22 = fixedDateTimeZone4.toTimeZone();
//        org.joda.time.JodaTimePermission jodaTimePermission24 = new org.joda.time.JodaTimePermission("dayOfWeek");
//        java.lang.String str25 = jodaTimePermission24.getActions();
//        boolean boolean26 = fixedDateTimeZone4.equals((java.lang.Object) jodaTimePermission24);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("dayOfWeek");
//        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
//        java.lang.String str3 = jodaTimePermission1.getActions();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
//        boolean boolean7 = dateTime5.isSupported(dateTimeFieldType6);
//        org.joda.time.DateTime dateTime9 = dateTime5.plusWeeks((int) (byte) 10);
//        org.joda.time.DateTime dateTime11 = dateTime5.minus((long) (short) 1);
//        int int12 = dateTime11.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime14 = dateTime11.plusSeconds(960);
//        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTime11);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property18 = dateTime17.dayOfWeek();
//        int int19 = dateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime21 = dateTime17.withZone(dateTimeZone20);
//        org.joda.time.DateTime.Property property22 = dateTime17.minuteOfHour();
//        org.joda.time.TimeOfDay timeOfDay23 = dateTime17.toTimeOfDay();
//        org.joda.time.DateTime dateTime25 = dateTime17.withYearOfCentury(10);
//        boolean boolean26 = jodaTimePermission1.equals((java.lang.Object) dateTime25);
//        org.junit.Assert.assertNotNull(permissionCollection2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(timeOfDay23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfWeek();
//        int int8 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime10 = dateTime6.withZone(dateTimeZone9);
//        org.joda.time.DateTime.Property property11 = dateTime10.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        int int16 = dateTime14.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = dateTime14.withZone(dateTimeZone17);
//        org.joda.time.DateTime.Property property19 = dateTime18.yearOfCentury();
//        org.joda.time.DurationField durationField20 = property19.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField20);
//        org.joda.time.DurationField durationField22 = unsupportedDateTimeField21.getRangeDurationField();
//        java.lang.String str23 = unsupportedDateTimeField21.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = unsupportedDateTimeField21.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder4.appendDecimal(dateTimeFieldType24, (int) ' ', 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder27.appendMonthOfYear((int) '#');
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
//        org.junit.Assert.assertNull(durationField22);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "yearOfCentury" + "'", str23.equals("yearOfCentury"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        boolean boolean3 = dateTime1.isSupported(dateTimeFieldType2);
//        org.joda.time.DateTime dateTime5 = dateTime1.plusWeeks((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = dateTime1.minus((long) (short) 1);
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property18 = dateTime17.dayOfWeek();
//        int int19 = dateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime21 = dateTime17.withZone(dateTimeZone20);
//        org.joda.time.DateTime.Property property22 = dateTime21.yearOfCentury();
//        org.joda.time.DurationField durationField23 = property22.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField24 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType15, durationField23);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType15, 31, (int) (byte) 1, 365);
//        org.joda.time.DateTime.Property property29 = dateTime1.property(dateTimeFieldType15);
//        org.joda.time.DateTime dateTime30 = property29.roundCeilingCopy();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeFieldType15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField24);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
//        java.lang.String str18 = unsupportedDateTimeField16.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = unsupportedDateTimeField16.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType19, (java.lang.Number) 60480000000L, "00:00:00.132");
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfCentury" + "'", str18.equals("yearOfCentury"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(98);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-98) + "'", int1 == (-98));
    }

//    @Test
//    public void test080() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test080");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime8 = property6.withMaximumValue();
//        org.joda.time.Interval interval9 = property6.toInterval();
//        org.joda.time.Chronology chronology10 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval9);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(interval9);
//        org.junit.Assert.assertNotNull(chronology10);
//    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int42 = dividedDateTimeField39.getDifference(1000L, (long) (byte) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        int int45 = dividedDateTimeField39.getMaximumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsShortText(9600L);
//        int int17 = offsetDateTimeField12.getDifference((long) (short) -1, 57600010L);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField12.getLeapDurationField();
//        int int20 = offsetDateTimeField12.getMinimumValue(10L);
//        org.joda.time.DateTimeField dateTimeField21 = offsetDateTimeField12.getWrappedField();
//        int int23 = offsetDateTimeField12.getLeapAmount((long) 5);
//        long long26 = offsetDateTimeField12.getDifferenceAsLong((long) 1380, 0L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNull(durationField18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 98 + "'", int20 == 98);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTimeISO();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, (int) (short) 100);
//        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
//        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.dayOfWeek();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        int int19 = fixedDateTimeZone17.getOffset((long) (short) 100);
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property22 = dateTime21.dayOfWeek();
//        org.joda.time.DateTime dateTime23 = property22.roundCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod24 = null;
//        org.joda.time.DateTime dateTime26 = dateTime23.withPeriodAdded(readablePeriod24, (int) (byte) 1);
//        org.joda.time.DateTime dateTime28 = dateTime26.plusDays(0);
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (short) 10);
//        int int31 = dateTime30.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay32 = dateTime30.toTimeOfDay();
//        org.joda.time.DateTime dateTime33 = dateTime28.withFields((org.joda.time.ReadablePartial) timeOfDay32);
//        boolean boolean34 = fixedDateTimeZone17.equals((java.lang.Object) dateTime28);
//        org.joda.time.Chronology chronology35 = gregorianChronology11.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone17);
//        org.joda.time.DateTime dateTime36 = dateTime9.toDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone17);
//        org.joda.time.DateTime dateTime37 = dateTime36.toDateTimeISO();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(gregorianChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(chronology35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime37);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField16.getType();
//        java.util.Locale locale29 = null;
//        try {
//            java.lang.String str30 = unsupportedDateTimeField16.getAsShortText(28800139L, locale29);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 23, (-82798063L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 82798086L + "'", long2 == 82798086L);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology7 = gregorianChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology6.days();
//        java.lang.String str9 = gregorianChronology6.toString();
//        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology6.getZone();
//        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology6.halfdayOfDay();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property14 = dateTime13.dayOfWeek();
//        java.lang.String str15 = property14.getName();
//        org.joda.time.DateTime dateTime16 = property14.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime18 = dateTime16.withMillis((long) (byte) 0);
//        org.joda.time.LocalDateTime localDateTime19 = dateTime18.toLocalDateTime();
//        long long21 = gregorianChronology6.set((org.joda.time.ReadablePartial) localDateTime19, 0L);
//        org.joda.time.DurationField durationField22 = gregorianChronology6.seconds();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[+00:00:00.032]" + "'", str9.equals("GregorianChronology[+00:00:00.032]"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfWeek" + "'", str15.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(localDateTime19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
//        org.junit.Assert.assertNotNull(durationField22);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        try {
//            java.lang.String str24 = unsupportedDateTimeField16.getAsText(31449600032L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = dateTime1.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime dateTime5 = dateTime1.minusMinutes(960);
        org.joda.time.DateTime.Property property6 = dateTime5.centuryOfEra();
        org.joda.time.DateTime dateTime9 = dateTime5.withDurationAdded((-28799999L), (int) (short) 0);
        org.joda.time.DateTime dateTime10 = dateTime9.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        int int29 = zeroIsMaxDateTimeField27.getMinimumValue(28799999L);
//        long long31 = zeroIsMaxDateTimeField27.roundCeiling((long) ' ');
//        int int33 = zeroIsMaxDateTimeField27.getLeapAmount((long) 16);
//        int int35 = zeroIsMaxDateTimeField27.getLeapAmount((long) 59);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 32L + "'", long31 == 32L);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
//    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("-01:00");
        org.joda.time.IllegalFieldValueException illegalFieldValueException6 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 0.0f, (java.lang.Number) 152, (java.lang.Number) 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException6.getDateTimeFieldType();
        java.lang.Number number8 = illegalFieldValueException6.getUpperBound();
        java.lang.Throwable[] throwableArray9 = illegalFieldValueException6.getSuppressed();
        boolean boolean10 = jodaTimePermission1.equals((java.lang.Object) illegalFieldValueException6);
        java.lang.String str11 = illegalFieldValueException6.toString();
        org.junit.Assert.assertNull(dateTimeFieldType7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1L + "'", number8.equals(1L));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.joda.time.IllegalFieldValueException: Value 0.0 for hi! must be in the range [152,1]" + "'", str11.equals("org.joda.time.IllegalFieldValueException: Value 0.0 for hi! must be in the range [152,1]"));
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        boolean boolean5 = dateTime1.isEqual(0L);
//        int int6 = dateTime1.getMinuteOfDay();
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime1.withDurationAdded(readableDuration7, 0);
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.DateTime dateTime11 = dateTime9.withZone(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone2.adjustOffset((long) 960, true);
//        long long7 = dateTimeZone2.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology8.weekyearOfCentury();
//        org.joda.time.DurationField durationField12 = zonedChronology8.months();
//        org.joda.time.DurationField durationField13 = zonedChronology8.millis();
//        try {
//            long long19 = zonedChronology8.getDateTimeMillis((long) 31, 42, 0, 4, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 42 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 960L + "'", long5 == 960L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(durationField13);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime1.era();
        org.joda.time.Chronology chronology4 = dateTime1.getChronology();
        java.util.Date date5 = dateTime1.toDate();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
//        java.lang.String str2 = dateTimeFormatter0.print(1L);
//        int int3 = dateTimeFormatter0.getDefaultYear();
//        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter0.getParser();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfWeek();
//        int int8 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime10 = dateTime6.withZone(dateTimeZone9);
//        org.joda.time.DateTime.Property property11 = dateTime10.yearOfCentury();
//        org.joda.time.DateTime dateTime13 = dateTime10.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime15 = dateTime13.minus((long) (short) -1);
//        org.joda.time.DateTime dateTime17 = dateTime15.minusYears(10);
//        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
//        try {
//            org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((java.lang.Object) dateTimeParser4, dateTimeZone18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.format.DateTimeFormatterBuilder$Composite");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "00:00:00.033" + "'", str2.equals("00:00:00.033"));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
//        org.junit.Assert.assertNotNull(dateTimeParser4);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime8.minus((long) (short) -1);
//        org.joda.time.DateTime.Property property11 = dateTime8.monthOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime.Property property13 = dateTime8.era();
//        org.joda.time.DurationField durationField14 = property13.getDurationField();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "1969365T010000+0000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 0.0f, (java.lang.Number) 152, (java.lang.Number) 1L);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = illegalFieldValueException4.getDateTimeFieldType();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0.0" + "'", str6.equals("0.0"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = unsupportedDateTimeField16.getType();
//        try {
//            long long22 = unsupportedDateTimeField16.roundHalfEven((long) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        long long26 = offsetDateTimeField12.roundHalfCeiling((long) (byte) -1);
//        int int28 = offsetDateTimeField12.get((long) 152);
//        long long31 = offsetDateTimeField12.addWrapField((long) 57600, (int) ' ');
//        int int32 = offsetDateTimeField12.getMaximumValue();
//        int int34 = offsetDateTimeField12.getMinimumValue(57600010L);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField12, 0, 1937, 152);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for yearOfCentury must be in the range [1937,152]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-259200000L) + "'", long26 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 98 + "'", int28 == 98);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 19353657600L + "'", long31 == 19353657600L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 150 + "'", int32 == 150);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 98 + "'", int34 == 98);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "00:00:00.033");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.yearOfEra();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = iSOChronology6.add(readablePeriod8, (long) 'a', (int) ' ');
        try {
            org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime(2, 1380, 59, 31, 82800010, 9, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 97L + "'", long11 == 97L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((int) ' ', (int) (byte) 10, (int) (byte) 10, 42, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 42 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test106() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test106");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property4 = dateTime3.dayOfWeek();
//        int int5 = dateTime3.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = dateTime3.withZone(dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime3.toDateTimeISO();
//        int int9 = dateTime3.getEra();
//        org.joda.time.DateTime dateTime11 = dateTime3.plusSeconds(57600);
//        org.joda.time.DateTime.Property property12 = dateTime11.hourOfDay();
//        java.lang.String str13 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimePrinter1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "T160000.042+0000" + "'", str13.equals("T160000.042+0000"));
//    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter27 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean28 = dateTimeFormatter27.isParser();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property31 = dateTime30.dayOfWeek();
//        int int32 = dateTime30.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone33);
//        org.joda.time.DateTime dateTime35 = dateTime30.toDateTimeISO();
//        org.joda.time.DateTime dateTime37 = dateTime35.plusSeconds((int) (short) 1);
//        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
//        java.lang.String str39 = dateTimeFormatter27.print((org.joda.time.ReadablePartial) localDateTime38);
//        try {
//            int int40 = unsupportedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) localDateTime38);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNotNull(dateTimeFormatter27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(localDateTime38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1970001T000001.042" + "'", str39.equals("1970001T000001.042"));
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        int int6 = fixedDateTimeZone4.getOffset((long) (short) 100);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) (byte) 1);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusDays(0);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
//        int int18 = dateTime17.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime17.toTimeOfDay();
//        org.joda.time.DateTime dateTime20 = dateTime15.withFields((org.joda.time.ReadablePartial) timeOfDay19);
//        boolean boolean21 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
//        java.util.TimeZone timeZone22 = fixedDateTimeZone4.toTimeZone();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forTimeZone(timeZone22);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(timeZone22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-7));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimeParser7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendHourOfDay(31);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        long long30 = zeroIsMaxDateTimeField27.add(19353657600L, 0);
//        long long33 = zeroIsMaxDateTimeField27.add(28800069L, (long) 70);
//        int int35 = zeroIsMaxDateTimeField27.getMinimumValue(31449600032L);
//        org.joda.time.ReadablePartial readablePartial36 = null;
//        int[] intArray41 = new int[] { 85800, (short) 100, 52 };
//        java.util.Locale locale43 = null;
//        try {
//            int[] intArray44 = zeroIsMaxDateTimeField27.set(readablePartial36, 0, intArray41, "dayOfWeek", locale43);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"dayOfWeek\" for yearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 19353657600L + "'", long30 == 19353657600L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28800139L + "'", long33 == 28800139L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertNotNull(intArray41);
//    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
//        java.lang.String str18 = unsupportedDateTimeField16.getName();
//        long long21 = unsupportedDateTimeField16.add(28800139L, 0L);
//        org.joda.time.DurationField durationField22 = unsupportedDateTimeField16.getLeapDurationField();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfCentury" + "'", str18.equals("yearOfCentury"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800139L + "'", long21 == 28800139L);
//        org.junit.Assert.assertNull(durationField22);
//    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        int int8 = fixedDateTimeZone6.getOffset((long) (short) 100);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfWeek();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) (byte) 1);
//        org.joda.time.DateTime dateTime17 = dateTime15.plusDays(0);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 10);
//        int int20 = dateTime19.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay21 = dateTime19.toTimeOfDay();
//        org.joda.time.DateTime dateTime22 = dateTime17.withFields((org.joda.time.ReadablePartial) timeOfDay21);
//        boolean boolean23 = fixedDateTimeZone6.equals((java.lang.Object) dateTime17);
//        org.joda.time.Chronology chronology24 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
//        long long28 = fixedDateTimeZone6.convertLocalToUTC((long) 1, false, (long) 1970);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
//    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test114");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        long long27 = offsetDateTimeField12.getDifferenceAsLong((long) (short) -1, (long) (-25200000));
//        org.joda.time.DurationField durationField28 = offsetDateTimeField12.getLeapDurationField();
//        org.joda.time.DurationField durationField29 = offsetDateTimeField12.getLeapDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertNull(durationField28);
//        org.junit.Assert.assertNull(durationField29);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (short) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendTwoDigitWeekyear((-1), false);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder8.appendMillisOfDay((int) (short) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendLiteral("16:00:00.100");
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime16.minuteOfHour();
//        java.lang.String str22 = property21.getAsShortText();
//        java.lang.String str23 = property21.getAsShortText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property21.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder27 = dateTimeFormatterBuilder14.appendDecimal(dateTimeFieldType24, 82800, 960);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder29 = dateTimeFormatterBuilder7.appendFixedDecimal(dateTimeFieldType24, 85800);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0" + "'", str22.equals("0"));
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "0" + "'", str23.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder27);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder29);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfWeek();
//        java.lang.String str4 = property3.getName();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime7 = dateTime5.withMillis((long) (byte) 0);
//        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime8);
//        java.lang.StringBuffer stringBuffer10 = null;
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property13 = dateTime12.dayOfWeek();
//        org.joda.time.DateTime.Property property14 = dateTime12.era();
//        org.joda.time.ReadableDuration readableDuration15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime12.plus(readableDuration15);
//        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime16);
//        try {
//            dateTimeFormatter0.printTo(stringBuffer10, (org.joda.time.ReadableInstant) dateTime16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "dayOfWeek" + "'", str4.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(localDateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "00:00:00.032" + "'", str9.equals("00:00:00.032"));
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 10L + "'", long17 == 10L);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("Property[dayOfWeek]");
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
//        boolean boolean1 = dateTimeFormatter0.isParser();
//        java.lang.Integer int2 = dateTimeFormatter0.getPivotYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeFormatter0.getZone();
//        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField5 = iSOChronology4.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        long long9 = dateTimeZone6.adjustOffset((long) 960, true);
//        long long11 = dateTimeZone6.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, dateTimeZone6);
//        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology12);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter0.withChronology(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertNull(int2);
//        org.junit.Assert.assertNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(iSOChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 960L + "'", long9 == 960L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 32L + "'", long11 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test119");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime1.era();
//        org.joda.time.Chronology chronology4 = dateTime1.getChronology();
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.plusMinutes(0);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.weekOfWeekyear();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property13 = dateTime12.dayOfWeek();
//        int int14 = dateTime12.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime16 = dateTime12.withZone(dateTimeZone15);
//        org.joda.time.DateTime.Property property17 = dateTime16.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType18, (int) 'a');
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
//        java.lang.String str24 = property23.getName();
//        org.joda.time.DateTime dateTime25 = property23.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime27 = dateTime25.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass28 = dateTime25.getClass();
//        org.joda.time.YearMonthDay yearMonthDay29 = dateTime25.toYearMonthDay();
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay29, 3, locale31);
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.weekOfWeekyear();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property38 = dateTime37.dayOfWeek();
//        int int39 = dateTime37.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime41 = dateTime37.withZone(dateTimeZone40);
//        org.joda.time.DateTime.Property property42 = dateTime41.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, dateTimeFieldType43, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField47 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField20, dateTimeFieldType43, 2000);
//        int int48 = dateTime1.get(dateTimeFieldType43);
//        org.joda.time.DateTime dateTime50 = dateTime1.plusYears(57600011);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "dayOfWeek" + "'", str24.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(yearMonthDay29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "3" + "'", str32.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 70 + "'", int48 == 70);
//        org.junit.Assert.assertNotNull(dateTime50);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test120");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime1.yearOfCentury();
//        org.joda.time.DateTime dateTime7 = property6.roundCeilingCopy();
//        org.joda.time.DurationField durationField8 = property6.getRangeDurationField();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(durationField8);
//    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone2.adjustOffset((long) 960, true);
//        long long7 = dateTimeZone2.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        try {
//            int[] intArray11 = iSOChronology0.get(readablePeriod9, (long) 69);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 960L + "'", long5 == 960L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime8 = property6.withMaximumValue();
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTime();
//        int int10 = mutableDateTime9.getSecondOfDay();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        int int29 = zeroIsMaxDateTimeField27.getMinimumValue(28799999L);
//        long long31 = zeroIsMaxDateTimeField27.roundCeiling((long) ' ');
//        long long33 = zeroIsMaxDateTimeField27.roundHalfFloor(31449600032L);
//        long long36 = zeroIsMaxDateTimeField27.add((long) (-28799999), 98);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 32L + "'", long31 == 32L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 31449600032L + "'", long33 == 31449600032L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-28799901L) + "'", long36 == (-28799901L));
//    }

//    @Test
//    public void test124() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test124");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        org.joda.time.DurationField durationField23 = unsupportedDateTimeField16.getRangeDurationField();
//        try {
//            long long26 = unsupportedDateTimeField16.addWrapField(821318400032L, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNull(durationField23);
//    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        org.joda.time.DurationField durationField23 = unsupportedDateTimeField16.getRangeDurationField();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
//        java.lang.String str27 = property26.getName();
//        org.joda.time.DateTime dateTime28 = property26.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime30 = dateTime28.minusHours(23);
//        org.joda.time.LocalDateTime localDateTime31 = dateTime30.toLocalDateTime();
//        int[] intArray36 = new int[] { 82800010, 0, 82800 };
//        try {
//            int[] intArray38 = unsupportedDateTimeField16.set((org.joda.time.ReadablePartial) localDateTime31, 0, intArray36, 98);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNull(durationField23);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "dayOfWeek" + "'", str27.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(localDateTime31);
//        org.junit.Assert.assertNotNull(intArray36);
//    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int42 = dividedDateTimeField39.getDifference(1000L, (long) (byte) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        long long45 = remainderDateTimeField43.roundHalfCeiling(54L);
//        long long47 = remainderDateTimeField43.roundCeiling(42L);
//        long long49 = remainderDateTimeField43.remainder((long) 2000);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-259200000L) + "'", long45 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 345600000L + "'", long47 == 345600000L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 259202000L + "'", long49 == 259202000L);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property4 = dateTime3.dayOfWeek();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy(152);
//        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy((int) (byte) 0);
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime11 = dateTime8.withCenturyOfEra(70);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimePrinter1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T000000.042+0000" + "'", str9.equals("T000000.042+0000"));
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsShortText(9600L);
//        long long16 = offsetDateTimeField12.roundHalfFloor((long) 28800);
//        long long18 = offsetDateTimeField12.roundHalfFloor((long) 2000);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-259200000L) + "'", long18 == (-259200000L));
//    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test129");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime(chronology3);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfWeek();
//        java.lang.String str8 = property7.getName();
//        org.joda.time.DateTime dateTime9 = property7.roundHalfFloorCopy();
//        long long10 = property7.remainder();
//        boolean boolean11 = dateTime4.equals((java.lang.Object) property7);
//        org.joda.time.DateTime dateTime13 = dateTime4.minusMillis(52);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "dayOfWeek" + "'", str8.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 42L + "'", long10 == 42L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("org.joda.time.IllegalFieldValueException: hi!: Value 0.0 for hi! must be in the range [152,1]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"org.joda.time.IllegalFieldValueException: hi!: Value 0.0 for hi! must be in the range [152,1]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime8.minus((long) (short) -1);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusMinutes((int) (byte) 10);
//        int int13 = dateTime12.getDayOfWeek();
//        boolean boolean14 = dateTime12.isBeforeNow();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("16:00:00.100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfHour((int) (byte) 0);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap9);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendMillisOfDay(59);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test133");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfHour();
//        java.lang.String str7 = property6.getAsShortText();
//        java.lang.String str8 = property6.getAsShortText();
//        org.joda.time.DateTime dateTime9 = property6.roundHalfFloorCopy();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(readableDuration10, 365);
//        org.joda.time.DateTime dateTime14 = dateTime12.plusMonths(52);
//        try {
//            org.joda.time.DateTime dateTime16 = dateTime12.withWeekOfWeekyear(57600);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600 for weekOfWeekyear must be in the range [1,53]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        int int6 = fixedDateTimeZone4.getOffset((long) (short) 100);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) (byte) 1);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusDays(0);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
//        int int18 = dateTime17.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime17.toTimeOfDay();
//        org.joda.time.DateTime dateTime20 = dateTime15.withFields((org.joda.time.ReadablePartial) timeOfDay19);
//        boolean boolean21 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
//        java.lang.String str23 = fixedDateTimeZone4.getNameKey(0L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "" + "'", str23.equals(""));
//    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int42 = dividedDateTimeField39.getDifference(1000L, (long) (byte) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField44 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        long long46 = remainderDateTimeField44.roundHalfFloor((long) 16);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-259200000L) + "'", long46 == (-259200000L));
//    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        java.lang.String str3 = property2.getName();
        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) (byte) 0);
        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime6);
        org.joda.time.DateTime.Property property9 = dateTime6.centuryOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfWeek" + "'", str3.equals("dayOfWeek"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        boolean boolean2 = dateTimeFormatter0.isParser();
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter0.parseDateTime("Property[era]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[era]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (short) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("16:00:00.100");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfHour((int) (byte) 0);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTimeZoneShortName(strMap12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendClockhourOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property18 = dateTime17.dayOfWeek();
//        int int19 = dateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime21 = dateTime17.withZone(dateTimeZone20);
//        org.joda.time.DateTime.Property property22 = dateTime21.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
//        int int27 = dateTime25.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime29 = dateTime25.withZone(dateTimeZone28);
//        org.joda.time.DateTime.Property property30 = dateTime29.yearOfCentury();
//        org.joda.time.DurationField durationField31 = property30.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField31);
//        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
//        java.lang.String str34 = unsupportedDateTimeField32.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField32.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder15.appendDecimal(dateTimeFieldType35, (int) ' ', 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder8.appendFixedSignedDecimal(dateTimeFieldType35, (int) (byte) 1);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType35, (-1), 1380, 15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for yearOfCentury must be in the range [1380,15]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
//        org.junit.Assert.assertNull(durationField33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "yearOfCentury" + "'", str34.equals("yearOfCentury"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField16.getLeapDurationField();
//        try {
//            int int29 = unsupportedDateTimeField16.getMaximumValue((-25200038L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNull(durationField27);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        org.joda.time.DateTime dateTime10 = dateTime8.minus(readablePeriod9);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("GregorianChronology[+00:00:00.032]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[+00:00:00.032]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException20 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType7, (java.lang.Number) 85800, (java.lang.Number) 10.0f, (java.lang.Number) (-3600000));
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        java.lang.String str20 = unsupportedDateTimeField16.getName();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "yearOfCentury" + "'", str20.equals("yearOfCentury"));
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
        org.joda.time.DateTime.Property property7 = dateTime5.era();
        boolean boolean8 = dateTime5.isEqualNow();
        org.joda.time.DateTime.Property property9 = dateTime5.millisOfSecond();
        boolean boolean10 = iSOChronology0.equals((java.lang.Object) property9);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "T230000.010-0100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        java.lang.String str3 = property2.getName();
        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime4.withYearOfEra(10);
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.plus(readablePeriod9);
        java.util.GregorianCalendar gregorianCalendar11 = dateTime4.toGregorianCalendar();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfWeek" + "'", str3.equals("dayOfWeek"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(gregorianCalendar11);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTimeISO();
//        int int7 = dateTime6.getYearOfEra();
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime6.toCalendar(locale8);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks(23);
//        org.joda.time.DateTime.Property property12 = dateTime6.dayOfYear();
//        java.lang.String str13 = property12.getName();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "dayOfYear" + "'", str13.equals("dayOfYear"));
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        int int1 = dateTime0.getDayOfYear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
//    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        long long26 = offsetDateTimeField12.roundHalfCeiling((long) (byte) -1);
//        long long29 = offsetDateTimeField12.add((long) 69, (long) (-7));
//        boolean boolean31 = offsetDateTimeField12.isLeap((long) 52);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-259200000L) + "'", long26 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-4233599931L) + "'", long29 == (-4233599931L));
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
//        java.lang.String str18 = unsupportedDateTimeField16.getName();
//        org.joda.time.ReadablePartial readablePartial19 = null;
//        int[] intArray21 = new int[] {};
//        try {
//            int[] intArray23 = unsupportedDateTimeField16.set(readablePartial19, (int) (byte) 1, intArray21, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfCentury" + "'", str18.equals("yearOfCentury"));
//        org.junit.Assert.assertNotNull(intArray21);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.lang.Object obj5 = null;
        boolean boolean6 = fixedDateTimeZone4.equals(obj5);
        long long9 = fixedDateTimeZone4.convertLocalToUTC((long) 365, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 365L + "'", long9 == 365L);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        long long27 = offsetDateTimeField12.getDifferenceAsLong((long) (short) -1, (long) (-25200000));
//        boolean boolean29 = offsetDateTimeField12.isLeap((long) 19);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test156");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone2.adjustOffset((long) 960, true);
//        long long7 = dateTimeZone2.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology8.weekOfWeekyear();
//        java.lang.String str12 = zonedChronology8.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 960L + "'", long5 == 960L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ZonedChronology[ISOChronology[UTC], +00:00:00.032]" + "'", str12.equals("ZonedChronology[ISOChronology[UTC], +00:00:00.032]"));
//    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsText(28800097L);
//        long long17 = offsetDateTimeField12.addWrapField((long) (-28799999), (int) (short) -1);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property20 = dateTime19.dayOfWeek();
//        int int21 = dateTime19.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime23 = dateTime19.withZone(dateTimeZone22);
//        org.joda.time.DateTime dateTime24 = dateTime19.toDateTimeISO();
//        org.joda.time.DateTime dateTime26 = dateTime24.plusSeconds((int) (short) 1);
//        org.joda.time.LocalDateTime localDateTime27 = dateTime26.toLocalDateTime();
//        int[] intArray30 = new int[] { 57600 };
//        try {
//            int[] intArray32 = offsetDateTimeField12.add((org.joda.time.ReadablePartial) localDateTime27, 82800010, intArray30, 15);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 82800010");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31420800001L + "'", long17 == 31420800001L);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(localDateTime27);
//        org.junit.Assert.assertNotNull(intArray30);
//    }

//    @Test
//    public void test158() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test158");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone2.adjustOffset((long) 960, true);
//        long long7 = dateTimeZone2.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology8.weekyearOfCentury();
//        org.joda.time.DateTimeField dateTimeField12 = zonedChronology8.halfdayOfDay();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 960L + "'", long5 == 960L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        java.lang.String str3 = property2.getName();
        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.minusHours(23);
        org.joda.time.LocalDateTime localDateTime7 = dateTime6.toLocalDateTime();
        org.joda.time.DateTime.Property property8 = dateTime6.centuryOfEra();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfWeek" + "'", str3.equals("dayOfWeek"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        int int28 = zeroIsMaxDateTimeField27.getMinimumValue();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = zeroIsMaxDateTimeField27.getAsShortText((long) (-28800000), locale30);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property34 = dateTime33.dayOfWeek();
//        org.joda.time.DateTime.Property property35 = dateTime33.era();
//        org.joda.time.ReadableDuration readableDuration36 = null;
//        org.joda.time.DateTime dateTime37 = dateTime33.plus(readableDuration36);
//        org.joda.time.LocalTime localTime38 = dateTime33.toLocalTime();
//        int int39 = zeroIsMaxDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) localTime38);
//        int int40 = zeroIsMaxDateTimeField27.getMaximumValue();
//        int int41 = zeroIsMaxDateTimeField27.getMaximumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "57600032" + "'", str31.equals("57600032"));
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(localTime38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 86400000 + "'", int40 == 86400000);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 86400000 + "'", int41 == 86400000);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        java.lang.String str3 = property2.getName();
        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) (byte) 0);
        java.lang.Class<?> wildcardClass7 = dateTime4.getClass();
        org.joda.time.DateTime dateTime9 = dateTime4.plusWeeks((-98));
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfWeek" + "'", str3.equals("dayOfWeek"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("dayOfWeek");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        long long9 = dateTimeZone2.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone7, 1L);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property12 = dateTime11.dayOfWeek();
//        org.joda.time.DateTime.Property property13 = dateTime11.minuteOfHour();
//        boolean boolean14 = fixedDateTimeZone7.equals((java.lang.Object) property13);
//        jodaTimePermission1.checkGuard((java.lang.Object) boolean14);
//        java.lang.String str16 = jodaTimePermission1.getName();
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 33L + "'", long9 == 33L);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime8.minus((long) (short) -1);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusMinutes((int) (byte) 10);
//        int int13 = dateTime10.getMillisOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime10.toDateTime();
//        boolean boolean15 = dateTime10.isBeforeNow();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test164");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsText(28800097L);
//        long long17 = offsetDateTimeField12.addWrapField((long) (-28799999), (int) (short) -1);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        int int19 = offsetDateTimeField12.getMaximumValue(readablePartial18);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31420800001L + "'", long17 == 31420800001L);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 150 + "'", int19 == 150);
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-28799997), (java.lang.Number) 69, (java.lang.Number) (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfSecond((int) (short) 1);
        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfDay();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime8 = dateTime5.plus(readableDuration7);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test167");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone2.adjustOffset((long) 960, true);
//        long long7 = dateTimeZone2.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        try {
//            int[] intArray12 = zonedChronology8.get(readablePeriod9, 32L, (long) 70);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 960L + "'", long5 == 960L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        long long10 = dateTimeZone7.convertLocalToUTC((-1L), false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
//        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone7);
//        try {
//            org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime(99, 1, (int) (short) 10, (int) (short) 0, 1969, (int) (short) 100, (org.joda.time.Chronology) gregorianChronology6);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-33L) + "'", long10 == (-33L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
//        org.junit.Assert.assertNotNull(zonedChronology12);
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime.Property property1 = dateTime0.dayOfMonth();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.withPeriodAdded(readablePeriod2, 1380);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(property1);
        org.junit.Assert.assertNotNull(dateTime4);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.hourOfDay();
//        int int4 = dateTime1.getMinuteOfHour();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int40 = dividedDateTimeField39.getMaximumValue();
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField41 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        long long44 = dividedDateTimeField39.add((long) 5, 31);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 37497600000005L + "'", long44 == 37497600000005L);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        long long14 = offsetDateTimeField12.roundHalfEven((long) 1);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-259200000L) + "'", long14 == (-259200000L));
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime1.era();
//        org.joda.time.Chronology chronology4 = dateTime1.getChronology();
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.plusMinutes(0);
//        org.joda.time.DateTime.Property property8 = dateTime1.minuteOfHour();
//        boolean boolean9 = dateTime1.isEqualNow();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsShortText(9600L);
//        int int17 = offsetDateTimeField12.getDifference((long) (short) -1, 57600010L);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField12.getLeapDurationField();
//        int int20 = offsetDateTimeField12.getMinimumValue(10L);
//        org.joda.time.DateTimeField dateTimeField21 = offsetDateTimeField12.getWrappedField();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property24 = dateTime23.dayOfWeek();
//        int int25 = dateTime23.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime27 = dateTime23.withZone(dateTimeZone26);
//        org.joda.time.DateTime.Property property28 = dateTime27.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = property28.getFieldType();
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property32 = dateTime31.dayOfWeek();
//        int int33 = dateTime31.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime35 = dateTime31.withZone(dateTimeZone34);
//        org.joda.time.DateTime.Property property36 = dateTime35.yearOfCentury();
//        org.joda.time.DurationField durationField37 = property36.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField38 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType29, durationField37);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField21, dateTimeFieldType29, 16);
//        long long43 = offsetDateTimeField40.add((long) (short) 0, 2000);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNull(durationField18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 98 + "'", int20 == 98);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField38);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1209600000000L + "'", long43 == 1209600000000L);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int42 = dividedDateTimeField39.getDifference(1000L, (long) (byte) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        org.joda.time.DurationField durationField44 = dividedDateTimeField39.getDurationField();
//        java.lang.String str45 = dividedDateTimeField39.getName();
//        int int46 = dividedDateTimeField39.getMaximumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "yearOfCentury" + "'", str45.equals("yearOfCentury"));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
//    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test178");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        int int29 = zeroIsMaxDateTimeField27.getMinimumValue(28799999L);
//        int int31 = zeroIsMaxDateTimeField27.getMaximumValue(0L);
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology32.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology32.weekOfWeekyear();
//        org.joda.time.DateTime dateTime36 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property37 = dateTime36.dayOfWeek();
//        int int38 = dateTime36.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime40 = dateTime36.withZone(dateTimeZone39);
//        org.joda.time.DateTime.Property property41 = dateTime40.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType42 = property41.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, dateTimeFieldType42, (int) 'a');
//        org.joda.time.DateTime dateTime46 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property47 = dateTime46.dayOfWeek();
//        java.lang.String str48 = property47.getName();
//        org.joda.time.DateTime dateTime49 = property47.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime51 = dateTime49.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass52 = dateTime49.getClass();
//        org.joda.time.YearMonthDay yearMonthDay53 = dateTime49.toYearMonthDay();
//        java.util.Locale locale55 = null;
//        java.lang.String str56 = offsetDateTimeField44.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay53, 3, locale55);
//        org.joda.time.DateTime dateTime58 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property59 = dateTime58.dayOfWeek();
//        int int60 = dateTime58.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime62 = dateTime58.withZone(dateTimeZone61);
//        org.joda.time.DateTime.Property property63 = dateTime62.yearOfCentury();
//        org.joda.time.DateTime dateTime65 = dateTime62.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime67 = dateTime65.minus((long) (short) -1);
//        org.joda.time.DateTime.Property property68 = dateTime65.monthOfYear();
//        org.joda.time.YearMonthDay yearMonthDay69 = dateTime65.toYearMonthDay();
//        int int70 = offsetDateTimeField44.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay69);
//        int int71 = zeroIsMaxDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay69);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 86400000 + "'", int31 == 86400000);
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(dateTimeFieldType42);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfWeek" + "'", str48.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertNotNull(yearMonthDay53);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "3" + "'", str56.equals("3"));
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(property68);
//        org.junit.Assert.assertNotNull(yearMonthDay69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 98 + "'", int70 == 98);
//        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 86400000 + "'", int71 == 86400000);
//    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        long long26 = offsetDateTimeField12.roundHalfCeiling((long) (byte) -1);
//        int int28 = offsetDateTimeField12.get((long) 152);
//        int int29 = offsetDateTimeField12.getOffset();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-259200000L) + "'", long26 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 98 + "'", int28 == 98);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 97 + "'", int29 == 97);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.centuries();
        try {
            long long5 = durationField2.subtract((-28799901L), 28800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -2880000000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test181");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.joda.time.DateTime.Property property3 = dateTime1.hourOfDay();
//        java.lang.String str4 = property3.getAsShortText();
//        org.joda.time.DateTime dateTime5 = property3.withMaximumValue();
//        try {
//            org.joda.time.DateTime dateTime7 = dateTime5.withSecondOfMinute(365);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime5);
//    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test182");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime1.era();
//        org.joda.time.Chronology chronology4 = dateTime1.getChronology();
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.plusMinutes(0);
//        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.weekOfWeekyear();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property13 = dateTime12.dayOfWeek();
//        int int14 = dateTime12.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime16 = dateTime12.withZone(dateTimeZone15);
//        org.joda.time.DateTime.Property property17 = dateTime16.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, dateTimeFieldType18, (int) 'a');
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
//        java.lang.String str24 = property23.getName();
//        org.joda.time.DateTime dateTime25 = property23.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime27 = dateTime25.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass28 = dateTime25.getClass();
//        org.joda.time.YearMonthDay yearMonthDay29 = dateTime25.toYearMonthDay();
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = offsetDateTimeField20.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay29, 3, locale31);
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField35 = iSOChronology33.weekOfWeekyear();
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property38 = dateTime37.dayOfWeek();
//        int int39 = dateTime37.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime41 = dateTime37.withZone(dateTimeZone40);
//        org.joda.time.DateTime.Property property42 = dateTime41.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField35, dateTimeFieldType43, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField47 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField20, dateTimeFieldType43, 2000);
//        int int48 = dateTime1.get(dateTimeFieldType43);
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str51 = dateTimeZone49.getShortName((long) 10);
//        org.joda.time.DateTime dateTime52 = dateTime1.toDateTime(dateTimeZone49);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(iSOChronology8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTimeFieldType18);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "dayOfWeek" + "'", str24.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(wildcardClass28);
//        org.junit.Assert.assertNotNull(yearMonthDay29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "3" + "'", str32.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertNotNull(dateTimeField35);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 70 + "'", int48 == 70);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "+00:00:00.032" + "'", str51.equals("+00:00:00.032"));
//        org.junit.Assert.assertNotNull(dateTime52);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "");
        org.joda.time.IllegalFieldValueException illegalFieldValueException7 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 0.0f, (java.lang.Number) 152, (java.lang.Number) 1L);
        illegalFieldValueException7.prependMessage("hi!");
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException7);
        java.lang.String str11 = illegalFieldValueException7.toString();
        java.lang.String str12 = illegalFieldValueException7.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.joda.time.IllegalFieldValueException: hi!: Value 0.0 for hi! must be in the range [152,1]" + "'", str11.equals("org.joda.time.IllegalFieldValueException: hi!: Value 0.0 for hi! must be in the range [152,1]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0.0" + "'", str12.equals("0.0"));
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime1.withDate(152, (int) (byte) 10, (int) (short) 1);
//        int int7 = dateTime1.getHourOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime1.minusYears(98);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42 + "'", int2 == 42);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendDayOfMonth(365);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendTimeZoneOffset("Property[era]", "1970-01-01T00:00:00.042+00:00:00.032", true, 10, 1969);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = unsupportedDateTimeField16.getType();
//        try {
//            long long23 = unsupportedDateTimeField16.set((long) (byte) 100, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(2);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfWeek();
//        int int8 = dateTime6.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime10 = dateTime6.withZone(dateTimeZone9);
//        org.joda.time.DateTime.Property property11 = dateTime10.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = property11.getFieldType();
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        int int16 = dateTime14.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = dateTime14.withZone(dateTimeZone17);
//        org.joda.time.DateTime.Property property19 = dateTime18.yearOfCentury();
//        org.joda.time.DurationField durationField20 = property19.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField21 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType12, durationField20);
//        int int24 = unsupportedDateTimeField21.getDifference((long) (-7), (long) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = unsupportedDateTimeField21.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder0.appendDecimal(dateTimeFieldType25, (int) ' ', 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendMillisOfSecond((int) 'a');
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTimeFieldType12);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTime.Property property3 = dateTime1.era();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.plus(readableDuration4);
        org.joda.time.DateTime dateTime7 = dateTime1.plusMonths(31);
        org.joda.time.DateTime dateTime8 = dateTime7.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfHour();
//        java.lang.String str7 = property6.getAsShortText();
//        java.lang.String str8 = property6.getAsShortText();
//        org.joda.time.DateTime dateTime9 = property6.roundHalfFloorCopy();
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime9.withDurationAdded(readableDuration10, 365);
//        int int13 = dateTime12.getDayOfMonth();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = iSOChronology0.seconds();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField19 = iSOChronology17.weekOfWeekyear();
//        org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property22 = dateTime21.dayOfWeek();
//        int int23 = dateTime21.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime25 = dateTime21.withZone(dateTimeZone24);
//        org.joda.time.DateTime.Property property26 = dateTime25.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, dateTimeFieldType27, (int) 'a');
//        org.joda.time.DateTime dateTime31 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property32 = dateTime31.dayOfWeek();
//        java.lang.String str33 = property32.getName();
//        org.joda.time.DateTime dateTime34 = property32.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime36 = dateTime34.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass37 = dateTime34.getClass();
//        org.joda.time.YearMonthDay yearMonthDay38 = dateTime34.toYearMonthDay();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = offsetDateTimeField29.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay38, 3, locale40);
//        int[] intArray48 = new int[] { 150, 42, 365, '4', (-3600000), 1380 };
//        try {
//            int int49 = unsupportedDateTimeField16.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay38, intArray48);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "dayOfWeek" + "'", str33.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(wildcardClass37);
//        org.junit.Assert.assertNotNull(yearMonthDay38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "3" + "'", str41.equals("3"));
//        org.junit.Assert.assertNotNull(intArray48);
//    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test193");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        boolean boolean4 = dateTime2.isSupported(dateTimeFieldType3);
//        org.joda.time.DateTime dateTime6 = dateTime2.plusWeeks((int) (byte) 10);
//        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime6);
//        long long8 = dateTime6.getMillis();
//        org.joda.time.DateTime dateTime10 = dateTime6.withMillis((long) ' ');
//        org.joda.time.DateTime.Property property11 = dateTime6.centuryOfEra();
//        org.joda.time.DateTime dateTime12 = property11.getDateTime();
//        org.joda.time.DateTime dateTime14 = dateTime12.withCenturyOfEra((int) (byte) 100);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-071T00:00:00+00:00:00.032" + "'", str7.equals("1970-071T00:00:00+00:00:00.032"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 6048000010L + "'", long8 == 6048000010L);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-7));
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendHourOfDay((int) (short) 10);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendDayOfWeek((-7));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("dayOfWeek");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        boolean boolean7 = dateTime5.isSupported(dateTimeFieldType6);
        org.joda.time.DateTime dateTime9 = dateTime5.plusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime5.minus((long) (short) 1);
        int int12 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.plusSeconds(960);
        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime11.toDateTime();
        org.joda.time.DateTime.Property property17 = dateTime16.year();
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-7));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder0.append(dateTimeParser7);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder0.appendMillisOfSecond((int) '4');
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTwoDigitWeekyear((-7));
        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatterBuilder11.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatter15.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter17 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser18 = dateTimeFormatter17.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter16, dateTimeParser18);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter14, dateTimeParser18);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder10.append(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimePrinter14);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeFormatter17);
        org.junit.Assert.assertNotNull(dateTimeParser18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendMillisOfDay((int) (byte) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendCenturyOfEra(0, 12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = unsupportedDateTimeField16.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) 23, (java.lang.Number) 31532400010L, (java.lang.Number) 345600000L);
//        java.lang.String str25 = illegalFieldValueException24.getIllegalValueAsString();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "23" + "'", str25.equals("23"));
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime8 = property6.withMaximumValue();
//        org.joda.time.DateTime dateTime9 = property6.withMinimumValue();
//        boolean boolean10 = dateTime9.isBeforeNow();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(2);
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder6.appendHourOfHalfday((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        int int2 = dateTimeZone0.getOffsetFromLocal((long) 3);
        boolean boolean4 = dateTimeZone0.isStandardOffset((long) (-1));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter7 = dateTimeFormatter6.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter9, dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder5.append(dateTimePrinter7, dateTimeParser11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder5.appendSecondOfDay((int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimePrinter7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = dateTime1.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime.Property property4 = dateTime1.monthOfYear();
        int int5 = dateTime1.getSecondOfMinute();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone6 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        int int8 = fixedDateTimeZone6.getOffset((long) (short) 100);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property11 = dateTime10.dayOfWeek();
//        org.joda.time.DateTime dateTime12 = property11.roundCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, (int) (byte) 1);
//        org.joda.time.DateTime dateTime17 = dateTime15.plusDays(0);
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 10);
//        int int20 = dateTime19.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay21 = dateTime19.toTimeOfDay();
//        org.joda.time.DateTime dateTime22 = dateTime17.withFields((org.joda.time.ReadablePartial) timeOfDay21);
//        boolean boolean23 = fixedDateTimeZone6.equals((java.lang.Object) dateTime17);
//        org.joda.time.Chronology chronology24 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone6);
//        java.lang.String str25 = fixedDateTimeZone6.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hi!" + "'", str25.equals("hi!"));
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfHour();
//        java.lang.String str7 = property6.getAsShortText();
//        int int8 = property6.getLeapAmount();
//        java.util.Locale locale9 = null;
//        java.lang.String str10 = property6.getAsText(locale9);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test207");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int42 = dividedDateTimeField39.getDifference(1000L, (long) (byte) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        long long45 = remainderDateTimeField43.roundHalfCeiling(54L);
//        int int47 = remainderDateTimeField43.get((long) ' ');
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-259200000L) + "'", long45 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 98 + "'", int47 == 98);
//    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        long long3 = property2.remainder();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property2.getAsShortText(locale4);
//        org.joda.time.DateTime dateTime6 = property2.roundFloorCopy();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 42L + "'", long3 == 42L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Thu" + "'", str5.equals("Thu"));
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(70, (-28799997));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: -28799997");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("null", (java.lang.Number) 10, (java.lang.Number) 31, (java.lang.Number) 28800139L);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test211");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime8 = property6.withMaximumValue();
//        org.joda.time.DateTime dateTime9 = property6.withMinimumValue();
//        org.joda.time.DurationField durationField10 = property6.getLeapDurationField();
//        org.joda.time.DateTimeField dateTimeField11 = property6.getField();
//        int int12 = property6.getMaximumValueOverall();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNull(durationField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 99 + "'", int12 == 99);
//    }

//    @Test
//    public void test212() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test212");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField16.getLeapDurationField();
//        org.joda.time.DurationField durationField28 = unsupportedDateTimeField16.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = unsupportedDateTimeField16.getType();
//        java.util.Locale locale31 = null;
//        try {
//            java.lang.String str32 = unsupportedDateTimeField16.getAsShortText((long) 82800, locale31);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNull(durationField27);
//        org.junit.Assert.assertNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime8.minus((long) (short) -1);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusMinutes((int) (byte) 10);
//        long long13 = dateTime12.getMillis();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1009843799989L) + "'", long13 == (-1009843799989L));
//    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int42 = dividedDateTimeField39.getDifference(1000L, (long) (byte) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        long long45 = remainderDateTimeField43.roundHalfCeiling(54L);
//        int int46 = remainderDateTimeField43.getDivisor();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-259200000L) + "'", long45 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2000 + "'", int46 == 2000);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-7));
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.append(dateTimePrinter5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendHalfdayOfDayText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap8 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap8);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder0.appendDayOfMonth(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder0.appendHourOfDay((int) (byte) 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfHour();
//        java.lang.String str7 = property6.getAsShortText();
//        org.joda.time.DateTime dateTime8 = property6.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime10 = dateTime8.plus((long) 3);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone2.adjustOffset((long) 960, true);
//        long long7 = dateTimeZone2.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology8);
//        org.joda.time.DurationField durationField10 = zonedChronology8.weekyears();
//        try {
//            long long18 = zonedChronology8.getDateTimeMillis((int) (byte) -1, (int) (byte) 100, 152, (int) (short) 10, 12, (-98), 97);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -98 for secondOfMinute must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 960L + "'", long5 == 960L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test218");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone2.adjustOffset((long) 960, true);
//        long long7 = dateTimeZone2.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology8);
//        org.joda.time.DurationField durationField10 = zonedChronology8.weekyears();
//        long long13 = durationField10.subtract((long) 85800, (long) (-28800000));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 960L + "'", long5 == 960L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 908840217600085800L + "'", long13 == 908840217600085800L);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "79200000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        long long3 = property2.remainder();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
//        int int6 = dateTime5.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay7 = dateTime5.toTimeOfDay();
//        org.joda.time.DateTime.Property property8 = dateTime5.weekOfWeekyear();
//        org.joda.time.DateTime.Property property9 = dateTime5.dayOfMonth();
//        org.joda.time.DateTime dateTime10 = property9.getDateTime();
//        int int11 = property2.compareTo((org.joda.time.ReadableInstant) dateTime10);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 42L + "'", long3 == 42L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        java.lang.String str3 = property2.getName();
        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime4.withYearOfEra(10);
        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((java.lang.Object) dateTime4);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfWeek" + "'", str3.equals("dayOfWeek"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test222");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime1.withDate(152, (int) (byte) 10, (int) (short) 1);
//        int int7 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime.Property property8 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime.Property property9 = dateTime1.secondOfMinute();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42 + "'", int2 == 42);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(property9);
//    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((-7));
//        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder3.toPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter8 = dateTimeFormatter7.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter8, dateTimeParser10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter6, dateTimeParser10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str15 = dateTimeFormatter13.print((long) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter13.withOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter13.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap19 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendTimeZoneShortName(strMap19);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder18.appendClockhourOfHalfday(2);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendDayOfWeekShortText();
//        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatterBuilder22.toParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str27 = dateTimeFormatter25.print((long) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter28 = dateTimeFormatter25.withOffsetParsed();
//        org.joda.time.format.DateTimeParser dateTimeParser29 = dateTimeFormatter25.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap31 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder32 = dateTimeFormatterBuilder30.appendTimeZoneShortName(strMap31);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder34 = dateTimeFormatterBuilder30.appendMillisOfDay((int) (short) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder36 = dateTimeFormatterBuilder34.appendHourOfHalfday(57600011);
//        org.joda.time.format.DateTimeParser dateTimeParser37 = dateTimeFormatterBuilder36.toParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendTwoDigitWeekyear((-7));
//        org.joda.time.format.DateTimePrinter dateTimePrinter41 = dateTimeFormatterBuilder38.toPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter43 = dateTimeFormatter42.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser45 = dateTimeFormatter44.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter46 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter43, dateTimeParser45);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter47 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter41, dateTimeParser45);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder48 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder48.appendTwoDigitWeekyear((-7));
//        org.joda.time.format.DateTimePrinter dateTimePrinter51 = dateTimeFormatterBuilder48.toPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter52 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter53 = dateTimeFormatter52.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter54 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser55 = dateTimeFormatter54.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter56 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter53, dateTimeParser55);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter57 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter51, dateTimeParser55);
//        org.joda.time.format.DateTimeParser[] dateTimeParserArray58 = new org.joda.time.format.DateTimeParser[] { dateTimeParser17, dateTimeParser24, dateTimeParser29, dateTimeParser37, dateTimeParser45, dateTimeParser55 };
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder2.append(dateTimePrinter6, dateTimeParserArray58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(dateTimePrinter6);
//        org.junit.Assert.assertNotNull(dateTimeFormatter7);
//        org.junit.Assert.assertNotNull(dateTimePrinter8);
//        org.junit.Assert.assertNotNull(dateTimeFormatter9);
//        org.junit.Assert.assertNotNull(dateTimeParser10);
//        org.junit.Assert.assertNotNull(dateTimeFormatter13);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970001" + "'", str15.equals("1970001"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTimeParser17);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//        org.junit.Assert.assertNotNull(dateTimeParser24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "1970001" + "'", str27.equals("1970001"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter28);
//        org.junit.Assert.assertNotNull(dateTimeParser29);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder32);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder34);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder36);
//        org.junit.Assert.assertNotNull(dateTimeParser37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimePrinter41);
//        org.junit.Assert.assertNotNull(dateTimeFormatter42);
//        org.junit.Assert.assertNotNull(dateTimePrinter43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(dateTimeParser45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//        org.junit.Assert.assertNotNull(dateTimePrinter51);
//        org.junit.Assert.assertNotNull(dateTimeFormatter52);
//        org.junit.Assert.assertNotNull(dateTimePrinter53);
//        org.junit.Assert.assertNotNull(dateTimeFormatter54);
//        org.junit.Assert.assertNotNull(dateTimeParser55);
//        org.junit.Assert.assertNotNull(dateTimeParserArray58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property5 = dateTime1.dayOfMonth();
//        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
//        org.joda.time.DateTime dateTime7 = property5.roundHalfEvenCopy();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime3 = property2.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime.Property property9 = dateTime5.dayOfYear();
//        int int10 = property9.getMaximumValue();
//        java.lang.Class<?> wildcardClass11 = property9.getClass();
//        org.joda.time.DateTime dateTime13 = property9.addToCopy(23);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(dateTime13);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (short) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("16:00:00.100");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfHour((int) (byte) 0);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTimeZoneShortName(strMap12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendClockhourOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property18 = dateTime17.dayOfWeek();
//        int int19 = dateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime21 = dateTime17.withZone(dateTimeZone20);
//        org.joda.time.DateTime.Property property22 = dateTime21.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
//        int int27 = dateTime25.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime29 = dateTime25.withZone(dateTimeZone28);
//        org.joda.time.DateTime.Property property30 = dateTime29.yearOfCentury();
//        org.joda.time.DurationField durationField31 = property30.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField31);
//        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
//        java.lang.String str34 = unsupportedDateTimeField32.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField32.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder15.appendDecimal(dateTimeFieldType35, (int) ' ', 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder8.appendFixedSignedDecimal(dateTimeFieldType35, (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder8.appendFractionOfDay(0, 150);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
//        org.junit.Assert.assertNull(durationField33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "yearOfCentury" + "'", str34.equals("yearOfCentury"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test230");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = unsupportedDateTimeField16.getType();
//        try {
//            int int22 = unsupportedDateTimeField16.getMaximumValue(57600000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        boolean boolean4 = dateTime2.isSupported(dateTimeFieldType3);
        org.joda.time.DateTime dateTime6 = dateTime2.plusWeeks((int) (byte) 10);
        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.util.Locale locale9 = dateTimeFormatter8.getLocale();
        java.lang.String str10 = dateTime2.toString(dateTimeFormatter8);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.parse("54000000", dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNull(locale9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1970" + "'", str10.equals("1970"));
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.DurationField durationField2 = iSOChronology0.minutes();
        long long7 = iSOChronology0.getDateTimeMillis(0, 9, 16, 97);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-62144841599903L) + "'", long7 == (-62144841599903L));
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("150");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"150/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@10b28f30");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
//        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfSecond((int) (short) 1);
//        int int6 = dateTime3.getYearOfEra();
//        org.joda.time.DateTime dateTime8 = dateTime3.withYear((int) '#');
//        int int9 = dateTime8.getMillisOfSecond();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone15 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        long long17 = dateTimeZone10.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone15, 1L);
//        org.joda.time.DateTime dateTime18 = dateTime8.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone15);
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property21 = dateTime20.dayOfWeek();
//        int int22 = dateTime20.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime24 = dateTime20.withZone(dateTimeZone23);
//        org.joda.time.DateTime.Property property25 = dateTime24.yearOfCentury();
//        org.joda.time.DurationField durationField26 = property25.getDurationField();
//        boolean boolean27 = org.joda.time.field.FieldUtils.equals((java.lang.Object) fixedDateTimeZone15, (java.lang.Object) property25);
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property25.getFieldType();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 33L + "'", long17 == 33L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        int int29 = zeroIsMaxDateTimeField27.getMinimumValue(28799999L);
//        java.lang.String str30 = zeroIsMaxDateTimeField27.getName();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "yearOfCentury" + "'", str30.equals("yearOfCentury"));
//    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsShortText(9600L);
//        long long17 = offsetDateTimeField12.getDifferenceAsLong(28800097L, (long) 960);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField12.getLeapDurationField();
//        org.joda.time.DateTime dateTime20 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property21 = dateTime20.dayOfWeek();
//        java.lang.String str22 = property21.getName();
//        org.joda.time.DateTime dateTime23 = property21.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime25 = dateTime23.withMillis((long) (byte) 0);
//        org.joda.time.LocalDateTime localDateTime26 = dateTime25.toLocalDateTime();
//        int int27 = offsetDateTimeField12.getMaximumValue((org.joda.time.ReadablePartial) localDateTime26);
//        long long30 = offsetDateTimeField12.add((long) ' ', (int) '4');
//        org.joda.time.ReadablePartial readablePartial31 = null;
//        java.util.Locale locale32 = null;
//        try {
//            java.lang.String str33 = offsetDateTimeField12.getAsText(readablePartial31, locale32);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertNull(durationField18);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "dayOfWeek" + "'", str22.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(localDateTime26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 150 + "'", int27 == 150);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 31449600032L + "'", long30 == 31449600032L);
//    }

//    @Test
//    public void test237() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test237");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        boolean boolean3 = dateTime1.isSupported(dateTimeFieldType2);
//        org.joda.time.DateTime dateTime5 = dateTime1.plusWeeks((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = dateTime1.minus((long) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime1.minusMinutes(57600);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime1.withDurationAdded(readableDuration10, (int) ' ');
//        int int13 = dateTime1.getDayOfWeek();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = dateTime1.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime dateTime5 = dateTime1.plusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime1.minus((long) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime1.minusMinutes(57600);
        org.joda.time.DateTime dateTime10 = dateTime9.withLaterOffsetAtOverlap();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        boolean boolean2 = dateTimeFormatter0.isPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 59);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsText(28800097L);
//        long long17 = offsetDateTimeField12.addWrapField((long) (-28799999), (int) (short) -1);
//        long long19 = offsetDateTimeField12.roundHalfFloor((long) 31);
//        try {
//            long long22 = offsetDateTimeField12.add(28800000L, 25401600152L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 25401600152 * 604800000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31420800001L + "'", long17 == 31420800001L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-259200000L) + "'", long19 == (-259200000L));
//    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone2.adjustOffset((long) 960, true);
//        long long7 = dateTimeZone2.convertUTCToLocal((long) (short) -1);
//        long long9 = dateTimeZone1.getMillisKeepLocal(dateTimeZone2, (long) 69);
//        java.lang.String str11 = dateTimeZone2.getName((long) 15);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 960L + "'", long5 == 960L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 31L + "'", long7 == 31L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-3599963L) + "'", long9 == (-3599963L));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.032" + "'", str11.equals("+00:00:00.032"));
//    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime(chronology3);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfWeek();
//        java.lang.String str8 = property7.getName();
//        org.joda.time.DateTime dateTime9 = property7.roundHalfFloorCopy();
//        long long10 = property7.remainder();
//        boolean boolean11 = dateTime4.equals((java.lang.Object) property7);
//        java.util.Locale locale13 = null;
//        try {
//            org.joda.time.DateTime dateTime14 = property7.setCopy("PST", locale13);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PST\" for dayOfWeek is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "dayOfWeek" + "'", str8.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 42L + "'", long10 == 42L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test243");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        boolean boolean3 = dateTime1.isSupported(dateTimeFieldType2);
//        org.joda.time.DateTime dateTime5 = dateTime1.plusWeeks((int) (byte) 10);
//        org.joda.time.DateTime dateTime7 = dateTime1.minus((long) (short) 1);
//        org.joda.time.DateTime dateTime9 = dateTime1.minusMinutes(57600);
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        long long13 = dateTimeZone10.adjustOffset((long) 960, true);
//        java.lang.String str15 = dateTimeZone10.getName((long) (short) 100);
//        long long18 = dateTimeZone10.convertLocalToUTC((long) 'a', true);
//        org.joda.time.DateTime dateTime19 = dateTime9.toDateTime(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 960L + "'", long13 == 960L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "+00:00:00.032" + "'", str15.equals("+00:00:00.032"));
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 65L + "'", long18 == 65L);
//        org.junit.Assert.assertNotNull(dateTime19);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(86400000, (int) (byte) 1, (int) (short) 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("dayOfWeek");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        boolean boolean7 = dateTime5.isSupported(dateTimeFieldType6);
        org.joda.time.DateTime dateTime9 = dateTime5.plusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime5.minus((long) (short) 1);
        int int12 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.plusSeconds(960);
        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime11.toDateTime();
        try {
            org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfSecond(28800);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 28800 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime16);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        org.joda.time.DurationField durationField23 = unsupportedDateTimeField16.getRangeDurationField();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
//        java.lang.String str27 = property26.getName();
//        org.joda.time.DateTime dateTime28 = property26.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime30 = dateTime28.withMillis((long) (byte) 0);
//        org.joda.time.LocalDateTime localDateTime31 = dateTime30.toLocalDateTime();
//        int[] intArray36 = new int[] { 42, (byte) 0, 150, (-25200000) };
//        try {
//            int int37 = unsupportedDateTimeField16.getMaximumValue((org.joda.time.ReadablePartial) localDateTime31, intArray36);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNull(durationField23);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "dayOfWeek" + "'", str27.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(localDateTime31);
//        org.junit.Assert.assertNotNull(intArray36);
//    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField16.getRangeDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology28 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField29 = iSOChronology28.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology28.weekOfWeekyear();
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property33 = dateTime32.dayOfWeek();
//        int int34 = dateTime32.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime36 = dateTime32.withZone(dateTimeZone35);
//        org.joda.time.DateTime.Property property37 = dateTime36.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = property37.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, dateTimeFieldType38, (int) 'a');
//        java.lang.String str42 = offsetDateTimeField40.getAsShortText(9600L);
//        long long45 = offsetDateTimeField40.getDifferenceAsLong(28800097L, (long) 960);
//        org.joda.time.DurationField durationField46 = offsetDateTimeField40.getLeapDurationField();
//        org.joda.time.chrono.ISOChronology iSOChronology47 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField48 = iSOChronology47.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField49 = iSOChronology47.weekOfWeekyear();
//        org.joda.time.DateTime dateTime51 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property52 = dateTime51.dayOfWeek();
//        int int53 = dateTime51.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime55 = dateTime51.withZone(dateTimeZone54);
//        org.joda.time.DateTime.Property property56 = dateTime55.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType57 = property56.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField59 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, dateTimeFieldType57, (int) 'a');
//        org.joda.time.DateTime dateTime61 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property62 = dateTime61.dayOfWeek();
//        java.lang.String str63 = property62.getName();
//        org.joda.time.DateTime dateTime64 = property62.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime66 = dateTime64.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass67 = dateTime64.getClass();
//        org.joda.time.YearMonthDay yearMonthDay68 = dateTime64.toYearMonthDay();
//        java.util.Locale locale70 = null;
//        java.lang.String str71 = offsetDateTimeField59.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay68, 3, locale70);
//        int int72 = offsetDateTimeField40.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay68);
//        int[] intArray80 = new int[] { 0, 86400000, 82800010, (short) 100, 100, 52 };
//        try {
//            int[] intArray82 = unsupportedDateTimeField16.addWrapPartial((org.joda.time.ReadablePartial) yearMonthDay68, 10, intArray80, 52);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNull(durationField27);
//        org.junit.Assert.assertNotNull(iSOChronology28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "98" + "'", str42.equals("98"));
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
//        org.junit.Assert.assertNull(durationField46);
//        org.junit.Assert.assertNotNull(iSOChronology47);
//        org.junit.Assert.assertNotNull(dateTimeField48);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertNotNull(dateTimeFieldType57);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "dayOfWeek" + "'", str63.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime64);
//        org.junit.Assert.assertNotNull(dateTime66);
//        org.junit.Assert.assertNotNull(wildcardClass67);
//        org.junit.Assert.assertNotNull(yearMonthDay68);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "3" + "'", str71.equals("3"));
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 98 + "'", int72 == 98);
//        org.junit.Assert.assertNotNull(intArray80);
//    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-7));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendFractionOfDay((int) (short) 10, (int) (short) -1);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfWeek();
//        int int9 = dateTime7.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime11 = dateTime7.withZone(dateTimeZone10);
//        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType13 = property12.getFieldType();
//        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property16 = dateTime15.dayOfWeek();
//        int int17 = dateTime15.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = dateTime15.withZone(dateTimeZone18);
//        org.joda.time.DateTime.Property property20 = dateTime19.yearOfCentury();
//        org.joda.time.DurationField durationField21 = property20.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField22 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType13, durationField21);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder5.appendSignedDecimal(dateTimeFieldType13, 0, 7);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder25.appendMonthOfYearShortText();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeFieldType13);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(durationField21);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField22);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.dayOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.centuryOfEra();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicDateTime();
        boolean boolean6 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter5);
        org.joda.time.DurationField durationField7 = iSOChronology0.hours();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(durationField7);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime8 = property6.withMaximumValue();
//        org.joda.time.DateTime dateTime9 = property6.withMinimumValue();
//        org.joda.time.DateTime dateTime11 = dateTime9.minus((long) 'a');
//        org.joda.time.DateTime dateTime12 = dateTime9.withTimeAtStartOfDay();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test251");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTimeISO();
//        int int7 = dateTime6.getYearOfEra();
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime6.toCalendar(locale8);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusWeeks(23);
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime6.withDate(0, 57600011, 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 57600011 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1970 + "'", int7 == 1970);
//        org.junit.Assert.assertNotNull(calendar9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property5 = dateTime1.dayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.withMillisOfSecond((int) (short) 100);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.withChronology(chronology8);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test253");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime1.era();
//        org.joda.time.Chronology chronology4 = dateTime1.getChronology();
//        int int5 = dateTime1.getDayOfMonth();
//        org.joda.time.DateTime dateTime7 = dateTime1.plusMinutes(0);
//        org.joda.time.DateTime.Property property8 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime9 = dateTime1.toDateTime();
//        org.joda.time.DateTime.Property property10 = dateTime1.era();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        long long4 = dateTimeZone1.convertLocalToUTC((-1L), false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone1);
//        org.joda.time.DurationField durationField7 = zonedChronology6.weeks();
//        org.joda.time.DateTimeField dateTimeField8 = zonedChronology6.monthOfYear();
//        java.lang.Object obj9 = null;
//        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) zonedChronology6, obj9);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-33L) + "'", long4 == (-33L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
//        org.junit.Assert.assertNotNull(zonedChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeField8);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test255");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime8.minus((long) (short) -1);
//        org.joda.time.DateTime.Property property11 = dateTime8.monthOfYear();
//        org.joda.time.DateTime dateTime13 = dateTime8.withCenturyOfEra(1);
//        boolean boolean15 = dateTime13.isBefore((-33L));
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test256");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (short) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("16:00:00.100");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfHour((int) (byte) 0);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap9 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap9);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap12 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendTimeZoneShortName(strMap12);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder11.appendClockhourOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property18 = dateTime17.dayOfWeek();
//        int int19 = dateTime17.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime21 = dateTime17.withZone(dateTimeZone20);
//        org.joda.time.DateTime.Property property22 = dateTime21.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = property22.getFieldType();
//        org.joda.time.DateTime dateTime25 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property26 = dateTime25.dayOfWeek();
//        int int27 = dateTime25.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime29 = dateTime25.withZone(dateTimeZone28);
//        org.joda.time.DateTime.Property property30 = dateTime29.yearOfCentury();
//        org.joda.time.DurationField durationField31 = property30.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField32 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType23, durationField31);
//        org.joda.time.DurationField durationField33 = unsupportedDateTimeField32.getRangeDurationField();
//        java.lang.String str34 = unsupportedDateTimeField32.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = unsupportedDateTimeField32.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = dateTimeFormatterBuilder15.appendDecimal(dateTimeFieldType35, (int) ' ', 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder8.appendFixedSignedDecimal(dateTimeFieldType35, (int) (byte) 1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder42 = dateTimeFormatterBuilder40.appendDayOfMonth(59);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField32);
//        org.junit.Assert.assertNull(durationField33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "yearOfCentury" + "'", str34.equals("yearOfCentury"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder38);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder42);
//    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
//        int int7 = dateTime5.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime9 = dateTime5.withZone(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.Chronology chronology11 = gregorianChronology10.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DurationField durationField13 = gregorianChronology10.seconds();
//        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology10.getZone();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970001" + "'", str2.equals("1970001"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.millisOfDay();
//        org.joda.time.DateTime dateTime27 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property28 = dateTime27.dayOfWeek();
//        org.joda.time.DateTime dateTime30 = property28.addToCopy(152);
//        org.joda.time.DateTime dateTime32 = property28.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime34 = dateTime32.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology35 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField36 = iSOChronology35.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology35.weekOfWeekyear();
//        org.joda.time.DateTime dateTime39 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property40 = dateTime39.dayOfWeek();
//        int int41 = dateTime39.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime43 = dateTime39.withZone(dateTimeZone42);
//        org.joda.time.DateTime.Property property44 = dateTime43.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType45 = property44.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, dateTimeFieldType45, (int) 'a');
//        org.joda.time.DateTime dateTime49 = dateTime34.withField(dateTimeFieldType45, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField50 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField25, dateTimeFieldType45);
//        int int51 = zeroIsMaxDateTimeField50.getMinimumValue();
//        java.util.Locale locale53 = null;
//        java.lang.String str54 = zeroIsMaxDateTimeField50.getAsShortText((long) (-28800000), locale53);
//        org.joda.time.DateTime dateTime56 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property57 = dateTime56.dayOfWeek();
//        org.joda.time.DateTime.Property property58 = dateTime56.era();
//        org.joda.time.ReadableDuration readableDuration59 = null;
//        org.joda.time.DateTime dateTime60 = dateTime56.plus(readableDuration59);
//        org.joda.time.LocalTime localTime61 = dateTime56.toLocalTime();
//        int int62 = zeroIsMaxDateTimeField50.getMinimumValue((org.joda.time.ReadablePartial) localTime61);
//        java.util.Locale locale63 = null;
//        try {
//            java.lang.String str64 = unsupportedDateTimeField16.getAsText((org.joda.time.ReadablePartial) localTime61, locale63);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertNotNull(gregorianChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(iSOChronology35);
//        org.junit.Assert.assertNotNull(dateTimeField36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTimeFieldType45);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "57600032" + "'", str54.equals("57600032"));
//        org.junit.Assert.assertNotNull(property57);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(localTime61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField7 = iSOChronology6.weekyears();
        boolean boolean9 = iSOChronology6.equals((java.lang.Object) 960L);
        try {
            org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(16, 57600011, 960, 59, 57600011, 1970, (org.joda.time.Chronology) iSOChronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 59 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = unsupportedDateTimeField16.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) 23, (java.lang.Number) 31532400010L, (java.lang.Number) 345600000L);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (-28799901L), "1970001");
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsShortText(9600L);
//        long long16 = offsetDateTimeField12.roundHalfFloor((long) 28800);
//        long long19 = offsetDateTimeField12.getDifferenceAsLong((long) 99, (long) 19);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
//        java.lang.String str18 = unsupportedDateTimeField16.toString();
//        org.joda.time.DurationField durationField19 = unsupportedDateTimeField16.getDurationField();
//        try {
//            long long22 = unsupportedDateTimeField16.add((-28799999L), (-3600000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -359998031 for year must be in the range [-292275054,292278993]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "UnsupportedDateTimeField" + "'", str18.equals("UnsupportedDateTimeField"));
//        org.junit.Assert.assertNotNull(durationField19);
//    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
//        java.lang.String str18 = unsupportedDateTimeField16.getName();
//        long long21 = unsupportedDateTimeField16.add(28800139L, 0L);
//        long long24 = unsupportedDateTimeField16.add((long) (byte) 100, 52L);
//        try {
//            long long27 = unsupportedDateTimeField16.set((long) (short) 10, 86400000);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfCentury" + "'", str18.equals("yearOfCentury"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800139L + "'", long21 == 28800139L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 164096150400100L + "'", long24 == 164096150400100L);
//    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test264");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHours((-1));
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long6 = dateTimeZone3.adjustOffset((long) 960, true);
//        long long8 = dateTimeZone3.convertUTCToLocal((long) (short) -1);
//        long long10 = dateTimeZone2.getMillisKeepLocal(dateTimeZone3, (long) 69);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) 'a', dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 960L + "'", long6 == 960L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 31L + "'", long8 == 31L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-3599963L) + "'", long10 == (-3599963L));
//    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime dateTime4 = property2.addToCopy(152);
//        org.joda.time.DateTime dateTime6 = property2.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField11 = iSOChronology9.weekOfWeekyear();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property14 = dateTime13.dayOfWeek();
//        int int15 = dateTime13.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime17 = dateTime13.withZone(dateTimeZone16);
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = property18.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, dateTimeFieldType19, (int) 'a');
//        org.joda.time.DateTime dateTime23 = dateTime8.withField(dateTimeFieldType19, 15);
//        org.joda.time.DateTime dateTime25 = dateTime23.minusDays(100);
//        org.joda.time.DateTime dateTime27 = dateTime23.minusWeeks(1970);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(iSOChronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((int) ' ');
        long long5 = dateTimeZone1.convertLocalToUTC((long) ' ', false, (long) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
//        java.lang.String str18 = unsupportedDateTimeField16.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType19 = unsupportedDateTimeField16.getType();
//        java.lang.String str20 = unsupportedDateTimeField16.getName();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property24 = dateTime23.dayOfWeek();
//        java.lang.String str25 = property24.getName();
//        org.joda.time.DateTime dateTime26 = property24.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime28 = dateTime26.withMillis((long) (byte) 0);
//        org.joda.time.LocalDateTime localDateTime29 = dateTime28.toLocalDateTime();
//        java.lang.String str30 = dateTimeFormatter21.print((org.joda.time.ReadablePartial) localDateTime29);
//        int[] intArray34 = new int[] { (byte) 0, 960 };
//        try {
//            int[] intArray36 = unsupportedDateTimeField16.addWrapPartial((org.joda.time.ReadablePartial) localDateTime29, 19, intArray34, (-7));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfCentury" + "'", str18.equals("yearOfCentury"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "yearOfCentury" + "'", str20.equals("yearOfCentury"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "dayOfWeek" + "'", str25.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(localDateTime29);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "00:00:00.032" + "'", str30.equals("00:00:00.032"));
//        org.junit.Assert.assertNotNull(intArray34);
//    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        java.util.Locale locale25 = null;
//        try {
//            java.lang.String str26 = unsupportedDateTimeField16.getAsText(readablePartial23, 2000, locale25);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
//        int int7 = dateTime5.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime9 = dateTime5.withZone(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.Chronology chronology11 = gregorianChronology10.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DurationField durationField13 = gregorianChronology10.seconds();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology10.millisOfSecond();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970001" + "'", str2.equals("1970001"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(7, 365);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2555 + "'", int2 == 2555);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime8.minus((long) (short) -1);
//        int int11 = dateTime10.getDayOfMonth();
//        org.joda.time.Instant instant12 = dateTime10.toInstant();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertNotNull(instant12);
//    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test272");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
//        int int7 = dateTime5.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime9 = dateTime5.withZone(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.Chronology chronology11 = gregorianChronology10.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DurationField durationField13 = gregorianChronology10.seconds();
//        org.joda.time.DurationField durationField14 = gregorianChronology10.millis();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970001" + "'", str2.equals("1970001"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(durationField13);
//        org.junit.Assert.assertNotNull(durationField14);
//    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField16.getLeapDurationField();
//        org.joda.time.DurationField durationField28 = unsupportedDateTimeField16.getRangeDurationField();
//        org.joda.time.DateTimeFieldType dateTimeFieldType29 = unsupportedDateTimeField16.getType();
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        int[] intArray32 = null;
//        java.util.Locale locale34 = null;
//        try {
//            int[] intArray35 = unsupportedDateTimeField16.set(readablePartial30, 57600011, intArray32, "54000000", locale34);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNull(durationField27);
//        org.junit.Assert.assertNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeFieldType29);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendHourOfHalfday(57600011);
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatterBuilder6.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfWeekShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test275");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property4 = dateTime3.dayOfWeek();
//        org.joda.time.DateTime dateTime5 = property4.roundCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod6 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.withPeriodAdded(readablePeriod6, (int) (byte) 1);
//        org.joda.time.DateTime dateTime10 = dateTime8.plusDays(0);
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) 10);
//        int int13 = dateTime12.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay14 = dateTime12.toTimeOfDay();
//        org.joda.time.DateTime dateTime15 = dateTime10.withFields((org.joda.time.ReadablePartial) timeOfDay14);
//        java.lang.String str16 = dateTimeFormatter1.print((org.joda.time.ReadablePartial) timeOfDay14);
//        java.lang.Integer int17 = dateTimeFormatter1.getPivotYear();
//        boolean boolean18 = gregorianChronology0.equals((java.lang.Object) dateTimeFormatter1);
//        java.lang.String str19 = gregorianChronology0.toString();
//        org.joda.time.DurationField durationField20 = gregorianChronology0.years();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "����-W��-�" + "'", str16.equals("����-W��-�"));
//        org.junit.Assert.assertNull(int17);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "GregorianChronology[+00:00:00.032]" + "'", str19.equals("GregorianChronology[+00:00:00.032]"));
//        org.junit.Assert.assertNotNull(durationField20);
//    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        long long29 = zeroIsMaxDateTimeField27.roundHalfCeiling((long) (-28799997));
//        long long31 = zeroIsMaxDateTimeField27.roundHalfFloor((long) (-25200000));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-28799997L) + "'", long29 == (-28799997L));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-25200000L) + "'", long31 == (-25200000L));
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusDays(0);
//        int int9 = dateTime6.getDayOfYear();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone5 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
        java.lang.Object obj6 = null;
        boolean boolean7 = fixedDateTimeZone5.equals(obj6);
        long long9 = fixedDateTimeZone5.nextTransition(1000L);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(0L, (org.joda.time.DateTimeZone) fixedDateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1000L + "'", long9 == 1000L);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.DateTime dateTime4 = dateTime1.toDateTime(chronology3);
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfWeek();
//        java.lang.String str8 = property7.getName();
//        org.joda.time.DateTime dateTime9 = property7.roundHalfFloorCopy();
//        long long10 = property7.remainder();
//        boolean boolean11 = dateTime4.equals((java.lang.Object) property7);
//        java.lang.String str12 = property7.getAsShortText();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "dayOfWeek" + "'", str8.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 42L + "'", long10 == 42L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Thu" + "'", str12.equals("Thu"));
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone2.adjustOffset((long) 960, true);
//        long long7 = dateTimeZone2.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology8.weekyearOfCentury();
//        org.joda.time.DurationField durationField12 = zonedChronology8.months();
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        int[] intArray18 = new int[] { 98, (-1), '#', (byte) -1 };
//        try {
//            zonedChronology8.validate(readablePartial13, intArray18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 960L + "'", long5 == 960L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(intArray18);
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
//        boolean boolean4 = dateTime2.isSupported(dateTimeFieldType3);
//        org.joda.time.DateTime dateTime6 = dateTime2.plusWeeks((int) (byte) 10);
//        java.lang.String str7 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime6);
//        long long8 = dateTime6.getMillis();
//        org.joda.time.DateTime dateTime10 = dateTime6.withWeekyear((int) (byte) -1);
//        try {
//            org.joda.time.DateTime dateTime15 = dateTime10.withTime(9, 2000, 99, 12);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-071T00:00:00+00:00:00.032" + "'", str7.equals("1970-071T00:00:00+00:00:00.032"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 6048000010L + "'", long8 == 6048000010L);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

//    @Test
//    public void test282() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test282");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsText(28800097L);
//        long long16 = offsetDateTimeField12.roundHalfFloor((-25200038L));
//        int int17 = offsetDateTimeField12.getOffset();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
//    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
//        boolean boolean3 = iSOChronology0.equals((java.lang.Object) 960L);
//        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
//        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField6 = iSOChronology5.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        long long10 = dateTimeZone7.adjustOffset((long) 960, true);
//        long long12 = dateTimeZone7.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology5, dateTimeZone7);
//        org.joda.time.Chronology chronology14 = iSOChronology0.withZone(dateTimeZone7);
//        org.joda.time.DurationField durationField15 = iSOChronology0.seconds();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(iSOChronology5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 960L + "'", long10 == 960L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 32L + "'", long12 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        long long3 = property2.remainder();
//        java.util.Locale locale4 = null;
//        java.lang.String str5 = property2.getAsShortText(locale4);
//        org.joda.time.DateTime dateTime6 = property2.withMaximumValue();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 42L + "'", long3 == 42L);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Thu" + "'", str5.equals("Thu"));
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.centuryOfEra();
        org.joda.time.DurationField durationField3 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test286");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology7 = gregorianChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology6.days();
//        java.lang.String str9 = gregorianChronology6.toString();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((-1));
//        long long13 = dateTimeZone11.convertUTCToLocal((long) 1);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone11);
//        org.joda.time.DateTimeField dateTimeField15 = zonedChronology14.weekyear();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[+00:00:00.032]" + "'", str9.equals("GregorianChronology[+00:00:00.032]"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-3599999L) + "'", long13 == (-3599999L));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        boolean boolean10 = dateTime8.isSupported(dateTimeFieldType9);
//        org.joda.time.DateTime dateTime12 = dateTime8.plusWeeks((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = dateTime8.minus((long) (short) 1);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property25 = dateTime24.dayOfWeek();
//        int int26 = dateTime24.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime28 = dateTime24.withZone(dateTimeZone27);
//        org.joda.time.DateTime.Property property29 = dateTime28.yearOfCentury();
//        org.joda.time.DurationField durationField30 = property29.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField30);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType22, 31, (int) (byte) 1, 365);
//        org.joda.time.DateTime.Property property36 = dateTime8.property(dateTimeFieldType22);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType22);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendTwoDigitWeekyear((-7));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder38.appendFractionOfDay((int) (short) 10, (int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser45 = dateTimeFormatter44.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder38.append(dateTimeParser45);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder4.appendOptional(dateTimeParser45);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder4.appendLiteral(' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder50 = dateTimeFormatterBuilder4.appendTimeZoneShortName();
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(dateTimeParser45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder50);
//    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test288");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        int int29 = zeroIsMaxDateTimeField27.getMinimumValue(28799999L);
//        int int31 = zeroIsMaxDateTimeField27.getMaximumValue(0L);
//        long long33 = zeroIsMaxDateTimeField27.roundFloor((long) '4');
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property36 = dateTime35.dayOfWeek();
//        int int37 = dateTime35.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime39 = dateTime35.withZone(dateTimeZone38);
//        org.joda.time.DateTime.Property property40 = dateTime39.yearOfCentury();
//        org.joda.time.DateTime dateTime42 = dateTime39.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime44 = dateTime42.minus((long) (short) -1);
//        org.joda.time.DateTime.Property property45 = dateTime42.monthOfYear();
//        org.joda.time.YearMonthDay yearMonthDay46 = dateTime42.toYearMonthDay();
//        int int47 = zeroIsMaxDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay46);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 86400000 + "'", int31 == 86400000);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 52L + "'", long33 == 52L);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(yearMonthDay46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
//    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.convertLocalToUTC((-1L), false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        int int6 = cachedDateTimeZone4.getOffset((long) 7);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        long long10 = dateTimeZone7.adjustOffset((long) 960, true);
//        java.lang.String str12 = dateTimeZone7.getName((long) (short) 100);
//        boolean boolean13 = cachedDateTimeZone4.equals((java.lang.Object) str12);
//        boolean boolean14 = cachedDateTimeZone4.isFixed();
//        long long16 = cachedDateTimeZone4.nextTransition((long) (short) 10);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-33L) + "'", long3 == (-33L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 960L + "'", long10 == 960L);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "+00:00:00.032" + "'", str12.equals("+00:00:00.032"));
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
//    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test290");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology24.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.millisOfDay();
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property29 = dateTime28.dayOfWeek();
//        org.joda.time.DateTime dateTime31 = property29.addToCopy(152);
//        org.joda.time.DateTime dateTime33 = property29.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime35 = dateTime33.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField38 = iSOChronology36.weekOfWeekyear();
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property41 = dateTime40.dayOfWeek();
//        int int42 = dateTime40.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime44 = dateTime40.withZone(dateTimeZone43);
//        org.joda.time.DateTime.Property property45 = dateTime44.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType46 = property45.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, dateTimeFieldType46, (int) 'a');
//        org.joda.time.DateTime dateTime50 = dateTime35.withField(dateTimeFieldType46, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField51 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField26, dateTimeFieldType46);
//        int int53 = zeroIsMaxDateTimeField51.getMinimumValue(28799999L);
//        long long55 = zeroIsMaxDateTimeField51.roundCeiling((long) ' ');
//        org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property58 = dateTime57.dayOfWeek();
//        int int59 = dateTime57.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime61 = dateTime57.withZone(dateTimeZone60);
//        org.joda.time.DateTime.Property property62 = dateTime57.minuteOfHour();
//        org.joda.time.TimeOfDay timeOfDay63 = dateTime57.toTimeOfDay();
//        int int64 = zeroIsMaxDateTimeField51.getMaximumValue((org.joda.time.ReadablePartial) timeOfDay63);
//        int[] intArray68 = new int[] { 42, 10 };
//        try {
//            int[] intArray70 = unsupportedDateTimeField16.set((org.joda.time.ReadablePartial) timeOfDay63, 0, intArray68, 2555);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertNotNull(dateTimeField25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(iSOChronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertNotNull(dateTimeFieldType46);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 32L + "'", long55 == 32L);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone60);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(property62);
//        org.junit.Assert.assertNotNull(timeOfDay63);
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 86400000 + "'", int64 == 86400000);
//        org.junit.Assert.assertNotNull(intArray68);
//    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property4 = dateTime3.dayOfWeek();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy(152);
//        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy((int) (byte) 0);
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime8.withDurationAdded(readableDuration10, (-3600000));
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime8.minus(readablePeriod13);
//        java.util.Locale locale16 = null;
//        try {
//            java.lang.String str17 = dateTime14.toString("ZonedChronology[ISOChronology[UTC], +00:00:00.032]", locale16);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: o");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimePrinter1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T000000.042+0000" + "'", str9.equals("T000000.042+0000"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField16.getRangeDurationField();
//        try {
//            long long29 = unsupportedDateTimeField16.remainder((long) 1970);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNull(durationField27);
//    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime8.minus((long) (short) -1);
//        org.joda.time.DateTime.Property property11 = dateTime8.monthOfYear();
//        org.joda.time.DateTime dateTime12 = property11.withMaximumValue();
//        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(152);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        java.lang.String str18 = property17.getName();
//        org.joda.time.DateTime dateTime19 = property17.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime21 = dateTime19.withMillis((long) (byte) 0);
//        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime14, (org.joda.time.ReadableInstant) dateTime21);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "dayOfWeek" + "'", str18.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(chronology22);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
        try {
            long long4 = dateTimeFormatter2.parseMillis("GregorianChronology[-01:00]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"GregorianChronology[-01:00]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        java.lang.String str3 = property2.getName();
        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime4.minusSeconds((int) (byte) 1);
        org.joda.time.DateTime dateTime9 = dateTime4.withTimeAtStartOfDay();
        int int10 = dateTime4.getDayOfWeek();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfWeek" + "'", str3.equals("dayOfWeek"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test296");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone31 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        int int33 = fixedDateTimeZone31.getOffset((long) (short) 100);
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (short) 10);
//        int int36 = dateTime35.getMinuteOfDay();
//        org.joda.time.Chronology chronology37 = null;
//        org.joda.time.DateTime dateTime38 = dateTime35.toDateTime(chronology37);
//        org.joda.time.LocalDateTime localDateTime39 = dateTime38.toLocalDateTime();
//        boolean boolean40 = fixedDateTimeZone31.isLocalDateTimeGap(localDateTime39);
//        int[] intArray43 = new int[] { (-1) };
//        try {
//            int[] intArray45 = unsupportedDateTimeField16.addWrapPartial((org.joda.time.ReadablePartial) localDateTime39, 1970, intArray43, 960);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(localDateTime39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(intArray43);
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (long) 28800);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int40 = dividedDateTimeField39.getMaximumValue();
//        int int41 = dividedDateTimeField39.getDivisor();
//        int int42 = dividedDateTimeField39.getMaximumValue();
//        int int44 = dividedDateTimeField39.getLeapAmount((long) 152);
//        long long47 = dividedDateTimeField39.add((long) 31, (long) 9);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2000 + "'", int41 == 2000);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 10886400000031L + "'", long47 == 10886400000031L);
//    }

//    @Test
//    public void test299() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test299");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfHour();
//        java.lang.String str7 = property6.getAsShortText();
//        java.lang.String str8 = property6.getAsShortText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property6.getFieldType();
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property12 = dateTime11.dayOfWeek();
//        org.joda.time.DateTime.Property property13 = dateTime11.era();
//        org.joda.time.ReadableDuration readableDuration14 = null;
//        org.joda.time.DateTime dateTime15 = dateTime11.plus(readableDuration14);
//        org.joda.time.DateTime dateTime17 = dateTime11.plusMonths(31);
//        int int18 = property6.getDifference((org.joda.time.ReadableInstant) dateTime11);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType9);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-7));
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendMinuteOfHour(82800);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test301");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfHour();
//        java.lang.String str7 = property6.getAsShortText();
//        org.joda.time.DateTime dateTime8 = property6.roundHalfFloorCopy();
//        int int9 = dateTime8.getDayOfWeek();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "0" + "'", str7.equals("0"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone2.adjustOffset((long) 960, true);
//        long long7 = dateTimeZone2.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology8);
//        org.joda.time.DurationField durationField10 = zonedChronology8.eras();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 960L + "'", long5 == 960L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(durationField10);
//    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.convertLocalToUTC((-1L), false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        int int6 = cachedDateTimeZone4.getOffsetFromLocal((long) (short) -1);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-33L) + "'", long3 == (-33L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = unsupportedDateTimeField16.getType();
//        try {
//            long long29 = unsupportedDateTimeField16.roundCeiling(0L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (byte) 10, 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        long long29 = zeroIsMaxDateTimeField27.roundHalfCeiling((long) 1);
//        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField31 = iSOChronology30.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        long long35 = dateTimeZone32.adjustOffset((long) 960, true);
//        long long37 = dateTimeZone32.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology38 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology30, dateTimeZone32);
//        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property41 = dateTime40.dayOfWeek();
//        java.lang.String str42 = property41.getName();
//        org.joda.time.DateTime dateTime43 = property41.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime45 = dateTime43.withMillis((long) (byte) 0);
//        org.joda.time.LocalDateTime localDateTime46 = dateTime45.toLocalDateTime();
//        boolean boolean47 = dateTimeZone32.isLocalDateTimeGap(localDateTime46);
//        int[] intArray52 = new int[] { 19, 'a', 152 };
//        try {
//            int[] intArray54 = zeroIsMaxDateTimeField27.set((org.joda.time.ReadablePartial) localDateTime46, (-98), intArray52, 97);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -98");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
//        org.junit.Assert.assertNotNull(iSOChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 960L + "'", long35 == 960L);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 32L + "'", long37 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology38);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "dayOfWeek" + "'", str42.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(localDateTime46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(intArray52);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        org.joda.time.DateTime.Property property4 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime6 = dateTime1.plus((long) (-3600000));
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        org.joda.time.DateTime dateTime9 = dateTime6.plus(164096150400100L);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
//        int int7 = dateTime5.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime9 = dateTime5.withZone(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.Chronology chronology11 = gregorianChronology10.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology10);
//        try {
//            org.joda.time.LocalDate localDate14 = dateTimeFormatter12.parseLocalDate("16");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"16\" is too short");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970001" + "'", str2.equals("1970001"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsShortText(9600L);
//        long long16 = offsetDateTimeField12.roundHalfFloor((long) 28800);
//        long long19 = offsetDateTimeField12.add(0L, 1937);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-259200000L) + "'", long16 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1171497600000L + "'", long19 == 1171497600000L);
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime5.withTimeAtStartOfDay();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.minus(readablePeriod7);
//        boolean boolean9 = dateTime8.isBeforeNow();
//        org.joda.time.DateTime dateTime11 = dateTime8.plusDays(0);
//        org.joda.time.DurationFieldType durationFieldType12 = null;
//        try {
//            org.joda.time.DateTime dateTime14 = dateTime11.withFieldAdded(durationFieldType12, 3);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfYear();
        org.joda.time.DurationField durationField3 = iSOChronology0.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int40 = dividedDateTimeField39.getMaximumValue();
//        java.lang.String str41 = dividedDateTimeField39.toString();
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property44 = dateTime43.dayOfWeek();
//        java.lang.String str45 = property44.getName();
//        org.joda.time.DateTime dateTime46 = property44.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime48 = dateTime46.minusHours(23);
//        org.joda.time.LocalDateTime localDateTime49 = dateTime48.toLocalDateTime();
//        int[] intArray52 = new int[] { 15 };
//        java.util.Locale locale54 = null;
//        try {
//            int[] intArray55 = dividedDateTimeField39.set((org.joda.time.ReadablePartial) localDateTime49, 70, intArray52, "UnsupportedDateTimeField", locale54);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UnsupportedDateTimeField\" for yearOfCentury is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "DateTimeField[yearOfCentury]" + "'", str41.equals("DateTimeField[yearOfCentury]"));
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(localDateTime49);
//        org.junit.Assert.assertNotNull(intArray52);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        java.lang.String str3 = property2.getName();
        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime4.plusSeconds((int) '#');
        org.joda.time.DateTime dateTime10 = dateTime4.withWeekyear(97);
        org.joda.time.DateTime dateTime12 = dateTime10.withMillisOfDay(19);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfWeek" + "'", str3.equals("dayOfWeek"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
//        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property4 = dateTime3.dayOfWeek();
//        org.joda.time.DateTime dateTime6 = property4.addToCopy(152);
//        org.joda.time.DateTime dateTime8 = property4.addWrapFieldToCopy((int) (byte) 0);
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.ReadableDuration readableDuration10 = null;
//        org.joda.time.DateTime dateTime12 = dateTime8.withDurationAdded(readableDuration10, (-3600000));
//        org.joda.time.ReadablePeriod readablePeriod13 = null;
//        org.joda.time.DateTime dateTime14 = dateTime8.minus(readablePeriod13);
//        org.joda.time.DateTime dateTime16 = dateTime8.minusMonths(12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimePrinter1);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "T000000.042+0000" + "'", str9.equals("T000000.042+0000"));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime16);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendTimeZoneOffset("T230000.010-0100", true, 16, 97);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendCenturyOfEra(0, 86400000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendCenturyOfEra(43, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime.Property property9 = dateTime5.dayOfYear();
//        org.joda.time.DateTime dateTime11 = dateTime5.minusHours((int) (byte) 100);
//        java.util.Locale locale12 = null;
//        java.util.Calendar calendar13 = dateTime5.toCalendar(locale12);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(calendar13);
//    }

//    @Test
//    public void test317() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test317");
//        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField7 = iSOChronology6.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        long long11 = dateTimeZone8.adjustOffset((long) 960, true);
//        long long13 = dateTimeZone8.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology6, dateTimeZone8);
//        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology14);
//        org.joda.time.DateTimeField dateTimeField16 = zonedChronology14.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField17 = zonedChronology14.weekyearOfCentury();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 10);
//        int int20 = dateTime19.getMinuteOfDay();
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime19.toDateTime(chronology21);
//        boolean boolean23 = zonedChronology14.equals((java.lang.Object) dateTime19);
//        org.joda.time.Chronology chronology24 = zonedChronology14.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str27 = dateTimeZone25.getShortName((long) 10);
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(dateTimeZone25);
//        org.joda.time.Chronology chronology29 = zonedChronology14.withZone(dateTimeZone25);
//        try {
//            org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime(82800, (int) '4', 960, 86400000, (int) ' ', 42, dateTimeZone25);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86400000 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology6);
//        org.junit.Assert.assertNotNull(durationField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 960L + "'", long11 == 960L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 32L + "'", long13 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(chronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(chronology24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "+00:00:00.032" + "'", str27.equals("+00:00:00.032"));
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(chronology29);
//    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendDayOfWeekShortText();
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = dateTimeFormatterBuilder5.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder5.appendClockhourOfHalfday(2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimePrinter6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test319");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology7 = gregorianChronology6.withUTC();
//        org.joda.time.DurationField durationField8 = gregorianChronology6.days();
//        java.lang.String str9 = gregorianChronology6.toString();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours((-1));
//        long long13 = dateTimeZone11.convertUTCToLocal((long) 1);
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone11);
//        org.joda.time.DurationField durationField15 = gregorianChronology6.centuries();
//        org.joda.time.Chronology chronology16 = gregorianChronology6.withUTC();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(gregorianChronology6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(durationField8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "GregorianChronology[+00:00:00.032]" + "'", str9.equals("GregorianChronology[+00:00:00.032]"));
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-3599999L) + "'", long13 == (-3599999L));
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(chronology16);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 99, (java.lang.Number) 100L, (java.lang.Number) 10886400000031L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
//        java.lang.String str18 = unsupportedDateTimeField16.getName();
//        long long21 = unsupportedDateTimeField16.add(28800139L, 0L);
//        long long24 = unsupportedDateTimeField16.add((long) (byte) 100, 52L);
//        try {
//            long long27 = unsupportedDateTimeField16.set(28799999L, 85800);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfCentury" + "'", str18.equals("yearOfCentury"));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800139L + "'", long21 == 28800139L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 164096150400100L + "'", long24 == 164096150400100L);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfDay((int) (short) 1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendWeekyear(1, 12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test323");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.convertLocalToUTC((-1L), false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        int int6 = cachedDateTimeZone4.getOffset((long) 7);
//        int int8 = cachedDateTimeZone4.getOffset((long) (byte) 0);
//        int int10 = cachedDateTimeZone4.getStandardOffset(32L);
//        int int12 = cachedDateTimeZone4.getOffset((long) 82800010);
//        long long14 = cachedDateTimeZone4.previousTransition(32L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-33L) + "'", long3 == (-33L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 32 + "'", int12 == 32);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 32L + "'", long14 == 32L);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = dateTime1.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime dateTime5 = dateTime1.minusMinutes(960);
        boolean boolean6 = dateTime1.isBeforeNow();
        java.util.GregorianCalendar gregorianCalendar7 = dateTime1.toGregorianCalendar();
        org.joda.time.DateTime dateTime9 = dateTime1.withYear(86400000);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(gregorianCalendar7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod4 = null;
//        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 1);
//        org.joda.time.DateTime dateTime8 = dateTime6.plusDays(0);
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 10);
//        int int11 = dateTime10.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay12 = dateTime10.toTimeOfDay();
//        org.joda.time.DateTime dateTime13 = dateTime8.withFields((org.joda.time.ReadablePartial) timeOfDay12);
//        java.util.GregorianCalendar gregorianCalendar14 = dateTime8.toGregorianCalendar();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(gregorianCalendar14);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        java.lang.String str3 = property2.getName();
        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
        int int5 = dateTime4.getMinuteOfHour();
        org.joda.time.DateTime dateTime6 = dateTime4.toDateTimeISO();
        org.joda.time.DateTime dateTime8 = dateTime4.minusMinutes(52);
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime4.plus(readableDuration9);
        org.joda.time.DateTime.Property property11 = dateTime10.dayOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfWeek" + "'", str3.equals("dayOfWeek"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("98", "57600032", (int) ' ', 365);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        long long30 = zeroIsMaxDateTimeField27.add(19353657600L, 0);
//        long long33 = zeroIsMaxDateTimeField27.add(28800069L, (long) 70);
//        java.util.Locale locale34 = null;
//        int int35 = zeroIsMaxDateTimeField27.getMaximumShortTextLength(locale34);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 19353657600L + "'", long30 == 19353657600L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 28800139L + "'", long33 == 28800139L);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 8 + "'", int35 == 8);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("16:00:00.100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendMinuteOfHour((int) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendText(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("dayOfWeek");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        boolean boolean7 = dateTime5.isSupported(dateTimeFieldType6);
        org.joda.time.DateTime dateTime9 = dateTime5.plusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime5.minus((long) (short) 1);
        int int12 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.plusSeconds(960);
        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTime11);
        org.joda.time.DateTime dateTime16 = dateTime11.toDateTime();
        java.lang.String str18 = dateTime11.toString("150");
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "150" + "'", str18.equals("150"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 13939200097L, 28800);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test333");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone2.adjustOffset((long) 960, true);
//        long long7 = dateTimeZone2.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology8.weekyearOfCentury();
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10);
//        int int14 = dateTime13.getMinuteOfDay();
//        org.joda.time.Chronology chronology15 = null;
//        org.joda.time.DateTime dateTime16 = dateTime13.toDateTime(chronology15);
//        boolean boolean17 = zonedChronology8.equals((java.lang.Object) dateTime13);
//        org.joda.time.DateTimeField dateTimeField18 = zonedChronology8.dayOfMonth();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 960L + "'", long5 == 960L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test334");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property5 = dateTime1.dayOfMonth();
//        org.joda.time.DateTime dateTime6 = property5.getDateTime();
//        int int7 = property5.getMinimumValue();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
//        boolean boolean12 = dateTime10.isSupported(dateTimeFieldType11);
//        org.joda.time.DateTime dateTime14 = dateTime10.plusWeeks((int) (byte) 10);
//        java.lang.String str15 = dateTimeFormatter8.print((org.joda.time.ReadableInstant) dateTime14);
//        long long16 = dateTime14.getMillis();
//        org.joda.time.DateTime dateTime18 = dateTime14.withMillis((long) ' ');
//        org.joda.time.DateTime.Property property19 = dateTime14.centuryOfEra();
//        int int20 = property5.compareTo((org.joda.time.ReadableInstant) dateTime14);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1970-071T00:00:00+00:00:00.032" + "'", str15.equals("1970-071T00:00:00+00:00:00.032"));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 6048000010L + "'", long16 == 6048000010L);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 31L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendClockhourOfHalfday(2);
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap5 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendTimeZoneShortName(strMap5);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
//        boolean boolean10 = dateTime8.isSupported(dateTimeFieldType9);
//        org.joda.time.DateTime dateTime12 = dateTime8.plusWeeks((int) (byte) 10);
//        org.joda.time.DateTime dateTime14 = dateTime8.minus((long) (short) 1);
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property25 = dateTime24.dayOfWeek();
//        int int26 = dateTime24.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime28 = dateTime24.withZone(dateTimeZone27);
//        org.joda.time.DateTime.Property property29 = dateTime28.yearOfCentury();
//        org.joda.time.DurationField durationField30 = property29.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField31 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType22, durationField30);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType22, 31, (int) (byte) 1, 365);
//        org.joda.time.DateTime.Property property36 = dateTime8.property(dateTimeFieldType22);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder37 = dateTimeFormatterBuilder4.appendShortText(dateTimeFieldType22);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder38 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder40 = dateTimeFormatterBuilder38.appendTwoDigitWeekyear((-7));
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder38.appendFractionOfDay((int) (short) 10, (int) (short) -1);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser45 = dateTimeFormatter44.getParser();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder46 = dateTimeFormatterBuilder38.append(dateTimeParser45);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder47 = dateTimeFormatterBuilder4.appendOptional(dateTimeParser45);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder49 = dateTimeFormatterBuilder4.appendLiteral(' ');
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder51 = dateTimeFormatterBuilder4.appendMillisOfSecond((int) (short) 100);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField31);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder37);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatter44);
//        org.junit.Assert.assertNotNull(dateTimeParser45);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder46);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder47);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder49);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder51);
//    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test337");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsShortText(9600L);
//        int int17 = offsetDateTimeField12.getDifference((long) (short) -1, 57600010L);
//        boolean boolean18 = offsetDateTimeField12.isSupported();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        int int6 = fixedDateTimeZone4.getOffset((long) (short) 100);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
//        org.joda.time.DateTime dateTime10 = property9.roundCeilingCopy();
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime13 = dateTime10.withPeriodAdded(readablePeriod11, (int) (byte) 1);
//        org.joda.time.DateTime dateTime15 = dateTime13.plusDays(0);
//        org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime((long) (short) 10);
//        int int18 = dateTime17.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay19 = dateTime17.toTimeOfDay();
//        org.joda.time.DateTime dateTime20 = dateTime15.withFields((org.joda.time.ReadablePartial) timeOfDay19);
//        boolean boolean21 = fixedDateTimeZone4.equals((java.lang.Object) dateTime15);
//        int int23 = fixedDateTimeZone4.getOffsetFromLocal((long) 1969);
//        int int25 = fixedDateTimeZone4.getOffset(0L);
//        int int27 = fixedDateTimeZone4.getStandardOffset(57600010L);
//        boolean boolean29 = fixedDateTimeZone4.isStandardOffset((long) (-1));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        org.joda.time.DurationField durationField17 = unsupportedDateTimeField16.getRangeDurationField();
//        java.lang.String str18 = unsupportedDateTimeField16.getName();
//        try {
//            long long21 = unsupportedDateTimeField16.set((long) 23, "����-W��-�");
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertNull(durationField17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfCentury" + "'", str18.equals("yearOfCentury"));
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (short) 10);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("16:00:00.100");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendClockhourOfHalfday(16);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder6.appendMillisOfSecond((int) 'a');
        dateTimeFormatterBuilder6.clear();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
        org.joda.time.DateTime dateTime5 = dateTime3.withMillisOfSecond((int) (short) 1);
        int int6 = dateTime3.getYearOfEra();
        org.joda.time.DateTime dateTime8 = dateTime3.withYear((int) '#');
        int int9 = dateTime3.getYearOfCentury();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1970 + "'", int6 == 1970);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test342");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField16.getRangeDurationField();
//        java.lang.String str28 = unsupportedDateTimeField16.getName();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNull(durationField27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "yearOfCentury" + "'", str28.equals("yearOfCentury"));
//    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test343");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        long long19 = unsupportedDateTimeField16.add(960L, (long) 0);
//        try {
//            int int21 = unsupportedDateTimeField16.get((-28799964L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 960L + "'", long19 == 960L);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = dateTime1.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime dateTime5 = dateTime1.plusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime7 = dateTime1.minus((long) (short) 1);
        org.joda.time.DateTime dateTime9 = dateTime1.minusMinutes(57600);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime12 = dateTime1.withDurationAdded(readableDuration10, (int) ' ');
        try {
            org.joda.time.DateTime dateTime14 = dateTime1.withYearOfCentury(1937);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1937 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test345");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        long long7 = dateTimeZone4.adjustOffset((long) 960, true);
//        java.lang.String str9 = dateTimeZone4.getName((long) (short) 100);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime1.toMutableDateTime(dateTimeZone4);
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = mutableDateTime10.toMutableDateTime(chronology11);
//        int int13 = mutableDateTime12.getMillisOfSecond();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 960L + "'", long7 == 960L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+00:00:00.032" + "'", str9.equals("+00:00:00.032"));
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//        org.junit.Assert.assertNotNull(mutableDateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 42 + "'", int13 == 42);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("16:00:00.000", false);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("dayOfWeek");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        java.lang.String str3 = jodaTimePermission1.getActions();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        boolean boolean7 = dateTime5.isSupported(dateTimeFieldType6);
        org.joda.time.DateTime dateTime9 = dateTime5.plusWeeks((int) (byte) 10);
        org.joda.time.DateTime dateTime11 = dateTime5.minus((long) (short) 1);
        int int12 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime11.plusSeconds(960);
        boolean boolean15 = jodaTimePermission1.equals((java.lang.Object) dateTime11);
        org.joda.time.DateTime dateTime17 = dateTime11.withMillis((long) (byte) 10);
        org.junit.Assert.assertNotNull(permissionCollection2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTime17);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.DateTime dateTime4 = dateTime1.plusSeconds(0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42 + "'", int2 == 42);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test349");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.convertLocalToUTC((-1L), false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        int int6 = cachedDateTimeZone4.getOffset((long) 7);
//        int int8 = cachedDateTimeZone4.getOffset((long) (byte) 0);
//        int int10 = cachedDateTimeZone4.getStandardOffset(32L);
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone4);
//        org.joda.time.DurationField durationField12 = iSOChronology11.years();
//        java.lang.String str13 = iSOChronology11.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-33L) + "'", long3 == (-33L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 32 + "'", int6 == 32);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 32 + "'", int8 == 32);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ISOChronology[+00:00:00.032]" + "'", str13.equals("ISOChronology[+00:00:00.032]"));
//    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test350");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime8 = property6.withMaximumValue();
//        org.joda.time.DateTime dateTime9 = property6.withMinimumValue();
//        org.joda.time.DurationField durationField10 = property6.getLeapDurationField();
//        org.joda.time.DateTime dateTime12 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property13 = dateTime12.dayOfWeek();
//        int int14 = dateTime12.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime16 = dateTime12.withZone(dateTimeZone15);
//        org.joda.time.DateTime.Property property17 = dateTime12.yearOfCentury();
//        org.joda.time.DateTime dateTime18 = property17.roundCeilingCopy();
//        org.joda.time.DateTime dateTime20 = dateTime18.plusHours(100);
//        long long21 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNull(durationField10);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-1L) + "'", long21 == (-1L));
//    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test351");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime1.withDate(152, (int) (byte) 10, (int) (short) 1);
//        java.util.Locale locale7 = null;
//        java.util.Calendar calendar8 = dateTime1.toCalendar(locale7);
//        org.joda.time.MutableDateTime mutableDateTime9 = dateTime1.toMutableDateTime();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42 + "'", int2 == 42);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(calendar8);
//        org.junit.Assert.assertNotNull(mutableDateTime9);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test353");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.ReadablePartial readablePartial27 = null;
//        try {
//            int int28 = unsupportedDateTimeField16.getMinimumValue(readablePartial27);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test354");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = dateTimeZone2.adjustOffset((long) 960, true);
//        long long7 = dateTimeZone2.convertUTCToLocal(0L);
//        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, dateTimeZone2);
//        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology8);
//        org.joda.time.DateTimeField dateTimeField10 = zonedChronology8.millisOfDay();
//        org.joda.time.DateTimeField dateTimeField11 = zonedChronology8.hourOfDay();
//        java.lang.String str12 = zonedChronology8.toString();
//        org.joda.time.DurationField durationField13 = zonedChronology8.eras();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 960L + "'", long5 == 960L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 32L + "'", long7 == 32L);
//        org.junit.Assert.assertNotNull(zonedChronology8);
//        org.junit.Assert.assertNotNull(chronology9);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertNotNull(dateTimeField11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ZonedChronology[ISOChronology[UTC], +00:00:00.032]" + "'", str12.equals("ZonedChronology[ISOChronology[UTC], +00:00:00.032]"));
//        org.junit.Assert.assertNotNull(durationField13);
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.centuries();
//        java.lang.String str3 = gregorianChronology0.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[+00:00:00.032]" + "'", str3.equals("GregorianChronology[+00:00:00.032]"));
//    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test356");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property27 = dateTime26.dayOfWeek();
//        int int28 = dateTime26.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime30 = dateTime26.withZone(dateTimeZone29);
//        org.joda.time.DateTime.Property property31 = dateTime30.yearOfCentury();
//        org.joda.time.DateTime dateTime33 = dateTime30.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime35 = dateTime33.minus((long) (short) -1);
//        org.joda.time.DateTime.Property property36 = dateTime33.monthOfYear();
//        org.joda.time.YearMonthDay yearMonthDay37 = dateTime33.toYearMonthDay();
//        int int38 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay37);
//        long long40 = offsetDateTimeField12.roundHalfCeiling(960L);
//        org.joda.time.DurationField durationField41 = offsetDateTimeField12.getLeapDurationField();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(yearMonthDay37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 98 + "'", int38 == 98);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-259200000L) + "'", long40 == (-259200000L));
//        org.junit.Assert.assertNull(durationField41);
//    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test357");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        int int30 = zeroIsMaxDateTimeField27.getDifference((-28800000L), (-1L));
//        org.joda.time.DateTime dateTime32 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property33 = dateTime32.dayOfWeek();
//        java.lang.String str34 = property33.getName();
//        org.joda.time.DateTime dateTime35 = property33.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime37 = dateTime35.withMillis((long) (byte) 0);
//        org.joda.time.LocalDateTime localDateTime38 = dateTime37.toLocalDateTime();
//        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology39.millisOfDay();
//        org.joda.time.DateTime dateTime43 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property44 = dateTime43.dayOfWeek();
//        org.joda.time.DateTime dateTime46 = property44.addToCopy(152);
//        org.joda.time.DateTime dateTime48 = property44.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime50 = dateTime48.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField52 = iSOChronology51.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField53 = iSOChronology51.weekOfWeekyear();
//        org.joda.time.DateTime dateTime55 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property56 = dateTime55.dayOfWeek();
//        int int57 = dateTime55.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime59 = dateTime55.withZone(dateTimeZone58);
//        org.joda.time.DateTime.Property property60 = dateTime59.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType61 = property60.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, dateTimeFieldType61, (int) 'a');
//        org.joda.time.DateTime dateTime65 = dateTime50.withField(dateTimeFieldType61, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField66 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField41, dateTimeFieldType61);
//        int int68 = zeroIsMaxDateTimeField66.getMinimumValue(28799999L);
//        long long70 = zeroIsMaxDateTimeField66.roundCeiling((long) ' ');
//        org.joda.time.DateTime dateTime72 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property73 = dateTime72.dayOfWeek();
//        java.lang.String str74 = property73.getName();
//        org.joda.time.DateTime dateTime75 = property73.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime77 = dateTime75.withMillis((long) (byte) 0);
//        org.joda.time.LocalDateTime localDateTime78 = dateTime77.toLocalDateTime();
//        boolean boolean79 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime78);
//        int[] intArray85 = new int[] { 1970, 5, (-28800000), 99 };
//        int[] intArray87 = zeroIsMaxDateTimeField66.addWrapField((org.joda.time.ReadablePartial) localDateTime78, (int) (byte) 0, intArray85, 3);
//        int int88 = zeroIsMaxDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) localDateTime38, intArray87);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-28799999) + "'", int30 == (-28799999));
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "dayOfWeek" + "'", str34.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(localDateTime38);
//        org.junit.Assert.assertNotNull(gregorianChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeField41);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertNotNull(dateTimeField52);
//        org.junit.Assert.assertNotNull(dateTimeField53);
//        org.junit.Assert.assertNotNull(property56);
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(dateTimeFieldType61);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 32L + "'", long70 == 32L);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "dayOfWeek" + "'", str74.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime75);
//        org.junit.Assert.assertNotNull(dateTime77);
//        org.junit.Assert.assertNotNull(localDateTime78);
//        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
//        org.junit.Assert.assertNotNull(intArray85);
//        org.junit.Assert.assertNotNull(intArray87);
//        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 1 + "'", int88 == 1);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test358");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMillisOfSecond();
//        org.joda.time.DateTime dateTime6 = dateTime1.withDate(152, (int) (byte) 10, (int) (short) 1);
//        org.joda.time.DateTime.Property property7 = dateTime6.yearOfCentury();
//        org.joda.time.MutableDateTime mutableDateTime8 = dateTime6.toMutableDateTime();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42 + "'", int2 == 42);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

//    @Test
//    public void test359() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test359");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime8.minus((long) (short) -1);
//        org.joda.time.DateTime.Property property11 = dateTime8.monthOfYear();
//        org.joda.time.DateTime.Property property12 = dateTime8.minuteOfHour();
//        org.joda.time.DateTime.Property property13 = dateTime8.era();
//        org.joda.time.DateTimeField dateTimeField14 = property13.getField();
//        org.joda.time.DateTime dateTime15 = property13.getDateTime();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-7));
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 1, false);
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatterBuilder0.toParser();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
//        boolean boolean3 = dateTime1.isSupported(dateTimeFieldType2);
//        org.joda.time.DateTime dateTime5 = dateTime1.plusWeeks((int) (byte) 10);
//        boolean boolean6 = dateTime5.isBeforeNow();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 10);
//        org.joda.time.DateTime dateTime11 = new org.joda.time.DateTime((long) (short) 0, dateTimeZone8);
//        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, (org.joda.time.ReadableInstant) dateTime11);
//        org.joda.time.DateTime dateTime14 = dateTime5.minus((long) 97);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+00:00:00.032" + "'", str10.equals("+00:00:00.032"));
//        org.junit.Assert.assertNotNull(chronology12);
//        org.junit.Assert.assertNotNull(dateTime14);
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test362");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        int int29 = zeroIsMaxDateTimeField27.getMinimumValue(28799999L);
//        long long31 = zeroIsMaxDateTimeField27.roundCeiling((long) ' ');
//        long long33 = zeroIsMaxDateTimeField27.roundHalfFloor(31449600032L);
//        java.lang.String str34 = zeroIsMaxDateTimeField27.getName();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 32L + "'", long31 == 32L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 31449600032L + "'", long33 == 31449600032L);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "yearOfCentury" + "'", str34.equals("yearOfCentury"));
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("yearOfCentury");
    }

//    @Test
//    public void test364() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test364");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        try {
//            int int24 = unsupportedDateTimeField16.getMaximumValue();
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test365");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.DateTime dateTime26 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property27 = dateTime26.dayOfWeek();
//        int int28 = dateTime26.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime30 = dateTime26.withZone(dateTimeZone29);
//        org.joda.time.DateTime.Property property31 = dateTime30.yearOfCentury();
//        org.joda.time.DateTime dateTime33 = dateTime30.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime35 = dateTime33.minus((long) (short) -1);
//        org.joda.time.DateTime.Property property36 = dateTime33.monthOfYear();
//        org.joda.time.YearMonthDay yearMonthDay37 = dateTime33.toYearMonthDay();
//        int int38 = offsetDateTimeField12.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay37);
//        int int39 = offsetDateTimeField12.getOffset();
//        int int42 = offsetDateTimeField12.getDifference((long) 1, 1L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(yearMonthDay37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 98 + "'", int38 == 98);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 97 + "'", int39 == 97);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test366");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsText(28800097L);
//        long long17 = offsetDateTimeField12.addWrapField((long) (-28799999), (int) (short) -1);
//        boolean boolean18 = offsetDateTimeField12.isSupported();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 31420800001L + "'", long17 == 31420800001L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test367");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
//        int int4 = dateTime3.getYearOfCentury();
//        java.util.Date date5 = dateTime3.toDate();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 70 + "'", int4 == 70);
//        org.junit.Assert.assertNotNull(date5);
//    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test368");
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property8 = dateTime7.dayOfWeek();
//        int int9 = dateTime7.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime11 = dateTime7.withZone(dateTimeZone10);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
//        org.joda.time.Chronology chronology13 = gregorianChronology12.withUTC();
//        org.joda.time.DurationField durationField14 = gregorianChronology12.days();
//        java.lang.String str15 = gregorianChronology12.toString();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.forOffsetHours((-1));
//        long long19 = dateTimeZone17.convertUTCToLocal((long) 1);
//        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology12, dateTimeZone17);
//        try {
//            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime((int) (byte) 100, 23, 98, 2555, 5, 0, dateTimeZone17);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2555 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(durationField14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[+00:00:00.032]" + "'", str15.equals("GregorianChronology[+00:00:00.032]"));
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-3599999L) + "'", long19 == (-3599999L));
//        org.junit.Assert.assertNotNull(zonedChronology20);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) 960L);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTime dateTime6 = dateTime4.withCenturyOfEra(82800);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        java.lang.String str3 = property2.getName();
        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) (byte) 0);
        org.joda.time.Instant instant7 = dateTime4.toInstant();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfWeek" + "'", str3.equals("dayOfWeek"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-7));
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.format.DateTimePrinter dateTimePrinter9 = dateTimeFormatter8.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTwoDigitWeekyear((-7));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.appendFractionOfDay((int) (short) 10, (int) (short) -1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser17 = dateTimeFormatter16.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder10.append(dateTimeParser17);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder7.append(dateTimePrinter9, dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimePrinter9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNotNull(dateTimeParser17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test372");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
//        int int4 = property2.getMaximumValue();
//        org.joda.time.DurationField durationField5 = property2.getDurationField();
//        java.lang.String str6 = property2.getAsText();
//        org.joda.time.DateTime dateTime7 = property2.getDateTime();
//        org.joda.time.DateTime dateTime8 = property2.withMinimumValue();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 7 + "'", int4 == 7);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Thursday" + "'", str6.equals("Thursday"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test373");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.dayOfWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        org.joda.time.DateTime dateTime7 = property5.addToCopy(152);
//        org.joda.time.DateTime dateTime9 = property5.addWrapFieldToCopy((int) (byte) 0);
//        org.joda.time.DateTime dateTime11 = dateTime9.plusYears((int) (byte) 100);
//        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField14 = iSOChronology12.weekOfWeekyear();
//        org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property17 = dateTime16.dayOfWeek();
//        int int18 = dateTime16.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = dateTime16.withZone(dateTimeZone19);
//        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType22 = property21.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, dateTimeFieldType22, (int) 'a');
//        org.joda.time.DateTime dateTime26 = dateTime11.withField(dateTimeFieldType22, 15);
//        org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField27 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType22);
//        int int28 = zeroIsMaxDateTimeField27.getMinimumValue();
//        java.util.Locale locale30 = null;
//        java.lang.String str31 = zeroIsMaxDateTimeField27.getAsShortText((long) (-28800000), locale30);
//        org.joda.time.DateTime dateTime33 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property34 = dateTime33.dayOfWeek();
//        org.joda.time.DateTime.Property property35 = dateTime33.era();
//        org.joda.time.ReadableDuration readableDuration36 = null;
//        org.joda.time.DateTime dateTime37 = dateTime33.plus(readableDuration36);
//        org.joda.time.LocalTime localTime38 = dateTime33.toLocalTime();
//        int int39 = zeroIsMaxDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) localTime38);
//        int int40 = zeroIsMaxDateTimeField27.getMaximumValue();
//        long long43 = zeroIsMaxDateTimeField27.addWrapField((long) '4', 2);
//        long long46 = zeroIsMaxDateTimeField27.getDifferenceAsLong(0L, (long) (-28799997));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(dateTimeFieldType22);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "57600032" + "'", str31.equals("57600032"));
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(localTime38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 86400000 + "'", int40 == 86400000);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 54L + "'", long43 == 54L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 28799997L + "'", long46 == 28799997L);
//    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime3 = property2.roundCeilingCopy();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime6 = dateTime3.withPeriodAdded(readablePeriod4, (int) (byte) 1);
        org.joda.time.DateTime dateTime8 = dateTime6.plusDays(0);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        boolean boolean11 = dateTimeZone9.isStandardOffset(69L);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        java.lang.String str3 = property2.getName();
        org.joda.time.DateTime dateTime4 = property2.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) (byte) 0);
        org.joda.time.DateTime dateTime8 = dateTime4.plusSeconds((int) '#');
        org.joda.time.DateTime dateTime10 = dateTime4.withWeekyear(97);
        org.joda.time.DateTime.Property property11 = dateTime10.monthOfYear();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "dayOfWeek" + "'", str3.equals("dayOfWeek"));
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test377");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime8.minus((long) (short) -1);
//        org.joda.time.DateTime dateTime12 = dateTime10.minusMinutes((int) (byte) 10);
//        int int13 = dateTime10.getMillisOfDay();
//        org.joda.time.DateTime dateTime14 = dateTime10.toDateTime();
//        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField17 = iSOChronology15.weekOfWeekyear();
//        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property20 = dateTime19.dayOfWeek();
//        int int21 = dateTime19.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime23 = dateTime19.withZone(dateTimeZone22);
//        org.joda.time.DateTime.Property property24 = dateTime23.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType25 = property24.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, dateTimeFieldType25, (int) 'a');
//        java.lang.String str29 = offsetDateTimeField27.getAsShortText(9600L);
//        long long32 = offsetDateTimeField27.getDifferenceAsLong(28800097L, (long) 960);
//        org.joda.time.DurationField durationField33 = offsetDateTimeField27.getLeapDurationField();
//        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property36 = dateTime35.dayOfWeek();
//        java.lang.String str37 = property36.getName();
//        org.joda.time.DateTime dateTime38 = property36.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime40 = dateTime38.withMillis((long) (byte) 0);
//        org.joda.time.LocalDateTime localDateTime41 = dateTime40.toLocalDateTime();
//        int int42 = offsetDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) localDateTime41);
//        org.joda.time.DateTime dateTime43 = dateTime14.withFields((org.joda.time.ReadablePartial) localDateTime41);
//        org.joda.time.LocalDateTime localDateTime44 = dateTime43.toLocalDateTime();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 43 + "'", int13 == 43);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(iSOChronology15);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType25);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "98" + "'", str29.equals("98"));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
//        org.junit.Assert.assertNull(durationField33);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "dayOfWeek" + "'", str37.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(localDateTime41);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 150 + "'", int42 == 150);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(localDateTime44);
//    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test378");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DurationField durationField7 = property6.getLeapDurationField();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
//        boolean boolean11 = dateTime9.isSupported(dateTimeFieldType10);
//        org.joda.time.DateTime dateTime13 = dateTime9.plusWeeks((int) (byte) 10);
//        org.joda.time.DateTime dateTime15 = dateTime13.minusMonths(1969);
//        int int16 = property6.compareTo((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property19 = dateTime18.dayOfWeek();
//        org.joda.time.DateTime.Property property20 = dateTime18.era();
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime18.plus(readableDuration21);
//        boolean boolean23 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime22);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNull(durationField7);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test379");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        try {
//            int int28 = unsupportedDateTimeField16.getLeapAmount(97L);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test380");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property3 = dateTime2.dayOfWeek();
//        java.lang.String str4 = property3.getName();
//        org.joda.time.DateTime dateTime5 = property3.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime7 = dateTime5.withMillis((long) (byte) 0);
//        org.joda.time.LocalDateTime localDateTime8 = dateTime7.toLocalDateTime();
//        java.lang.String str9 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDateTime8);
//        java.lang.Appendable appendable10 = null;
//        try {
//            dateTimeFormatter0.printTo(appendable10, (long) 98);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "dayOfWeek" + "'", str4.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(localDateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "00:00:00.032" + "'", str9.equals("00:00:00.032"));
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        boolean boolean3 = dateTime1.isSupported(dateTimeFieldType2);
        org.joda.time.DateTime dateTime5 = dateTime1.plusWeeks((int) (byte) 10);
        long long6 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime1);
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime1.toCalendar(locale7);
        org.joda.time.LocalTime localTime9 = dateTime1.toLocalTime();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
        org.junit.Assert.assertNotNull(calendar8);
        org.junit.Assert.assertNotNull(localTime9);
    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test382");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        boolean boolean5 = dateTime1.isEqual(0L);
//        int int6 = dateTime1.getWeekOfWeekyear();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test383");
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap1 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTimeZoneShortName(strMap1);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder0.appendMillisOfDay((int) (short) 10);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder4.appendLiteral("16:00:00.100");
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
//        int int10 = dateTime8.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime12 = dateTime8.withZone(dateTimeZone11);
//        org.joda.time.DateTime.Property property13 = dateTime8.minuteOfHour();
//        java.lang.String str14 = property13.getAsShortText();
//        java.lang.String str15 = property13.getAsShortText();
//        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property13.getFieldType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder6.appendDecimal(dateTimeFieldType16, 82800, 960);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder6.appendSecondOfDay(28800);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder21.appendDayOfMonth(1970);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "0" + "'", str14.equals("0"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType16);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime4 = property2.addToCopy(152);
        org.joda.time.DateTime dateTime6 = property2.addWrapFieldToCopy(10);
        org.joda.time.DateTime dateTime8 = dateTime6.withMillis(0L);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime6.getZone();
        org.joda.time.DateTime dateTime11 = dateTime6.plusMonths(82800);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("null");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"null\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test386");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
//        int int7 = dateTime5.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime9 = dateTime5.withZone(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.Chronology chronology11 = gregorianChronology10.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology10.millisOfDay();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970001" + "'", str2.equals("1970001"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test387");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        java.lang.String str2 = dateTimeZone0.getShortName((long) 10);
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone0);
//        java.lang.String str5 = dateTimeZone0.getName((long) 'a');
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone0.getShortName(0L, locale7);
//        java.util.Locale locale10 = null;
//        java.lang.String str11 = dateTimeZone0.getShortName((long) 1970, locale10);
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property14 = dateTime13.dayOfWeek();
//        org.joda.time.DateTime.Property property15 = dateTime13.era();
//        org.joda.time.Chronology chronology16 = dateTime13.getChronology();
//        int int17 = dateTime13.getDayOfMonth();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("hi!", "", 0, (-1));
//        java.lang.Object obj23 = null;
//        boolean boolean24 = fixedDateTimeZone22.equals(obj23);
//        int int26 = fixedDateTimeZone22.getStandardOffset(6048000010L);
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime13.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone22);
//        int int28 = dateTimeZone0.getOffset((org.joda.time.ReadableInstant) mutableDateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "+00:00:00.032" + "'", str2.equals("+00:00:00.032"));
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+00:00:00.032" + "'", str5.equals("+00:00:00.032"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.032" + "'", str8.equals("+00:00:00.032"));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "+00:00:00.032" + "'", str11.equals("+00:00:00.032"));
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 32 + "'", int28 == 32);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Wed", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Wed/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        org.joda.time.DateTime.Property property4 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime6 = dateTime1.plus((long) (-3600000));
        org.joda.time.DateTime.Property property7 = dateTime6.minuteOfHour();
        java.util.Locale locale8 = null;
        int int9 = property7.getMaximumShortTextLength(locale8);
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("GregorianChronology[+00:00:00.032]");
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("GregorianChronology[-01:00]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'GregorianChronology[-01:00]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test393");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        int int2 = dateTime1.getMinuteOfDay();
//        org.joda.time.TimeOfDay timeOfDay3 = dateTime1.toTimeOfDay();
//        org.joda.time.DateTime.Property property4 = dateTime1.weekOfWeekyear();
//        org.joda.time.DateTime.Property property5 = dateTime1.dayOfMonth();
//        org.joda.time.DateTime dateTime6 = property5.getDateTime();
//        org.joda.time.DateTime dateTime7 = property5.withMaximumValue();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
//        org.junit.Assert.assertNotNull(timeOfDay3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
        long long5 = iSOChronology0.add(6048000010L, (long) 960, (int) 'a');
        org.joda.time.DurationField durationField6 = iSOChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 6048093130L + "'", long5 == 6048093130L);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime((java.lang.Object) dateTime1);
        org.joda.time.DateTime.Property property4 = dateTime1.centuryOfEra();
        org.joda.time.DateTime dateTime6 = dateTime1.plus((long) (-3600000));
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime1.getZone();
        org.junit.Assert.assertNotNull(property2);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test396");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        long long3 = property2.remainder();
//        java.util.Locale locale4 = null;
//        int int5 = property2.getMaximumShortTextLength(locale4);
//        java.lang.String str6 = property2.getName();
//        org.joda.time.DurationField durationField7 = property2.getDurationField();
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 42L + "'", long3 == 42L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "dayOfWeek" + "'", str6.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(durationField7);
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test397");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int42 = dividedDateTimeField39.getDifference(1000L, (long) (byte) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        long long45 = remainderDateTimeField43.roundHalfCeiling(54L);
//        try {
//            long long48 = remainderDateTimeField43.set((long) (short) 100, 16);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 16 for yearOfCentury must be in the range [98,150]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-259200000L) + "'", long45 == (-259200000L));
//    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test398");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime5.plus(readableDuration7);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test399");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int42 = dividedDateTimeField39.getDifference(1000L, (long) (byte) 1);
//        org.joda.time.DurationField durationField43 = dividedDateTimeField39.getDurationField();
//        int int44 = dividedDateTimeField39.getDivisor();
//        try {
//            long long47 = dividedDateTimeField39.set((long) 'a', 1969);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for yearOfCentury must be in the range [0,0]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2000 + "'", int44 == 2000);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("ZonedChronology[ISOChronology[UTC], +00:00:00.032]", true);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = dateTimeFormatterBuilder0.appendMonthOfYearShortText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder1);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test402");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int42 = dividedDateTimeField39.getDifference(1000L, (long) (byte) 1);
//        org.joda.time.DurationField durationField43 = dividedDateTimeField39.getDurationField();
//        int int44 = dividedDateTimeField39.getMaximumValue();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
//    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test403");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.toDateTimeISO();
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime6.withPeriodAdded(readablePeriod7, (int) (short) 100);
//        org.joda.time.DateTime dateTime11 = dateTime6.minusSeconds(1970);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test404");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime5.plusMonths(365);
//        long long11 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime10);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 959817600010L + "'", long11 == 959817600010L);
//    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test405");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withDefaultYear(2555);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970001" + "'", str2.equals("1970001"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test406");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime1.minuteOfHour();
//        org.joda.time.DateTime dateTime7 = dateTime1.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime9 = dateTime1.plusSeconds(59);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-7));
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = dateTimeFormatter4.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter5, dateTimeParser7);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser7);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter9.withChronology(chronology10);
        java.lang.Appendable appendable12 = null;
        try {
            dateTimeFormatter11.printTo(appendable12, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimePrinter5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (-3599963L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime((int) (short) 0, 1969, (int) (byte) -1, 31, (int) (short) 1, 23, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test410() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test410");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField27 = iSOChronology25.weekOfWeekyear();
//        org.joda.time.DateTime dateTime29 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property30 = dateTime29.dayOfWeek();
//        int int31 = dateTime29.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = dateTime29.withZone(dateTimeZone32);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property34.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, dateTimeFieldType35, (int) 'a');
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType35, 2000);
//        int int42 = dividedDateTimeField39.getDifference(1000L, (long) (byte) 1);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField43 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField39);
//        long long45 = remainderDateTimeField43.roundHalfCeiling(54L);
//        long long47 = remainderDateTimeField43.roundCeiling(42L);
//        java.lang.String str49 = remainderDateTimeField43.getAsText((-82798063L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(iSOChronology25);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(dateTimeFieldType35);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-259200000L) + "'", long45 == (-259200000L));
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 345600000L + "'", long47 == 345600000L);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "98" + "'", str49.equals("98"));
//    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(7, 12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfEra();
        org.joda.time.DurationField durationField4 = iSOChronology0.centuries();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, (-28799997));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("ZonedChronology[ISOChronology[UTC], +00:00:00.032]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ZonedChronology[ISOChronology[UT...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(28800059L);
        org.joda.time.MutableDateTime mutableDateTime2 = dateTime1.toMutableDateTime();
        org.junit.Assert.assertNotNull(mutableDateTime2);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test415");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTime dateTime8 = dateTime5.minusYears((int) ' ');
//        org.joda.time.DateTime dateTime10 = dateTime8.minus((long) (short) -1);
//        org.joda.time.DateTime.Property property11 = dateTime8.monthOfYear();
//        org.joda.time.DateTime dateTime13 = dateTime8.withCenturyOfEra(1);
//        boolean boolean15 = dateTime13.isBefore((long) 82800010);
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test416");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        org.joda.time.DateTime dateTime14 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property15 = dateTime14.dayOfWeek();
//        java.lang.String str16 = property15.getName();
//        org.joda.time.DateTime dateTime17 = property15.roundHalfFloorCopy();
//        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (byte) 0);
//        java.lang.Class<?> wildcardClass20 = dateTime17.getClass();
//        org.joda.time.YearMonthDay yearMonthDay21 = dateTime17.toYearMonthDay();
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay21, 3, locale23);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder28 = dateTimeFormatterBuilder25.appendTwoDigitYear(15, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder30 = dateTimeFormatterBuilder28.appendSecondOfMinute(100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder31 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap32 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder33 = dateTimeFormatterBuilder31.appendTimeZoneShortName(strMap32);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder35 = dateTimeFormatterBuilder31.appendClockhourOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime37 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property38 = dateTime37.dayOfWeek();
//        int int39 = dateTime37.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime41 = dateTime37.withZone(dateTimeZone40);
//        org.joda.time.DateTime.Property property42 = dateTime41.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = property42.getFieldType();
//        org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property46 = dateTime45.dayOfWeek();
//        int int47 = dateTime45.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime49 = dateTime45.withZone(dateTimeZone48);
//        org.joda.time.DateTime.Property property50 = dateTime49.yearOfCentury();
//        org.joda.time.DurationField durationField51 = property50.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField52 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType43, durationField51);
//        org.joda.time.DurationField durationField53 = unsupportedDateTimeField52.getRangeDurationField();
//        java.lang.String str54 = unsupportedDateTimeField52.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType55 = unsupportedDateTimeField52.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder58 = dateTimeFormatterBuilder35.appendDecimal(dateTimeFieldType55, (int) ' ', 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder59 = dateTimeFormatterBuilder30.appendText(dateTimeFieldType55);
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField61 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField12, dateTimeFieldType55, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertNotNull(yearMonthDay21);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "3" + "'", str24.equals("3"));
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder28);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder30);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder33);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder35);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertNotNull(property42);
//        org.junit.Assert.assertNotNull(dateTimeFieldType43);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertNotNull(durationField51);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField52);
//        org.junit.Assert.assertNull(durationField53);
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "yearOfCentury" + "'", str54.equals("yearOfCentury"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType55);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder58);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder59);
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test417");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        long long3 = dateTimeZone0.convertLocalToUTC((-1L), false);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone4 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone0);
//        long long6 = cachedDateTimeZone4.nextTransition((long) 10);
//        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property9 = dateTime8.dayOfWeek();
//        int int10 = dateTime8.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime12 = dateTime8.withZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = dateTime8.toDateTimeISO();
//        int int14 = dateTime13.getYearOfEra();
//        java.util.Locale locale15 = null;
//        java.util.Calendar calendar16 = dateTime13.toCalendar(locale15);
//        boolean boolean17 = cachedDateTimeZone4.equals((java.lang.Object) dateTime13);
//        java.lang.String str19 = cachedDateTimeZone4.getNameKey((long) 15);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-33L) + "'", long3 == (-33L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone4);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1970 + "'", int14 == 1970);
//        org.junit.Assert.assertNotNull(calendar16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNull(str19);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test418");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        int int3 = dateTime1.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = dateTime1.withZone(dateTimeZone4);
//        org.joda.time.DateTime.Property property6 = dateTime5.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType7 = property6.getFieldType();
//        org.joda.time.DateTime dateTime9 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property10 = dateTime9.dayOfWeek();
//        int int11 = dateTime9.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = dateTime9.withZone(dateTimeZone12);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DurationField durationField15 = property14.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField16 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType7, durationField15);
//        int int19 = unsupportedDateTimeField16.getDifference((long) (-7), (long) 0);
//        long long22 = unsupportedDateTimeField16.getDifferenceAsLong(1L, 100L);
//        boolean boolean23 = unsupportedDateTimeField16.isLenient();
//        long long26 = unsupportedDateTimeField16.add((long) (-28799999), 0);
//        org.joda.time.DurationField durationField27 = unsupportedDateTimeField16.getLeapDurationField();
//        org.joda.time.DurationField durationField28 = unsupportedDateTimeField16.getRangeDurationField();
//        try {
//            java.lang.String str30 = unsupportedDateTimeField16.getAsText((-28800000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: yearOfCentury field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeFieldType7);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField16);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-28799999L) + "'", long26 == (-28799999L));
//        org.junit.Assert.assertNull(durationField27);
//        org.junit.Assert.assertNull(durationField28);
//    }

//    @Test
//    public void test419() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test419");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        java.lang.String str2 = dateTimeFormatter0.print((long) 10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withOffsetParsed();
//        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property6 = dateTime5.dayOfWeek();
//        int int7 = dateTime5.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime9 = dateTime5.withZone(dateTimeZone8);
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
//        org.joda.time.Chronology chronology11 = gregorianChronology10.withUTC();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gregorianChronology10);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter12.withPivotYear((java.lang.Integer) 1);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970001" + "'", str2.equals("1970001"));
//        org.junit.Assert.assertNotNull(dateTimeFormatter3);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertNotNull(chronology11);
//        org.junit.Assert.assertNotNull(dateTimeFormatter12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter14);
//    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test420");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfEra();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
//        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property5 = dateTime4.dayOfWeek();
//        int int6 = dateTime4.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = dateTime4.withZone(dateTimeZone7);
//        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType10 = property9.getFieldType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType10, (int) 'a');
//        java.lang.String str14 = offsetDateTimeField12.getAsShortText(9600L);
//        int int17 = offsetDateTimeField12.getDifference((long) (short) -1, 57600010L);
//        org.joda.time.DurationField durationField18 = offsetDateTimeField12.getLeapDurationField();
//        int int20 = offsetDateTimeField12.getMinimumValue(10L);
//        org.joda.time.DateTimeField dateTimeField21 = offsetDateTimeField12.getWrappedField();
//        int int23 = offsetDateTimeField12.getLeapAmount((long) 5);
//        long long25 = offsetDateTimeField12.roundHalfEven(19353657600L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeFieldType10);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "98" + "'", str14.equals("98"));
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNull(durationField18);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 98 + "'", int20 == 98);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 19094400000L + "'", long25 == 19094400000L);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((-7));
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatterBuilder0.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 100, true);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear((int) (short) 1, false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap11 = null;
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendTimeZoneShortName(strMap11);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendClockhourOfHalfday(2);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.appendDayOfWeekShortText();
        org.joda.time.format.DateTimePrinter dateTimePrinter16 = dateTimeFormatterBuilder15.toPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendTwoDigitWeekyear((-7));
        org.joda.time.format.DateTimePrinter dateTimePrinter20 = dateTimeFormatterBuilder17.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.format.DateTimePrinter dateTimePrinter22 = dateTimeFormatter21.getPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder17.append(dateTimePrinter22);
        boolean boolean24 = dateTimeFormatterBuilder23.canBuildPrinter();
        org.joda.time.format.DateTimeParser dateTimeParser25 = dateTimeFormatterBuilder23.toParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder26 = dateTimeFormatterBuilder9.append(dateTimePrinter16, dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimePrinter16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimePrinter20);
        org.junit.Assert.assertNotNull(dateTimeFormatter21);
        org.junit.Assert.assertNotNull(dateTimePrinter22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTimeParser25);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder26);
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test422");
//        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property2 = dateTime1.dayOfWeek();
//        org.joda.time.DateTime.Property property3 = dateTime1.era();
//        boolean boolean4 = dateTime1.isEqualNow();
//        org.joda.time.DateTime.Property property5 = dateTime1.millisOfSecond();
//        org.joda.time.DateTime dateTime7 = dateTime1.plusYears(52);
//        org.joda.time.ReadableDuration readableDuration8 = null;
//        org.joda.time.DateTime dateTime9 = dateTime7.minus(readableDuration8);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = new org.joda.time.format.DateTimeFormatterBuilder();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendTwoDigitYear(15, true);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendSecondOfMinute(100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = new org.joda.time.format.DateTimeFormatterBuilder();
//        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap17 = null;
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder16.appendTimeZoneShortName(strMap17);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder16.appendClockhourOfDay((int) (short) 1);
//        org.joda.time.DateTime dateTime22 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property23 = dateTime22.dayOfWeek();
//        int int24 = dateTime22.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime26 = dateTime22.withZone(dateTimeZone25);
//        org.joda.time.DateTime.Property property27 = dateTime26.yearOfCentury();
//        org.joda.time.DateTimeFieldType dateTimeFieldType28 = property27.getFieldType();
//        org.joda.time.DateTime dateTime30 = new org.joda.time.DateTime((long) (short) 10);
//        org.joda.time.DateTime.Property property31 = dateTime30.dayOfWeek();
//        int int32 = dateTime30.getSecondOfDay();
//        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime34 = dateTime30.withZone(dateTimeZone33);
//        org.joda.time.DateTime.Property property35 = dateTime34.yearOfCentury();
//        org.joda.time.DurationField durationField36 = property35.getRangeDurationField();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField37 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField36);
//        org.joda.time.DurationField durationField38 = unsupportedDateTimeField37.getRangeDurationField();
//        java.lang.String str39 = unsupportedDateTimeField37.getName();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = unsupportedDateTimeField37.getType();
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder43 = dateTimeFormatterBuilder20.appendDecimal(dateTimeFieldType40, (int) ' ', 100);
//        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder44 = dateTimeFormatterBuilder15.appendText(dateTimeFieldType40);
//        int int45 = dateTime9.get(dateTimeFieldType40);
//        org.joda.time.IllegalFieldValueException illegalFieldValueException48 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 1.0f, "16");
//        org.junit.Assert.assertNotNull(property2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder20);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTimeFieldType28);
//        org.junit.Assert.assertNotNull(property31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(durationField36);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField37);
//        org.junit.Assert.assertNull(durationField38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "yearOfCentury" + "'", str39.equals("yearOfCentury"));
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder43);
//        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder44);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 22 + "'", int45 == 22);
//    }
//}

