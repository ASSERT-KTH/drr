import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) '4');
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.months();
        long long4 = durationField1.subtract((long) (byte) 1, (long) 'a');
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-255139199999L) + "'", long4 == (-255139199999L));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(0L, chronology7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(10);
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfSecond();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology10, (org.joda.time.ReadableDateTime) dateTime13, (org.joda.time.ReadableDateTime) dateTime16);
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        long long21 = limitChronology17.add(readablePeriod18, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime22 = limitChronology17.getUpperLimit();
        boolean boolean23 = property3.equals((java.lang.Object) limitChronology17);
        org.joda.time.MutableDateTime mutableDateTime24 = org.joda.time.MutableDateTime.now((org.joda.time.Chronology) limitChronology17);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-255139199999L) + "'", long21 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(mutableDateTime24);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(10);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = limitChronology18.add(readablePeriod19, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime23 = limitChronology18.getUpperLimit();
        boolean boolean24 = property4.equals((java.lang.Object) limitChronology18);
        java.util.Locale locale25 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology18, locale25);
        java.util.Locale locale27 = dateTimeParserBucket26.getLocale();
        dateTimeParserBucket26.setOffset((java.lang.Integer) 320);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime32 = null;
        boolean boolean33 = dateTimeZone31.isLocalDateTimeGap(localDateTime32);
        org.joda.time.chrono.JulianChronology julianChronology34 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime36 = null;
        boolean boolean37 = dateTimeZone35.isLocalDateTimeGap(localDateTime36);
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone35);
        boolean boolean39 = julianChronology34.equals((java.lang.Object) dateTimeZone35);
        org.joda.time.DateTime dateTime40 = new org.joda.time.DateTime(319L, dateTimeZone35);
        dateTimeParserBucket26.setZone(dateTimeZone35);
        java.lang.Integer int42 = dateTimeParserBucket26.getPivotYear();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-255139199999L) + "'", long22 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(julianChronology34);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(int42);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(12, 1, 321, 19, 320);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 320 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(chronology2);
//        int int4 = mutableDateTime3.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime3.era();
//        mutableDateTime3.setDate((long) 86399999);
//        int int10 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "", 9600);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 741 + "'", int4 == 741);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-9601) + "'", int10 == (-9601));
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(10);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = limitChronology18.add(readablePeriod19, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime23 = limitChronology18.getUpperLimit();
        boolean boolean24 = property4.equals((java.lang.Object) limitChronology18);
        java.util.Locale locale25 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology18, locale25);
        java.util.Locale locale27 = dateTimeParserBucket26.getLocale();
        long long28 = dateTimeParserBucket26.computeMillis();
        org.joda.time.Instant instant29 = new org.joda.time.Instant((java.lang.Object) long28);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-255139199999L) + "'", long22 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1L + "'", long28 == 1L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfSecond(0, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitYear((-32));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendMinuteOfHour((int) (byte) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatterBuilder11.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        long long3 = mutableDateTime2.getMillis();
        mutableDateTime2.setMinuteOfHour(0);
        org.joda.time.Instant instant6 = mutableDateTime2.toInstant();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant6.withDurationAdded(readableDuration7, 740);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant12 = instant9.withDurationAdded(readableDuration10, 100);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant12);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) (byte) 0);
//        int int4 = dateTime1.getDayOfYear();
//        org.joda.time.DateTime dateTime6 = dateTime1.minus((long) 319);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        org.joda.time.DateTime dateTime9 = dateTime1.withPeriodAdded(readablePeriod7, 960);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 163 + "'", int4 == 163);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.parse("������", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"������\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
//        org.joda.time.Chronology chronology14 = limitChronology13.withUTC();
//        org.joda.time.DateTimeField dateTimeField15 = limitChronology13.minuteOfDay();
//        java.lang.String str16 = limitChronology13.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:20:54.454Z, 2019-06-12T12:21:04.454Z]" + "'", str16.equals("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:20:54.454Z, 2019-06-12T12:21:04.454Z]"));
//    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime5 = property3.add(0);
        org.joda.time.DurationField durationField6 = property3.getLeapDurationField();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime dateTime11 = property10.withMaximumValue();
        org.joda.time.DateTime dateTime13 = property10.addToCopy(0);
        org.joda.time.DateTime dateTime14 = property10.roundCeilingCopy();
        org.joda.time.DateTime dateTime16 = dateTime14.plus((long) (-32));
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.MutableDateTime mutableDateTime19 = new org.joda.time.MutableDateTime(dateTimeZone18);
        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime((-433428L), dateTimeZone18);
        org.joda.time.DateTime dateTime21 = dateTime16.toDateTime(dateTimeZone18);
        int int22 = property3.compareTo((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime24 = dateTime21.minus(readablePeriod23);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime5);
        org.junit.Assert.assertNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(dateTime24);
    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.chrono.JulianChronology julianChronology1 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider2 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds(10);
//        org.joda.time.DateTime.Property property7 = dateTime6.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
//        org.joda.time.Chronology chronology11 = null;
//        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(0L, chronology11);
//        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime12);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds(10);
//        org.joda.time.DateTime.Property property18 = dateTime17.yearOfCentury();
//        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology14, (org.joda.time.ReadableDateTime) dateTime17, (org.joda.time.ReadableDateTime) dateTime20);
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        long long25 = limitChronology21.add(readablePeriod22, (-255139199999L), (-1));
//        org.joda.time.DateTime dateTime26 = limitChronology21.getUpperLimit();
//        boolean boolean27 = property7.equals((java.lang.Object) limitChronology21);
//        java.util.Locale locale28 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket29 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology21, locale28);
//        java.util.Locale locale30 = dateTimeParserBucket29.getLocale();
//        java.lang.String str33 = defaultNameProvider2.getShortName(locale30, "1970-01-01T00:00:00.000Z", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:50.536-07:00, 2019-06-12T05:20:00.537-07:00]");
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds(10);
//        org.joda.time.DateTime.Property property37 = dateTime36.yearOfCentury();
//        org.joda.time.DateTime.Property property38 = dateTime36.millisOfSecond();
//        org.joda.time.LocalDate localDate39 = dateTime36.toLocalDate();
//        org.joda.time.DateTime.Property property40 = dateTime36.year();
//        int int41 = dateTime36.getMinuteOfDay();
//        org.joda.time.DateTime dateTime43 = dateTime36.withEra((int) (short) 1);
//        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime47 = dateTime45.minusSeconds(10);
//        org.joda.time.DateTime.Property property48 = dateTime47.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology50 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49);
//        org.joda.time.Chronology chronology52 = null;
//        org.joda.time.MutableDateTime mutableDateTime53 = new org.joda.time.MutableDateTime(0L, chronology52);
//        org.joda.time.MutableDateTime.Property property54 = mutableDateTime53.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology55 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone49, (org.joda.time.ReadableInstant) mutableDateTime53);
//        org.joda.time.DateTime dateTime56 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime58 = dateTime56.minusSeconds(10);
//        org.joda.time.DateTime.Property property59 = dateTime58.yearOfCentury();
//        org.joda.time.DateTime.Property property60 = dateTime58.millisOfSecond();
//        org.joda.time.DateTime dateTime61 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology62 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology55, (org.joda.time.ReadableDateTime) dateTime58, (org.joda.time.ReadableDateTime) dateTime61);
//        org.joda.time.ReadablePeriod readablePeriod63 = null;
//        long long66 = limitChronology62.add(readablePeriod63, (-255139199999L), (-1));
//        org.joda.time.DateTime dateTime67 = limitChronology62.getUpperLimit();
//        boolean boolean68 = property48.equals((java.lang.Object) limitChronology62);
//        java.util.Locale locale69 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket70 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology62, locale69);
//        java.util.Locale locale71 = dateTimeParserBucket70.getLocale();
//        java.util.Calendar calendar72 = dateTime43.toCalendar(locale71);
//        java.lang.String str75 = defaultNameProvider2.getShortName(locale71, "1", "");
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket78 = new org.joda.time.format.DateTimeParserBucket((long) 19, (org.joda.time.Chronology) julianChronology1, locale71, (java.lang.Integer) 5, 319);
//        int int79 = dateTimeParserBucket78.getOffset();
//        org.junit.Assert.assertNotNull(julianChronology1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(gJChronology9);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(limitChronology21);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-255139199999L) + "'", long25 == (-255139199999L));
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(locale30);
//        org.junit.Assert.assertNull(str33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 740 + "'", int41 == 740);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeZone49);
//        org.junit.Assert.assertNotNull(gJChronology50);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertNotNull(gJChronology55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(property59);
//        org.junit.Assert.assertNotNull(property60);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(limitChronology62);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + (-255139199999L) + "'", long66 == (-255139199999L));
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertNotNull(locale71);
//        org.junit.Assert.assertNotNull(calendar72);
//        org.junit.Assert.assertNull(str75);
//        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (-255139199999L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-9223372036854775808L) + "'", long1 == (-9223372036854775808L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) 'a', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTimeZoneId();
        boolean boolean8 = dateTimeFormatterBuilder7.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
//        java.lang.String str7 = mutableDateTime4.toString();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.secondOfMinute();
//        org.joda.time.ReadablePeriod readablePeriod9 = null;
//        mutableDateTime4.add(readablePeriod9);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str7.equals("1970-01-01T00:00:00.000Z"));
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHour();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(0L, chronology6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(10);
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfCentury();
        org.joda.time.DateTime.Property property14 = dateTime12.millisOfSecond();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology9, (org.joda.time.ReadableDateTime) dateTime12, (org.joda.time.ReadableDateTime) dateTime15);
        org.joda.time.DateTime dateTime17 = limitChronology16.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod18 = null;
        org.joda.time.DateTime dateTime20 = dateTime17.withPeriodAdded(readablePeriod18, (int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.MutableDateTime mutableDateTime25 = new org.joda.time.MutableDateTime(0L, chronology24);
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) mutableDateTime25);
        org.joda.time.MutableDateTime mutableDateTime28 = dateTime17.toMutableDateTime(dateTimeZone21);
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.yearOfEra();
        int int30 = mutableDateTime28.getYear();
        org.joda.time.MutableDateTime.Property property31 = mutableDateTime28.monthOfYear();
        org.joda.time.Chronology chronology33 = null;
        org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime(0L, chronology33);
        mutableDateTime28.setDate((org.joda.time.ReadableInstant) mutableDateTime34);
        int int38 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime34, "������", 86390);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(mutableDateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-86391) + "'", int38 == (-86391));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendSecondOfMinute(488);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("10", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"10/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        java.util.TimeZone timeZone1 = null;
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
//        org.joda.time.MutableDateTime mutableDateTime3 = org.joda.time.MutableDateTime.now(dateTimeZone2);
//        int int4 = mutableDateTime3.getWeekOfWeekyear();
//        boolean boolean5 = gregorianChronology0.equals((java.lang.Object) int4);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(mutableDateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
//        long long3 = mutableDateTime2.getMillis();
//        int int4 = mutableDateTime2.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.secondOfMinute();
//        mutableDateTime2.setSecondOfMinute(2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(0L, chronology7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(10);
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfSecond();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology10, (org.joda.time.ReadableDateTime) dateTime13, (org.joda.time.ReadableDateTime) dateTime16);
        org.joda.time.DateTime dateTime18 = limitChronology17.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) (short) 0);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTimeField dateTimeField23 = gJChronology22.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(740);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = dateTimeFormatter2.withPivotYear((java.lang.Integer) 1439);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 84, (long) 2019);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 169596 + "'", int2 == 169596);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay(1439);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder3.appendWeekyear(6, 0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTime dateTime14 = limitChronology13.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (short) 0);
        org.joda.time.DateTime dateTime19 = dateTime17.minus((long) (short) -1);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime(0L, chronology21);
        long long23 = mutableDateTime22.getMillis();
        boolean boolean24 = dateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime22);
        org.joda.time.DateTime dateTime26 = dateTime17.withWeekyear(12);
        org.joda.time.ReadablePeriod readablePeriod27 = null;
        org.joda.time.DateTime dateTime28 = dateTime17.minus(readablePeriod27);
        try {
            org.joda.time.DateTime dateTime30 = dateTime28.withMillisOfSecond(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = limitChronology13.add(readablePeriod14, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime18 = limitChronology13.getUpperLimit();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) limitChronology13, dateTimeZone19);
        org.joda.time.Chronology chronology21 = zonedChronology20.withUTC();
        org.joda.time.DurationField durationField22 = zonedChronology20.halfdays();
        org.joda.time.DurationFieldType durationFieldType23 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField24 = new org.joda.time.field.DecoratedDurationField(durationField22, durationFieldType23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-255139199999L) + "'", long17 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(0L, chronology9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(10);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
        org.joda.time.DateTime.Property property17 = dateTime15.millisOfSecond();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology12, (org.joda.time.ReadableDateTime) dateTime15, (org.joda.time.ReadableDateTime) dateTime18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        long long23 = limitChronology19.add(readablePeriod20, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime24 = limitChronology19.getUpperLimit();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ZonedChronology zonedChronology26 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) limitChronology19, dateTimeZone25);
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime28 = null;
        boolean boolean29 = dateTimeZone27.isLocalDateTimeGap(localDateTime28);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime(0L, chronology34);
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, (org.joda.time.ReadableInstant) mutableDateTime35);
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime40 = dateTime38.minusSeconds(10);
        org.joda.time.DateTime.Property property41 = dateTime40.yearOfCentury();
        org.joda.time.DateTime.Property property42 = dateTime40.millisOfSecond();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology44 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology37, (org.joda.time.ReadableDateTime) dateTime40, (org.joda.time.ReadableDateTime) dateTime43);
        org.joda.time.DateTime dateTime45 = limitChronology44.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod46 = null;
        org.joda.time.DateTime dateTime48 = dateTime45.withPeriodAdded(readablePeriod46, (int) (short) 0);
        org.joda.time.chrono.GJChronology gJChronology49 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone27, (org.joda.time.ReadableInstant) dateTime48);
        long long51 = dateTimeZone27.convertUTCToLocal((long) 163);
        org.joda.time.LocalDateTime localDateTime52 = null;
        boolean boolean53 = dateTimeZone27.isLocalDateTimeGap(localDateTime52);
        org.joda.time.ReadableInstant readableInstant54 = null;
        int int55 = dateTimeZone27.getOffset(readableInstant54);
        org.joda.time.Chronology chronology56 = zonedChronology26.withZone(dateTimeZone27);
        try {
            org.joda.time.DateTime dateTime57 = new org.joda.time.DateTime(86399, (int) (short) 1, (int) (byte) 1, 19, 488, 169596, dateTimeZone27);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 488 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-255139199999L) + "'", long23 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(zonedChronology26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(limitChronology44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(gJChronology49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 163L + "'", long51 == 163L);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(chronology56);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
//        long long3 = mutableDateTime2.getMillis();
//        mutableDateTime2.setMinuteOfHour(0);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(dateTimeZone7);
//        long long9 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime8.centuryOfEra();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime12 = null;
//        boolean boolean13 = dateTimeZone11.isLocalDateTimeGap(localDateTime12);
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
//        org.joda.time.DurationField durationField15 = gJChronology14.months();
//        org.joda.time.DateTimeZone dateTimeZone16 = gJChronology14.getZone();
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
//        mutableDateTime8.setZoneRetainFields(dateTimeZone16);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-433428L) + "'", long9 == (-433428L));
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
//    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(10);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = limitChronology18.add(readablePeriod19, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime23 = limitChronology18.getUpperLimit();
        boolean boolean24 = property4.equals((java.lang.Object) limitChronology18);
        java.util.Locale locale25 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology18, locale25);
        long long29 = dateTimeParserBucket26.computeMillis(false, "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:20:05.132Z, 2019-06-12T12:20:15.133Z]");
        long long30 = dateTimeParserBucket26.computeMillis();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-255139199999L) + "'", long22 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1L + "'", long29 == 1L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1L + "'", long30 == 1L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(10);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfCentury();
        org.joda.time.DateTime.Property property6 = dateTime4.millisOfSecond();
        org.joda.time.LocalDate localDate7 = dateTime4.toLocalDate();
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) localDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(localDate7);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
//        java.lang.String str7 = mutableDateTime4.toString();
//        java.util.TimeZone timeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
//        mutableDateTime4.setZoneRetainFields(dateTimeZone9);
//        try {
//            org.joda.time.chrono.JulianChronology julianChronology12 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone9, 86390);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 86390");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str7.equals("1970-01-01T00:00:00.000Z"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (long) 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.era();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.roundHalfFloor();
//        int int8 = property4.getMaximumValueOverall();
//        org.joda.time.MutableDateTime mutableDateTime10 = property4.addWrapField((-1));
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.year();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime();
        org.joda.time.DateTime dateTime9 = dateTime2.plusMonths((int) (short) 10);
        try {
            org.joda.time.DateTime dateTime13 = dateTime2.withDate((int) '4', 169596, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 169596 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.era();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.roundHalfFloor();
//        try {
//            mutableDateTime7.setDateTime((int) (short) 10, (int) (short) -1, (int) (byte) 10, (int) '#', (-32), 37, 52);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        long long3 = mutableDateTime2.getMillis();
        mutableDateTime2.setMinuteOfHour(0);
        org.joda.time.Instant instant6 = mutableDateTime2.toInstant();
        mutableDateTime2.addWeekyears(321);
        mutableDateTime2.setMillis((long) 488);
        mutableDateTime2.addWeeks(321);
        mutableDateTime2.setMillisOfDay(44448);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int int0 = org.joda.time.MutableDateTime.ROUND_HALF_CEILING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DateTime.Property property5 = dateTime4.hourOfDay();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = limitChronology13.add(readablePeriod14, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime18 = limitChronology13.getUpperLimit();
        org.joda.time.DateTime.Property property19 = dateTime18.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-255139199999L) + "'", long17 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = limitChronology13.add(readablePeriod14, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime18 = limitChronology13.getUpperLimit();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) limitChronology13, dateTimeZone19);
        org.joda.time.Chronology chronology21 = zonedChronology20.withUTC();
        java.lang.Object obj22 = null;
        boolean boolean23 = zonedChronology20.equals(obj22);
        org.joda.time.Chronology chronology24 = zonedChronology20.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-255139199999L) + "'", long17 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("Jan");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Jan\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.seconds();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfSecond(0, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitYear((-32));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder12.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendTwoDigitWeekyear((int) 'a', false);
        org.joda.time.format.DateTimePrinter dateTimePrinter19 = dateTimeFormatterBuilder15.toPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser21 = dateTimeFormatter20.getParser();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder9.append(dateTimePrinter19, dateTimeParser21);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder23 = dateTimeFormatterBuilder22.appendMonthOfYearShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder22.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimePrinter19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTimeParser21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTimeField dateTimeField7 = gJChronology6.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        mutableDateTime4.setDayOfYear(163);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            int int11 = mutableDateTime4.get(dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) 'a', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendTwoDigitWeekyear(1970);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = limitChronology13.add(readablePeriod14, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime18 = limitChronology13.getUpperLimit();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) limitChronology13, dateTimeZone19);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone19);
        long long24 = dateTimeZone19.convertLocalToUTC((long) 86399, false);
        org.joda.time.LocalDateTime localDateTime25 = null;
        boolean boolean26 = dateTimeZone19.isLocalDateTimeGap(localDateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-255139199999L) + "'", long17 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 86399L + "'", long24 == 86399L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        mutableDateTime4.setDayOfYear(163);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime4.secondOfMinute();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(10);
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfCentury();
        org.joda.time.DateTime dateTime14 = property13.withMaximumValue();
        org.joda.time.DateTime dateTime16 = dateTime14.withYear((int) '4');
        org.joda.time.DateTime dateTime18 = dateTime14.plus((long) 1439);
        org.joda.time.DateTime.Property property19 = dateTime18.dayOfYear();
        try {
            int int20 = property9.getDifference((org.joda.time.ReadableInstant) dateTime18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -4070953260");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) (-741));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DurationField durationField5 = gJChronology4.months();
        org.joda.time.DateTimeZone dateTimeZone6 = gJChronology4.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        int int9 = cachedDateTimeZone7.getOffset(0L);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((long) 44, (org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
//        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
//        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
//        org.joda.time.DateTime dateTime6 = dateTime4.withYear((int) '4');
//        org.joda.time.DateTime dateTime8 = dateTime4.plus((long) 1439);
//        org.joda.time.YearMonthDay yearMonthDay9 = dateTime8.toYearMonthDay();
//        long long10 = dateTime8.getMillis();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(yearMonthDay9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 4084950060728L + "'", long10 == 4084950060728L);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        long long3 = mutableDateTime2.getMillis();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds(10);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfCentury();
        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
        org.joda.time.DateTime dateTime10 = property7.addToCopy(0);
        org.joda.time.DateTime dateTime11 = property7.roundCeilingCopy();
        mutableDateTime2.setMillis((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            mutableDateTime2.set(dateTimeFieldType13, (-9601));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        java.lang.Object obj14 = null;
        boolean boolean15 = limitChronology13.equals(obj14);
        org.joda.time.DurationField durationField16 = limitChronology13.weekyears();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(durationField16);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYearOfCentury(488, 321);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay(1439);
        boolean boolean6 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendTimeZoneId();
        boolean boolean8 = dateTimeFormatterBuilder5.canBuildPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.weekOfWeekyear();
        int int5 = dateTime2.getCenturyOfEra();
        org.joda.time.DateTime.Property property6 = dateTime2.millisOfDay();
        org.joda.time.DateTime.Property property7 = dateTime2.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DateTime.Property property5 = dateTime4.hourOfDay();
        org.joda.time.DateTime dateTime6 = property5.getDateTime();
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(100);
        java.lang.String str7 = property4.toString();
        org.joda.time.DateTime dateTime9 = property4.setCopy((int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime9.era();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[millisOfSecond]" + "'", str7.equals("Property[millisOfSecond]"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.millisOfDay();
        mutableDateTime4.setSecondOfDay((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.Instant instant6 = instant4.plus((long) (short) 10);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant6.withDurationAdded(readableDuration7, 319);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant11 = instant6.minus(readableDuration10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        long long3 = mutableDateTime2.getMillis();
        mutableDateTime2.setMinuteOfHour(0);
        org.joda.time.Instant instant6 = mutableDateTime2.toInstant();
        org.joda.time.Instant instant9 = instant6.withDurationAdded((long) (short) 100, 488);
        org.joda.time.DateTime dateTime10 = instant6.toDateTime();
        org.joda.time.Chronology chronology11 = instant6.getChronology();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfSecond(0, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendFractionOfHour(488, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder10.appendFractionOfMinute((int) (byte) 10, 44);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.minuteOfHour();
        org.joda.time.DateTime dateTime16 = dateTime12.plusMillis(321);
        boolean boolean17 = dateTime16.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(10);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = limitChronology18.add(readablePeriod19, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime23 = limitChronology18.getUpperLimit();
        boolean boolean24 = property4.equals((java.lang.Object) limitChronology18);
        java.util.Locale locale25 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology18, locale25);
        java.util.Locale locale27 = dateTimeParserBucket26.getLocale();
        dateTimeParserBucket26.setOffset((java.lang.Integer) 320);
        org.joda.time.Chronology chronology30 = dateTimeParserBucket26.getChronology();
        org.joda.time.DateTimeZone dateTimeZone31 = dateTimeParserBucket26.getZone();
        org.joda.time.Chronology chronology32 = dateTimeParserBucket26.getChronology();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-255139199999L) + "'", long22 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(chronology32);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
//        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
//        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = dateTime7.plusMonths((int) (short) 10);
//        boolean boolean10 = dateTime4.isEqual((org.joda.time.ReadableInstant) dateTime7);
//        org.joda.time.ReadablePeriod readablePeriod11 = null;
//        org.joda.time.DateTime dateTime12 = dateTime7.plus(readablePeriod11);
//        org.joda.time.DateTime dateTime14 = dateTime12.withMillisOfSecond(5);
//        long long15 = dateTime12.getMillis();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560342070111L + "'", long15 == 1560342070111L);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.year();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.Chronology chronology5 = iSOChronology4.withUTC();
        org.joda.time.DateTime dateTime6 = dateTime2.withChronology(chronology5);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(1, (int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter0.withZone(dateTimeZone5);
        java.lang.String str8 = dateTimeZone5.getShortName((long) 321);
        org.joda.time.chrono.BuddhistChronology buddhistChronology9 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.Chronology chronology11 = dateTime10.getChronology();
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(chronology11);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime(0L, chronology16);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime22 = dateTime20.minusSeconds(10);
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfCentury();
        org.joda.time.DateTime.Property property24 = dateTime22.millisOfSecond();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology19, (org.joda.time.ReadableDateTime) dateTime22, (org.joda.time.ReadableDateTime) dateTime25);
        org.joda.time.DateTimeField dateTimeField27 = gJChronology19.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology19.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField(chronology11, dateTimeField28);
        org.joda.time.field.SkipDateTimeField skipDateTimeField31 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) buddhistChronology9, (org.joda.time.DateTimeField) skipUndoDateTimeField29, 3);
        long long33 = skipUndoDateTimeField29.roundHalfCeiling((-9223372036854775808L));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+01:00" + "'", str8.equals("+01:00"));
        org.junit.Assert.assertNotNull(buddhistChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(limitChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-9223372036854775808L) + "'", long33 == (-9223372036854775808L));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology6.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology6.millisOfSecond();
        org.joda.time.DurationField durationField16 = gJChronology6.halfdays();
        long long19 = durationField16.subtract(0L, (long) 2000);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-86400000000L) + "'", long19 == (-86400000000L));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(100);
        org.joda.time.DateTime dateTime7 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime9 = property4.setCopy((int) (byte) 1);
        int int10 = dateTime9.getYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2019 + "'", int10 == 2019);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) 1, 6, 163);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 159 + "'", int3 == 159);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        try {
            org.joda.time.MutableDateTime mutableDateTime1 = org.joda.time.MutableDateTime.parse("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:20:08.901Z, 2019-06-12T12:20:18.902Z]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"LimitChronology[GJChronology[UTC...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        try {
            long long9 = gregorianChronology0.getDateTimeMillis(319, 320, (-1), 0, 6, (-9601), 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -9601 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test079() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test079");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.LocalDateTime localDateTime1 = null;
//        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
//        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.DurationField durationField4 = gJChronology3.months();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
//        org.joda.time.Chronology chronology8 = null;
//        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
//        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
//        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology11.minuteOfDay();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField19, (int) '#');
//        boolean boolean22 = skipUndoDateTimeField21.isSupported();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime25 = dateTime23.minusSeconds(10);
//        org.joda.time.DateTime.Property property26 = dateTime25.yearOfCentury();
//        org.joda.time.DateTime.Property property27 = dateTime25.millisOfSecond();
//        org.joda.time.LocalDate localDate28 = dateTime25.toLocalDate();
//        int int29 = skipUndoDateTimeField21.getMaximumValue((org.joda.time.ReadablePartial) localDate28);
//        int int31 = skipUndoDateTimeField21.getMaximumValue(0L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.dateTime();
//        org.joda.time.chrono.GJChronology gJChronology33 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField34 = gJChronology33.months();
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime37 = dateTime35.minusSeconds(10);
//        org.joda.time.DateTime.Property property38 = dateTime37.yearOfCentury();
//        org.joda.time.DateTime.Property property39 = dateTime37.millisOfSecond();
//        org.joda.time.LocalDate localDate40 = dateTime37.toLocalDate();
//        long long42 = gJChronology33.set((org.joda.time.ReadablePartial) localDate40, (long) (byte) 10);
//        java.lang.String str43 = dateTimeFormatter32.print((org.joda.time.ReadablePartial) localDate40);
//        int[] intArray45 = null;
//        try {
//            int[] intArray47 = skipUndoDateTimeField21.addWrapField((org.joda.time.ReadablePartial) localDate40, 521, intArray45, 44448);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(gJChronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(limitChronology18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1439 + "'", int29 == 1439);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1439 + "'", int31 == 1439);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(gJChronology33);
//        org.junit.Assert.assertNotNull(durationField34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1560297600010L + "'", long42 == 1560297600010L);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "2019-06-12T��:��:��.000" + "'", str43.equals("2019-06-12T��:��:��.000"));
//    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property3.addToCopy(0);
        org.joda.time.DateTime dateTime7 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.plus((long) (-32));
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime12 = dateTime7.withPeriodAdded(readablePeriod10, 319);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime(0L, chronology16);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) mutableDateTime17);
        java.lang.String str20 = mutableDateTime17.toString();
        java.util.TimeZone timeZone21 = null;
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forTimeZone(timeZone21);
        mutableDateTime17.setZoneRetainFields(dateTimeZone22);
        org.joda.time.DateTime dateTime24 = dateTime12.withZoneRetainFields(dateTimeZone22);
        org.joda.time.DateTime dateTime26 = dateTime12.minusYears(0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str20.equals("1970-01-01T00:00:00.000Z"));
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYear((int) (byte) 0, 1439);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder6.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder8.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter11 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser13 = dateTimeFormatter12.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter11, dateTimeParser13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder10.appendOptional(dateTimeParser13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser13);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder0.appendMinuteOfDay(2019);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeParser13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTime dateTime14 = limitChronology13.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (short) 0);
        org.joda.time.DateTime dateTime19 = dateTime17.minus((long) (short) -1);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime(0L, chronology21);
        long long23 = mutableDateTime22.getMillis();
        boolean boolean24 = dateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime22);
        int int25 = dateTime17.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.millisOfDay();
        mutableDateTime4.setDate((-3599849L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.months();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        java.lang.String str3 = gJChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology0.getZone();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[UTC]" + "'", str3.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTime.Property property14 = dateTime12.minuteOfHour();
        org.joda.time.DateTime dateTime16 = dateTime12.plusMillis(321);
        org.joda.time.DateTime.Property property17 = dateTime16.millisOfDay();
        org.joda.time.DateTime dateTime19 = dateTime16.minusMillis((int) (byte) -1);
        org.joda.time.DateTime.Property property20 = dateTime19.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        long long3 = mutableDateTime2.getMillis();
        mutableDateTime2.setMinuteOfHour(0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.weekOfWeekyear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder0.appendYearOfCentury(488, 321);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendDayOfMonth(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder7.appendMonthOfYearText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeUtils.getZone(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfSecond(0, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendFractionOfHour(488, (int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder4.appendMinuteOfDay((int) 'a');
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test090() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test090");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) (byte) 0);
//        int int4 = dateTime1.getDayOfYear();
//        org.joda.time.ReadablePeriod readablePeriod5 = null;
//        org.joda.time.DateTime dateTime7 = dateTime1.withPeriodAdded(readablePeriod5, (int) (byte) 100);
//        org.joda.time.DateTime dateTime9 = dateTime1.plusYears(84);
//        org.joda.time.MutableDateTime mutableDateTime10 = dateTime9.toMutableDateTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 163 + "'", int4 == 163);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(mutableDateTime10);
//    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "Jan");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Zone must not be null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        long long3 = mutableDateTime2.getMillis();
        mutableDateTime2.setMinuteOfHour(0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.hourOfDay();
        mutableDateTime2.setMillisOfSecond(163);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        long long3 = mutableDateTime2.getMillis();
        mutableDateTime2.setMinuteOfHour(0);
        org.joda.time.Instant instant6 = mutableDateTime2.toInstant();
        mutableDateTime2.setDayOfMonth((int) (short) 10);
        mutableDateTime2.setMillisOfSecond(1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(instant6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime6 = dateTime4.withYear((int) '4');
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property3.addToCopy(0);
        org.joda.time.DateTime dateTime8 = property3.addWrapFieldToCopy((int) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone10 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone12 = gregorianChronology9.getZone();
        org.joda.time.DateTime dateTime13 = dateTime8.toDateTime(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
//        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
//        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
//        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
//        org.joda.time.DateTime.Property property6 = dateTime2.year();
//        int int7 = dateTime2.getMinuteOfDay();
//        org.joda.time.DateTime dateTime9 = dateTime2.withEra((int) (short) 1);
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(10);
//        org.joda.time.DateTime.Property property13 = dateTime12.yearOfCentury();
//        org.joda.time.DateTime.Property property14 = dateTime12.millisOfSecond();
//        org.joda.time.LocalDate localDate15 = dateTime12.toLocalDate();
//        org.joda.time.DateTime.Property property16 = dateTime12.year();
//        org.joda.time.MutableDateTime mutableDateTime17 = dateTime12.toMutableDateTime();
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        mutableDateTime17.add(readablePeriod18);
//        org.joda.time.MutableDateTime.Property property20 = mutableDateTime17.year();
//        org.joda.time.Chronology chronology21 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) mutableDateTime17);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(localDate5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 741 + "'", int7 == 741);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(localDate15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(mutableDateTime17);
//        org.junit.Assert.assertNotNull(property20);
//        org.junit.Assert.assertNotNull(chronology21);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = gregorianChronology0.getZone();
        java.lang.String str2 = dateTimeZone1.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UTC" + "'", str2.equals("UTC"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) -1, '4', 70, 488, 0, false, (int) (short) 0);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder0.addCutover((-432688), ' ', 169596, 24, 100, false, 86399);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTime dateTime14 = limitChronology13.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime(0L, chronology21);
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime22.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) mutableDateTime22);
        org.joda.time.MutableDateTime mutableDateTime25 = dateTime14.toMutableDateTime(dateTimeZone18);
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.yearOfEra();
        int int27 = mutableDateTime25.getYear();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime25.monthOfYear();
        org.joda.time.MutableDateTime mutableDateTime30 = property28.addWrapField(163);
        org.joda.time.DateTime dateTime31 = mutableDateTime30.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(mutableDateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfMonth();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfCentury();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.Chronology chronology0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
//        org.joda.time.Chronology chronology4 = null;
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(0L, chronology4);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime5.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1, (org.joda.time.ReadableInstant) mutableDateTime5);
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds(10);
//        org.joda.time.DateTime.Property property11 = dateTime10.yearOfCentury();
//        org.joda.time.DateTime.Property property12 = dateTime10.millisOfSecond();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology14 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology7, (org.joda.time.ReadableDateTime) dateTime10, (org.joda.time.ReadableDateTime) dateTime13);
//        org.joda.time.DateTime dateTime15 = limitChronology14.getUpperLimit();
//        org.joda.time.ReadablePeriod readablePeriod16 = null;
//        org.joda.time.DateTime dateTime18 = dateTime15.withPeriodAdded(readablePeriod16, (int) (short) 0);
//        org.joda.time.DateTime dateTime20 = dateTime18.minus((long) (short) -1);
//        int int21 = dateTime18.getMinuteOfHour();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22);
//        org.joda.time.Chronology chronology25 = null;
//        org.joda.time.MutableDateTime mutableDateTime26 = new org.joda.time.MutableDateTime(0L, chronology25);
//        org.joda.time.MutableDateTime.Property property27 = mutableDateTime26.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone22, (org.joda.time.ReadableInstant) mutableDateTime26);
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime31 = dateTime29.minusSeconds(10);
//        org.joda.time.DateTime.Property property32 = dateTime31.yearOfCentury();
//        org.joda.time.DateTime.Property property33 = dateTime31.millisOfSecond();
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology35 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology28, (org.joda.time.ReadableDateTime) dateTime31, (org.joda.time.ReadableDateTime) dateTime34);
//        org.joda.time.DateTime dateTime36 = limitChronology35.getLowerLimit();
//        try {
//            org.joda.time.chrono.LimitChronology limitChronology37 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime18, (org.joda.time.ReadableDateTime) dateTime36);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(limitChronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 21 + "'", int21 == 21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(limitChronology35);
//        org.junit.Assert.assertNotNull(dateTime36);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[millisOfSecond]", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:58.886-07:00, 2019-06-12T05:20:08.887-07:00]", (int) '4', 319);
        long long6 = fixedDateTimeZone4.previousTransition((long) (short) 1);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (long) 84, (int) (short) 1);
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(gJChronology9);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime6 = dateTime4.withDayOfYear((int) (byte) 10);
        int int7 = dateTime6.getYearOfCentury();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime10 = dateTime6.withDurationAdded(readableDuration8, 320);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 99 + "'", int7 == 99);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(dateTimeZone1);
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((-433428L), dateTimeZone1);
        try {
            mutableDateTime3.setMillisOfSecond((-32));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) (short) -1, (int) (byte) 1);
        java.lang.String str3 = dateTimeZone2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-01:01" + "'", str3.equals("-01:01"));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DurationField durationField5 = property3.getDurationField();
        java.lang.String str6 = property3.getAsString();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        int int1 = dateTimeFormatter0.getDefaultYear();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronolgy();
        try {
            org.joda.time.LocalDate localDate5 = dateTimeFormatter0.parseLocalDate("1970-01-01T00:00:00.000Z");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1970-01-01T00:00:00.000Z\" is malformed at \"-01-01T00:00:00.000Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = property3.roundHalfCeiling();
        try {
            org.joda.time.MutableDateTime mutableDateTime6 = property3.set("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:20:08.901Z, 2019-06-12T12:20:18.902Z]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:20:08.901Z, 2019-06-12T12:20:18.902Z]\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime6 = property5.roundHalfCeiling();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(0L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(10);
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfCentury();
        org.joda.time.DateTime.Property property18 = dateTime16.millisOfSecond();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology20 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology13, (org.joda.time.ReadableDateTime) dateTime16, (org.joda.time.ReadableDateTime) dateTime19);
        org.joda.time.DateTimeFieldType dateTimeFieldType21 = null;
        boolean boolean22 = dateTime16.isSupported(dateTimeFieldType21);
        org.joda.time.chrono.LimitChronology limitChronology23 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology1, (org.joda.time.ReadableDateTime) mutableDateTime6, (org.joda.time.ReadableDateTime) dateTime16);
        org.joda.time.DurationField durationField24 = limitChronology23.weeks();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(limitChronology20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(limitChronology23);
        org.junit.Assert.assertNotNull(durationField24);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        try {
            long long2 = dateTimeFormatter0.parseMillis("org.joda.time.IllegalFieldValueException: Value \"LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:46.352-07:00, 2019-06-12T05:19:56.353-07:00]\" for LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:46.352-07:00, 2019-06-12T05:19:56.353-07:00] is not supported");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalFieldValueE...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1560297600010L, (java.lang.Number) 321L, (java.lang.Number) 57600010L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder3.appendTwoDigitWeekyear((int) 'a', false);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder3.appendFractionOfHour(0, 159);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property4.getDateTime();
        org.joda.time.DateTime dateTime6 = property4.roundHalfEvenCopy();
        org.joda.time.LocalDate localDate7 = dateTime6.toLocalDate();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(100);
        org.joda.time.DateTime dateTime7 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime9 = property4.setCopy((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMonths((-432688));
        org.joda.time.DateTime dateTime13 = dateTime11.withEra(0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology6.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology6.millisOfSecond();
        org.joda.time.DurationField durationField16 = gJChronology6.halfdays();
        org.joda.time.DateTimeField dateTimeField17 = gJChronology6.weekyear();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology6.yearOfCentury();
        try {
            long long26 = gJChronology6.getDateTimeMillis(10, 1, 44448, 9600, (int) (short) 0, (-741), 70);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 9600 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) (byte) 0);
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.DateTime.Property property5 = dateTime3.property(dateTimeFieldType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, 163L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 163L + "'", long2 == 163L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime5 = null;
        boolean boolean6 = dateTimeZone4.isLocalDateTimeGap(localDateTime5);
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        boolean boolean8 = julianChronology3.equals((java.lang.Object) dateTimeZone4);
        int int9 = julianChronology3.getMinimumDaysInFirstWeek();
        try {
            long long17 = julianChronology3.getDateTimeMillis(0, (int) '#', (int) (short) 100, 740, 86390, (int) (short) -1, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 740 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test121");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.era();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.roundHalfFloor();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = dateTime8.withLaterOffsetAtOverlap();
//        org.joda.time.DateTime dateTime11 = dateTime9.withSecondOfMinute((int) (byte) 0);
//        int int12 = dateTime9.getDayOfYear();
//        boolean boolean13 = mutableDateTime7.isEqual((org.joda.time.ReadableInstant) dateTime9);
//        mutableDateTime7.addMillis((-9601));
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 163 + "'", int12 == 163);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        long long4 = dateTimeZone0.convertLocalToUTC((long) 99, true);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 99L + "'", long4 == 99L);
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test123");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
//        mutableDateTime2.addWeekyears(0);
//        org.joda.time.ReadablePeriod readablePeriod7 = null;
//        mutableDateTime2.add(readablePeriod7);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
//        org.junit.Assert.assertNotNull(property4);
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(10);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = limitChronology18.add(readablePeriod19, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime23 = limitChronology18.getUpperLimit();
        boolean boolean24 = property4.equals((java.lang.Object) limitChronology18);
        java.util.Locale locale25 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology18, locale25);
        int int27 = dateTimeParserBucket26.getOffset();
        java.lang.Integer int28 = dateTimeParserBucket26.getPivotYear();
        dateTimeParserBucket26.setOffset((java.lang.Integer) 99);
        java.lang.Object obj31 = dateTimeParserBucket26.saveState();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-255139199999L) + "'", long22 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(int28);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = gJChronology3.months();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology11.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField19, (int) '#');
        long long24 = skipUndoDateTimeField21.set((long) (short) 1, (int) (byte) 1);
        long long26 = skipUndoDateTimeField21.roundHalfFloor((long) (-86391));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-60000L) + "'", long26 == (-60000L));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime7 = property6.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        int int1 = dateTimeFormatter0.getDefaultYear();
        boolean boolean2 = dateTimeFormatter0.isParser();
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTimeZone dateTimeZone4 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(chronology3);
        org.junit.Assert.assertNull(dateTimeZone4);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder2.appendFractionOfDay(5, (-32));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendMinuteOfDay(0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatterBuilder2.toFormatter();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = gJChronology3.months();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone6.getUncachedZone();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime10 = dateTime8.minusSeconds(10);
        org.joda.time.DateTime.Property property11 = dateTime10.yearOfCentury();
        org.joda.time.DateTime.Property property12 = dateTime10.millisOfSecond();
        org.joda.time.DateTime dateTime13 = property12.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime15 = dateTime13.plusMinutes(1);
        boolean boolean16 = cachedDateTimeZone6.equals((java.lang.Object) dateTime15);
        int int18 = cachedDateTimeZone6.getOffset((long) 5);
        int int20 = cachedDateTimeZone6.getStandardOffset((long) 521);
        long long22 = cachedDateTimeZone6.nextTransition((-227210599712394376L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-227210599712394376L) + "'", long22 == (-227210599712394376L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property3.addToCopy(0);
        org.joda.time.DateTime dateTime8 = dateTime6.plusMillis(1);
        org.joda.time.DateTime dateTime10 = dateTime6.minusMonths(1439);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        org.joda.time.Instant instant3 = mutableDateTime2.toInstant();
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTime();
        try {
            mutableDateTime4.setDayOfWeek((int) '#');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime9 = null;
        boolean boolean10 = dateTimeZone8.isLocalDateTimeGap(localDateTime9);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.DurationField durationField12 = gJChronology11.months();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime(0L, chronology16);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime22 = dateTime20.minusSeconds(10);
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfCentury();
        org.joda.time.DateTime.Property property24 = dateTime22.millisOfSecond();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology19, (org.joda.time.ReadableDateTime) dateTime22, (org.joda.time.ReadableDateTime) dateTime25);
        org.joda.time.DateTimeField dateTimeField27 = gJChronology19.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField29 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27, (int) '#');
        boolean boolean30 = skipUndoDateTimeField29.isSupported();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime33 = dateTime31.minusSeconds(10);
        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
        org.joda.time.DateTime.Property property35 = dateTime33.millisOfSecond();
        org.joda.time.LocalDate localDate36 = dateTime33.toLocalDate();
        int int37 = skipUndoDateTimeField29.getMaximumValue((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.DateTime dateTime38 = dateTime6.withFields((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.DateTime dateTime40 = dateTime38.withSecondOfMinute(0);
        org.joda.time.MutableDateTime mutableDateTime41 = dateTime38.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(limitChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1439 + "'", int37 == 1439);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(mutableDateTime41);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(10);
        org.joda.time.DateTime dateTime5 = dateTime3.plusWeeks(960);
        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfHour();
        org.joda.time.DateTime dateTime8 = dateTime5.plusWeeks(9600);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(0L, chronology13);
        org.joda.time.MutableDateTime.Property property15 = mutableDateTime14.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10, (org.joda.time.ReadableInstant) mutableDateTime14);
        long long18 = dateTimeZone9.getMillisKeepLocal(dateTimeZone10, (long) (byte) 100);
        org.joda.time.DateTime dateTime19 = new org.joda.time.DateTime((long) 3, dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(gJChronology16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 100L + "'", long18 == 100L);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTime dateTime14 = limitChronology13.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (short) 0);
        org.joda.time.DateTime dateTime19 = dateTime17.minus((long) (short) -1);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime(0L, chronology21);
        long long23 = mutableDateTime22.getMillis();
        boolean boolean24 = dateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime22);
        org.joda.time.DateTime dateTime26 = dateTime17.withWeekyear(12);
        org.joda.time.DateTime dateTime27 = dateTime26.toDateTime();
        org.joda.time.DateTime dateTime29 = dateTime26.withYearOfEra(488);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        java.lang.String str7 = mutableDateTime4.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(0L, chronology11);
        org.joda.time.MutableDateTime.Property property13 = mutableDateTime12.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8, (org.joda.time.ReadableInstant) mutableDateTime12);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime17 = dateTime15.minusSeconds(10);
        org.joda.time.DateTime.Property property18 = dateTime17.yearOfCentury();
        org.joda.time.DateTime.Property property19 = dateTime17.millisOfSecond();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology21 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology14, (org.joda.time.ReadableDateTime) dateTime17, (org.joda.time.ReadableDateTime) dateTime20);
        org.joda.time.ReadablePeriod readablePeriod22 = null;
        long long25 = limitChronology21.add(readablePeriod22, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime26 = limitChronology21.getUpperLimit();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ZonedChronology zonedChronology28 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) limitChronology21, dateTimeZone27);
        mutableDateTime4.setZoneRetainFields(dateTimeZone27);
        org.joda.time.MutableDateTime mutableDateTime30 = new org.joda.time.MutableDateTime((java.lang.Object) mutableDateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str7.equals("1970-01-01T00:00:00.000Z"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(limitChronology21);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-255139199999L) + "'", long25 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(zonedChronology28);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray12 = new org.joda.time.format.DateTimeParser[] { dateTimeParser7, dateTimeParser9, dateTimeParser11 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder4.append(dateTimePrinter5, dateTimeParserArray12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMinuteOfHour(37);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder15.appendCenturyOfEra(99, (int) (byte) 0);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder20 = dateTimeFormatterBuilder18.appendMillisOfDay((-86391));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeParserArray12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gJChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(960, 1970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 960");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.year();
        org.joda.time.DateTime dateTime8 = dateTime2.plus((long) 37);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter5 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser7 = dateTimeFormatter6.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser9 = dateTimeFormatter8.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser11 = dateTimeFormatter10.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray12 = new org.joda.time.format.DateTimeParser[] { dateTimeParser7, dateTimeParser9, dateTimeParser11 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder4.append(dateTimePrinter5, dateTimeParserArray12);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMinuteOfHour(37);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder13.appendDayOfWeekShortText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder13.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertNotNull(dateTimeParser7);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTimeParser9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTimeParser11);
        org.junit.Assert.assertNotNull(dateTimeParserArray12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTime dateTime14 = limitChronology13.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime(0L, chronology21);
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime22.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) mutableDateTime22);
        org.joda.time.MutableDateTime mutableDateTime25 = dateTime14.toMutableDateTime(dateTimeZone18);
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime29 = dateTime27.minusSeconds(10);
        org.joda.time.DateTime.Property property30 = dateTime29.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime(0L, chronology34);
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, (org.joda.time.ReadableInstant) mutableDateTime35);
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime40 = dateTime38.minusSeconds(10);
        org.joda.time.DateTime.Property property41 = dateTime40.yearOfCentury();
        org.joda.time.DateTime.Property property42 = dateTime40.millisOfSecond();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology44 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology37, (org.joda.time.ReadableDateTime) dateTime40, (org.joda.time.ReadableDateTime) dateTime43);
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        long long48 = limitChronology44.add(readablePeriod45, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime49 = limitChronology44.getUpperLimit();
        boolean boolean50 = property30.equals((java.lang.Object) limitChronology44);
        java.util.Locale locale51 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket52 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology44, locale51);
        java.util.Locale locale53 = dateTimeParserBucket52.getLocale();
        dateTimeParserBucket52.setOffset((java.lang.Integer) 320);
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime58 = null;
        boolean boolean59 = dateTimeZone57.isLocalDateTimeGap(localDateTime58);
        org.joda.time.chrono.JulianChronology julianChronology60 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone57);
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime62 = null;
        boolean boolean63 = dateTimeZone61.isLocalDateTimeGap(localDateTime62);
        org.joda.time.chrono.GJChronology gJChronology64 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone61);
        boolean boolean65 = julianChronology60.equals((java.lang.Object) dateTimeZone61);
        org.joda.time.DateTime dateTime66 = new org.joda.time.DateTime(319L, dateTimeZone61);
        dateTimeParserBucket52.setZone(dateTimeZone61);
        long long69 = dateTimeZone18.getMillisKeepLocal(dateTimeZone61, (long) 1988);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(limitChronology44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-255139199999L) + "'", long48 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(locale53);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(julianChronology60);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(gJChronology64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1988L + "'", long69 == 1988L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfSecond(0, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder4.appendFractionOfHour(488, (int) (short) 100);
        dateTimeFormatterBuilder10.clear();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder10.appendYearOfCentury(741, 52);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.months();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.era();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime((long) (-741), (org.joda.time.Chronology) gJChronology1);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfCentury();
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(property5);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
//        java.lang.Object obj14 = null;
//        boolean boolean15 = limitChronology13.equals(obj14);
//        java.lang.String str16 = limitChronology13.toString();
//        org.joda.time.DurationField durationField17 = limitChronology13.minutes();
//        org.joda.time.DateTimeField dateTimeField18 = limitChronology13.monthOfYear();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField20 = gJChronology19.months();
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology19.weekyearOfCentury();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology23 = dateTime22.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime(chronology23);
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
//        org.joda.time.Chronology chronology28 = null;
//        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime(0L, chronology28);
//        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, (org.joda.time.ReadableInstant) mutableDateTime29);
//        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds(10);
//        org.joda.time.DateTime.Property property35 = dateTime34.yearOfCentury();
//        org.joda.time.DateTime.Property property36 = dateTime34.millisOfSecond();
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology38 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology31, (org.joda.time.ReadableDateTime) dateTime34, (org.joda.time.ReadableDateTime) dateTime37);
//        org.joda.time.DateTimeField dateTimeField39 = gJChronology31.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField40 = gJChronology31.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField(chronology23, dateTimeField40);
//        int int44 = skipUndoDateTimeField41.getDifference((long) 320, (-1L));
//        org.joda.time.field.SkipDateTimeField skipDateTimeField46 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology19, (org.joda.time.DateTimeField) skipUndoDateTimeField41, (int) (byte) 10);
//        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField48 = gJChronology47.months();
//        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime51 = dateTime49.minusSeconds(10);
//        org.joda.time.DateTime.Property property52 = dateTime51.yearOfCentury();
//        org.joda.time.DateTime.Property property53 = dateTime51.millisOfSecond();
//        org.joda.time.LocalDate localDate54 = dateTime51.toLocalDate();
//        long long56 = gJChronology47.set((org.joda.time.ReadablePartial) localDate54, (long) (byte) 10);
//        java.lang.Class<?> wildcardClass57 = localDate54.getClass();
//        int[] intArray61 = new int[] { (-1), 1, 5 };
//        int int62 = skipUndoDateTimeField41.getMinimumValue((org.joda.time.ReadablePartial) localDate54, intArray61);
//        long long64 = skipUndoDateTimeField41.roundHalfCeiling((long) (short) -1);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField65 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) limitChronology13, (org.joda.time.DateTimeField) skipUndoDateTimeField41);
//        int int67 = skipUndoDateTimeField41.get(86390L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:21:06.385Z, 2019-06-12T12:21:16.385Z]" + "'", str16.equals("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:21:06.385Z, 2019-06-12T12:21:16.385Z]"));
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(chronology23);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(gJChronology26);
//        org.junit.Assert.assertNotNull(property30);
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(limitChronology38);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 321 + "'", int44 == 321);
//        org.junit.Assert.assertNotNull(gJChronology47);
//        org.junit.Assert.assertNotNull(durationField48);
//        org.junit.Assert.assertNotNull(dateTime49);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1560297600010L + "'", long56 == 1560297600010L);
//        org.junit.Assert.assertNotNull(wildcardClass57);
//        org.junit.Assert.assertNotNull(intArray61);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-1L) + "'", long64 == (-1L));
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 390 + "'", int67 == 390);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = null;
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder3.appendFraction(dateTimeFieldType4, 2, 159);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = gJChronology3.months();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology11.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField19, (int) '#');
        org.joda.time.tz.DefaultNameProvider defaultNameProvider24 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime27 = dateTime25.minusSeconds(10);
        org.joda.time.DateTime.Property property28 = dateTime27.yearOfCentury();
        org.joda.time.DateTime dateTime29 = property28.withMaximumValue();
        org.joda.time.DateTime dateTime30 = dateTime29.withLaterOffsetAtOverlap();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField32 = gJChronology31.months();
        org.joda.time.DateTimeField dateTimeField33 = gJChronology31.weekyearOfCentury();
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
        org.joda.time.Chronology chronology35 = dateTime34.getChronology();
        org.joda.time.MutableDateTime mutableDateTime36 = new org.joda.time.MutableDateTime(chronology35);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37);
        org.joda.time.Chronology chronology40 = null;
        org.joda.time.MutableDateTime mutableDateTime41 = new org.joda.time.MutableDateTime(0L, chronology40);
        org.joda.time.MutableDateTime.Property property42 = mutableDateTime41.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone37, (org.joda.time.ReadableInstant) mutableDateTime41);
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime46 = dateTime44.minusSeconds(10);
        org.joda.time.DateTime.Property property47 = dateTime46.yearOfCentury();
        org.joda.time.DateTime.Property property48 = dateTime46.millisOfSecond();
        org.joda.time.DateTime dateTime49 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology50 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology43, (org.joda.time.ReadableDateTime) dateTime46, (org.joda.time.ReadableDateTime) dateTime49);
        org.joda.time.DateTimeField dateTimeField51 = gJChronology43.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField52 = gJChronology43.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField53 = new org.joda.time.field.SkipUndoDateTimeField(chronology35, dateTimeField52);
        int int56 = skipUndoDateTimeField53.getDifference((long) 320, (-1L));
        org.joda.time.field.SkipDateTimeField skipDateTimeField58 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology31, (org.joda.time.DateTimeField) skipUndoDateTimeField53, (int) (byte) 10);
        org.joda.time.DateTime dateTime61 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime63 = dateTime61.minusSeconds(10);
        org.joda.time.DateTime.Property property64 = dateTime63.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone65 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology66 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone65);
        org.joda.time.Chronology chronology68 = null;
        org.joda.time.MutableDateTime mutableDateTime69 = new org.joda.time.MutableDateTime(0L, chronology68);
        org.joda.time.MutableDateTime.Property property70 = mutableDateTime69.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology71 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone65, (org.joda.time.ReadableInstant) mutableDateTime69);
        org.joda.time.DateTime dateTime72 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime74 = dateTime72.minusSeconds(10);
        org.joda.time.DateTime.Property property75 = dateTime74.yearOfCentury();
        org.joda.time.DateTime.Property property76 = dateTime74.millisOfSecond();
        org.joda.time.DateTime dateTime77 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology78 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology71, (org.joda.time.ReadableDateTime) dateTime74, (org.joda.time.ReadableDateTime) dateTime77);
        org.joda.time.ReadablePeriod readablePeriod79 = null;
        long long82 = limitChronology78.add(readablePeriod79, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime83 = limitChronology78.getUpperLimit();
        boolean boolean84 = property64.equals((java.lang.Object) limitChronology78);
        java.util.Locale locale85 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket86 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology78, locale85);
        java.util.Locale locale87 = dateTimeParserBucket86.getLocale();
        java.lang.String str88 = skipDateTimeField58.getAsShortText(10L, locale87);
        java.util.Calendar calendar89 = dateTime30.toCalendar(locale87);
        java.lang.String str92 = defaultNameProvider24.getShortName(locale87, "2019-06-12T��:��:��.000", "Property[weekOfWeekyear]");
        long long93 = skipUndoDateTimeField21.set((long) 12, "1", locale87);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(chronology35);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(gJChronology38);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(limitChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 321 + "'", int56 == 321);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTimeZone65);
        org.junit.Assert.assertNotNull(gJChronology66);
        org.junit.Assert.assertNotNull(property70);
        org.junit.Assert.assertNotNull(gJChronology71);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(dateTime74);
        org.junit.Assert.assertNotNull(property75);
        org.junit.Assert.assertNotNull(property76);
        org.junit.Assert.assertNotNull(dateTime77);
        org.junit.Assert.assertNotNull(limitChronology78);
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + (-255139199999L) + "'", long82 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(locale87);
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "10" + "'", str88.equals("10"));
        org.junit.Assert.assertNotNull(calendar89);
        org.junit.Assert.assertNull(str92);
        org.junit.Assert.assertTrue("'" + long93 + "' != '" + 60012L + "'", long93 == 60012L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.fullTime();
        java.util.Locale locale1 = dateTimeFormatter0.getLocale();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear(319);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks(960);
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.DateTime dateTime8 = property5.setCopy("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:20:52.817Z, 2019-06-12T12:21:02.840Z]", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:20:52.817Z, 2019-06-12T12:21:02.840Z]\" for minuteOfHour is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime4.millisOfDay();
        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundHalfFloor();
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        boolean boolean10 = mutableDateTime8.isSupported(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(mutableDateTime8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        mutableDateTime4.setDayOfYear(163);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime4.weekyear();
        org.joda.time.Chronology chronology11 = null;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(0L, chronology11);
        long long13 = mutableDateTime12.getMillis();
        mutableDateTime12.setMinuteOfHour(0);
        org.joda.time.Instant instant16 = mutableDateTime12.toInstant();
        org.joda.time.Instant instant19 = instant16.withDurationAdded((long) (short) 100, 488);
        org.joda.time.DateTime dateTime20 = instant16.toDateTime();
        org.joda.time.DateTime dateTime22 = dateTime20.withMillisOfSecond((int) (byte) 10);
        boolean boolean23 = mutableDateTime4.isBefore((org.joda.time.ReadableInstant) dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(instant16);
        org.junit.Assert.assertNotNull(instant19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(10);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        org.joda.time.DateTime dateTime5 = property4.withMaximumValue();
        org.joda.time.DurationField durationField6 = property4.getDurationField();
        org.joda.time.DateTime dateTime7 = property4.roundHalfFloorCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.withYear(12);
        boolean boolean10 = dateTime7.isBeforeNow();
        org.joda.time.DateTime dateTime12 = dateTime7.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime(0L, chronology16);
        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) mutableDateTime17);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime22 = dateTime20.minusSeconds(10);
        org.joda.time.DateTime.Property property23 = dateTime22.yearOfCentury();
        org.joda.time.DateTime.Property property24 = dateTime22.millisOfSecond();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology19, (org.joda.time.ReadableDateTime) dateTime22, (org.joda.time.ReadableDateTime) dateTime25);
        org.joda.time.DateTime dateTime27 = limitChronology26.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime30 = dateTime27.withPeriodAdded(readablePeriod28, (int) (short) 0);
        org.joda.time.DateTime dateTime32 = dateTime30.minus((long) (short) -1);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime(0L, chronology34);
        long long36 = mutableDateTime35.getMillis();
        boolean boolean37 = dateTime30.isEqual((org.joda.time.ReadableInstant) mutableDateTime35);
        org.joda.time.DateTime dateTime39 = dateTime30.withWeekyear(12);
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.DateTime dateTime41 = dateTime30.minus(readablePeriod40);
        boolean boolean42 = dateTime7.isEqual((org.joda.time.ReadableInstant) dateTime41);
        boolean boolean43 = iSOChronology0.equals((java.lang.Object) boolean42);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(limitChronology26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[millisOfSecond]", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:58.886-07:00, 2019-06-12T05:20:08.887-07:00]", (int) '4', 319);
        long long6 = fixedDateTimeZone4.previousTransition((long) (short) 1);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (long) 84, (int) (short) 1);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((-255139199999L));
        long long13 = fixedDateTimeZone4.nextTransition((long) 3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 3L + "'", long13 == 3L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        java.lang.String str7 = mutableDateTime4.toString();
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime4.secondOfMinute();
        int int9 = mutableDateTime4.getYearOfCentury();
        mutableDateTime4.setDate(319L);
        int int12 = mutableDateTime4.getWeekyear();
        mutableDateTime4.setWeekyear(44448);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str7.equals("1970-01-01T00:00:00.000Z"));
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 70 + "'", int9 == 70);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1970 + "'", int12 == 1970);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gJChronology0.months();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.weekyearOfCentury();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(chronology4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(0L, chronology9);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(10);
//        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
//        org.joda.time.DateTime.Property property17 = dateTime15.millisOfSecond();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology12, (org.joda.time.ReadableDateTime) dateTime15, (org.joda.time.ReadableDateTime) dateTime18);
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology12.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology12.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField21);
//        int int25 = skipUndoDateTimeField22.getDifference((long) 320, (-1L));
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField22, (int) (byte) 10);
//        long long29 = skipDateTimeField27.roundHalfEven(0L);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField31 = gJChronology30.months();
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology30.weekyearOfCentury();
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology34 = dateTime33.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime(chronology34);
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone36);
//        org.joda.time.Chronology chronology39 = null;
//        org.joda.time.MutableDateTime mutableDateTime40 = new org.joda.time.MutableDateTime(0L, chronology39);
//        org.joda.time.MutableDateTime.Property property41 = mutableDateTime40.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone36, (org.joda.time.ReadableInstant) mutableDateTime40);
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime45 = dateTime43.minusSeconds(10);
//        org.joda.time.DateTime.Property property46 = dateTime45.yearOfCentury();
//        org.joda.time.DateTime.Property property47 = dateTime45.millisOfSecond();
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology49 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology42, (org.joda.time.ReadableDateTime) dateTime45, (org.joda.time.ReadableDateTime) dateTime48);
//        org.joda.time.DateTimeField dateTimeField50 = gJChronology42.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField51 = gJChronology42.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField52 = new org.joda.time.field.SkipUndoDateTimeField(chronology34, dateTimeField51);
//        int int55 = skipUndoDateTimeField52.getDifference((long) 320, (-1L));
//        org.joda.time.field.SkipDateTimeField skipDateTimeField57 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology30, (org.joda.time.DateTimeField) skipUndoDateTimeField52, (int) (byte) 10);
//        org.joda.time.chrono.GJChronology gJChronology58 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField59 = gJChronology58.months();
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime62 = dateTime60.minusSeconds(10);
//        org.joda.time.DateTime.Property property63 = dateTime62.yearOfCentury();
//        org.joda.time.DateTime.Property property64 = dateTime62.millisOfSecond();
//        org.joda.time.LocalDate localDate65 = dateTime62.toLocalDate();
//        long long67 = gJChronology58.set((org.joda.time.ReadablePartial) localDate65, (long) (byte) 10);
//        java.lang.Class<?> wildcardClass68 = localDate65.getClass();
//        int[] intArray72 = new int[] { (-1), 1, 5 };
//        int int73 = skipUndoDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) localDate65, intArray72);
//        int int74 = skipDateTimeField27.getMinimumValue((org.joda.time.ReadablePartial) localDate65);
//        long long76 = skipDateTimeField27.roundHalfEven((long) 2);
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(limitChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 321 + "'", int25 == 321);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(chronology34);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(gJChronology37);
//        org.junit.Assert.assertNotNull(property41);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(property46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(limitChronology49);
//        org.junit.Assert.assertNotNull(dateTimeField50);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 321 + "'", int55 == 321);
//        org.junit.Assert.assertNotNull(gJChronology58);
//        org.junit.Assert.assertNotNull(durationField59);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTime62);
//        org.junit.Assert.assertNotNull(property63);
//        org.junit.Assert.assertNotNull(property64);
//        org.junit.Assert.assertNotNull(localDate65);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1560297600010L + "'", long67 == 1560297600010L);
//        org.junit.Assert.assertNotNull(wildcardClass68);
//        org.junit.Assert.assertNotNull(intArray72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 2L + "'", long76 == 2L);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = gJChronology3.months();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology11.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField19, (int) '#');
        java.util.Locale locale23 = null;
        java.lang.String str24 = skipUndoDateTimeField21.getAsText((long) (short) 10, locale23);
        int int25 = skipUndoDateTimeField21.getMinimumValue();
        long long28 = skipUndoDateTimeField21.add(2678400960L, (-60000L));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0" + "'", str24.equals("0"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-921599040L) + "'", long28 == (-921599040L));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.chrono.BuddhistChronology buddhistChronology7 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology8 = buddhistChronology7.withUTC();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.Chronology chronology10 = buddhistChronology7.withZone(dateTimeZone9);
        try {
            org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(1, 100, 2000, 0, 0, 390, 0, chronology10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(buddhistChronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(chronology10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.MutableDateTime mutableDateTime0 = new org.joda.time.MutableDateTime();
        mutableDateTime0.add(0L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        boolean boolean9 = julianChronology4.equals((java.lang.Object) dateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(319L, dateTimeZone5);
        long long12 = dateTimeZone5.convertUTCToLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property4.getDateTime();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        org.joda.time.DateTime dateTime8 = dateTime6.withYearOfCentury(0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMinuteOfDay(1439);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder5.appendSecondOfMinute(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder10 = dateTimeFormatterBuilder7.appendYearOfCentury(12, (int) (byte) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder10.appendLiteral("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:57.973-07:00, 2019-06-12T05:20:07.973-07:00]");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendFractionOfSecond(2000, 84);
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder12.appendTimeZoneOffset("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:57.973-07:00, 2019-06-12T05:20:07.973-07:00]", "19", false, 19, (-9601));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:46.352-07:00, 2019-06-12T05:19:56.353-07:00]", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:46.352-07:00, 2019-06-12T05:19:56.353-07:00]");
        illegalFieldValueException2.prependMessage("");
        java.lang.Number number5 = illegalFieldValueException2.getUpperBound();
        java.lang.String str6 = illegalFieldValueException2.getFieldName();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:46.352-07:00, 2019-06-12T05:19:56.353-07:00]" + "'", str6.equals("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:46.352-07:00, 2019-06-12T05:19:56.353-07:00]"));
        org.junit.Assert.assertNull(dateTimeFieldType7);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTime dateTime14 = limitChronology13.getLowerLimit();
        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
        org.joda.time.DateTime dateTime17 = property15.setCopy(20);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime17);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(chronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(0L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(10);
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfCentury();
        org.joda.time.DateTime.Property property18 = dateTime16.millisOfSecond();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology20 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology13, (org.joda.time.ReadableDateTime) dateTime16, (org.joda.time.ReadableDateTime) dateTime19);
        org.joda.time.DateTimeField dateTimeField21 = gJChronology13.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology13.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField22);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology3, (org.joda.time.DateTimeField) skipUndoDateTimeField23, 740);
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField27 = gJChronology26.months();
        org.joda.time.DateTimeField dateTimeField28 = gJChronology26.secondOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField30 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) julianChronology3, dateTimeField28, 2000);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(limitChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[millisOfSecond]", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:58.886-07:00, 2019-06-12T05:20:08.887-07:00]", (int) '4', 319);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 12);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = fixedDateTimeZone4.getOffsetFromLocal(433428L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(chronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(0L, chronology7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(10);
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfSecond();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology10, (org.joda.time.ReadableDateTime) dateTime13, (org.joda.time.ReadableDateTime) dateTime16);
        org.joda.time.DateTimeField dateTimeField18 = gJChronology10.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology10.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField19);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField22 = gJChronology21.months();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.weekyearOfCentury();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField25 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField23, 740);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField27 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField25, 390);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(0L, dateTimeZone1);
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone1);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
//        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
//        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField3 = gJChronology2.months();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds(10);
//        org.joda.time.DateTime.Property property7 = dateTime6.yearOfCentury();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfSecond();
//        org.joda.time.LocalDate localDate9 = dateTime6.toLocalDate();
//        long long11 = gJChronology2.set((org.joda.time.ReadablePartial) localDate9, (long) (byte) 10);
//        java.lang.Class<?> wildcardClass12 = localDate9.getClass();
//        java.lang.String str13 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate9);
//        org.joda.time.format.DateTimePrinter dateTimePrinter14 = dateTimeFormatter0.getPrinter();
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(gJChronology2);
//        org.junit.Assert.assertNotNull(durationField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560297600010L + "'", long11 == 1560297600010L);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "������" + "'", str13.equals("������"));
//        org.junit.Assert.assertNotNull(dateTimePrinter14);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        long long3 = mutableDateTime2.getMillis();
        mutableDateTime2.setMinuteOfHour(0);
        org.joda.time.Instant instant6 = mutableDateTime2.toInstant();
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant6.withDurationAdded(readableDuration7, 320);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("6/12/19", "Property[secondOfMinute]", 0, 0);
        long long6 = fixedDateTimeZone4.nextTransition((long) 960);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 960L + "'", long6 == 960L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateOptionalTimeParser();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(0L, chronology2);
        long long4 = mutableDateTime3.getMillis();
        mutableDateTime3.setMinuteOfHour(0);
        org.joda.time.Instant instant7 = mutableDateTime3.toInstant();
        int int10 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime3, "hi!", 740);
        mutableDateTime3.setSecondOfDay(0);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(instant7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-741) + "'", int10 == (-741));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[millisOfSecond]", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:58.886-07:00, 2019-06-12T05:20:08.887-07:00]", (int) '4', 319);
        long long6 = fixedDateTimeZone4.previousTransition((long) (short) 1);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (long) 84, (int) (short) 1);
        int int11 = fixedDateTimeZone4.getOffsetFromLocal((-255139199999L));
        long long13 = fixedDateTimeZone4.nextTransition(0L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
//        long long3 = mutableDateTime2.getMillis();
//        mutableDateTime2.setMinuteOfHour(0);
//        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(dateTimeZone7);
//        long long9 = property6.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime8);
//        org.joda.time.MutableDateTime.Property property10 = mutableDateTime8.centuryOfEra();
//        org.joda.time.MutableDateTime mutableDateTime11 = property10.roundHalfFloor();
//        org.joda.time.DurationFieldType durationFieldType12 = null;
//        try {
//            mutableDateTime11.add(durationFieldType12, 1439);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-433428L) + "'", long9 == (-433428L));
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(mutableDateTime11);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks(960);
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        org.joda.time.DateTime dateTime7 = dateTime4.plusWeeks(9600);
        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime(0L, chronology12);
        org.joda.time.MutableDateTime.Property property14 = mutableDateTime13.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9, (org.joda.time.ReadableInstant) mutableDateTime13);
        long long17 = dateTimeZone8.getMillisKeepLocal(dateTimeZone9, (long) (byte) 100);
        org.joda.time.ReadableInstant readableInstant18 = null;
        int int19 = dateTimeZone8.getOffset(readableInstant18);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 100L + "'", long17 == 100L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology6.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology6.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField16 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField15);
        org.joda.time.DurationField durationField17 = delegatedDateTimeField16.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(10);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = limitChronology18.add(readablePeriod19, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime23 = limitChronology18.getUpperLimit();
        boolean boolean24 = property4.equals((java.lang.Object) limitChronology18);
        java.util.Locale locale25 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology18, locale25);
        java.util.Locale locale27 = dateTimeParserBucket26.getLocale();
        dateTimeParserBucket26.setOffset((java.lang.Integer) 320);
        org.joda.time.Chronology chronology30 = dateTimeParserBucket26.getChronology();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31);
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.MutableDateTime mutableDateTime35 = new org.joda.time.MutableDateTime(0L, chronology34);
        org.joda.time.MutableDateTime.Property property36 = mutableDateTime35.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology37 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone31, (org.joda.time.ReadableInstant) mutableDateTime35);
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime40 = dateTime38.minusSeconds(10);
        org.joda.time.DateTime.Property property41 = dateTime40.yearOfCentury();
        org.joda.time.DateTime.Property property42 = dateTime40.millisOfSecond();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology44 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology37, (org.joda.time.ReadableDateTime) dateTime40, (org.joda.time.ReadableDateTime) dateTime43);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology46 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone45);
        org.joda.time.Chronology chronology47 = limitChronology44.withZone(dateTimeZone45);
        long long51 = dateTimeZone45.convertLocalToUTC((long) (byte) 0, false, (long) 521);
        boolean boolean52 = dateTimeParserBucket26.restoreState((java.lang.Object) false);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-255139199999L) + "'", long22 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(gJChronology32);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(gJChronology37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(property41);
        org.junit.Assert.assertNotNull(property42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(limitChronology44);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(gJChronology46);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 0L + "'", long51 == 0L);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks(960);
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        org.joda.time.DurationField durationField6 = property5.getRangeDurationField();
        org.joda.time.DateTime dateTime7 = property5.roundCeilingCopy();
        org.joda.time.DateTime.Property property8 = dateTime7.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.months();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.weekyearOfCentury();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(chronology4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(0L, chronology9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(10);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
        org.joda.time.DateTime.Property property17 = dateTime15.millisOfSecond();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology12, (org.joda.time.ReadableDateTime) dateTime15, (org.joda.time.ReadableDateTime) dateTime18);
        org.joda.time.DateTimeField dateTimeField20 = gJChronology12.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField21 = gJChronology12.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField21);
        int int25 = skipUndoDateTimeField22.getDifference((long) 320, (-1L));
        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField22, (int) (byte) 10);
        org.joda.time.DurationField durationField28 = skipUndoDateTimeField22.getLeapDurationField();
        int int30 = skipUndoDateTimeField22.getMinimumValue(6000000L);
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 321 + "'", int25 == 321);
        org.junit.Assert.assertNull(durationField28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[millisOfSecond]", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:58.886-07:00, 2019-06-12T05:20:08.887-07:00]", (int) '4', 319);
        long long6 = fixedDateTimeZone4.previousTransition((long) (short) 1);
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, (long) 84, (int) (short) 1);
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test184");
//        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField1 = gJChronology0.months();
//        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.weekyearOfCentury();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology4 = dateTime3.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime5 = new org.joda.time.MutableDateTime(chronology4);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(0L, chronology9);
//        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime10);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(10);
//        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
//        org.joda.time.DateTime.Property property17 = dateTime15.millisOfSecond();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology12, (org.joda.time.ReadableDateTime) dateTime15, (org.joda.time.ReadableDateTime) dateTime18);
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology12.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology12.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, dateTimeField21);
//        int int25 = skipUndoDateTimeField22.getDifference((long) 320, (-1L));
//        org.joda.time.field.SkipDateTimeField skipDateTimeField27 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField22, (int) (byte) 10);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField29 = gJChronology28.months();
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime32 = dateTime30.minusSeconds(10);
//        org.joda.time.DateTime.Property property33 = dateTime32.yearOfCentury();
//        org.joda.time.DateTime.Property property34 = dateTime32.millisOfSecond();
//        org.joda.time.LocalDate localDate35 = dateTime32.toLocalDate();
//        long long37 = gJChronology28.set((org.joda.time.ReadablePartial) localDate35, (long) (byte) 10);
//        java.lang.Class<?> wildcardClass38 = localDate35.getClass();
//        int[] intArray42 = new int[] { (-1), 1, 5 };
//        int int43 = skipUndoDateTimeField22.getMinimumValue((org.joda.time.ReadablePartial) localDate35, intArray42);
//        org.joda.time.ReadablePartial readablePartial44 = null;
//        int[] intArray50 = new int[] { (byte) -1, (short) 10, 321, 321 };
//        try {
//            int[] intArray52 = skipUndoDateTimeField22.addWrapField(readablePartial44, 12, intArray50, (-9601));
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 12");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gJChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(chronology4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(gJChronology7);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(limitChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 321 + "'", int25 == 321);
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertNotNull(durationField29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(localDate35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560297600010L + "'", long37 == 1560297600010L);
//        org.junit.Assert.assertNotNull(wildcardClass38);
//        org.junit.Assert.assertNotNull(intArray42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
//        org.junit.Assert.assertNotNull(intArray50);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(0L, chronology6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(10);
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfCentury();
        org.joda.time.DateTime.Property property14 = dateTime12.millisOfSecond();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology9, (org.joda.time.ReadableDateTime) dateTime12, (org.joda.time.ReadableDateTime) dateTime15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology9.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField18);
        long long21 = skipUndoDateTimeField19.remainder((long) (byte) 10);
        try {
            long long24 = skipUndoDateTimeField19.set(1560342070111L, 1970);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1970 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.months();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.weekyearOfCentury();
        org.joda.time.DurationField durationField3 = gJChronology0.weeks();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[millisOfSecond]", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:58.886-07:00, 2019-06-12T05:20:08.887-07:00]", (int) '4', 319);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 12);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = fixedDateTimeZone4.getOffset(2678400960L);
        int int12 = fixedDateTimeZone4.getStandardOffset(2678400960L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 319 + "'", int12 == 319);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DurationField durationField14 = limitChronology13.eras();
        org.joda.time.DateTime dateTime15 = limitChronology13.getUpperLimit();
        try {
            long long21 = limitChronology13.getDateTimeMillis((long) 70, 0, (-9601), (int) (short) 1, 960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.chrono.LimitChronology.LimitException; message: The instant is below the supported minimum of 2019-06-12T12:21:12.262Z (GJChronology[UTC,cutover=1970-01-01])");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone1);
        long long5 = dateTimeZone1.convertLocalToUTC((long) 321, false);
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(dateTimeZone1);
        try {
            mutableDateTime6.setDayOfWeek(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 321L + "'", long5 == 321L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("org.joda.time.IllegalInstantException: hi!", 10, 19, (-32));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for org.joda.time.IllegalInstantException: hi! must be in the range [19,-32]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.era();
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = property4.getAsShortText(locale5);
//        org.joda.time.MutableDateTime mutableDateTime7 = property4.getMutableDateTime();
//        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.secondOfMinute();
//        org.joda.time.DurationField durationField9 = property8.getLeapDurationField();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "AD" + "'", str6.equals("AD"));
//        org.junit.Assert.assertNotNull(mutableDateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNull(durationField9);
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
//        mutableDateTime2.addWeekyears(0);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
//        org.joda.time.DateTime dateTime11 = property10.withMaximumValue();
//        org.joda.time.DateTime dateTime13 = dateTime11.withYear((int) '4');
//        org.joda.time.DateTime dateTime15 = dateTime11.plus((long) 1439);
//        org.joda.time.YearMonthDay yearMonthDay16 = dateTime15.toYearMonthDay();
//        long long17 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime15);
//        mutableDateTime2.setTime((org.joda.time.ReadableInstant) dateTime15);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(yearMonthDay16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 4084950073771L + "'", long17 == 4084950073771L);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.shortDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTime dateTime14 = limitChronology13.getUpperLimit();
        org.joda.time.DateTimeField dateTimeField15 = limitChronology13.millisOfDay();
        org.joda.time.DateTimeField dateTimeField16 = limitChronology13.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTime dateTime14 = limitChronology13.getLowerLimit();
        org.joda.time.DateTime.Property property15 = dateTime14.weekyear();
        org.joda.time.DateTime dateTime16 = property15.getDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) (byte) 0);
        org.joda.time.DateTime dateTime5 = dateTime1.minusMonths((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime8 = dateTime5.plusHours((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(100);
        org.joda.time.DateTime dateTime7 = property4.roundFloorCopy();
        org.joda.time.DateTime dateTime9 = property4.setCopy((int) (byte) 1);
        try {
            org.joda.time.DateTime dateTime11 = property4.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for millisOfSecond is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:46.352-07:00, 2019-06-12T05:19:56.353-07:00]", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:46.352-07:00, 2019-06-12T05:19:56.353-07:00]");
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Number number4 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertNull(dateTimeFieldType3);
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(10);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = limitChronology18.add(readablePeriod19, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime23 = limitChronology18.getUpperLimit();
        boolean boolean24 = property4.equals((java.lang.Object) limitChronology18);
        java.util.Locale locale25 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology18, locale25);
        java.util.Locale locale27 = dateTimeParserBucket26.getLocale();
        dateTimeParserBucket26.setOffset((java.lang.Integer) 320);
        org.joda.time.Chronology chronology30 = dateTimeParserBucket26.getChronology();
        int int31 = dateTimeParserBucket26.getOffset();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-255139199999L) + "'", long22 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(locale27);
        org.junit.Assert.assertNotNull(chronology30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 320 + "'", int31 == 320);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime8 = null;
        boolean boolean9 = dateTimeZone7.isLocalDateTimeGap(localDateTime8);
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime(0L, chronology14);
        org.joda.time.MutableDateTime.Property property16 = mutableDateTime15.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11, (org.joda.time.ReadableInstant) mutableDateTime15);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime20 = dateTime18.minusSeconds(10);
        org.joda.time.DateTime.Property property21 = dateTime20.yearOfCentury();
        org.joda.time.DateTime.Property property22 = dateTime20.millisOfSecond();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology24 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology17, (org.joda.time.ReadableDateTime) dateTime20, (org.joda.time.ReadableDateTime) dateTime23);
        org.joda.time.DateTime dateTime25 = limitChronology24.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        org.joda.time.DateTime dateTime28 = dateTime25.withPeriodAdded(readablePeriod26, (int) (short) 0);
        org.joda.time.chrono.GJChronology gJChronology29 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) dateTime28);
        long long31 = dateTimeZone7.convertUTCToLocal((long) 163);
        org.joda.time.LocalDateTime localDateTime32 = null;
        boolean boolean33 = dateTimeZone7.isLocalDateTimeGap(localDateTime32);
        try {
            org.joda.time.MutableDateTime mutableDateTime34 = new org.joda.time.MutableDateTime(44, 9600, 1439, 3, 12, (-1), (int) (byte) 0, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(limitChronology24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(gJChronology29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 163L + "'", long31 == 163L);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendTwoDigitWeekyear(2000);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder0.appendTimeZoneId();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = limitChronology13.add(readablePeriod14, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime18 = limitChronology13.getUpperLimit();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) limitChronology13, dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime22 = null;
        boolean boolean23 = dateTimeZone21.isLocalDateTimeGap(localDateTime22);
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime(0L, chronology28);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, (org.joda.time.ReadableInstant) mutableDateTime29);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds(10);
        org.joda.time.DateTime.Property property35 = dateTime34.yearOfCentury();
        org.joda.time.DateTime.Property property36 = dateTime34.millisOfSecond();
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology38 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology31, (org.joda.time.ReadableDateTime) dateTime34, (org.joda.time.ReadableDateTime) dateTime37);
        org.joda.time.DateTime dateTime39 = limitChronology38.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod40 = null;
        org.joda.time.DateTime dateTime42 = dateTime39.withPeriodAdded(readablePeriod40, (int) (short) 0);
        org.joda.time.chrono.GJChronology gJChronology43 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21, (org.joda.time.ReadableInstant) dateTime42);
        long long45 = dateTimeZone21.convertUTCToLocal((long) 163);
        org.joda.time.LocalDateTime localDateTime46 = null;
        boolean boolean47 = dateTimeZone21.isLocalDateTimeGap(localDateTime46);
        org.joda.time.ReadableInstant readableInstant48 = null;
        int int49 = dateTimeZone21.getOffset(readableInstant48);
        org.joda.time.Chronology chronology50 = zonedChronology20.withZone(dateTimeZone21);
        org.joda.time.DateTimeZone dateTimeZone51 = zonedChronology20.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-255139199999L) + "'", long17 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(limitChronology38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(gJChronology43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 163L + "'", long45 == 163L);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(chronology50);
        org.junit.Assert.assertNotNull(dateTimeZone51);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) 3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
        try {
            org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime((java.lang.Object) chronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("20", (int) '#');
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(0L, chronology5);
        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) mutableDateTime6);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime11 = dateTime9.minusSeconds(10);
        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
        org.joda.time.DateTime.Property property13 = dateTime11.millisOfSecond();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology8, (org.joda.time.ReadableDateTime) dateTime11, (org.joda.time.ReadableDateTime) dateTime14);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
        org.joda.time.Chronology chronology18 = limitChronology15.withZone(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(1, (int) (short) 0);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance(chronology18, dateTimeZone21);
        org.joda.time.DateTime dateTime23 = dateTime1.toDateTime(dateTimeZone21);
        org.joda.time.DateTime dateTime25 = dateTime23.minusMinutes((-32));
        org.joda.time.DateTime dateTime27 = dateTime23.minusMinutes(24);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(limitChronology15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gJChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.year();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = gregorianChronology8.getZone();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.millisOfSecond();
        org.joda.time.DateTimeZone dateTimeZone11 = gregorianChronology8.getZone();
        mutableDateTime7.setChronology((org.joda.time.Chronology) gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test209");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime6 = property4.set(2019);
//        mutableDateTime6.setTime((long) 3);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("6/12/19", "Property[secondOfMinute]", 0, 0);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.lang.String str7 = fixedDateTimeZone4.getNameKey((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[secondOfMinute]" + "'", str7.equals("Property[secondOfMinute]"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        long long17 = limitChronology13.add(readablePeriod14, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime18 = limitChronology13.getUpperLimit();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) limitChronology13, dateTimeZone19);
        org.joda.time.Chronology chronology21 = zonedChronology20.withUTC();
        org.joda.time.DurationField durationField22 = zonedChronology20.halfdays();
        org.joda.time.Chronology chronology23 = zonedChronology20.withUTC();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-255139199999L) + "'", long17 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(chronology23);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime dateTime4 = dateTime2.plusWeeks(960);
        org.joda.time.DateTime.Property property5 = dateTime4.minuteOfHour();
        org.joda.time.DurationField durationField6 = property5.getRangeDurationField();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((long) (short) 0);
        org.joda.time.DateTime dateTime10 = dateTime8.plusMinutes((int) (byte) 0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder11.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder13.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder18 = dateTimeFormatterBuilder13.appendYearOfCentury((int) (short) 1, (-32));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder13.appendDayOfWeekText();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime21 = null;
        boolean boolean22 = dateTimeZone20.isLocalDateTimeGap(localDateTime21);
        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
        org.joda.time.DurationField durationField24 = gJChronology23.months();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology26 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
        org.joda.time.Chronology chronology28 = null;
        org.joda.time.MutableDateTime mutableDateTime29 = new org.joda.time.MutableDateTime(0L, chronology28);
        org.joda.time.MutableDateTime.Property property30 = mutableDateTime29.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25, (org.joda.time.ReadableInstant) mutableDateTime29);
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime34 = dateTime32.minusSeconds(10);
        org.joda.time.DateTime.Property property35 = dateTime34.yearOfCentury();
        org.joda.time.DateTime.Property property36 = dateTime34.millisOfSecond();
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology38 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology31, (org.joda.time.ReadableDateTime) dateTime34, (org.joda.time.ReadableDateTime) dateTime37);
        org.joda.time.DateTimeField dateTimeField39 = gJChronology31.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField41 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology23, dateTimeField39, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = skipUndoDateTimeField41.getType();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder45 = dateTimeFormatterBuilder19.appendFraction(dateTimeFieldType42, 5, 521);
        try {
            org.joda.time.DateTime dateTime47 = dateTime8.withField(dateTimeFieldType42, 169596);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 169596 for minuteOfDay must be in the range [0,1439]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder15);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder18);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(gJChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(gJChronology26);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(gJChronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(property36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(limitChronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder45);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:50.536-07:00, 2019-06-12T05:20:00.537-07:00]", "");
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.DateTime dateTime8 = dateTime6.withLaterOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("Property[millisOfSecond]", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:58.886-07:00, 2019-06-12T05:20:08.887-07:00]", (int) '4', 319);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.util.Locale locale15 = dateTimeFormatter14.getLocale();
        boolean boolean16 = dateTimeFormatter14.isParser();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(1, (int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter14.withZone(dateTimeZone19);
        java.lang.String str22 = dateTimeZone19.getShortName((long) 321);
        long long24 = fixedDateTimeZone13.getMillisKeepLocal(dateTimeZone19, (long) 99);
        org.joda.time.DateTime dateTime25 = dateTime6.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.Chronology chronology26 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.DateTime.Property property27 = dateTime25.monthOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNull(locale15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+01:00" + "'", str22.equals("+01:00"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-3599849L) + "'", long24 == (-3599849L));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(property27);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = dateTime2.minusSeconds(10);
        org.joda.time.DateTime.Property property5 = dateTime4.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology7 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.MutableDateTime mutableDateTime10 = new org.joda.time.MutableDateTime(0L, chronology9);
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6, (org.joda.time.ReadableInstant) mutableDateTime10);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(10);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
        org.joda.time.DateTime.Property property17 = dateTime15.millisOfSecond();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology19 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology12, (org.joda.time.ReadableDateTime) dateTime15, (org.joda.time.ReadableDateTime) dateTime18);
        org.joda.time.ReadablePeriod readablePeriod20 = null;
        long long23 = limitChronology19.add(readablePeriod20, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime24 = limitChronology19.getUpperLimit();
        boolean boolean25 = property5.equals((java.lang.Object) limitChronology19);
        java.util.Locale locale26 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket27 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology19, locale26);
        java.util.Locale locale28 = dateTimeParserBucket27.getLocale();
        java.lang.String str31 = defaultNameProvider0.getShortName(locale28, "1970-01-01T00:00:00.000Z", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:50.536-07:00, 2019-06-12T05:20:00.537-07:00]");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider32 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime36 = dateTime34.minusSeconds(10);
        org.joda.time.DateTime.Property property37 = dateTime36.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38);
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.MutableDateTime mutableDateTime42 = new org.joda.time.MutableDateTime(0L, chronology41);
        org.joda.time.MutableDateTime.Property property43 = mutableDateTime42.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology44 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone38, (org.joda.time.ReadableInstant) mutableDateTime42);
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime47 = dateTime45.minusSeconds(10);
        org.joda.time.DateTime.Property property48 = dateTime47.yearOfCentury();
        org.joda.time.DateTime.Property property49 = dateTime47.millisOfSecond();
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology51 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology44, (org.joda.time.ReadableDateTime) dateTime47, (org.joda.time.ReadableDateTime) dateTime50);
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        long long55 = limitChronology51.add(readablePeriod52, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime56 = limitChronology51.getUpperLimit();
        boolean boolean57 = property37.equals((java.lang.Object) limitChronology51);
        java.util.Locale locale58 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket59 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology51, locale58);
        java.util.Locale locale60 = dateTimeParserBucket59.getLocale();
        java.lang.String str63 = defaultNameProvider32.getShortName(locale60, "1970-01-01T00:00:00.000Z", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:50.536-07:00, 2019-06-12T05:20:00.537-07:00]");
        java.lang.String str66 = defaultNameProvider0.getName(locale60, "0", "");
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gJChronology7);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(limitChronology19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-255139199999L) + "'", long23 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(locale28);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(property43);
        org.junit.Assert.assertNotNull(gJChronology44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(limitChronology51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + (-255139199999L) + "'", long55 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(locale60);
        org.junit.Assert.assertNull(str63);
        org.junit.Assert.assertNull(str66);
    }

//    @Test
//    public void test216() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test216");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
//        mutableDateTime2.addWeekyears(0);
//        org.joda.time.Instant instant7 = mutableDateTime2.toInstant();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(instant7);
//    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = gJChronology3.months();
        org.joda.time.DateTimeZone dateTimeZone5 = gJChronology3.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone6 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone6.getUncachedZone();
        int int9 = cachedDateTimeZone6.getStandardOffset(10L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(cachedDateTimeZone6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder1 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder1.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder5 = dateTimeFormatterBuilder3.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimePrinter dateTimePrinter6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser8 = dateTimeFormatter7.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser10 = dateTimeFormatter9.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser12 = dateTimeFormatter11.getParser();
        org.joda.time.format.DateTimeParser[] dateTimeParserArray13 = new org.joda.time.format.DateTimeParser[] { dateTimeParser8, dateTimeParser10, dateTimeParser12 };
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = dateTimeFormatterBuilder5.append(dateTimePrinter6, dateTimeParserArray13);
        boolean boolean15 = iSOChronology0.equals((java.lang.Object) dateTimeFormatterBuilder14);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendTimeZoneId();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder5);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeParser8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertNotNull(dateTimeParser10);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeParser12);
        org.junit.Assert.assertNotNull(dateTimeParserArray13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        java.lang.String str3 = dateTimeFormatter0.print((long) (short) 100);
        org.joda.time.Chronology chronology4 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1970" + "'", str3.equals("1970"));
        org.junit.Assert.assertNull(chronology4);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime6 = property3.addToCopy(0);
        org.joda.time.DateTime dateTime7 = property3.roundCeilingCopy();
        org.joda.time.DateTime dateTime9 = dateTime7.plus((long) (-32));
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.MutableDateTime mutableDateTime12 = new org.joda.time.MutableDateTime(dateTimeZone11);
        org.joda.time.MutableDateTime mutableDateTime13 = new org.joda.time.MutableDateTime((-433428L), dateTimeZone11);
        org.joda.time.DateTime dateTime14 = dateTime9.toDateTime(dateTimeZone11);
        java.lang.String str15 = dateTimeZone11.toString();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "UTC" + "'", str15.equals("UTC"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.yearOfCentury();
        org.joda.time.Interval interval7 = property6.toInterval();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(interval7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.LocalDate localDate5 = dateTime2.toLocalDate();
        org.joda.time.DateTime.Property property6 = dateTime2.year();
        org.joda.time.MutableDateTime mutableDateTime7 = dateTime2.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        mutableDateTime7.add(readablePeriod8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime7.year();
        org.joda.time.ReadableDuration readableDuration11 = null;
        mutableDateTime7.add(readableDuration11);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) (byte) 0);
        org.joda.time.DateTime dateTime5 = dateTime1.minusMonths((int) (byte) 100);
        org.joda.time.DateTime dateTime9 = dateTime5.withDate((int) (byte) 100, 12, (int) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.withDayOfYear(2);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
//        long long3 = mutableDateTime2.getMillis();
//        int int4 = mutableDateTime2.getMinuteOfDay();
//        mutableDateTime2.setDayOfYear(12);
//        java.lang.String str8 = mutableDateTime2.toString("6/12/19");
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        mutableDateTime2.add(readableDuration9, 163);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(0L, chronology13);
//        long long15 = mutableDateTime14.getMillis();
//        mutableDateTime14.setMinuteOfHour(0);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime(dateTimeZone19);
//        long long21 = property18.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime20);
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime20.centuryOfEra();
//        mutableDateTime2.setMillis((org.joda.time.ReadableInstant) mutableDateTime20);
//        mutableDateTime2.addSeconds((-432688));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "6/12/19" + "'", str8.equals("6/12/19"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-433428L) + "'", long21 == (-433428L));
//        org.junit.Assert.assertNotNull(property22);
//    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.Instant instant6 = instant4.plus((long) (short) 10);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant6.withDurationAdded(readableDuration7, 319);
        org.joda.time.DateTime dateTime10 = instant9.toDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.joda.time.format.DateTimeParser dateTimeParser5 = dateTimeFormatter4.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter3, dateTimeParser5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder0.appendOptional(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatter4);
        org.junit.Assert.assertNotNull(dateTimeParser5);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField2 = gJChronology1.months();
//        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.era();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = dateTime4.minusSeconds(10);
//        org.joda.time.DateTime.Property property7 = dateTime6.yearOfCentury();
//        org.joda.time.DateTime.Property property8 = dateTime6.millisOfSecond();
//        org.joda.time.LocalDate localDate9 = dateTime6.toLocalDate();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField11 = gJChronology10.months();
//        org.joda.time.DateTimeField dateTimeField12 = gJChronology10.weekyearOfCentury();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology14 = dateTime13.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime15 = new org.joda.time.MutableDateTime(chronology14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        org.joda.time.Chronology chronology19 = null;
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime(0L, chronology19);
//        org.joda.time.MutableDateTime.Property property21 = mutableDateTime20.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16, (org.joda.time.ReadableInstant) mutableDateTime20);
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime25 = dateTime23.minusSeconds(10);
//        org.joda.time.DateTime.Property property26 = dateTime25.yearOfCentury();
//        org.joda.time.DateTime.Property property27 = dateTime25.millisOfSecond();
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology29 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology22, (org.joda.time.ReadableDateTime) dateTime25, (org.joda.time.ReadableDateTime) dateTime28);
//        org.joda.time.DateTimeField dateTimeField30 = gJChronology22.minuteOfDay();
//        org.joda.time.DateTimeField dateTimeField31 = gJChronology22.millisOfSecond();
//        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField32 = new org.joda.time.field.SkipUndoDateTimeField(chronology14, dateTimeField31);
//        int int35 = skipUndoDateTimeField32.getDifference((long) 320, (-1L));
//        org.joda.time.field.SkipDateTimeField skipDateTimeField37 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology10, (org.joda.time.DateTimeField) skipUndoDateTimeField32, (int) (byte) 10);
//        org.joda.time.chrono.GJChronology gJChronology38 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField39 = gJChronology38.months();
//        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime42 = dateTime40.minusSeconds(10);
//        org.joda.time.DateTime.Property property43 = dateTime42.yearOfCentury();
//        org.joda.time.DateTime.Property property44 = dateTime42.millisOfSecond();
//        org.joda.time.LocalDate localDate45 = dateTime42.toLocalDate();
//        long long47 = gJChronology38.set((org.joda.time.ReadablePartial) localDate45, (long) (byte) 10);
//        java.lang.Class<?> wildcardClass48 = localDate45.getClass();
//        int[] intArray52 = new int[] { (-1), 1, 5 };
//        int int53 = skipUndoDateTimeField32.getMinimumValue((org.joda.time.ReadablePartial) localDate45, intArray52);
//        gJChronology1.validate((org.joda.time.ReadablePartial) localDate9, intArray52);
//        org.joda.time.DateTimeField dateTimeField55 = gJChronology1.millisOfSecond();
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider56 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime60 = dateTime58.minusSeconds(10);
//        org.joda.time.DateTime.Property property61 = dateTime60.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology63 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone62);
//        org.joda.time.Chronology chronology65 = null;
//        org.joda.time.MutableDateTime mutableDateTime66 = new org.joda.time.MutableDateTime(0L, chronology65);
//        org.joda.time.MutableDateTime.Property property67 = mutableDateTime66.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology68 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone62, (org.joda.time.ReadableInstant) mutableDateTime66);
//        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime71 = dateTime69.minusSeconds(10);
//        org.joda.time.DateTime.Property property72 = dateTime71.yearOfCentury();
//        org.joda.time.DateTime.Property property73 = dateTime71.millisOfSecond();
//        org.joda.time.DateTime dateTime74 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology75 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology68, (org.joda.time.ReadableDateTime) dateTime71, (org.joda.time.ReadableDateTime) dateTime74);
//        org.joda.time.ReadablePeriod readablePeriod76 = null;
//        long long79 = limitChronology75.add(readablePeriod76, (-255139199999L), (-1));
//        org.joda.time.DateTime dateTime80 = limitChronology75.getUpperLimit();
//        boolean boolean81 = property61.equals((java.lang.Object) limitChronology75);
//        java.util.Locale locale82 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket83 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology75, locale82);
//        java.util.Locale locale84 = dateTimeParserBucket83.getLocale();
//        java.lang.String str87 = defaultNameProvider56.getShortName(locale84, "1970-01-01T00:00:00.000Z", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:50.536-07:00, 2019-06-12T05:20:00.537-07:00]");
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket89 = new org.joda.time.format.DateTimeParserBucket((long) 0, (org.joda.time.Chronology) gJChronology1, locale84, (java.lang.Integer) 6);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(localDate9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(durationField11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(property27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(limitChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 321 + "'", int35 == 321);
//        org.junit.Assert.assertNotNull(gJChronology38);
//        org.junit.Assert.assertNotNull(durationField39);
//        org.junit.Assert.assertNotNull(dateTime40);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1560297600010L + "'", long47 == 1560297600010L);
//        org.junit.Assert.assertNotNull(wildcardClass48);
//        org.junit.Assert.assertNotNull(intArray52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
//        org.junit.Assert.assertNotNull(dateTimeField55);
//        org.junit.Assert.assertNotNull(dateTime58);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(property61);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(gJChronology63);
//        org.junit.Assert.assertNotNull(property67);
//        org.junit.Assert.assertNotNull(gJChronology68);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(property72);
//        org.junit.Assert.assertNotNull(property73);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(limitChronology75);
//        org.junit.Assert.assertTrue("'" + long79 + "' != '" + (-255139199999L) + "'", long79 == (-255139199999L));
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertNotNull(locale84);
//        org.junit.Assert.assertNull(str87);
//    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getWeekOfWeekyear();
//        org.joda.time.MutableDateTime mutableDateTime4 = mutableDateTime2.toMutableDateTime();
//        mutableDateTime2.addWeeks(99);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertNotNull(mutableDateTime4);
//    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime2 = null;
        boolean boolean3 = dateTimeZone1.isLocalDateTimeGap(localDateTime2);
        org.joda.time.chrono.JulianChronology julianChronology4 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime6 = null;
        boolean boolean7 = dateTimeZone5.isLocalDateTimeGap(localDateTime6);
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        boolean boolean9 = julianChronology4.equals((java.lang.Object) dateTimeZone5);
        org.joda.time.DateTime dateTime10 = new org.joda.time.DateTime(319L, dateTimeZone5);
        boolean boolean12 = dateTimeZone5.isStandardOffset(0L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(julianChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfSecond(0, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitYear((-32));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder7.appendTwoDigitWeekyear(86399999);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        boolean boolean2 = dateTimeFormatter1.isOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withOffsetParsed();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter1.withPivotYear((java.lang.Integer) 10);
        try {
            org.joda.time.MutableDateTime mutableDateTime6 = org.joda.time.MutableDateTime.parse("19700101T000000Z", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"19700101T000000Z\" is malformed at \"01T000000Z\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        long long3 = mutableDateTime2.getMillis();
        mutableDateTime2.setMinuteOfHour(0);
        org.joda.time.Instant instant6 = mutableDateTime2.toInstant();
        org.joda.time.Instant instant9 = instant6.withDurationAdded((long) (short) 100, 488);
        org.joda.time.MutableDateTime mutableDateTime10 = instant6.toMutableDateTimeISO();
        mutableDateTime10.setMillis(59999L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.Chronology chronology2 = dateTime1.getChronology();
        org.joda.time.MutableDateTime mutableDateTime3 = new org.joda.time.MutableDateTime(chronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(0L, chronology7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(10);
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfSecond();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology10, (org.joda.time.ReadableDateTime) dateTime13, (org.joda.time.ReadableDateTime) dateTime16);
        org.joda.time.DateTimeField dateTimeField18 = gJChronology10.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField19 = gJChronology10.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField20 = new org.joda.time.field.SkipUndoDateTimeField(chronology2, dateTimeField19);
        int int21 = skipUndoDateTimeField20.getMinimumValue();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField22 = new org.joda.time.field.SkipUndoDateTimeField(chronology0, (org.joda.time.DateTimeField) skipUndoDateTimeField20);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime25 = null;
        boolean boolean26 = dateTimeZone24.isLocalDateTimeGap(localDateTime25);
        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
        org.joda.time.DurationField durationField28 = gJChronology27.months();
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29);
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.MutableDateTime mutableDateTime33 = new org.joda.time.MutableDateTime(0L, chronology32);
        org.joda.time.MutableDateTime.Property property34 = mutableDateTime33.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29, (org.joda.time.ReadableInstant) mutableDateTime33);
        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime38 = dateTime36.minusSeconds(10);
        org.joda.time.DateTime.Property property39 = dateTime38.yearOfCentury();
        org.joda.time.DateTime.Property property40 = dateTime38.millisOfSecond();
        org.joda.time.DateTime dateTime41 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology42 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology35, (org.joda.time.ReadableDateTime) dateTime38, (org.joda.time.ReadableDateTime) dateTime41);
        org.joda.time.DateTimeField dateTimeField43 = gJChronology35.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField45 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField43, (int) '#');
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime49 = dateTime47.minusSeconds(10);
        org.joda.time.DateTime.Property property50 = dateTime49.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology52 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone51);
        org.joda.time.Chronology chronology54 = null;
        org.joda.time.MutableDateTime mutableDateTime55 = new org.joda.time.MutableDateTime(0L, chronology54);
        org.joda.time.MutableDateTime.Property property56 = mutableDateTime55.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology57 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone51, (org.joda.time.ReadableInstant) mutableDateTime55);
        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime60 = dateTime58.minusSeconds(10);
        org.joda.time.DateTime.Property property61 = dateTime60.yearOfCentury();
        org.joda.time.DateTime.Property property62 = dateTime60.millisOfSecond();
        org.joda.time.DateTime dateTime63 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology64 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology57, (org.joda.time.ReadableDateTime) dateTime60, (org.joda.time.ReadableDateTime) dateTime63);
        org.joda.time.ReadablePeriod readablePeriod65 = null;
        long long68 = limitChronology64.add(readablePeriod65, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime69 = limitChronology64.getUpperLimit();
        boolean boolean70 = property50.equals((java.lang.Object) limitChronology64);
        java.util.Locale locale71 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket72 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology64, locale71);
        java.util.Locale locale73 = dateTimeParserBucket72.getLocale();
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket74 = new org.joda.time.format.DateTimeParserBucket((long) 84, (org.joda.time.Chronology) gJChronology27, locale73);
        int int75 = skipUndoDateTimeField20.getMaximumTextLength(locale73);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(gJChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gJChronology30);
        org.junit.Assert.assertNotNull(property34);
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(limitChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(gJChronology52);
        org.junit.Assert.assertNotNull(property56);
        org.junit.Assert.assertNotNull(gJChronology57);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(property61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(limitChronology64);
        org.junit.Assert.assertTrue("'" + long68 + "' != '" + (-255139199999L) + "'", long68 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(locale73);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 3 + "'", int75 == 3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        long long3 = mutableDateTime2.getMillis();
        mutableDateTime2.setMinuteOfHour(0);
        org.joda.time.Instant instant6 = mutableDateTime2.toInstant();
        org.joda.time.Instant instant9 = instant6.withDurationAdded((long) (short) 100, 488);
        org.joda.time.MutableDateTime mutableDateTime10 = instant6.toMutableDateTimeISO();
        org.joda.time.MutableDateTime.Property property11 = mutableDateTime10.minuteOfHour();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) (byte) 0);
        org.joda.time.DateTime dateTime5 = dateTime1.minusMonths((int) (byte) 100);
        org.joda.time.DateTime dateTime9 = dateTime5.withDate((int) (byte) 100, 12, (int) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime9.minusMinutes(488);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        long long3 = mutableDateTime2.getMillis();
        mutableDateTime2.setMinuteOfHour(0);
        org.joda.time.Instant instant6 = mutableDateTime2.toInstant();
        org.joda.time.MutableDateTime mutableDateTime7 = instant6.toMutableDateTime();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        mutableDateTime7.add(readablePeriod8, 86399999);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(mutableDateTime7);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        java.lang.String str7 = mutableDateTime4.toString();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        mutableDateTime4.setZoneRetainFields(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        mutableDateTime4.add(readablePeriod11);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(10);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
        org.joda.time.DateTime dateTime17 = property16.withMaximumValue();
        org.joda.time.DateTime dateTime19 = property16.addToCopy(0);
        org.joda.time.DateTime dateTime20 = property16.roundCeilingCopy();
        org.joda.time.DateTime dateTime22 = dateTime20.plus((long) (-32));
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime25 = dateTime20.withPeriodAdded(readablePeriod23, 319);
        boolean boolean26 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) dateTime20);
        mutableDateTime4.setYear(100);
        mutableDateTime4.addMonths(52);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str7.equals("1970-01-01T00:00:00.000Z"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTime dateTime14 = limitChronology13.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime(0L, chronology21);
        org.joda.time.MutableDateTime.Property property23 = mutableDateTime22.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) mutableDateTime22);
        org.joda.time.MutableDateTime mutableDateTime25 = dateTime14.toMutableDateTime(dateTimeZone18);
        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.yearOfEra();
        int int27 = mutableDateTime25.getYear();
        org.joda.time.MutableDateTime.Property property28 = mutableDateTime25.monthOfYear();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime31 = dateTime29.minusSeconds(10);
        org.joda.time.DateTime.Property property32 = dateTime31.yearOfCentury();
        org.joda.time.DateTime.Property property33 = dateTime31.millisOfSecond();
        org.joda.time.DateTime dateTime35 = property33.addWrapFieldToCopy(100);
        org.joda.time.DateTime dateTime36 = property33.roundFloorCopy();
        long long37 = property28.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime36);
        org.joda.time.MutableDateTime mutableDateTime39 = property28.add((long) 99);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(gJChronology24);
        org.junit.Assert.assertNotNull(mutableDateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertNotNull(mutableDateTime39);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.DateTimeFormat.mediumTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((int) ' ');
        org.joda.time.format.DateTimePrinter dateTimePrinter3 = dateTimeFormatter0.getPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimePrinter3);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property4.getDateTime();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        try {
            org.joda.time.DateTime dateTime8 = dateTime6.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test241");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
//        java.lang.String str14 = limitChronology13.toString();
//        java.lang.String str15 = limitChronology13.toString();
//        org.joda.time.DateTimeField dateTimeField16 = limitChronology13.secondOfMinute();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:21:18.589Z, 2019-06-12T12:21:28.590Z]" + "'", str14.equals("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:21:18.589Z, 2019-06-12T12:21:28.590Z]"));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:21:18.589Z, 2019-06-12T12:21:28.590Z]" + "'", str15.equals("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:21:18.589Z, 2019-06-12T12:21:28.590Z]"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime5 = property4.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime7 = dateTime5.plusHours(741);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology6.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology6.millisOfSecond();
        org.joda.time.Chronology chronology16 = gJChronology6.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone21 = new org.joda.time.tz.FixedDateTimeZone("Property[millisOfSecond]", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:58.886-07:00, 2019-06-12T05:20:08.887-07:00]", (int) '4', 319);
        long long23 = fixedDateTimeZone21.previousTransition((long) (short) 1);
        org.joda.time.Chronology chronology24 = gJChronology6.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone21);
        long long26 = fixedDateTimeZone21.previousTransition(4084950053420L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(chronology24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 4084950053420L + "'", long26 == 4084950053420L);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
//        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(0L, chronology7);
//        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime8);
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(10);
//        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
//        org.joda.time.DateTime.Property property15 = dateTime13.millisOfSecond();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology10, (org.joda.time.ReadableDateTime) dateTime13, (org.joda.time.ReadableDateTime) dateTime16);
//        org.joda.time.ReadablePeriod readablePeriod18 = null;
//        long long21 = limitChronology17.add(readablePeriod18, (-255139199999L), (-1));
//        org.joda.time.DateTime dateTime22 = limitChronology17.getUpperLimit();
//        boolean boolean23 = property3.equals((java.lang.Object) limitChronology17);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.Chronology chronology27 = null;
//        org.joda.time.MutableDateTime mutableDateTime28 = new org.joda.time.MutableDateTime(0L, chronology27);
//        org.joda.time.MutableDateTime.Property property29 = mutableDateTime28.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24, (org.joda.time.ReadableInstant) mutableDateTime28);
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime33 = dateTime31.minusSeconds(10);
//        org.joda.time.DateTime.Property property34 = dateTime33.yearOfCentury();
//        org.joda.time.DateTime.Property property35 = dateTime33.millisOfSecond();
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology37 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology30, (org.joda.time.ReadableDateTime) dateTime33, (org.joda.time.ReadableDateTime) dateTime36);
//        java.lang.Object obj38 = null;
//        boolean boolean39 = limitChronology37.equals(obj38);
//        java.lang.String str40 = limitChronology37.toString();
//        org.joda.time.DurationField durationField41 = limitChronology37.minutes();
//        boolean boolean42 = limitChronology17.equals((java.lang.Object) durationField41);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(gJChronology5);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(gJChronology10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(limitChronology17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-255139199999L) + "'", long21 == (-255139199999L));
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(property29);
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(property35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(limitChronology37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:21:18.851Z, 2019-06-12T12:21:28.851Z]" + "'", str40.equals("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:21:18.851Z, 2019-06-12T12:21:28.851Z]"));
//        org.junit.Assert.assertNotNull(durationField41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.dayOfMonth();
//        org.joda.time.ReadableDuration readableDuration5 = null;
//        mutableDateTime2.add(readableDuration5);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
//        org.junit.Assert.assertNotNull(property4);
//    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.era();
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime2.yearOfCentury();
//        mutableDateTime2.setTime((-9223372036854775808L));
//        org.joda.time.ReadablePeriod readablePeriod8 = null;
//        mutableDateTime2.add(readablePeriod8, 100);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(property5);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 169596, (-3599849L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -610519991004");
        } catch (java.lang.ArithmeticException e) {
        }
    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test249");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
//        long long3 = mutableDateTime2.getMillis();
//        int int4 = mutableDateTime2.getMinuteOfDay();
//        mutableDateTime2.setDayOfYear(12);
//        java.lang.String str8 = mutableDateTime2.toString("6/12/19");
//        org.joda.time.ReadableDuration readableDuration9 = null;
//        mutableDateTime2.add(readableDuration9, 163);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.MutableDateTime mutableDateTime14 = new org.joda.time.MutableDateTime(0L, chronology13);
//        long long15 = mutableDateTime14.getMillis();
//        mutableDateTime14.setMinuteOfHour(0);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime14.hourOfDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.MutableDateTime mutableDateTime20 = new org.joda.time.MutableDateTime(dateTimeZone19);
//        long long21 = property18.getDifferenceAsLong((org.joda.time.ReadableInstant) mutableDateTime20);
//        org.joda.time.MutableDateTime.Property property22 = mutableDateTime20.centuryOfEra();
//        mutableDateTime2.setMillis((org.joda.time.ReadableInstant) mutableDateTime20);
//        long long24 = mutableDateTime2.getMillis();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "6/12/19" + "'", str8.equals("6/12/19"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-433428L) + "'", long21 == (-433428L));
//        org.junit.Assert.assertNotNull(property22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560342089233L + "'", long24 == 1560342089233L);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DurationField durationField4 = gJChronology3.months();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology11.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField21 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology3, dateTimeField19, (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField23 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipUndoDateTimeField21, dateTimeFieldType22);
        long long25 = skipUndoDateTimeField21.roundHalfCeiling((long) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = buddhistChronology0.withZone(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) (byte) 0);
        org.joda.time.DateTime dateTime5 = dateTime1.minusMonths((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTimeISO();
        org.joda.time.DateTime.Property property7 = dateTime5.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("Property[millisOfSecond]", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:58.886-07:00, 2019-06-12T05:20:08.887-07:00]", (int) '4', 319);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 12);
        boolean boolean7 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int10 = fixedDateTimeZone4.getOffset(2678400960L);
        int int12 = fixedDateTimeZone4.getStandardOffset(1560297600010L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 52 + "'", int6 == 52);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 319 + "'", int12 == 319);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("Property[millisOfSecond]", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:58.886-07:00, 2019-06-12T05:20:08.887-07:00]", (int) '4', 319);
        int int12 = fixedDateTimeZone10.getOffsetFromLocal((long) 12);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(10);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
        org.joda.time.DateTime.Property property17 = dateTime15.millisOfSecond();
        org.joda.time.DateTime dateTime18 = property17.getDateTime();
        org.joda.time.DateTime dateTime19 = property17.roundHalfEvenCopy();
        org.joda.time.DurationField durationField20 = property17.getDurationField();
        int int21 = property17.getMinimumValue();
        boolean boolean22 = fixedDateTimeZone10.equals((java.lang.Object) int21);
        try {
            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(0, 740, 4, 44, (int) '#', 0, (org.joda.time.DateTimeZone) fixedDateTimeZone10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 44 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test257");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(dateTimeZone1);
//        long long4 = dateTimeZone1.convertUTCToLocal((long) 319);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withZone(dateTimeZone1);
//        org.joda.time.tz.DefaultNameProvider defaultNameProvider7 = new org.joda.time.tz.DefaultNameProvider();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime11 = dateTime9.minusSeconds(10);
//        org.joda.time.DateTime.Property property12 = dateTime11.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.MutableDateTime mutableDateTime17 = new org.joda.time.MutableDateTime(0L, chronology16);
//        org.joda.time.MutableDateTime.Property property18 = mutableDateTime17.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone13, (org.joda.time.ReadableInstant) mutableDateTime17);
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime22 = dateTime20.minusSeconds(10);
//        org.joda.time.DateTime.Property property23 = dateTime22.yearOfCentury();
//        org.joda.time.DateTime.Property property24 = dateTime22.millisOfSecond();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology26 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology19, (org.joda.time.ReadableDateTime) dateTime22, (org.joda.time.ReadableDateTime) dateTime25);
//        org.joda.time.ReadablePeriod readablePeriod27 = null;
//        long long30 = limitChronology26.add(readablePeriod27, (-255139199999L), (-1));
//        org.joda.time.DateTime dateTime31 = limitChronology26.getUpperLimit();
//        boolean boolean32 = property12.equals((java.lang.Object) limitChronology26);
//        java.util.Locale locale33 = null;
//        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket34 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology26, locale33);
//        java.util.Locale locale35 = dateTimeParserBucket34.getLocale();
//        java.lang.String str38 = defaultNameProvider7.getShortName(locale35, "1970-01-01T00:00:00.000Z", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:50.536-07:00, 2019-06-12T05:20:00.537-07:00]");
//        java.lang.String str39 = dateTimeZone1.getName((long) 999, locale35);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 319L + "'", long4 == 319L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter5);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(gJChronology14);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(property24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(limitChronology26);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-255139199999L) + "'", long30 == (-255139199999L));
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(locale35);
//        org.junit.Assert.assertNull(str38);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Coordinated Universal Time" + "'", str39.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        long long3 = mutableDateTime2.getMillis();
        mutableDateTime2.setMinuteOfHour(0);
        org.joda.time.MutableDateTime.Property property6 = mutableDateTime2.hourOfDay();
        java.util.Date date7 = mutableDateTime2.toDate();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.months();
        org.joda.time.DateTimeField dateTimeField2 = gJChronology0.secondOfDay();
        java.lang.String str3 = gJChronology0.toString();
        org.joda.time.DurationField durationField4 = gJChronology0.months();
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GJChronology[UTC]" + "'", str3.equals("GJChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology6.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology6.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(dateTimeZone1);
        long long4 = dateTimeZone1.convertUTCToLocal((long) 319);
        org.joda.time.Chronology chronology5 = gregorianChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime((java.lang.Object) gregorianChronology0, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 319L + "'", long4 == 319L);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology5 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.MutableDateTime mutableDateTime8 = new org.joda.time.MutableDateTime(0L, chronology7);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime8.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) mutableDateTime8);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime11.minusSeconds(10);
        org.joda.time.DateTime.Property property14 = dateTime13.yearOfCentury();
        org.joda.time.DateTime.Property property15 = dateTime13.millisOfSecond();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology17 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology10, (org.joda.time.ReadableDateTime) dateTime13, (org.joda.time.ReadableDateTime) dateTime16);
        org.joda.time.DateTime dateTime18 = limitChronology17.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.DateTime dateTime21 = dateTime18.withPeriodAdded(readablePeriod19, (int) (short) 0);
        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = gJChronology22.add(readablePeriod23, (long) 86390, (int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gJChronology5);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(gJChronology10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(limitChronology17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(gJChronology22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 86390L + "'", long26 == 86390L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(chronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(0L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(10);
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfCentury();
        org.joda.time.DateTime.Property property18 = dateTime16.millisOfSecond();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology20 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology13, (org.joda.time.ReadableDateTime) dateTime16, (org.joda.time.ReadableDateTime) dateTime19);
        org.joda.time.DateTimeField dateTimeField21 = gJChronology13.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology13.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField22);
        org.joda.time.field.SkipDateTimeField skipDateTimeField25 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) julianChronology3, (org.joda.time.DateTimeField) skipUndoDateTimeField23, 740);
        try {
            long long33 = julianChronology3.getDateTimeMillis((int) (short) 10, 319, 1970, 70, 5, (int) (short) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(julianChronology3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(limitChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime1.minusSeconds(10);
        org.joda.time.DateTime.Property property4 = dateTime3.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        long long22 = limitChronology18.add(readablePeriod19, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime23 = limitChronology18.getUpperLimit();
        boolean boolean24 = property4.equals((java.lang.Object) limitChronology18);
        java.util.Locale locale25 = null;
        org.joda.time.format.DateTimeParserBucket dateTimeParserBucket26 = new org.joda.time.format.DateTimeParserBucket((long) (short) 1, (org.joda.time.Chronology) limitChronology18, locale25);
        int int27 = dateTimeParserBucket26.getOffset();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime30 = dateTime28.minusSeconds(10);
        org.joda.time.DateTime.Property property31 = dateTime30.yearOfCentury();
        org.joda.time.DateTime dateTime32 = property31.withMaximumValue();
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.DateTime dateTime34 = dateTime32.minus(readableDuration33);
        org.joda.time.DateTime.Property property35 = dateTime34.year();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime37 = null;
        boolean boolean38 = dateTimeZone36.isLocalDateTimeGap(localDateTime37);
        org.joda.time.chrono.GJChronology gJChronology39 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone36);
        org.joda.time.DurationField durationField40 = gJChronology39.months();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41);
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.MutableDateTime mutableDateTime45 = new org.joda.time.MutableDateTime(0L, chronology44);
        org.joda.time.MutableDateTime.Property property46 = mutableDateTime45.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology47 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone41, (org.joda.time.ReadableInstant) mutableDateTime45);
        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime50 = dateTime48.minusSeconds(10);
        org.joda.time.DateTime.Property property51 = dateTime50.yearOfCentury();
        org.joda.time.DateTime.Property property52 = dateTime50.millisOfSecond();
        org.joda.time.DateTime dateTime53 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology54 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology47, (org.joda.time.ReadableDateTime) dateTime50, (org.joda.time.ReadableDateTime) dateTime53);
        org.joda.time.DateTimeField dateTimeField55 = gJChronology47.minuteOfDay();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField57 = new org.joda.time.field.SkipUndoDateTimeField((org.joda.time.Chronology) gJChronology39, dateTimeField55, (int) '#');
        boolean boolean58 = skipUndoDateTimeField57.isSupported();
        org.joda.time.DateTime dateTime59 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime61 = dateTime59.minusSeconds(10);
        org.joda.time.DateTime.Property property62 = dateTime61.yearOfCentury();
        org.joda.time.DateTime.Property property63 = dateTime61.millisOfSecond();
        org.joda.time.LocalDate localDate64 = dateTime61.toLocalDate();
        int int65 = skipUndoDateTimeField57.getMaximumValue((org.joda.time.ReadablePartial) localDate64);
        org.joda.time.DateTime dateTime66 = dateTime34.withFields((org.joda.time.ReadablePartial) localDate64);
        org.joda.time.DateTime dateTime68 = dateTime66.withSecondOfMinute(0);
        boolean boolean69 = dateTimeParserBucket26.restoreState((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-255139199999L) + "'", long22 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(gJChronology39);
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(gJChronology42);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(gJChronology47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(property51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(limitChronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(property63);
        org.junit.Assert.assertNotNull(localDate64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1439 + "'", int65 == 1439);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime.Property property4 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime6 = property4.addWrapFieldToCopy(100);
        java.lang.String str7 = property4.toString();
        org.joda.time.DateTime dateTime9 = property4.setCopy((int) 'a');
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime12 = property10.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Property[millisOfSecond]" + "'", str7.equals("Property[millisOfSecond]"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder2.appendYearOfCentury((int) (short) 1, (-32));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder8 = dateTimeFormatterBuilder2.appendDayOfWeekText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder8.appendFractionOfDay(52, (-32));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder13 = dateTimeFormatterBuilder8.appendSecondOfMinute((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder14 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder16 = dateTimeFormatterBuilder14.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder17 = dateTimeFormatterBuilder16.appendHalfdayOfDayText();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder19 = dateTimeFormatterBuilder17.appendMinuteOfDay(1439);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder21 = dateTimeFormatterBuilder19.appendSecondOfMinute(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder22 = dateTimeFormatterBuilder19.appendMonthOfYearText();
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap23 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder24 = dateTimeFormatterBuilder19.appendTimeZoneShortName(strMap23);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder25 = dateTimeFormatterBuilder8.appendTimeZoneShortName(strMap23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder8);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder13);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder16);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder17);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder19);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder21);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder22);
        org.junit.Assert.assertNotNull(strMap23);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder24);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder25);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        long long3 = mutableDateTime2.getMillis();
        int int4 = mutableDateTime2.getMinuteOfDay();
        mutableDateTime2.setDayOfYear(12);
        java.lang.String str8 = mutableDateTime2.toString("6/12/19");
        org.joda.time.ReadableDuration readableDuration9 = null;
        mutableDateTime2.add(readableDuration9, 163);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        org.joda.time.Chronology chronology15 = null;
        org.joda.time.MutableDateTime mutableDateTime16 = new org.joda.time.MutableDateTime(0L, chronology15);
        org.joda.time.MutableDateTime.Property property17 = mutableDateTime16.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12, (org.joda.time.ReadableInstant) mutableDateTime16);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime21 = dateTime19.minusSeconds(10);
        org.joda.time.DateTime.Property property22 = dateTime21.yearOfCentury();
        org.joda.time.DateTime.Property property23 = dateTime21.millisOfSecond();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology25 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology18, (org.joda.time.ReadableDateTime) dateTime21, (org.joda.time.ReadableDateTime) dateTime24);
        org.joda.time.ReadablePeriod readablePeriod26 = null;
        long long29 = limitChronology25.add(readablePeriod26, (-255139199999L), (-1));
        org.joda.time.DateTime dateTime30 = limitChronology25.getUpperLimit();
        mutableDateTime2.setChronology((org.joda.time.Chronology) limitChronology25);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "6/12/19" + "'", str8.equals("6/12/19"));
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(limitChronology25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-255139199999L) + "'", long29 == (-255139199999L));
        org.junit.Assert.assertNotNull(dateTime30);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Instant instant4 = gJChronology3.getGregorianCutover();
        org.joda.time.Instant instant6 = instant4.plus((long) (short) 10);
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.Instant instant9 = instant6.withDurationAdded(readableDuration7, 319);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Instant instant11 = instant6.plus(readableDuration10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(instant4);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(instant9);
        org.junit.Assert.assertNotNull(instant11);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = buddhistChronology0.withZone(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.MutableDateTime mutableDateTime9 = new org.joda.time.MutableDateTime(0L, chronology8);
        org.joda.time.MutableDateTime.Property property10 = mutableDateTime9.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5, (org.joda.time.ReadableInstant) mutableDateTime9);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(10);
        org.joda.time.DateTime.Property property15 = dateTime14.yearOfCentury();
        org.joda.time.DateTime.Property property16 = dateTime14.millisOfSecond();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology18 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology11, (org.joda.time.ReadableDateTime) dateTime14, (org.joda.time.ReadableDateTime) dateTime17);
        org.joda.time.DateTimeField dateTimeField19 = gJChronology11.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology11.millisOfSecond();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField21 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField20);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime24 = dateTime22.minusSeconds(10);
        org.joda.time.DateTime.Property property25 = dateTime24.yearOfCentury();
        org.joda.time.DateTime dateTime26 = property25.withMaximumValue();
        org.joda.time.DateTime dateTime28 = dateTime26.withYear((int) '4');
        org.joda.time.DateTime dateTime30 = dateTime26.plus((long) 1439);
        org.joda.time.YearMonthDay yearMonthDay31 = dateTime30.toYearMonthDay();
        java.util.Locale locale33 = null;
        java.lang.String str34 = delegatedDateTimeField21.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay31, (int) (short) 1, locale33);
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField36 = new org.joda.time.field.SkipUndoDateTimeField(chronology4, (org.joda.time.DateTimeField) delegatedDateTimeField21, 321);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(limitChronology18);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(yearMonthDay31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "1" + "'", str34.equals("1"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.millisOfSecond();
        org.joda.time.MutableDateTime mutableDateTime4 = property3.roundHalfCeiling();
        int int5 = mutableDateTime4.getRoundingMode();
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.weekOfWeekyear();
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        mutableDateTime2.addMillis(0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(70, 19, 320, 0, 1988, 4, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1988 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField2 = gJChronology1.months();
        org.joda.time.DateTimeField dateTimeField3 = gJChronology1.weekyearOfCentury();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.Chronology chronology5 = dateTime4.getChronology();
        org.joda.time.MutableDateTime mutableDateTime6 = new org.joda.time.MutableDateTime(chronology5);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology8 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.MutableDateTime mutableDateTime11 = new org.joda.time.MutableDateTime(0L, chronology10);
        org.joda.time.MutableDateTime.Property property12 = mutableDateTime11.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7, (org.joda.time.ReadableInstant) mutableDateTime11);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime16 = dateTime14.minusSeconds(10);
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfCentury();
        org.joda.time.DateTime.Property property18 = dateTime16.millisOfSecond();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology20 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology13, (org.joda.time.ReadableDateTime) dateTime16, (org.joda.time.ReadableDateTime) dateTime19);
        org.joda.time.DateTimeField dateTimeField21 = gJChronology13.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField22 = gJChronology13.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField23 = new org.joda.time.field.SkipUndoDateTimeField(chronology5, dateTimeField22);
        int int26 = skipUndoDateTimeField23.getDifference((long) 320, (-1L));
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology1, (org.joda.time.DateTimeField) skipUndoDateTimeField23, (int) (byte) 10);
        int int29 = skipDateTimeField28.getMinimumValue();
        boolean boolean30 = gregorianChronology0.equals((java.lang.Object) skipDateTimeField28);
        boolean boolean31 = skipDateTimeField28.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gJChronology8);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(limitChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 321 + "'", int26 == 321);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.minus(readableDuration5);
        org.joda.time.DateTime.Property property7 = dateTime6.year();
        org.joda.time.DateTime dateTime8 = dateTime6.withLaterOffsetAtOverlap();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("Property[millisOfSecond]", "LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T05:19:58.886-07:00, 2019-06-12T05:20:08.887-07:00]", (int) '4', 319);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = org.joda.time.format.DateTimeFormat.mediumDateTime();
        java.util.Locale locale15 = dateTimeFormatter14.getLocale();
        boolean boolean16 = dateTimeFormatter14.isParser();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(1, (int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter14.withZone(dateTimeZone19);
        java.lang.String str22 = dateTimeZone19.getShortName((long) 321);
        long long24 = fixedDateTimeZone13.getMillisKeepLocal(dateTimeZone19, (long) 99);
        org.joda.time.DateTime dateTime25 = dateTime6.withZoneRetainFields((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        long long27 = fixedDateTimeZone13.nextTransition(1L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNull(locale15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "+01:00" + "'", str22.equals("+01:00"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-3599849L) + "'", long24 == (-3599849L));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendDayOfWeek(163);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder4 = dateTimeFormatterBuilder2.appendMillisOfSecond((int) (short) 100);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder7 = dateTimeFormatterBuilder4.appendFractionOfSecond(0, 2019);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder9 = dateTimeFormatterBuilder7.appendTwoDigitYear((-32));
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder11 = dateTimeFormatterBuilder9.appendMinuteOfDay(5);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder12 = dateTimeFormatterBuilder11.appendTimeZoneId();
        try {
            org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder15 = dateTimeFormatterBuilder12.appendYearOfEra((-741), 44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder4);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder7);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder9);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder11);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder12);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
//        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
//        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
//        org.joda.time.DateTime dateTime6 = dateTime4.withYear((int) '4');
//        org.joda.time.DateTime dateTime8 = dateTime4.plus((long) 1439);
//        org.joda.time.YearMonthDay yearMonthDay9 = dateTime8.toYearMonthDay();
//        long long10 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.DateTime dateTime12 = dateTime8.plusMonths(6);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(yearMonthDay9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 4084950083468L + "'", long10 == 4084950083468L);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        mutableDateTime4.setDayOfYear(163);
        org.joda.time.MutableDateTime.Property property9 = mutableDateTime4.weekyear();
        org.joda.time.MutableDateTime mutableDateTime11 = property9.set(0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(mutableDateTime11);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        try {
            org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(86399, (int) (short) 100, 0, 20, 70, 321, 740);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 70 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.DateTimeFormat.mediumTime();
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:21:06.385Z, 2019-06-12T12:21:16.385Z]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"LimitChronology[GJChronology[UTC...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.MutableDateTime mutableDateTime7 = new org.joda.time.MutableDateTime(0L, chronology6);
        org.joda.time.MutableDateTime.Property property8 = mutableDateTime7.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, (org.joda.time.ReadableInstant) mutableDateTime7);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime12 = dateTime10.minusSeconds(10);
        org.joda.time.DateTime.Property property13 = dateTime12.yearOfCentury();
        org.joda.time.DateTime.Property property14 = dateTime12.millisOfSecond();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology16 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology9, (org.joda.time.ReadableDateTime) dateTime12, (org.joda.time.ReadableDateTime) dateTime15);
        org.joda.time.DateTimeField dateTimeField17 = gJChronology9.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField18 = gJChronology9.millisOfSecond();
        org.joda.time.field.SkipUndoDateTimeField skipUndoDateTimeField19 = new org.joda.time.field.SkipUndoDateTimeField(chronology1, dateTimeField18);
        long long21 = skipUndoDateTimeField19.roundHalfEven(10L);
        long long24 = skipUndoDateTimeField19.addWrapField((long) 4, 70);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(gJChronology9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(limitChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 74L + "'", long24 == 74L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
//        org.joda.time.DateTime.Property property14 = dateTime12.minuteOfDay();
//        int int15 = property14.get();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 741 + "'", int15 == 741);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        java.lang.String str7 = mutableDateTime4.toString();
        java.util.TimeZone timeZone8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forTimeZone(timeZone8);
        mutableDateTime4.setZoneRetainFields(dateTimeZone9);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        mutableDateTime4.add(readablePeriod11);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime15 = dateTime13.minusSeconds(10);
        org.joda.time.DateTime.Property property16 = dateTime15.yearOfCentury();
        org.joda.time.DateTime dateTime17 = property16.withMaximumValue();
        org.joda.time.DateTime dateTime19 = property16.addToCopy(0);
        org.joda.time.DateTime dateTime20 = property16.roundCeilingCopy();
        org.joda.time.DateTime dateTime22 = dateTime20.plus((long) (-32));
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        org.joda.time.DateTime dateTime25 = dateTime20.withPeriodAdded(readablePeriod23, 319);
        boolean boolean26 = mutableDateTime4.isEqual((org.joda.time.ReadableInstant) dateTime20);
        mutableDateTime4.setYear(100);
        org.joda.time.MutableDateTime.Property property29 = mutableDateTime4.millisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1970-01-01T00:00:00.000Z" + "'", str7.equals("1970-01-01T00:00:00.000Z"));
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(property29);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        java.util.TimeZone timeZone0 = null;
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
//        org.joda.time.MutableDateTime mutableDateTime2 = org.joda.time.MutableDateTime.now(dateTimeZone1);
//        int int3 = mutableDateTime2.getWeekOfWeekyear();
//        org.joda.time.ReadableDuration readableDuration4 = null;
//        mutableDateTime2.add(readableDuration4);
//        boolean boolean7 = mutableDateTime2.isEqual((long) 'a');
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(mutableDateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test287() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test287");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
//        org.joda.time.Chronology chronology3 = null;
//        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
//        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
//        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
//        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
//        org.joda.time.DateTime dateTime14 = limitChronology13.getUpperLimit();
//        org.joda.time.ReadablePeriod readablePeriod15 = null;
//        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.UTC;
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.Chronology chronology21 = null;
//        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime(0L, chronology21);
//        org.joda.time.MutableDateTime.Property property23 = mutableDateTime22.millisOfSecond();
//        org.joda.time.chrono.GJChronology gJChronology24 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18, (org.joda.time.ReadableInstant) mutableDateTime22);
//        org.joda.time.MutableDateTime mutableDateTime25 = dateTime14.toMutableDateTime(dateTimeZone18);
//        org.joda.time.MutableDateTime.Property property26 = mutableDateTime25.yearOfEra();
//        int int27 = mutableDateTime25.getYear();
//        org.joda.time.MutableDateTime.Property property28 = mutableDateTime25.monthOfYear();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime31 = dateTime29.minusSeconds(10);
//        org.joda.time.DateTime dateTime33 = dateTime31.plusWeeks(960);
//        org.joda.time.DateTime.Property property34 = dateTime33.minuteOfHour();
//        org.joda.time.DurationField durationField35 = property34.getRangeDurationField();
//        org.joda.time.DateTime dateTime37 = property34.addToCopy((long) (short) 0);
//        org.joda.time.DateTime dateTime39 = dateTime37.plusMinutes((int) (byte) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
//        boolean boolean41 = dateTimeFormatter40.isOffsetParsed();
//        org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstanceUTC();
//        org.joda.time.DurationField durationField43 = gJChronology42.months();
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime46 = dateTime44.minusSeconds(10);
//        org.joda.time.DateTime.Property property47 = dateTime46.yearOfCentury();
//        org.joda.time.DateTime.Property property48 = dateTime46.millisOfSecond();
//        org.joda.time.LocalDate localDate49 = dateTime46.toLocalDate();
//        long long51 = gJChronology42.set((org.joda.time.ReadablePartial) localDate49, (long) (byte) 10);
//        java.lang.Class<?> wildcardClass52 = localDate49.getClass();
//        java.lang.String str53 = dateTimeFormatter40.print((org.joda.time.ReadablePartial) localDate49);
//        org.joda.time.DateTime dateTime54 = dateTime37.withFields((org.joda.time.ReadablePartial) localDate49);
//        mutableDateTime25.setMillis((org.joda.time.ReadableInstant) dateTime54);
//        mutableDateTime25.addMinutes((int) ' ');
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(gJChronology1);
//        org.junit.Assert.assertNotNull(property5);
//        org.junit.Assert.assertNotNull(gJChronology6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(property11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(limitChronology13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(gJChronology24);
//        org.junit.Assert.assertNotNull(mutableDateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2019 + "'", int27 == 2019);
//        org.junit.Assert.assertNotNull(property28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(durationField35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(dateTimeFormatter40);
//        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
//        org.junit.Assert.assertNotNull(gJChronology42);
//        org.junit.Assert.assertNotNull(durationField43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(property47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1560297600010L + "'", long51 == 1560297600010L);
//        org.junit.Assert.assertNotNull(wildcardClass52);
//        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "������" + "'", str53.equals("������"));
//        org.junit.Assert.assertNotNull(dateTime54);
//    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("Coordinated Universal Time", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"Coordinated Universal Time/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test289() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test289");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.Chronology chronology1 = dateTime0.getChronology();
//        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(chronology1);
//        int int3 = mutableDateTime2.getMinuteOfDay();
//        org.joda.time.MutableDateTime.Property property4 = mutableDateTime2.weekyear();
//        org.joda.time.MutableDateTime mutableDateTime6 = property4.set(2019);
//        org.joda.time.MutableDateTime.Property property7 = mutableDateTime6.monthOfYear();
//        org.joda.time.MutableDateTime mutableDateTime8 = property7.roundHalfEven();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 741 + "'", int3 == 741);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(mutableDateTime6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(mutableDateTime8);
//    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = dateTime0.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime3 = dateTime1.withSecondOfMinute((int) (byte) 0);
        org.joda.time.DateTime dateTime5 = dateTime1.minusMonths((int) (byte) 100);
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTimeISO();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime13 = property11.addWrapFieldToCopy(100);
        org.joda.time.DateTime dateTime14 = property11.roundFloorCopy();
        org.joda.time.DateTime dateTime16 = property11.setCopy((int) (byte) 1);
        org.joda.time.DateTime dateTime18 = dateTime16.minusMonths((-432688));
        int int19 = mutableDateTime6.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gJChronology0.seconds();
        try {
            long long9 = gJChronology0.getDateTimeMillis(0, 2019, 3, 169596, 740, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 169596 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gJChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.MutableDateTime mutableDateTime2 = new org.joda.time.MutableDateTime(0L, chronology1);
        org.joda.time.MutableDateTime.Property property3 = mutableDateTime2.millisOfSecond();
        mutableDateTime2.setYear(12);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds(10);
        org.joda.time.DateTime.Property property9 = dateTime8.yearOfCentury();
        org.joda.time.DateTime dateTime10 = property9.withMaximumValue();
        org.joda.time.DateTime dateTime12 = dateTime10.withDayOfYear((int) (byte) 10);
        mutableDateTime2.setDate((org.joda.time.ReadableInstant) dateTime10);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("LimitChronology[GJChronology[UTC,cutover=1970-01-01], 2019-06-12T12:20:52.817Z, 2019-06-12T12:21:02.840Z]", "");
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTimeField dateTimeField14 = gJChronology6.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology6.millisOfSecond();
        org.joda.time.DurationField durationField16 = gJChronology6.halfdays();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime19 = dateTime17.minusSeconds(10);
        org.joda.time.DateTime.Property property20 = dateTime19.yearOfCentury();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        org.joda.time.DateTime dateTime22 = dateTime21.withLaterOffsetAtOverlap();
        org.joda.time.MutableDateTime mutableDateTime24 = new org.joda.time.MutableDateTime(0L);
        try {
            org.joda.time.chrono.LimitChronology limitChronology25 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime21, (org.joda.time.ReadableDateTime) mutableDateTime24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(86399, 960, 44, 70);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusSeconds(10);
        org.joda.time.DateTime.Property property3 = dateTime2.yearOfCentury();
        org.joda.time.DateTime dateTime4 = property3.withMaximumValue();
        org.joda.time.DateTime dateTime6 = dateTime4.withYear((int) '4');
        org.joda.time.DateTime.Property property7 = dateTime4.minuteOfHour();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(4084950083468L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.LocalDateTime localDateTime1 = null;
        boolean boolean2 = dateTimeZone0.isLocalDateTimeGap(localDateTime1);
        org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone4 = gJChronology3.getZone();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = dateTime5.minusSeconds(10);
        org.joda.time.DateTime dateTime9 = dateTime7.plusWeeks(960);
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfHour();
        org.joda.time.DurationField durationField11 = property10.getRangeDurationField();
        org.joda.time.DateTime dateTime13 = property10.addToCopy((long) (short) 0);
        org.joda.time.DateTime.Property property14 = dateTime13.hourOfDay();
        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.LocalDateTime localDateTime16 = dateTime13.toLocalDateTime();
        boolean boolean17 = org.joda.time.DateTimeUtils.isContiguous((org.joda.time.ReadablePartial) localDateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(gJChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(gJChronology15);
        org.junit.Assert.assertNotNull(localDateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GJChronology gJChronology1 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0);
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.MutableDateTime mutableDateTime4 = new org.joda.time.MutableDateTime(0L, chronology3);
        org.joda.time.MutableDateTime.Property property5 = mutableDateTime4.millisOfSecond();
        org.joda.time.chrono.GJChronology gJChronology6 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, (org.joda.time.ReadableInstant) mutableDateTime4);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusSeconds(10);
        org.joda.time.DateTime.Property property10 = dateTime9.yearOfCentury();
        org.joda.time.DateTime.Property property11 = dateTime9.millisOfSecond();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.chrono.LimitChronology limitChronology13 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) gJChronology6, (org.joda.time.ReadableDateTime) dateTime9, (org.joda.time.ReadableDateTime) dateTime12);
        org.joda.time.DateTime dateTime14 = limitChronology13.getUpperLimit();
        org.joda.time.ReadablePeriod readablePeriod15 = null;
        org.joda.time.DateTime dateTime17 = dateTime14.withPeriodAdded(readablePeriod15, (int) (short) 0);
        org.joda.time.DateTime dateTime19 = dateTime17.minus((long) (short) -1);
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.MutableDateTime mutableDateTime22 = new org.joda.time.MutableDateTime(0L, chronology21);
        long long23 = mutableDateTime22.getMillis();
        boolean boolean24 = dateTime17.isEqual((org.joda.time.ReadableInstant) mutableDateTime22);
        org.joda.time.DateTime dateTime26 = dateTime17.withWeekyear(12);
        java.util.Locale locale27 = null;
        java.util.Calendar calendar28 = dateTime26.toCalendar(locale27);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gJChronology1);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(gJChronology6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(limitChronology13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(calendar28);
    }
}

