import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology2, (java.lang.Object) 4);
        org.joda.time.Period period5 = new org.joda.time.Period(4L, periodType1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField6 = iSOChronology2.halfdays();
        org.joda.time.DurationField durationField7 = iSOChronology2.days();
        org.joda.time.DurationField durationField8 = iSOChronology2.months();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(5051);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-5051) + "'", int1 == (-5051));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        int int27 = dividedDateTimeField26.getMaximumValue();
        java.util.Locale locale28 = null;
        int int29 = dividedDateTimeField26.getMaximumShortTextLength(locale28);
        long long32 = dividedDateTimeField26.addWrapField((-62102995621990L), 5049);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62102995621990L) + "'", long32 == (-62102995621990L));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundCeiling((long) 1);
        int int45 = remainderDateTimeField42.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 86400000L + "'", long44 == 86400000L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 99 + "'", int45 == 99);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        long long8 = offsetDateTimeField4.add((long) ' ', (long) 8);
        org.joda.time.DurationField durationField9 = offsetDateTimeField4.getLeapDurationField();
        java.lang.String str10 = offsetDateTimeField4.toString();
        org.joda.time.ReadablePartial readablePartial11 = null;
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial11);
        long long14 = offsetDateTimeField4.roundCeiling(100L);
        long long17 = offsetDateTimeField4.add((long) (-8), (long) (short) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 691200032L + "'", long8 == 691200032L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str10.equals("DateTimeField[dayOfWeek]"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 86400000L + "'", long14 == 86400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-86400008L) + "'", long17 == (-86400008L));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 5044);
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText(readablePartial6, 100, locale8);
        int int12 = offsetDateTimeField5.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 5044);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField17.getAsShortText(readablePartial18, 100, locale20);
        int int24 = offsetDateTimeField17.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int int26 = offsetDateTimeField17.getMinimumValue(readablePartial25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField17.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology34 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology30, dateTimeZone33);
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone37 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone36);
        java.lang.String str39 = cachedDateTimeZone37.getNameKey((long) (short) -1);
        int int41 = cachedDateTimeZone37.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology42 = gregorianChronology30.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone37);
        org.joda.time.DurationField durationField43 = gregorianChronology30.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = unsupportedDateTimeField44.getType();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField47 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType45, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 99 + "'", int12 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "100" + "'", str21.equals("100"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 99 + "'", int24 == 99);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5045 + "'", int26 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(zonedChronology34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(cachedDateTimeZone37);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "UTC" + "'", str39.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeFieldType45);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean21 = unsupportedDurationField20.isPrecise();
        long long22 = unsupportedDurationField20.getUnitMillis();
        try {
            int int24 = unsupportedDurationField20.getValue(8639999999L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
        java.util.Locale locale45 = null;
        int int46 = remainderDateTimeField42.getMaximumTextLength(locale45);
        long long48 = remainderDateTimeField42.roundHalfEven((-210866774822000L));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField42, (int) '#');
        long long53 = remainderDateTimeField42.addWrapField((long) 5049, (-28800000));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8640000000L + "'", long44 == 8640000000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-210866803200000L) + "'", long48 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 5049L + "'", long53 == 5049L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 10, (long) 100, periodType2);
        org.joda.time.DurationFieldType durationFieldType5 = period3.getFieldType(0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(durationFieldType5, (java.lang.Number) (-1104537599889L), (java.lang.Number) 350, (java.lang.Number) (-2208988799900L));
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(durationFieldType5);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        long long47 = unsupportedDateTimeField43.add(44700000L, 3024000000L);
        try {
            long long50 = unsupportedDateTimeField43.set((long) 5044, "Millis");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3024044700000L + "'", long47 == 3024044700000L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Weeks", (java.lang.Number) 1L, (java.lang.Number) 0, (java.lang.Number) (-210858120000000L));
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        java.lang.String str8 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-210858120000000L) + "'", number7.equals((-210858120000000L)));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1" + "'", str8.equals("1"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period6 = period4.plusMillis(1);
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.Period period8 = period4.withPeriodType(periodType7);
        org.joda.time.Period period10 = org.joda.time.Period.minutes(0);
        org.joda.time.Period period12 = period10.minusDays((int) (byte) 1);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period16 = new org.joda.time.Period((long) 1, 0L, periodType15);
        org.joda.time.PeriodType periodType17 = periodType15.withSecondsRemoved();
        org.joda.time.PeriodType periodType18 = periodType17.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType19 = null;
        boolean boolean20 = periodType17.isSupported(durationFieldType19);
        org.joda.time.PeriodType periodType21 = periodType17.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology22 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period23 = new org.joda.time.Period((java.lang.Object) period10, periodType21, (org.joda.time.Chronology) gregorianChronology22);
        org.joda.time.Period period24 = period8.normalizedStandard(periodType21);
        int int25 = period24.getSeconds();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(gregorianChronology22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        boolean boolean15 = scaledDurationField12.isPrecise();
        long long18 = scaledDurationField12.add((-100982246400000L), 66);
        org.joda.time.DurationFieldType durationFieldType19 = scaledDurationField12.getType();
        java.lang.String str20 = scaledDurationField12.toString();
        long long22 = scaledDurationField12.getMillis(7);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 107293680000000L + "'", long18 == 107293680000000L);
        org.junit.Assert.assertNotNull(durationFieldType19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "DurationField[hours]" + "'", str20.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 22089866400000L + "'", long22 == 22089866400000L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        int int2 = period1.getWeeks();
        org.joda.time.Period period4 = period1.minusYears(99);
        try {
            org.joda.time.Weeks weeks5 = period4.toStandardWeeks();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Weeks as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDayTime();
        java.lang.String str2 = periodType1.getName();
        org.joda.time.PeriodType periodType3 = periodType1.withMinutesRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology4, (java.lang.Object) 4);
        org.joda.time.Chronology chronology7 = iSOChronology4.withUTC();
        long long11 = iSOChronology4.add((long) (byte) 0, (long) 350, 0);
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) 1, periodType3, (org.joda.time.Chronology) iSOChronology4);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology4.minuteOfDay();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "YearMonthDayTime" + "'", str2.equals("YearMonthDayTime"));
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField4.getMinimumValue(readablePartial12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField4.getType();
        java.lang.String str15 = offsetDateTimeField4.getName();
        try {
            long long18 = offsetDateTimeField4.set(0L, "Millis");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Millis\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5045 + "'", int13 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfWeek" + "'", str15.equals("dayOfWeek"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        boolean boolean46 = unsupportedDateTimeField43.isSupported();
        org.joda.time.ReadablePartial readablePartial47 = null;
        java.util.Locale locale48 = null;
        try {
            java.lang.String str49 = unsupportedDateTimeField43.getAsShortText(readablePartial47, locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        org.joda.time.Period period3 = period1.minusDays((int) (byte) 1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 1, 0L, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withSecondsRemoved();
        org.joda.time.PeriodType periodType9 = periodType8.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = periodType8.isSupported(durationFieldType10);
        org.joda.time.PeriodType periodType12 = periodType8.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period1, periodType12, (org.joda.time.Chronology) gregorianChronology13);
        java.lang.Object obj15 = null;
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) gregorianChronology13, obj15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology13.clockhourOfHalfday();
        try {
            long long25 = gregorianChronology13.getDateTimeMillis(5047, 64, 350, (int) (short) 1, 0, 4, (-12783));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -12783 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        long long29 = dividedDateTimeField26.getDifferenceAsLong(5043L, (long) 99);
        long long32 = dividedDateTimeField26.getDifferenceAsLong((-86400008L), 3660105L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        int int13 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = offsetDateTimeField4.getMaximumValue(readablePartial14);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5051 + "'", int13 == 5051);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5051 + "'", int15 == 5051);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Weeks", (java.lang.Number) 1L, (java.lang.Number) 0, (java.lang.Number) (-210858120000000L));
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DurationFieldType durationFieldType6 = illegalFieldValueException4.getDurationFieldType();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        illegalFieldValueException4.prependMessage("+00:00:00.100");
        boolean boolean10 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertNull(durationFieldType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Weeks" + "'", str7.equals("Weeks"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getLeapDurationField();
        try {
            int int46 = unsupportedDateTimeField43.getMinimumValue(3024000007L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNull(durationField44);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField43.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial46 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology48 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int49 = gregorianChronology48.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology48.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, 5044);
        org.joda.time.ReadablePartial readablePartial53 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int55 = gregorianChronology54.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology54.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, 5044);
        java.lang.String str59 = offsetDateTimeField58.getName();
        long long61 = offsetDateTimeField58.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial62 = null;
        int[] intArray65 = new int[] { 100, (byte) -1 };
        int int66 = offsetDateTimeField58.getMaximumValue(readablePartial62, intArray65);
        int int67 = offsetDateTimeField52.getMaximumValue(readablePartial53, intArray65);
        try {
            int[] intArray69 = unsupportedDateTimeField43.set(readablePartial46, (int) (short) 10, intArray65, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertNotNull(gregorianChronology48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "dayOfWeek" + "'", str59.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 0L + "'", long61 == 0L);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 5051 + "'", int66 == 5051);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 5051 + "'", int67 == 5051);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        boolean boolean15 = scaledDurationField12.isPrecise();
        long long17 = scaledDurationField12.getMillis(0);
        int int19 = scaledDurationField12.getValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology20.halfdayOfDay();
        org.joda.time.DurationField durationField26 = gregorianChronology20.years();
        org.joda.time.Period period28 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType30 = period28.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField32 = new org.joda.time.field.ScaledDurationField(durationField26, durationFieldType30, (int) (byte) 100);
        int int34 = scaledDurationField32.getValue(4999L);
        boolean boolean35 = scaledDurationField32.isPrecise();
        int int36 = scaledDurationField12.compareTo((org.joda.time.DurationField) scaledDurationField32);
        int int38 = scaledDurationField12.getValue(3660105L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(zonedChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, (long) 100, chronology3);
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        org.joda.time.Period period8 = period6.withWeeks((int) (short) 100);
        org.joda.time.Period period10 = period8.withMinutes(0);
        org.joda.time.Period period12 = period8.plusWeeks((int) (byte) 1);
        int int13 = period12.getWeeks();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 101 + "'", int13 == 101);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.withSeconds((int) '#');
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = period3.isSupported(durationFieldType4);
        org.joda.time.Period period7 = period3.withMillis((int) (short) 10);
        org.joda.time.Period period9 = period3.minusDays((-8));
        int int10 = period3.getMonths();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        int int10 = fixedDateTimeZone4.getStandardOffset((long) (-1));
        java.lang.String str12 = fixedDateTimeZone4.getNameKey(35L);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Millis" + "'", str12.equals("Millis"));
        org.junit.Assert.assertNotNull(dateTimeZone13);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.weekOfWeekyear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        int int29 = dividedDateTimeField26.getDifference(0L, 182L);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = dividedDateTimeField26.getType();
        org.joda.time.ReadablePartial readablePartial31 = null;
        int int32 = dividedDateTimeField26.getMinimumValue(readablePartial31);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology4.getZone();
        long long12 = zonedChronology4.getDateTimeMillis(10L, 1, (int) (short) 1, 0, 105);
        org.joda.time.Chronology chronology13 = zonedChronology4.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3660105L + "'", long12 == 3660105L);
        org.junit.Assert.assertNotNull(chronology13);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundCeiling((long) 1);
        org.joda.time.DurationField durationField45 = remainderDateTimeField42.getRangeDurationField();
        java.lang.String str47 = remainderDateTimeField42.getAsShortText((-100L));
        long long49 = remainderDateTimeField42.roundFloor((-2699186774822000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 86400000L + "'", long44 == 86400000L);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "47" + "'", str47.equals("47"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + (-2699186803200000L) + "'", long49 == (-2699186803200000L));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DurationField durationField6 = zonedChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology4.secondOfDay();
        try {
            long long13 = zonedChronology4.getDateTimeMillis(57600032L, 10096, 110, 5051, 5044);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10096 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        java.lang.String str17 = offsetDateTimeField16.getName();
        long long19 = offsetDateTimeField16.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        int[] intArray23 = new int[] { 100, (byte) -1 };
        int int24 = offsetDateTimeField16.getMaximumValue(readablePartial20, intArray23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField16.getAsShortText(readablePartial25, (int) '4', locale27);
        long long31 = offsetDateTimeField16.add(28800000L, (int) (byte) 100);
        long long34 = offsetDateTimeField16.addWrapField((long) 35, 35);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField16.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType35, 66);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType35, (-5051), (-5051), (int) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "dayOfWeek" + "'", str17.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5051 + "'", int24 == 5051);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "52" + "'", str28.equals("52"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 8668800000L + "'", long31 == 8668800000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 35L + "'", long34 == 35L);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
        long long46 = remainderDateTimeField42.roundFloor(43734096000000L);
        org.joda.time.ReadablePartial readablePartial47 = null;
        java.util.Locale locale48 = null;
        try {
            java.lang.String str49 = remainderDateTimeField42.getAsText(readablePartial47, locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8640000000L + "'", long44 == 8640000000L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43734038400000L + "'", long46 == 43734038400000L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "-1.0");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.joda.time.Period period8 = new org.joda.time.Period(0, (int) ' ', 0, (int) (short) -1, 0, (int) (short) -1, (int) (short) 1, 10);
        org.joda.time.Period period10 = period8.withDays(0);
        org.joda.time.Period period12 = period8.withYears((int) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType13 = null;
        boolean boolean14 = period8.isSupported(durationFieldType13);
        org.joda.time.Period period16 = period8.plusMonths((-1));
        org.joda.time.Period period18 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType20 = period18.getFieldType(4);
        org.joda.time.Period period22 = period8.withFieldAdded(durationFieldType20, 2);
        org.joda.time.Period period24 = period22.minusSeconds(101);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(period24);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology43.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology43, dateTimeZone46);
        org.joda.time.DurationField durationField48 = gregorianChronology43.minutes();
        org.joda.time.DurationField durationField49 = gregorianChronology43.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField49);
        org.joda.time.DurationField durationField51 = unsupportedDateTimeField50.getLeapDurationField();
        long long54 = unsupportedDateTimeField50.getDifferenceAsLong(8640000100L, (-57600000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(zonedChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertNull(durationField51);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long17 = scaledDurationField12.add((long) (byte) -1, 0);
        java.lang.String str18 = scaledDurationField12.toString();
        int int19 = scaledDurationField12.getScalar();
        int int21 = scaledDurationField12.getValue((-62102995621990L));
        int int22 = scaledDurationField12.getScalar();
        long long25 = scaledDurationField12.getMillis(4999L, 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DurationField[hours]" + "'", str18.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-19) + "'", int21 == (-19));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 15775320326400000L + "'", long25 == 15775320326400000L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        org.joda.time.ReadablePartial readablePartial45 = null;
        try {
            int int46 = unsupportedDateTimeField43.getMinimumValue(readablePartial45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period1 = period0.negated();
        org.joda.time.Hours hours2 = period0.toStandardHours();
        int int3 = period0.getYears();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(hours2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
        boolean boolean20 = offsetDateTimeField4.isLenient();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean21 = unsupportedDurationField20.isPrecise();
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, (long) 100, chronology25);
        int int27 = period26.size();
        org.joda.time.Period period28 = period26.negated();
        org.joda.time.Period period30 = period28.withWeeks((int) (short) 100);
        org.joda.time.Period period32 = period30.withMinutes(0);
        org.joda.time.Period period34 = period30.plusWeeks((int) (byte) 1);
        boolean boolean35 = unsupportedDurationField20.equals((java.lang.Object) period34);
        long long36 = unsupportedDurationField20.getUnitMillis();
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology41 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology37, dateTimeZone40);
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology37.halfdayOfDay();
        org.joda.time.DurationField durationField43 = gregorianChronology37.years();
        org.joda.time.Period period45 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType47 = period45.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField49 = new org.joda.time.field.ScaledDurationField(durationField43, durationFieldType47, (int) (byte) 100);
        int int51 = scaledDurationField49.getValue(4999L);
        boolean boolean52 = scaledDurationField49.isPrecise();
        long long54 = scaledDurationField49.getMillis(0);
        int int56 = scaledDurationField49.getValue(10L);
        int int57 = unsupportedDurationField20.compareTo((org.joda.time.DurationField) scaledDurationField49);
        try {
            long long60 = unsupportedDurationField20.getMillis((long) 66, (long) (-8));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 8 + "'", int27 == 8);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(zonedChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertNotNull(durationFieldType47);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period6 = period4.plusMillis(1);
        org.joda.time.Period period8 = period6.withSeconds((int) (byte) 100);
        int int9 = period6.getWeeks();
        org.joda.time.Period period10 = period6.negated();
        int int11 = period6.size();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        long long12 = offsetDateTimeField4.add(0L, (long) (byte) 100);
        long long14 = offsetDateTimeField4.remainder(12622780800000L);
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField4.getMaximumTextLength(locale15);
        int int18 = offsetDateTimeField4.get((long) 66);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 8640000000L + "'", long12 == 8640000000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5048 + "'", int18 == 5048);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 5044);
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField13.getAsShortText(readablePartial14, 100, locale16);
        int int20 = offsetDateTimeField13.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int22 = gregorianChronology21.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 5044);
        org.joda.time.ReadablePartial readablePartial26 = null;
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField25.getAsShortText(readablePartial26, 100, locale28);
        int int32 = offsetDateTimeField25.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = offsetDateTimeField25.getMinimumValue(readablePartial33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField25.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType35, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField(dateTimeField8, dateTimeFieldType35, 99);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology40, (java.lang.Object) 4);
        org.joda.time.Chronology chronology43 = iSOChronology40.withUTC();
        org.joda.time.DurationField durationField44 = iSOChronology40.minutes();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone47 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone46);
        org.joda.time.Chronology chronology48 = iSOChronology40.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone47);
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology40.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int51 = gregorianChronology50.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology50.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 5044);
        org.joda.time.ReadablePartial readablePartial55 = null;
        java.util.Locale locale57 = null;
        java.lang.String str58 = offsetDateTimeField54.getAsShortText(readablePartial55, 100, locale57);
        int int61 = offsetDateTimeField54.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = offsetDateTimeField54.getMinimumValue(readablePartial62);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField54.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField66 = new org.joda.time.field.DividedDateTimeField(dateTimeField49, dateTimeFieldType64, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField39, dateTimeFieldType64, 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType64, 2);
        int int72 = remainderDateTimeField70.getMaximumValue((long) '#');
        long long75 = remainderDateTimeField70.addWrapField(32L, (-28800000));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 99 + "'", int20 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "100" + "'", str29.equals("100"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 99 + "'", int32 == 99);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 5045 + "'", int34 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(cachedDateTimeZone47);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "100" + "'", str58.equals("100"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 99 + "'", int61 == 99);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 5045 + "'", int63 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 32L + "'", long75 == 32L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean21 = unsupportedDurationField20.isPrecise();
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, (long) 100, chronology25);
        int int27 = period26.size();
        org.joda.time.Period period28 = period26.negated();
        org.joda.time.Period period30 = period28.withWeeks((int) (short) 100);
        org.joda.time.Period period32 = period30.withMinutes(0);
        org.joda.time.Period period34 = period30.plusWeeks((int) (byte) 1);
        boolean boolean35 = unsupportedDurationField20.equals((java.lang.Object) period34);
        try {
            long long38 = unsupportedDurationField20.getDifferenceAsLong((long) (-1), 28800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 8 + "'", int27 == 8);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = lenientChronology3.era();
        java.lang.String str5 = lenientChronology3.toString();
        org.joda.time.DurationField durationField6 = lenientChronology3.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str5.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundHalfFloor(8639999999L);
        int int46 = remainderDateTimeField42.getMaximumValue((long) 2);
        java.util.Locale locale48 = null;
        java.lang.String str49 = remainderDateTimeField42.getAsText((long) 35, locale48);
        int int51 = remainderDateTimeField42.getLeapAmount((-100982246400000L));
        long long53 = remainderDateTimeField42.roundHalfCeiling(0L);
        long long55 = remainderDateTimeField42.roundHalfEven(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8640000000L + "'", long44 == 8640000000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 99 + "'", int46 == 99);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "48" + "'", str49.equals("48"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 0L + "'", long53 == 0L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DurationField durationField6 = zonedChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology4.secondOfDay();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int14 = fixedDateTimeZone12.getOffset(0L);
        int int16 = fixedDateTimeZone12.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str18 = fixedDateTimeZone12.getNameKey(0L);
        boolean boolean19 = fixedDateTimeZone12.isFixed();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.Chronology chronology22 = zonedChronology4.withZone(dateTimeZone21);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Millis" + "'", str18.equals("Millis"));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(chronology22);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.time();
        org.joda.time.Period period6 = period4.normalizedStandard(periodType5);
        int int7 = period6.getMinutes();
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 59 + "'", int7 == 59);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
        long long21 = offsetDateTimeField4.roundCeiling(100L);
        org.joda.time.DurationField durationField22 = offsetDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 86400000L + "'", long21 == 86400000L);
        org.junit.Assert.assertNull(durationField22);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 1, 0L, periodType2);
        org.joda.time.PeriodType periodType4 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withHoursRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) lenientChronology3);
        org.joda.time.Chronology chronology5 = lenientChronology4.withUTC();
        boolean boolean7 = lenientChronology4.equals((java.lang.Object) 2440587.500000116d);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        java.lang.String str4 = iSOChronology0.toString();
        org.joda.time.DurationField durationField5 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        long long15 = offsetDateTimeField4.add((long) (byte) 0, 0);
        int int17 = offsetDateTimeField4.getLeapAmount(110479572000000L);
        int int18 = offsetDateTimeField4.getMaximumValue();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5051 + "'", int18 == 5051);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        boolean boolean15 = scaledDurationField12.isPrecise();
        int int18 = scaledDurationField12.getValue((long) (byte) 1, (-4L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
        java.util.Locale locale45 = null;
        int int46 = remainderDateTimeField42.getMaximumTextLength(locale45);
        long long48 = remainderDateTimeField42.roundHalfEven((-210866774822000L));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField42, (int) '#');
        long long52 = offsetDateTimeField50.roundHalfEven(350L);
        long long55 = offsetDateTimeField50.add(1560626720050L, (int) '#');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8640000000L + "'", long44 == 8640000000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-210866803200000L) + "'", long48 == (-210866803200000L));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1563650720050L + "'", long55 == 1563650720050L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean21 = unsupportedDurationField20.isPrecise();
        java.lang.String str22 = unsupportedDurationField20.getName();
        boolean boolean23 = unsupportedDurationField20.isSupported();
        try {
            long long25 = unsupportedDurationField20.getMillis((-2699186803200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hours" + "'", str22.equals("hours"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period6 = period4.plusMillis(1);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period6.toDurationTo(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(1L, periodType11, chronology12);
        org.joda.time.PeriodType periodType14 = periodType11.withYearsRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType11);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period15.toDurationFrom(readableInstant16);
        int int18 = period15.getSeconds();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone5);
        org.joda.time.Period period8 = org.joda.time.Period.ZERO;
        boolean boolean10 = period8.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period11 = period8.normalizedStandard();
        org.joda.time.Duration duration12 = period8.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant13);
        org.joda.time.MutablePeriod mutablePeriod15 = period14.toMutablePeriod();
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period14.isSupported(durationFieldType16);
        int[] intArray20 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period14, (-1104451199899L), (long) 99);
        int int21 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(mutablePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DurationField durationField6 = zonedChronology4.minutes();
        try {
            long long11 = zonedChronology4.getDateTimeMillis(2, 1, 110, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 110 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType5 = periodType4.withWeeksRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology6, (java.lang.Object) 4);
        org.joda.time.Chronology chronology9 = iSOChronology6.withUTC();
        org.joda.time.DurationField durationField10 = iSOChronology6.minutes();
        boolean boolean11 = periodType5.equals((java.lang.Object) iSOChronology6);
        org.joda.time.PeriodType periodType12 = periodType5.withMonthsRemoved();
        boolean boolean13 = lenientChronology3.equals((java.lang.Object) periodType5);
        org.joda.time.DateTimeField dateTimeField14 = lenientChronology3.clockhourOfDay();
        org.joda.time.DurationField durationField15 = lenientChronology3.years();
        org.joda.time.DateTimeField dateTimeField16 = lenientChronology3.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long21 = unsupportedDurationField20.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType22 = unsupportedDurationField20.getType();
        try {
            long long24 = unsupportedDurationField20.getMillis((-100));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType22);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (short) 10);
        org.joda.time.Period period3 = period1.plusYears(66);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long17 = scaledDurationField12.getDifferenceAsLong((-1104537599899L), 10L);
        long long20 = scaledDurationField12.getMillis(0L, (-210858120000000L));
        int int23 = scaledDurationField12.getDifference((-210863736000000L), (-210863736000000L));
        long long26 = scaledDurationField12.getValueAsLong((-100973088000000L), 182L);
        int int29 = scaledDurationField12.getValue((-1085L), 208275926400000L);
        boolean boolean30 = scaledDurationField12.isPrecise();
        long long33 = scaledDurationField12.add(5043L, 190L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31L) + "'", long26 == (-31L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 599582131205043L + "'", long33 == 599582131205043L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(32);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(1L, periodType2, chronology3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType2);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology10 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology6, dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology6.halfdayOfDay();
        org.joda.time.DurationField durationField12 = gregorianChronology6.years();
        org.joda.time.Period period14 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType16 = period14.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField18 = new org.joda.time.field.ScaledDurationField(durationField12, durationFieldType16, (int) (byte) 100);
        int int19 = scaledDurationField18.getScalar();
        int int22 = scaledDurationField18.getValue(57600000L, 0L);
        org.joda.time.DurationFieldType durationFieldType23 = scaledDurationField18.getType();
        boolean boolean24 = period5.isSupported(durationFieldType23);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(zonedChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(durationFieldType16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("5049");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"5049/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period(0L, 10L, periodType2, chronology4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        boolean boolean7 = period5.isSupported(durationFieldType6);
        org.joda.time.Period period9 = period5.plusSeconds((int) (short) 100);
        org.joda.time.Period period11 = period5.plusMonths(1);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long16 = scaledDurationField12.getMillis((int) '#');
        long long19 = scaledDurationField12.subtract(0L, (int) ' ');
        long long21 = scaledDurationField12.getValueAsLong((long) '#');
        int int24 = scaledDurationField12.getDifference(182L, (long) (byte) 100);
        long long26 = scaledDurationField12.getValueAsLong((long) 1);
        long long29 = scaledDurationField12.getMillis((long) (byte) 1, (long) 7);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 110449332000000L + "'", long16 == 110449332000000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-100982246400000L) + "'", long19 == (-100982246400000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 3155760000000L + "'", long29 == 3155760000000L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        try {
            long long47 = unsupportedDateTimeField43.roundHalfFloor((-13L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.DurationField durationField6 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        long long29 = dividedDateTimeField26.getDifferenceAsLong(5043L, (long) 99);
        long long31 = dividedDateTimeField26.remainder(4010105L);
        int int32 = dividedDateTimeField26.getMinimumValue();
        java.util.Locale locale35 = null;
        try {
            long long36 = dividedDateTimeField26.set(99L, "org.joda.time.IllegalFieldValueException: Value \"ZonedChronology[GregorianChronology[UTC], UTC]\" for hi! is not supported", locale35);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"org.joda.time.IllegalFieldValueException: Value \"ZonedChronology[GregorianChronology[UTC], UTC]\" for hi! is not supported\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 4010105L + "'", long31 == 4010105L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test077");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
//        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
//        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
//        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
//        long long11 = cachedDateTimeZone7.convertLocalToUTC((long) (short) 1, true);
//        org.joda.time.LocalDateTime localDateTime12 = null;
//        boolean boolean13 = cachedDateTimeZone7.isLocalDateTimeGap(localDateTime12);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = cachedDateTimeZone7.getName(32L, locale15);
//        int int18 = cachedDateTimeZone7.getOffset(68412783L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
//        org.junit.Assert.assertNotNull(chronology3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Coordinated Universal Time" + "'", str16.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
        java.util.Locale locale45 = null;
        int int46 = remainderDateTimeField42.getMaximumTextLength(locale45);
        long long48 = remainderDateTimeField42.roundHalfEven((-210866774822000L));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField42, (int) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int52 = gregorianChronology51.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology51.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, 5044);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField55.getAsShortText(readablePartial56, 100, locale58);
        int int62 = offsetDateTimeField55.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int64 = gregorianChronology63.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology63.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 5044);
        java.lang.String str68 = offsetDateTimeField67.getName();
        long long70 = offsetDateTimeField67.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial71 = null;
        int[] intArray74 = new int[] { 100, (byte) -1 };
        int int75 = offsetDateTimeField67.getMaximumValue(readablePartial71, intArray74);
        org.joda.time.ReadablePartial readablePartial76 = null;
        java.util.Locale locale78 = null;
        java.lang.String str79 = offsetDateTimeField67.getAsShortText(readablePartial76, (int) '4', locale78);
        long long82 = offsetDateTimeField67.add(28800000L, (int) (byte) 100);
        long long85 = offsetDateTimeField67.addWrapField((long) 35, 35);
        org.joda.time.DateTimeFieldType dateTimeFieldType86 = offsetDateTimeField67.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField88 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField55, dateTimeFieldType86, 66);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField89 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField42, dateTimeFieldType86);
        long long92 = dividedDateTimeField89.getDifferenceAsLong((long) 32, (-2699186803200000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8640000000L + "'", long44 == 8640000000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-210866803200000L) + "'", long48 == (-210866803200000L));
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "100" + "'", str59.equals("100"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 99 + "'", int62 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "dayOfWeek" + "'", str68.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 5051 + "'", int75 == 5051);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "52" + "'", str79.equals("52"));
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 8668800000L + "'", long82 == 8668800000L);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 35L + "'", long85 == 35L);
        org.junit.Assert.assertNotNull(dateTimeFieldType86);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 312405L + "'", long92 == 312405L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) zonedChronology6);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int9 = gregorianChronology8.getMinimumDaysInFirstWeek();
        org.joda.time.Period period10 = org.joda.time.Period.ZERO;
        org.joda.time.Period period11 = period10.negated();
        org.joda.time.Period period16 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period18 = period16.plusMillis(1);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Duration duration20 = period18.toDurationTo(readableInstant19);
        org.joda.time.Period period21 = period10.minus((org.joda.time.ReadablePeriod) period18);
        long long24 = gregorianChronology8.add((org.joda.time.ReadablePeriod) period21, (-210858120000000L), 0);
        boolean boolean25 = zonedChronology6.equals((java.lang.Object) period21);
        org.joda.time.Chronology chronology26 = zonedChronology6.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-210858120000000L) + "'", long24 == (-210858120000000L));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("", (-5051), (-100), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -5051 for  must be in the range [-100,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        long long29 = dividedDateTimeField26.getDifferenceAsLong(12783L, (-210858048422000L));
        org.joda.time.DurationField durationField30 = dividedDateTimeField26.getDurationField();
        int int33 = dividedDateTimeField26.getDifference((long) (short) -1, 262860105L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 190L + "'", long29 == 190L);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test082");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
//        java.lang.String str6 = cachedDateTimeZone2.getName((-210866760000000L));
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone2.getUncachedZone();
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        java.lang.String str10 = dateTimeZone9.toString();
//        long long12 = dateTimeZone7.getMillisKeepLocal(dateTimeZone9, (long) (short) 10);
//        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 10L + "'", long12 == 10L);
//        org.junit.Assert.assertNotNull(iSOChronology13);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        long long15 = offsetDateTimeField4.add((long) (byte) 0, 0);
        org.joda.time.ReadablePartial readablePartial16 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int18 = gregorianChronology17.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField19 = gregorianChronology17.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField21 = new org.joda.time.field.OffsetDateTimeField(dateTimeField19, 5044);
        org.joda.time.DurationField durationField22 = offsetDateTimeField21.getLeapDurationField();
        int int23 = offsetDateTimeField21.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial24 = null;
        int[] intArray31 = new int[] { '4', (short) -1, (short) 1, 350, 5044 };
        int[] intArray33 = offsetDateTimeField21.addWrapPartial(readablePartial24, 10, intArray31, (int) (short) 0);
        int int34 = offsetDateTimeField4.getMaximumValue(readablePartial16, intArray31);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dateTimeField19);
        org.junit.Assert.assertNull(durationField22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5051 + "'", int23 == 5051);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 5051 + "'", int34 == 5051);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        boolean boolean46 = unsupportedDateTimeField43.isSupported();
        try {
            int int49 = unsupportedDateTimeField43.getDifference((long) 105, (-25245561600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 25245561600");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
        int int6 = cachedDateTimeZone2.getOffset((-210858120000000L));
        int int8 = cachedDateTimeZone2.getOffset(720000000L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone9, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.centuryOfEra();
        org.joda.time.DurationField durationField7 = gregorianChronology0.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test087");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
//        int int6 = cachedDateTimeZone2.getStandardOffset((-1104537599999L));
//        java.lang.String str8 = cachedDateTimeZone2.getShortName(3660105L);
//        boolean boolean9 = cachedDateTimeZone2.isFixed();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        long long29 = dividedDateTimeField26.getDifferenceAsLong(5043L, (long) 99);
        long long31 = dividedDateTimeField26.remainder(4010105L);
        int int32 = dividedDateTimeField26.getMinimumValue();
        long long34 = dividedDateTimeField26.roundCeiling((long) (short) -1);
        org.joda.time.ReadablePartial readablePartial35 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int38 = gregorianChronology37.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, 5044);
        org.joda.time.DurationField durationField42 = offsetDateTimeField41.getLeapDurationField();
        int int43 = offsetDateTimeField41.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial44 = null;
        int[] intArray51 = new int[] { '4', (short) -1, (short) 1, 350, 5044 };
        int[] intArray53 = offsetDateTimeField41.addWrapPartial(readablePartial44, 10, intArray51, (int) (short) 0);
        java.util.Locale locale55 = null;
        try {
            int[] intArray56 = dividedDateTimeField26.set(readablePartial35, (int) '#', intArray53, "5051", locale55);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5051 for dayOfWeek must be in the range [0,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 4010105L + "'", long31 == 4010105L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNull(durationField42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 5051 + "'", int43 == 5051);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray53);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 5044);
        org.joda.time.ReadablePartial readablePartial7 = null;
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField6.getAsShortText(readablePartial7, 100, locale9);
        int int13 = offsetDateTimeField6.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int15 = gregorianChronology14.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, 5044);
        org.joda.time.ReadablePartial readablePartial19 = null;
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField18.getAsShortText(readablePartial19, 100, locale21);
        int int25 = offsetDateTimeField18.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial26 = null;
        int int27 = offsetDateTimeField18.getMinimumValue(readablePartial26);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField30 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField6, dateTimeFieldType28, 7);
        boolean boolean31 = gregorianChronology0.equals((java.lang.Object) offsetDateTimeField30);
        boolean boolean32 = offsetDateTimeField30.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 99 + "'", int13 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "100" + "'", str22.equals("100"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 99 + "'", int25 == 99);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5045 + "'", int27 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey(0L);
        int int12 = fixedDateTimeZone4.getOffset((long) 35);
        java.util.TimeZone timeZone13 = fixedDateTimeZone4.toTimeZone();
        long long16 = fixedDateTimeZone4.convertLocalToUTC(43734067200000L, true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Millis" + "'", str10.equals("Millis"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43734067199900L + "'", long16 == 43734067199900L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfMinute();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        int int27 = dividedDateTimeField26.getMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int29 = gregorianChronology28.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 5044);
        org.joda.time.ReadablePartial readablePartial33 = null;
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField32.getAsShortText(readablePartial33, 100, locale35);
        int int39 = offsetDateTimeField32.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int41 = gregorianChronology40.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, 5044);
        org.joda.time.ReadablePartial readablePartial45 = null;
        java.util.Locale locale47 = null;
        java.lang.String str48 = offsetDateTimeField44.getAsShortText(readablePartial45, 100, locale47);
        int int51 = offsetDateTimeField44.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial52 = null;
        int int53 = offsetDateTimeField44.getMinimumValue(readablePartial52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = offsetDateTimeField44.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, dateTimeFieldType54, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology57.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology61 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology57, dateTimeZone60);
        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone64 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone63);
        java.lang.String str66 = cachedDateTimeZone64.getNameKey((long) (short) -1);
        int int68 = cachedDateTimeZone64.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology69 = gregorianChronology57.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone64);
        org.joda.time.DurationField durationField70 = gregorianChronology57.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField71 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType54, durationField70);
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = unsupportedDateTimeField71.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField73 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, dateTimeFieldType72);
        org.joda.time.DurationField durationField74 = dividedDateTimeField26.getDurationField();
        try {
            long long77 = dividedDateTimeField26.set((long) (short) 100, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for dayOfWeek must be in the range [0,2]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 99 + "'", int39 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "100" + "'", str48.equals("100"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 99 + "'", int51 == 99);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 5045 + "'", int53 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(gregorianChronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(zonedChronology61);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(cachedDateTimeZone64);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "UTC" + "'", str66.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(chronology69);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField71);
        org.junit.Assert.assertNotNull(dateTimeFieldType72);
        org.junit.Assert.assertNotNull(durationField74);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = zonedChronology4.year();
        long long10 = zonedChronology4.add(110449418400000L, 3660105L, (int) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 110449535523360L + "'", long10 == 110449535523360L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 5044);
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField13.getAsShortText(readablePartial14, 100, locale16);
        int int20 = offsetDateTimeField13.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int22 = gregorianChronology21.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 5044);
        org.joda.time.ReadablePartial readablePartial26 = null;
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField25.getAsShortText(readablePartial26, 100, locale28);
        int int32 = offsetDateTimeField25.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = offsetDateTimeField25.getMinimumValue(readablePartial33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField25.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType35, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField(dateTimeField8, dateTimeFieldType35, 99);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology40, (java.lang.Object) 4);
        org.joda.time.Chronology chronology43 = iSOChronology40.withUTC();
        org.joda.time.DurationField durationField44 = iSOChronology40.minutes();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone47 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone46);
        org.joda.time.Chronology chronology48 = iSOChronology40.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone47);
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology40.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int51 = gregorianChronology50.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology50.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 5044);
        org.joda.time.ReadablePartial readablePartial55 = null;
        java.util.Locale locale57 = null;
        java.lang.String str58 = offsetDateTimeField54.getAsShortText(readablePartial55, 100, locale57);
        int int61 = offsetDateTimeField54.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = offsetDateTimeField54.getMinimumValue(readablePartial62);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField54.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField66 = new org.joda.time.field.DividedDateTimeField(dateTimeField49, dateTimeFieldType64, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField39, dateTimeFieldType64, 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType64, 2);
        java.lang.Number number71 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException74 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, number71, (java.lang.Number) 2, (java.lang.Number) (-20985292800000L));
        org.joda.time.IllegalFieldValueException illegalFieldValueException76 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType64, "org.joda.time.IllegalInstantException: Coordinated Universal Time");
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 99 + "'", int20 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "100" + "'", str29.equals("100"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 99 + "'", int32 == 99);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 5045 + "'", int34 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(cachedDateTimeZone47);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "100" + "'", str58.equals("100"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 99 + "'", int61 == 99);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 5045 + "'", int63 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.DurationField durationField7 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.weekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField42 = new org.joda.time.field.DividedDateTimeField(dateTimeField11, dateTimeFieldType38, 99);
        long long45 = dividedDateTimeField42.getDifferenceAsLong(1560626720050L, 28800350L);
        org.joda.time.chrono.ISOChronology iSOChronology46 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean48 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology46, (java.lang.Object) 4);
        org.joda.time.Chronology chronology49 = iSOChronology46.withUTC();
        org.joda.time.DurationField durationField50 = iSOChronology46.minutes();
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone53 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone52);
        org.joda.time.Chronology chronology54 = iSOChronology46.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone53);
        org.joda.time.DateTimeField dateTimeField55 = iSOChronology46.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology56 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int57 = gregorianChronology56.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology56.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField58, 5044);
        org.joda.time.ReadablePartial readablePartial61 = null;
        java.util.Locale locale63 = null;
        java.lang.String str64 = offsetDateTimeField60.getAsShortText(readablePartial61, 100, locale63);
        int int67 = offsetDateTimeField60.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial68 = null;
        int int69 = offsetDateTimeField60.getMinimumValue(readablePartial68);
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = offsetDateTimeField60.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField72 = new org.joda.time.field.DividedDateTimeField(dateTimeField55, dateTimeFieldType70, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField73 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField42, dateTimeFieldType70);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField75 = new org.joda.time.field.DividedDateTimeField(dateTimeField8, dateTimeFieldType70, 101);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 182L + "'", long45 == 182L);
        org.junit.Assert.assertNotNull(iSOChronology46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(chronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(cachedDateTimeZone53);
        org.junit.Assert.assertNotNull(chronology54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(gregorianChronology56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "100" + "'", str64.equals("100"));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 99 + "'", int67 == 99);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 5045 + "'", int69 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundHalfFloor(8639999999L);
        long long46 = remainderDateTimeField42.roundFloor((long) (short) -1);
        org.joda.time.DurationField durationField47 = remainderDateTimeField42.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8640000000L + "'", long44 == 8640000000L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-86400000L) + "'", long46 == (-86400000L));
        org.junit.Assert.assertNotNull(durationField47);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = zonedChronology4.year();
        org.joda.time.Chronology chronology7 = zonedChronology4.withUTC();
        long long11 = zonedChronology4.add(10L, (-1104537599899L), (int) (byte) 1);
        org.joda.time.DateTimeField dateTimeField12 = zonedChronology4.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1104537599889L) + "'", long11 == (-1104537599889L));
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        long long29 = dividedDateTimeField26.getDifferenceAsLong(5043L, (long) 99);
        long long31 = dividedDateTimeField26.remainder(4010105L);
        org.joda.time.DurationField durationField32 = dividedDateTimeField26.getDurationField();
        boolean boolean33 = dividedDateTimeField26.isLenient();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 4010105L + "'", long31 == 4010105L);
        org.junit.Assert.assertNotNull(durationField32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.minusSeconds(350);
        org.joda.time.Period period5 = period3.withMinutes((int) '#');
        org.joda.time.Period period7 = period5.withDays((int) (byte) -1);
        org.joda.time.Duration duration8 = period5.toStandardDuration();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration8);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.joda.time.Period period1 = org.joda.time.Period.months(110);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.toString();
        org.joda.time.ReadablePartial readablePartial46 = null;
        org.joda.time.Period period49 = new org.joda.time.Period(0L, (long) (-1));
        int[] intArray50 = period49.getValues();
        try {
            int int51 = unsupportedDateTimeField43.getMaximumValue(readablePartial46, intArray50);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(intArray50);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial20 = null;
        int[] intArray21 = null;
        int int22 = offsetDateTimeField4.getMaximumValue(readablePartial20, intArray21);
        long long25 = offsetDateTimeField4.add(110449332000000L, 1);
        long long27 = offsetDateTimeField4.roundHalfCeiling((-86400008L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5051 + "'", int22 == 5051);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 110449418400000L + "'", long25 == 110449418400000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-86400000L) + "'", long27 == (-86400000L));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
        java.util.Locale locale45 = null;
        int int46 = remainderDateTimeField42.getMaximumTextLength(locale45);
        long long48 = remainderDateTimeField42.roundHalfEven((-210866774822000L));
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField42, (int) '#');
        org.joda.time.chrono.GregorianChronology gregorianChronology51 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int52 = gregorianChronology51.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField53 = gregorianChronology51.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField55 = new org.joda.time.field.OffsetDateTimeField(dateTimeField53, 5044);
        org.joda.time.ReadablePartial readablePartial56 = null;
        java.util.Locale locale58 = null;
        java.lang.String str59 = offsetDateTimeField55.getAsShortText(readablePartial56, 100, locale58);
        int int62 = offsetDateTimeField55.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology63 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int64 = gregorianChronology63.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField65 = gregorianChronology63.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, 5044);
        java.lang.String str68 = offsetDateTimeField67.getName();
        long long70 = offsetDateTimeField67.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial71 = null;
        int[] intArray74 = new int[] { 100, (byte) -1 };
        int int75 = offsetDateTimeField67.getMaximumValue(readablePartial71, intArray74);
        org.joda.time.ReadablePartial readablePartial76 = null;
        java.util.Locale locale78 = null;
        java.lang.String str79 = offsetDateTimeField67.getAsShortText(readablePartial76, (int) '4', locale78);
        long long82 = offsetDateTimeField67.add(28800000L, (int) (byte) 100);
        long long85 = offsetDateTimeField67.addWrapField((long) 35, 35);
        org.joda.time.DateTimeFieldType dateTimeFieldType86 = offsetDateTimeField67.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField88 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField55, dateTimeFieldType86, 66);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField89 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField42, dateTimeFieldType86);
        int int92 = remainderDateTimeField42.getDifference(3024000000L, (long) (-8));
        long long95 = remainderDateTimeField42.addWrapField(0L, (int) (byte) -1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8640000000L + "'", long44 == 8640000000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-210866803200000L) + "'", long48 == (-210866803200000L));
        org.junit.Assert.assertNotNull(gregorianChronology51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "100" + "'", str59.equals("100"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 99 + "'", int62 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "dayOfWeek" + "'", str68.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 0L + "'", long70 == 0L);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 5051 + "'", int75 == 5051);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "52" + "'", str79.equals("52"));
        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 8668800000L + "'", long82 == 8668800000L);
        org.junit.Assert.assertTrue("'" + long85 + "' != '" + 35L + "'", long85 == 35L);
        org.junit.Assert.assertNotNull(dateTimeFieldType86);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 35 + "'", int92 == 35);
        org.junit.Assert.assertTrue("'" + long95 + "' != '" + (-86400000L) + "'", long95 == (-86400000L));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        long long7 = iSOChronology0.add((long) (byte) 0, (long) 350, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int14 = fixedDateTimeZone12.getOffset(0L);
        int int16 = fixedDateTimeZone12.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str18 = fixedDateTimeZone12.getNameKey(0L);
        int int20 = fixedDateTimeZone12.getOffset((long) (byte) 10);
        org.joda.time.Chronology chronology21 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        long long23 = fixedDateTimeZone12.nextTransition((long) (-28800000));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Millis" + "'", str18.equals("Millis"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-28800000L) + "'", long23 == (-28800000L));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int13 = scaledDurationField12.getScalar();
        int int16 = scaledDurationField12.getValue(57600000L, 0L);
        int int19 = scaledDurationField12.getDifference((-2208988799900L), (-96L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DurationField durationField4 = gregorianChronology0.minutes();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfDay();
        java.lang.String str4 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[UTC]" + "'", str4.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        long long47 = unsupportedDateTimeField43.add(44700000L, 3024000000L);
        java.util.Locale locale49 = null;
        try {
            java.lang.String str50 = unsupportedDateTimeField43.getAsText((-1L), locale49);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3024044700000L + "'", long47 == 3024044700000L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.joda.time.Period period8 = new org.joda.time.Period(66, 0, 5045, 5048, 0, (int) (byte) 1, 35, 128100000);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        boolean boolean2 = period0.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period3 = period0.normalizedStandard();
        org.joda.time.Seconds seconds4 = period0.toStandardSeconds();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(seconds4);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.joda.time.Period period1 = org.joda.time.Period.months((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        int int12 = fixedDateTimeZone4.getOffsetFromLocal(4010105L);
        int int14 = fixedDateTimeZone4.getStandardOffset(57600032L);
        long long16 = fixedDateTimeZone4.convertUTCToLocal((-1104451199899L));
        java.util.TimeZone timeZone17 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-1104451199799L) + "'", long16 == (-1104451199799L));
        org.junit.Assert.assertNotNull(timeZone17);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((-210866774822000L), (long) 99);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-210866774821901L) + "'", long2 == (-210866774821901L));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) 'a');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder4 = dateTimeZoneBuilder0.setStandardOffset(0);
        java.io.DataOutput dataOutput6 = null;
        try {
            dateTimeZoneBuilder0.writeTo("P100WT-8H35S", dataOutput6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder4);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology43.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology43, dateTimeZone46);
        org.joda.time.DurationField durationField48 = gregorianChronology43.minutes();
        org.joda.time.DurationField durationField49 = gregorianChronology43.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField49);
        try {
            int int52 = unsupportedDateTimeField50.getLeapAmount(107293680000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(zonedChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long17 = scaledDurationField12.getDifferenceAsLong((-1104537599899L), 10L);
        long long20 = scaledDurationField12.getMillis(0L, (-210858120000000L));
        int int23 = scaledDurationField12.getDifference((-210863736000000L), (-210863736000000L));
        long long26 = scaledDurationField12.getMillis(5049L, 306102434400000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 15933105043200000L + "'", long26 == 15933105043200000L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weekyears();
        org.joda.time.DurationField durationField5 = gregorianChronology0.weekyears();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        long long36 = dividedDateTimeField33.getDifferenceAsLong(1560626720050L, 28800350L);
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean39 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology37, (java.lang.Object) 4);
        org.joda.time.Chronology chronology40 = iSOChronology37.withUTC();
        org.joda.time.DurationField durationField41 = iSOChronology37.minutes();
        org.joda.time.DateTimeZone dateTimeZone43 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone44 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone43);
        org.joda.time.Chronology chronology45 = iSOChronology37.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology37.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int48 = gregorianChronology47.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, 5044);
        org.joda.time.ReadablePartial readablePartial52 = null;
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField51.getAsShortText(readablePartial52, 100, locale54);
        int int58 = offsetDateTimeField51.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial59 = null;
        int int60 = offsetDateTimeField51.getMinimumValue(readablePartial59);
        org.joda.time.DateTimeFieldType dateTimeFieldType61 = offsetDateTimeField51.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField63 = new org.joda.time.field.DividedDateTimeField(dateTimeField46, dateTimeFieldType61, (int) '#');
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField64 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33, dateTimeFieldType61);
        org.joda.time.ReadablePartial readablePartial65 = null;
        java.util.Locale locale67 = null;
        java.lang.String str68 = dividedDateTimeField33.getAsShortText(readablePartial65, (-28800000), locale67);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 182L + "'", long36 == 182L);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(dateTimeZone43);
        org.junit.Assert.assertNotNull(cachedDateTimeZone44);
        org.junit.Assert.assertNotNull(chronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "100" + "'", str55.equals("100"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 99 + "'", int58 == 99);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 5045 + "'", int60 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType61);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "-28800000" + "'", str68.equals("-28800000"));
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test120");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
//        int int6 = cachedDateTimeZone2.getOffset((-210858120000000L));
//        int int8 = cachedDateTimeZone2.getOffset(720000000L);
//        int int10 = cachedDateTimeZone2.getStandardOffset((long) (short) 10);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = cachedDateTimeZone2.getShortName(0L, locale12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
//        java.lang.String str15 = gregorianChronology14.toString();
//        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.era();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "GregorianChronology[UTC]" + "'", str15.equals("GregorianChronology[UTC]"));
//        org.junit.Assert.assertNotNull(dateTimeField16);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long17 = scaledDurationField12.add((long) (byte) -1, 0);
        long long20 = scaledDurationField12.getValueAsLong(290736000350L, 35343820800000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("P8M-1DT-1M1.010S", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"P8M-1DT-1M1.010S/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        boolean boolean15 = scaledDurationField12.isPrecise();
        long long17 = scaledDurationField12.getMillis(0);
        boolean boolean18 = scaledDurationField12.isPrecise();
        int int21 = scaledDurationField12.getDifference(0L, 12783L);
        try {
            long long24 = scaledDurationField12.getMillis((-210858048410990L), 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -21085804841099000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.seconds(0);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period6 = new org.joda.time.Period((long) 1, 0L, periodType5);
        org.joda.time.Period period7 = period2.withPeriodType(periodType5);
        int int8 = period7.getMillis();
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period7.toDurationFrom(readableInstant9);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration10);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(duration10);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "LenientChronology[GregorianChronology[+35:35]]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        long long12 = offsetDateTimeField4.add(0L, (long) (byte) 100);
        long long14 = offsetDateTimeField4.remainder(12622780800000L);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int[] intArray19 = new int[] { 100, (short) 1 };
        try {
            int[] intArray21 = offsetDateTimeField4.set(readablePartial15, (int) (short) 0, intArray19, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for dayOfWeek must be in the range [5045,5051]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 8640000000L + "'", long12 == 8640000000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period4 = new org.joda.time.Period((long) 1, 0L, periodType3);
        org.joda.time.PeriodType periodType5 = periodType3.withSecondsRemoved();
        org.joda.time.PeriodType periodType6 = periodType5.withHoursRemoved();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) 0, periodType5);
        org.joda.time.Period period8 = period7.toPeriod();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Weeks", (java.lang.Number) 1L, (java.lang.Number) 0, (java.lang.Number) (-210858120000000L));
        illegalFieldValueException4.prependMessage("");
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        org.joda.time.Period period8 = new org.joda.time.Period((java.lang.Object) str7);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone5);
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology(chronology7);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int15 = fixedDateTimeZone13.getOffset(0L);
        int int17 = fixedDateTimeZone13.getOffsetFromLocal((long) (byte) 100);
        int int19 = fixedDateTimeZone13.getStandardOffset((long) (-1));
        java.lang.String str21 = fixedDateTimeZone13.getNameKey(35L);
        org.joda.time.chrono.ZonedChronology zonedChronology22 = org.joda.time.chrono.ZonedChronology.getInstance(chronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
        java.lang.String str24 = fixedDateTimeZone13.getName(107293680000000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Millis" + "'", str21.equals("Millis"));
        org.junit.Assert.assertNotNull(zonedChronology22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "+00:00:00.100" + "'", str24.equals("+00:00:00.100"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
        org.joda.time.Period period10 = new org.joda.time.Period(0L, 10L, periodType7, chronology9);
        long long13 = iSOChronology0.add((org.joda.time.ReadablePeriod) period10, (-62103152099990L), 0);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62103152099990L) + "'", long13 == (-62103152099990L));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        boolean boolean46 = unsupportedDateTimeField43.isLenient();
        org.joda.time.ReadablePartial readablePartial47 = null;
        try {
            int int48 = unsupportedDateTimeField43.getMinimumValue(readablePartial47);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("LenientChronology[GregorianChronology[+35:35]]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'LenientChronology[GregorianChronology[+35:35]]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        boolean boolean2 = period0.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period3 = period0.normalizedStandard();
        org.joda.time.Duration duration4 = period0.toStandardDuration();
        org.joda.time.Period period6 = org.joda.time.Period.millis(100);
        boolean boolean7 = org.joda.time.field.FieldUtils.equals((java.lang.Object) duration4, (java.lang.Object) period6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration4, readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration4, readableInstant10);
        org.joda.time.Period period13 = period11.minusMinutes((int) (short) 1);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology43.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology43, dateTimeZone46);
        org.joda.time.DurationField durationField48 = gregorianChronology43.minutes();
        org.joda.time.DurationField durationField49 = gregorianChronology43.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField49);
        int int53 = unsupportedDateTimeField50.getDifference((-210858048422000L), 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(zonedChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-6681) + "'", int53 == (-6681));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        long long15 = scaledDurationField12.getMillis((long) 66, (long) 5047);
        long long18 = scaledDurationField12.getDifferenceAsLong(1560626719950L, 43734096000000L);
        long long20 = scaledDurationField12.getMillis(5048);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 208275926400000L + "'", long15 == 208275926400000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-13L) + "'", long18 == (-13L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 15929949369600000L + "'", long20 == 15929949369600000L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        boolean boolean46 = unsupportedDateTimeField43.isSupported();
        java.lang.String str47 = unsupportedDateTimeField43.getName();
        java.util.Locale locale48 = null;
        try {
            int int49 = unsupportedDateTimeField43.getMaximumShortTextLength(locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "dayOfWeek" + "'", str47.equals("dayOfWeek"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        java.lang.String str17 = offsetDateTimeField16.getName();
        long long19 = offsetDateTimeField16.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial20 = null;
        int[] intArray23 = new int[] { 100, (byte) -1 };
        int int24 = offsetDateTimeField16.getMaximumValue(readablePartial20, intArray23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        java.util.Locale locale27 = null;
        java.lang.String str28 = offsetDateTimeField16.getAsShortText(readablePartial25, (int) '4', locale27);
        long long31 = offsetDateTimeField16.add(28800000L, (int) (byte) 100);
        long long34 = offsetDateTimeField16.addWrapField((long) 35, 35);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField16.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType35, 66);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) dividedDateTimeField37, (int) (short) 1, (int) '4', 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for dayOfWeek must be in the range [52,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "dayOfWeek" + "'", str17.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5051 + "'", int24 == 5051);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "52" + "'", str28.equals("52"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 8668800000L + "'", long31 == 8668800000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 35L + "'", long34 == 35L);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period6 = period4.plusMillis(1);
        org.joda.time.Period period8 = period6.plusMillis((-12783));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withDaysRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long17 = scaledDurationField12.getDifferenceAsLong((-1104537599899L), 10L);
        long long20 = scaledDurationField12.getMillis(0L, (-210858120000000L));
        int int23 = scaledDurationField12.getDifference((-210863736000000L), (-210863736000000L));
        long long26 = scaledDurationField12.getValueAsLong((-100973088000000L), 182L);
        int int29 = scaledDurationField12.getValue((-1085L), 208275926400000L);
        try {
            long long31 = scaledDurationField12.getMillis((-210866688422000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -21086668842200000 * 31556952000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31L) + "'", long26 == (-31L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        long long7 = iSOChronology0.add((long) (byte) 0, (long) 350, 0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int14 = fixedDateTimeZone12.getOffset(0L);
        int int16 = fixedDateTimeZone12.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str18 = fixedDateTimeZone12.getNameKey(0L);
        int int20 = fixedDateTimeZone12.getOffset((long) (byte) 10);
        org.joda.time.Chronology chronology21 = iSOChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone12);
        org.joda.time.DurationField durationField22 = iSOChronology0.eras();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Millis" + "'", str18.equals("Millis"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        boolean boolean15 = scaledDurationField12.isPrecise();
        int int16 = scaledDurationField12.getScalar();
        int int19 = scaledDurationField12.getValue((long) (short) 10, 57600000L);
        long long21 = scaledDurationField12.getValueAsLong((long) 64);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DurationField durationField6 = zonedChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology4.secondOfDay();
        org.joda.time.DurationField durationField8 = zonedChronology4.months();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology4.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology4.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) (-1.0d), "+00:00:00.100");
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 0.0f, (java.lang.Number) 101, (java.lang.Number) 52L);
        illegalFieldValueException40.prependMessage("dayOfWeek");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.DurationField durationField7 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.weekyear();
        org.joda.time.DurationField durationField9 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField10 = gregorianChronology0.millis();
        long long13 = durationField10.subtract(43734067199900L, (-1L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43734067199901L + "'", long13 == 43734067199901L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = zonedChronology4.year();
        org.joda.time.DateTimeField dateTimeField6 = zonedChronology4.clockhourOfHalfday();
        java.lang.String str7 = zonedChronology4.toString();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) zonedChronology4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str7.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Weeks", (java.lang.Number) 1L, (java.lang.Number) 0, (java.lang.Number) (-210858120000000L));
        illegalFieldValueException4.prependMessage("");
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Weeks" + "'", str7.equals("Weeks"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.year();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 5044);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField10.getAsShortText(readablePartial11, 100, locale13);
        int int17 = offsetDateTimeField10.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 5044);
        org.joda.time.ReadablePartial readablePartial23 = null;
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField22.getAsShortText(readablePartial23, 100, locale25);
        int int29 = offsetDateTimeField22.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial30 = null;
        int int31 = offsetDateTimeField22.getMinimumValue(readablePartial30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField22.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, dateTimeFieldType32, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType32, 99);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, (java.lang.Number) (-1.0d), "+00:00:00.100");
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField41 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType32, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100" + "'", str14.equals("100"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 99 + "'", int17 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "100" + "'", str26.equals("100"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 99 + "'", int29 == 99);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 5045 + "'", int31 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test149");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
//        int int6 = cachedDateTimeZone2.getOffset((-210858120000000L));
//        int int8 = cachedDateTimeZone2.getOffset(720000000L);
//        int int10 = cachedDateTimeZone2.getStandardOffset((long) (short) 10);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = cachedDateTimeZone2.getShortName(0L, locale12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone15 = cachedDateTimeZone2.getUncachedZone();
//        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
//        java.lang.String str18 = cachedDateTimeZone2.getName((-100973088000000L));
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
//        org.junit.Assert.assertNotNull(gregorianChronology14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(gregorianChronology16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Coordinated Universal Time" + "'", str18.equals("Coordinated Universal Time"));
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0);
        java.lang.String str2 = gregorianChronology1.toString();
        org.joda.time.DurationField durationField3 = gregorianChronology1.hours();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DurationField durationField6 = zonedChronology4.months();
        try {
            long long14 = zonedChronology4.getDateTimeMillis((int) (short) 100, (int) (short) -1, 5048, 350, 0, (int) (short) -1, 105);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 350 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 5044);
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField13.getAsShortText(readablePartial14, 100, locale16);
        int int20 = offsetDateTimeField13.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int22 = gregorianChronology21.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField23 = gregorianChronology21.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField25 = new org.joda.time.field.OffsetDateTimeField(dateTimeField23, 5044);
        org.joda.time.ReadablePartial readablePartial26 = null;
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField25.getAsShortText(readablePartial26, 100, locale28);
        int int32 = offsetDateTimeField25.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial33 = null;
        int int34 = offsetDateTimeField25.getMinimumValue(readablePartial33);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField25.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField13, dateTimeFieldType35, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField39 = new org.joda.time.field.DividedDateTimeField(dateTimeField8, dateTimeFieldType35, 99);
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean42 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology40, (java.lang.Object) 4);
        org.joda.time.Chronology chronology43 = iSOChronology40.withUTC();
        org.joda.time.DurationField durationField44 = iSOChronology40.minutes();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone47 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone46);
        org.joda.time.Chronology chronology48 = iSOChronology40.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone47);
        org.joda.time.DateTimeField dateTimeField49 = iSOChronology40.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology50 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int51 = gregorianChronology50.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField52 = gregorianChronology50.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField54 = new org.joda.time.field.OffsetDateTimeField(dateTimeField52, 5044);
        org.joda.time.ReadablePartial readablePartial55 = null;
        java.util.Locale locale57 = null;
        java.lang.String str58 = offsetDateTimeField54.getAsShortText(readablePartial55, 100, locale57);
        int int61 = offsetDateTimeField54.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial62 = null;
        int int63 = offsetDateTimeField54.getMinimumValue(readablePartial62);
        org.joda.time.DateTimeFieldType dateTimeFieldType64 = offsetDateTimeField54.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField66 = new org.joda.time.field.DividedDateTimeField(dateTimeField49, dateTimeFieldType64, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField39, dateTimeFieldType64, 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField70 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType64, 2);
        long long72 = remainderDateTimeField70.roundCeiling((long) (byte) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 99 + "'", int20 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "100" + "'", str29.equals("100"));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 99 + "'", int32 == 99);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 5045 + "'", int34 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(cachedDateTimeZone47);
        org.junit.Assert.assertNotNull(chronology48);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNotNull(gregorianChronology50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dateTimeField52);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "100" + "'", str58.equals("100"));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 99 + "'", int61 == 99);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 5045 + "'", int63 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType64);
        org.junit.Assert.assertTrue("'" + long72 + "' != '" + 10L + "'", long72 == 10L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        org.joda.time.DurationFieldType durationFieldType15 = scaledDurationField12.getType();
        long long18 = scaledDurationField12.getDifferenceAsLong(3024044700000L, (-62102995621990L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(durationFieldType15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 20L + "'", long18 == 20L);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test154");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getShortName(100L);
//        int int6 = cachedDateTimeZone2.getStandardOffset((long) (byte) 1);
//        java.lang.String str8 = cachedDateTimeZone2.getNameKey((long) (short) -1);
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) cachedDateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Period period2 = org.joda.time.Period.ZERO;
        org.joda.time.Period period3 = period2.negated();
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period10 = period8.plusMillis(1);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationTo(readableInstant11);
        org.joda.time.Period period13 = period2.minus((org.joda.time.ReadablePeriod) period10);
        long long16 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period13, (-210858120000000L), 0);
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-210858120000000L) + "'", long16 == (-210858120000000L));
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.joda.time.Period period1 = org.joda.time.Period.parse("PT35H10M350.010S");
        org.joda.time.Period period3 = period1.withMinutes((int) (byte) 1);
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Period period5 = org.joda.time.Period.ZERO;
        boolean boolean7 = period5.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period8 = period5.normalizedStandard();
        org.joda.time.Duration duration9 = period5.toStandardDuration();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant4, (org.joda.time.ReadableDuration) duration9, periodType10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant14);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period15.toDurationTo(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18);
        org.joda.time.Period period20 = period3.minus((org.joda.time.ReadablePeriod) period19);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.months();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.joda.time.Period period1 = org.joda.time.Period.years(0);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.joda.time.Period period4 = period1.withWeeks(4);
        org.joda.time.Period period6 = period1.plusSeconds((int) (byte) 10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        long long11 = cachedDateTimeZone7.convertLocalToUTC((long) (short) 1, true);
        org.joda.time.LocalDateTime localDateTime12 = null;
        boolean boolean13 = cachedDateTimeZone7.isLocalDateTimeGap(localDateTime12);
        int int15 = cachedDateTimeZone7.getStandardOffset((-2699186803200000L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1L + "'", long11 == 1L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        java.lang.String str46 = unsupportedDateTimeField43.toString();
        org.joda.time.DurationField durationField47 = unsupportedDateTimeField43.getLeapDurationField();
        org.joda.time.DurationField durationField48 = unsupportedDateTimeField43.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "UnsupportedDateTimeField" + "'", str46.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertNotNull(durationField48);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, (long) 100, chronology3);
        org.joda.time.Hours hours5 = period4.toStandardHours();
        org.joda.time.Period period7 = period4.withMonths(7);
        org.joda.time.Period period9 = period4.withYears((int) (short) 1);
        org.joda.time.Period period11 = period4.minusMinutes(64);
        int int12 = period4.getHours();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(hours5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        boolean boolean15 = scaledDurationField12.isPrecise();
        long long17 = scaledDurationField12.getMillis(0);
        long long20 = scaledDurationField12.getDifferenceAsLong(720000000L, (long) 'a');
        java.lang.String str21 = scaledDurationField12.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "hours" + "'", str21.equals("hours"));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.centuries();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.millis();
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(1L, periodType3, chronology4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        org.joda.time.Period period15 = new org.joda.time.Period(0, (int) ' ', 0, (int) (short) -1, 0, (int) (short) -1, (int) (short) 1, 10);
        org.joda.time.Period period17 = period15.withDays(0);
        org.joda.time.Period period19 = period15.withYears((int) (byte) 100);
        org.joda.time.DurationFieldType durationFieldType20 = null;
        boolean boolean21 = period15.isSupported(durationFieldType20);
        org.joda.time.Period period23 = period15.plusMonths((-1));
        org.joda.time.Period period25 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType27 = period25.getFieldType(4);
        org.joda.time.Period period29 = period15.withFieldAdded(durationFieldType27, 2);
        int int30 = periodType3.indexOf(durationFieldType27);
        org.joda.time.PeriodType periodType31 = periodType3.withMonthsRemoved();
        boolean boolean33 = periodType3.equals((java.lang.Object) 59);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(periodType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean21 = unsupportedDurationField20.isPrecise();
        java.lang.String str22 = unsupportedDurationField20.getName();
        java.lang.String str23 = unsupportedDurationField20.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hours" + "'", str22.equals("hours"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "UnsupportedDurationField[hours]" + "'", str23.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.ReadableInterval readableInterval3 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance(chronology4);
        org.joda.time.DateTimeField dateTimeField6 = lenientChronology5.hourOfHalfday();
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(readableInterval3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        java.lang.String str4 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GregorianChronology[UTC]" + "'", str4.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long21 = unsupportedDurationField20.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType22 = unsupportedDurationField20.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int24 = gregorianChronology23.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology26 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology23);
        java.lang.String str27 = lenientChronology26.toString();
        org.joda.time.DurationField durationField28 = lenientChronology26.weeks();
        int int29 = unsupportedDurationField20.compareTo(durationField28);
        boolean boolean30 = unsupportedDurationField20.isSupported();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(lenientChronology26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str27.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.joda.time.Period period4 = new org.joda.time.Period((int) '#', (int) (byte) 10, 35, 5048);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        int int27 = dividedDateTimeField26.getMaximumValue();
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int29 = gregorianChronology28.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField32 = new org.joda.time.field.OffsetDateTimeField(dateTimeField30, 5044);
        org.joda.time.ReadablePartial readablePartial33 = null;
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField32.getAsShortText(readablePartial33, 100, locale35);
        int int39 = offsetDateTimeField32.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int41 = gregorianChronology40.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology40.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField44 = new org.joda.time.field.OffsetDateTimeField(dateTimeField42, 5044);
        org.joda.time.ReadablePartial readablePartial45 = null;
        java.util.Locale locale47 = null;
        java.lang.String str48 = offsetDateTimeField44.getAsShortText(readablePartial45, 100, locale47);
        int int51 = offsetDateTimeField44.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial52 = null;
        int int53 = offsetDateTimeField44.getMinimumValue(readablePartial52);
        org.joda.time.DateTimeFieldType dateTimeFieldType54 = offsetDateTimeField44.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField56 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField32, dateTimeFieldType54, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology57 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField58 = gregorianChronology57.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology61 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology57, dateTimeZone60);
        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone64 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone63);
        java.lang.String str66 = cachedDateTimeZone64.getNameKey((long) (short) -1);
        int int68 = cachedDateTimeZone64.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology69 = gregorianChronology57.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone64);
        org.joda.time.DurationField durationField70 = gregorianChronology57.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField71 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType54, durationField70);
        org.joda.time.DateTimeFieldType dateTimeFieldType72 = unsupportedDateTimeField71.getType();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField73 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26, dateTimeFieldType72);
        java.util.Locale locale75 = null;
        java.lang.String str76 = dividedDateTimeField26.getAsText(0, locale75);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2 + "'", int27 == 2);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "100" + "'", str36.equals("100"));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 99 + "'", int39 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "100" + "'", str48.equals("100"));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 99 + "'", int51 == 99);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 5045 + "'", int53 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType54);
        org.junit.Assert.assertNotNull(gregorianChronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(zonedChronology61);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(cachedDateTimeZone64);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "UTC" + "'", str66.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(chronology69);
        org.junit.Assert.assertNotNull(durationField70);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField71);
        org.junit.Assert.assertNotNull(dateTimeFieldType72);
        org.junit.Assert.assertTrue("'" + str76 + "' != '" + "0" + "'", str76.equals("0"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        org.joda.time.Period period3 = period1.minusDays((int) (byte) 1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 1, 0L, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withSecondsRemoved();
        org.joda.time.PeriodType periodType9 = periodType8.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = periodType8.isSupported(durationFieldType10);
        org.joda.time.PeriodType periodType12 = periodType8.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period1, periodType12, (org.joda.time.Chronology) gregorianChronology13);
        try {
            org.joda.time.Period period16 = period14.plusSeconds((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test172");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
//        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
//        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology0.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 110);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(zonedChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(chronology7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "UTC" + "'", str10.equals("UTC"));
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.years();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology4, dateTimeZone7);
        org.joda.time.Chronology chronology9 = gregorianChronology2.withZone(dateTimeZone7);
        org.joda.time.Period period10 = org.joda.time.Period.ZERO;
        boolean boolean12 = period10.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period13 = period10.normalizedStandard();
        org.joda.time.Duration duration14 = period10.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.Period period16 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant15);
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        boolean boolean18 = org.joda.time.field.FieldUtils.equals((java.lang.Object) gregorianChronology2, (java.lang.Object) mutablePeriod17);
        org.joda.time.Period period19 = new org.joda.time.Period(0L, periodType1, (org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField4.getMaximumValue(readablePartial6);
        long long10 = offsetDateTimeField4.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 5044);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField17.getAsShortText(readablePartial18, 100, locale20);
        int int24 = offsetDateTimeField17.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int26 = gregorianChronology25.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 5044);
        org.joda.time.ReadablePartial readablePartial30 = null;
        java.util.Locale locale32 = null;
        java.lang.String str33 = offsetDateTimeField29.getAsShortText(readablePartial30, 100, locale32);
        int int36 = offsetDateTimeField29.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int int38 = offsetDateTimeField29.getMinimumValue(readablePartial37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, dateTimeFieldType39, 7);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType39, (-12783), 2, 106);
        long long48 = offsetDateTimeField4.addWrapField(8668703000L, (-19));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5051 + "'", int7 == 5051);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "100" + "'", str21.equals("100"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 99 + "'", int24 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 99 + "'", int36 == 99);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 5045 + "'", int38 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 8236703000L + "'", long48 == 8236703000L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone5);
        org.joda.time.Period period8 = org.joda.time.Period.ZERO;
        boolean boolean10 = period8.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period11 = period8.normalizedStandard();
        org.joda.time.Duration duration12 = period8.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant13);
        org.joda.time.MutablePeriod mutablePeriod15 = period14.toMutablePeriod();
        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) gregorianChronology0, (java.lang.Object) mutablePeriod15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Duration duration18 = mutablePeriod15.toDurationTo(readableInstant17);
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.Period period20 = org.joda.time.Period.ZERO;
        boolean boolean22 = period20.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period23 = period20.normalizedStandard();
        org.joda.time.Duration duration24 = period20.toStandardDuration();
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period26 = new org.joda.time.Period(readableInstant19, (org.joda.time.ReadableDuration) duration24, periodType25);
        org.joda.time.chrono.GregorianChronology gregorianChronology27 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField28 = gregorianChronology27.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology31 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology27, dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone34 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone33);
        java.lang.String str36 = cachedDateTimeZone34.getNameKey((long) (short) -1);
        int int38 = cachedDateTimeZone34.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology39 = gregorianChronology27.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone34);
        org.joda.time.Period period40 = new org.joda.time.Period((java.lang.Object) readableInstant17, periodType25, chronology39);
        org.joda.time.Period period42 = period40.withMinutes((int) 'a');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(mutablePeriod15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(duration18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(duration24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(gregorianChronology27);
        org.junit.Assert.assertNotNull(dateTimeField28);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(zonedChronology31);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(cachedDateTimeZone34);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "UTC" + "'", str36.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(period42);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 10);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException11 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) (-210858048422000L), "DateTimeField[dayOfWeek]");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withHoursRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test178");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
//        java.lang.String str6 = cachedDateTimeZone2.getName((-210866760000000L));
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone2.getUncachedZone();
//        long long11 = cachedDateTimeZone2.convertLocalToUTC((long) 5044, false, 43715883600000L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 5044L + "'", long11 == 5044L);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.joda.time.Period period3 = org.joda.time.Period.minutes(0);
        org.joda.time.Period period5 = period3.minusDays((int) (byte) 1);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period9 = new org.joda.time.Period((long) 1, 0L, periodType8);
        org.joda.time.PeriodType periodType10 = periodType8.withSecondsRemoved();
        org.joda.time.PeriodType periodType11 = periodType10.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType12 = null;
        boolean boolean13 = periodType10.isSupported(durationFieldType12);
        org.joda.time.PeriodType periodType14 = periodType10.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) period3, periodType14, (org.joda.time.Chronology) gregorianChronology15);
        java.lang.Object obj17 = null;
        boolean boolean18 = org.joda.time.field.FieldUtils.equals((java.lang.Object) gregorianChronology15, obj17);
        org.joda.time.Period period19 = new org.joda.time.Period((-62102995616991L), 57600032L, (org.joda.time.Chronology) gregorianChronology15);
        org.joda.time.Period period21 = period19.minusSeconds((int) (short) 100);
        try {
            org.joda.time.Weeks weeks22 = period19.toStandardWeeks();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Weeks as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology43.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology43, dateTimeZone46);
        org.joda.time.DurationField durationField48 = gregorianChronology43.minutes();
        org.joda.time.DurationField durationField49 = gregorianChronology43.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField49);
        org.joda.time.PeriodType periodType53 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period54 = new org.joda.time.Period((long) 1, 0L, periodType53);
        org.joda.time.PeriodType periodType55 = periodType53.withSecondsRemoved();
        org.joda.time.PeriodType periodType56 = periodType55.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType57 = null;
        boolean boolean58 = periodType55.isSupported(durationFieldType57);
        org.joda.time.PeriodType periodType59 = periodType55.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int61 = gregorianChronology60.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology60.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology63 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology60);
        org.joda.time.DateTimeField dateTimeField64 = lenientChronology63.era();
        org.joda.time.DurationField durationField65 = lenientChronology63.hours();
        boolean boolean66 = periodType59.equals((java.lang.Object) durationField65);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField65);
        try {
            int int69 = unsupportedDateTimeField67.getMinimumValue((long) 105);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(zonedChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(periodType59);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 4 + "'", int61 == 4);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(lenientChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period6 = period4.plusMillis(1);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period6.toDurationTo(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(1L, periodType11, chronology12);
        org.joda.time.PeriodType periodType14 = periodType11.withYearsRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType11);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.Duration duration17 = period15.toDurationFrom(readableInstant16);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration17, readableInstant18);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(duration17);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        long long48 = unsupportedDateTimeField43.getDifferenceAsLong((long) 10, (long) (short) -1);
        try {
            long long51 = unsupportedDateTimeField43.set(43734067199901L, (-12783));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withDaysRemoved();
        boolean boolean3 = periodType0.equals((java.lang.Object) 128100000);
        try {
            org.joda.time.DurationFieldType durationFieldType5 = periodType0.getFieldType((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.joda.time.Period period1 = org.joda.time.Period.years(0);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.joda.time.Period period4 = period1.withWeeks(4);
        int int5 = period1.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        boolean boolean2 = period0.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period3 = period0.normalizedStandard();
        org.joda.time.Duration duration4 = period0.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration4, readableInstant5);
        org.joda.time.MutablePeriod mutablePeriod7 = period6.toMutablePeriod();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period6.isSupported(durationFieldType8);
        org.joda.time.Period period11 = period6.withWeeks(350);
        int int12 = period11.getMillis();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(mutablePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = org.joda.time.Period.ZERO;
        boolean boolean5 = period3.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period6 = period3.normalizedStandard();
        org.joda.time.Duration duration7 = period3.toStandardDuration();
        org.joda.time.Period period9 = org.joda.time.Period.millis(100);
        boolean boolean10 = org.joda.time.field.FieldUtils.equals((java.lang.Object) duration7, (java.lang.Object) period9);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration7, periodType11);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.minutes();
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration7, periodType13);
        org.joda.time.Period period15 = new org.joda.time.Period(0L, periodType13);
        org.joda.time.PeriodType periodType16 = periodType13.withMinutesRemoved();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType16);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getLeapDurationField();
        long long47 = unsupportedDateTimeField43.add((-13L), 5051);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNull(durationField44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 5050987L + "'", long47 == 5050987L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundCeiling((long) 1);
        org.joda.time.DurationField durationField45 = remainderDateTimeField42.getRangeDurationField();
        long long47 = remainderDateTimeField42.roundCeiling(57600000L);
        long long50 = remainderDateTimeField42.getDifferenceAsLong((-210858120000000L), (-100982246400000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 86400000L + "'", long44 == 86400000L);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 86400000L + "'", long47 == 86400000L);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-1271711L) + "'", long50 == (-1271711L));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.joda.time.Period period5 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period7 = period5.plusMillis(1);
        org.joda.time.Period period9 = period7.withSeconds((int) (byte) 100);
        int int10 = period7.getWeeks();
        org.joda.time.Period period11 = period7.negated();
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearMonthDayTime();
        java.lang.String str13 = periodType12.getName();
        org.joda.time.Period period14 = period11.normalizedStandard(periodType12);
        org.joda.time.PeriodType periodType15 = periodType12.withMonthsRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology20 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology16, dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology16.halfdayOfDay();
        org.joda.time.DurationField durationField22 = gregorianChronology16.years();
        org.joda.time.Period period24 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType26 = period24.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField28 = new org.joda.time.field.ScaledDurationField(durationField22, durationFieldType26, (int) (byte) 100);
        boolean boolean29 = periodType15.isSupported(durationFieldType26);
        org.joda.time.Period period30 = new org.joda.time.Period((long) 100, periodType15);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "YearMonthDayTime" + "'", str13.equals("YearMonthDayTime"));
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(zonedChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DurationField durationField6 = zonedChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology4.secondOfDay();
        org.joda.time.DurationField durationField8 = zonedChronology4.months();
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology4.minuteOfDay();
        org.joda.time.DurationField durationField10 = zonedChronology4.centuries();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) zonedChronology6);
        org.joda.time.Duration duration8 = period7.toStandardDuration();
        java.lang.Class<?> wildcardClass9 = period7.getClass();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 10, (long) 100, periodType2);
        org.joda.time.Period period4 = period3.normalizedStandard();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology4.getZone();
        long long12 = zonedChronology4.getDateTimeMillis(10L, 1, (int) (short) 1, 0, 105);
        org.joda.time.Period period13 = org.joda.time.Period.ZERO;
        boolean boolean15 = period13.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period16 = period13.normalizedStandard();
        org.joda.time.Period period17 = org.joda.time.Period.ZERO;
        boolean boolean19 = period17.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period20 = period16.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = period17.indexOf(durationFieldType21);
        long long25 = zonedChronology4.add((org.joda.time.ReadablePeriod) period17, (-1L), 7);
        org.joda.time.chrono.LenientChronology lenientChronology26 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology4);
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology4.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField28 = zonedChronology4.minuteOfHour();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3660105L + "'", long12 == 3660105L);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertNotNull(lenientChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeField28);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        long long14 = offsetDateTimeField4.roundHalfEven(68412783L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 86400000L + "'", long14 == 86400000L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.util.Locale locale47 = null;
        try {
            long long48 = unsupportedDateTimeField43.set((long) 5049, "P8M-1DT-1M1.010S", locale47);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int13 = scaledDurationField12.getScalar();
        int int16 = scaledDurationField12.getValue(57600000L, 0L);
        long long19 = scaledDurationField12.getDifferenceAsLong(0L, (long) (-1));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("-1.0", "350", 350, (-12783));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-41700000L), (long) 10096);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -421003200000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Period period3 = org.joda.time.Period.ZERO;
        boolean boolean5 = period3.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period6 = period3.normalizedStandard();
        org.joda.time.Duration duration7 = period3.toStandardDuration();
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration7, periodType8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType12 = periodType11.withWeeksRemoved();
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant10, periodType11);
        java.lang.String str14 = periodType11.toString();
        org.joda.time.Period period15 = new org.joda.time.Period(1560626719950L, (-61273296421990L), periodType11);
        int int16 = period15.getHours();
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PeriodType[YearMonthDayTime]" + "'", str14.equals("PeriodType[YearMonthDayTime]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-11) + "'", int16 == (-11));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) -1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        int int4 = period3.getYears();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        int int1 = period0.getSeconds();
        int int2 = period0.getSeconds();
        org.joda.time.Seconds seconds3 = period0.toStandardSeconds();
        org.joda.time.Period period5 = period0.minusWeeks((int) (short) 100);
        int int6 = period0.getYears();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(seconds3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "ZonedChronology[GregorianChronology[UTC], UTC]");
        java.lang.Number number3 = illegalFieldValueException2.getUpperBound();
        java.lang.String str4 = illegalFieldValueException2.toString();
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"ZonedChronology[GregorianChronology[UTC], UTC]\" for hi! is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"ZonedChronology[GregorianChronology[UTC], UTC]\" for hi! is not supported"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int13 = scaledDurationField12.getScalar();
        int int16 = scaledDurationField12.getValue(57600000L, 0L);
        org.joda.time.DurationFieldType durationFieldType17 = scaledDurationField12.getType();
        try {
            long long20 = scaledDurationField12.getMillis(15933105043200000L, (long) (-12783));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1593310504320000000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(durationFieldType17);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Weeks", (java.lang.Number) 1L, (java.lang.Number) 0, (java.lang.Number) (-210858120000000L));
        illegalFieldValueException4.prependMessage("");
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.Number number8 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.String str9 = illegalFieldValueException4.toString();
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1L + "'", number8.equals(1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.joda.time.IllegalFieldValueException: : Value 1 for Weeks must be in the range [0,-210858120000000]" + "'", str9.equals("org.joda.time.IllegalFieldValueException: : Value 1 for Weeks must be in the range [0,-210858120000000]"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

//    @Test
//    public void test207() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test207");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
//        int int6 = cachedDateTimeZone2.getOffset((-210858120000000L));
//        int int8 = cachedDateTimeZone2.getOffset(720000000L);
//        int int10 = cachedDateTimeZone2.getStandardOffset((long) (short) 10);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = cachedDateTimeZone2.getShortName(0L, locale12);
//        long long15 = cachedDateTimeZone2.nextTransition(720000000L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "UTC" + "'", str13.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 720000000L + "'", long15 == 720000000L);
//    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = unsupportedDateTimeField43.getType();
        org.joda.time.DurationField durationField47 = unsupportedDateTimeField43.getRangeDurationField();
        try {
            boolean boolean49 = unsupportedDateTimeField43.isLeap(552960000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNull(durationField47);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long21 = unsupportedDurationField20.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType22 = unsupportedDurationField20.getType();
        try {
            long long25 = unsupportedDurationField20.add((-28108799968L), 5048);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType22);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period6 = period4.plusMillis(1);
        org.joda.time.Period period8 = period6.withSeconds((int) (byte) 100);
        int int9 = period6.getWeeks();
        org.joda.time.Period period11 = period6.withSeconds(105);
        org.joda.time.Period period13 = period6.plusHours(128100000);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
        long long21 = offsetDateTimeField4.roundCeiling(100L);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField4.getAsShortText((long) 5044, locale23);
        boolean boolean26 = offsetDateTimeField4.isLeap((-1104451199899L));
        java.util.Locale locale27 = null;
        int int28 = offsetDateTimeField4.getMaximumTextLength(locale27);
        java.lang.String str29 = offsetDateTimeField4.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 86400000L + "'", long21 == 86400000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "5048" + "'", str24.equals("5048"));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str29.equals("DateTimeField[dayOfWeek]"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        long long15 = scaledDurationField12.getMillis((long) 66, (long) 5047);
        long long18 = scaledDurationField12.getMillis(35, 22089866400000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 208275926400000L + "'", long15 == 208275926400000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 110449353600000L + "'", long18 == 110449353600000L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period6 = period4.plusMillis(1);
        org.joda.time.Period period8 = period6.withSeconds((int) (byte) 100);
        int int9 = period6.getWeeks();
        org.joda.time.Period period10 = period6.negated();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearMonthDayTime();
        java.lang.String str12 = periodType11.getName();
        org.joda.time.Period period13 = period10.normalizedStandard(periodType11);
        org.joda.time.PeriodType periodType14 = periodType11.withMonthsRemoved();
        org.joda.time.PeriodType periodType15 = periodType11.withMinutesRemoved();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "YearMonthDayTime" + "'", str12.equals("YearMonthDayTime"));
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.DateTimeField dateTimeField3 = lenientChronology2.centuryOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        boolean boolean46 = unsupportedDateTimeField43.isSupported();
        boolean boolean47 = unsupportedDateTimeField43.isSupported();
        org.joda.time.ReadablePartial readablePartial48 = null;
        java.util.Locale locale49 = null;
        try {
            java.lang.String str50 = unsupportedDateTimeField43.getAsShortText(readablePartial48, locale49);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        java.lang.String str2 = gregorianChronology0.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "GregorianChronology[UTC]" + "'", str2.equals("GregorianChronology[UTC]"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.joda.time.Period period8 = new org.joda.time.Period(0, 59, (-100), 5044, 350, 5051, (int) (byte) -1, 8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) '4');
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 1);
        int int2 = period1.getMinutes();
        org.joda.time.Minutes minutes3 = period1.toStandardMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(minutes3);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean21 = unsupportedDurationField20.isPrecise();
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, (long) 100, chronology25);
        int int27 = period26.size();
        org.joda.time.Period period28 = period26.negated();
        org.joda.time.Period period30 = period28.withWeeks((int) (short) 100);
        org.joda.time.Period period32 = period30.withMinutes(0);
        org.joda.time.Period period34 = period30.plusWeeks((int) (byte) 1);
        boolean boolean35 = unsupportedDurationField20.equals((java.lang.Object) period34);
        try {
            long long38 = unsupportedDurationField20.getDifferenceAsLong(28800182L, 32L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 8 + "'", int27 == 8);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField4.getMinimumValue(readablePartial12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField4.getType();
        java.lang.String str16 = offsetDateTimeField4.getAsText((long) '#');
        org.joda.time.ReadablePartial readablePartial17 = null;
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.Period period19 = org.joda.time.Period.ZERO;
        boolean boolean21 = period19.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period22 = period19.normalizedStandard();
        org.joda.time.Duration duration23 = period19.toStandardDuration();
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period25 = new org.joda.time.Period(readableInstant18, (org.joda.time.ReadableDuration) duration23, periodType24);
        org.joda.time.Period period26 = period25.toPeriod();
        int[] intArray27 = period25.getValues();
        int int28 = offsetDateTimeField4.getMaximumValue(readablePartial17, intArray27);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5045 + "'", int13 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "5048" + "'", str16.equals("5048"));
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5051 + "'", int28 == 5051);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        int int29 = dividedDateTimeField26.getDifference(0L, 182L);
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = dividedDateTimeField26.getType();
        java.lang.String str31 = dividedDateTimeField26.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str31.equals("DateTimeField[dayOfWeek]"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        int int1 = period0.getSeconds();
        int int2 = period0.getSeconds();
        org.joda.time.Seconds seconds3 = period0.toStandardSeconds();
        org.joda.time.Period period5 = period0.plusYears((int) (short) 10);
        org.joda.time.format.PeriodFormatter periodFormatter6 = null;
        java.lang.String str7 = period0.toString(periodFormatter6);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(seconds3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "PT0S" + "'", str7.equals("PT0S"));
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test225");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getShortName(100L);
//        int int6 = cachedDateTimeZone2.getStandardOffset((long) (byte) 1);
//        java.lang.String str8 = cachedDateTimeZone2.getNameKey((long) (-8));
//        long long10 = cachedDateTimeZone2.previousTransition((long) 110);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "UTC" + "'", str8.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 110L + "'", long10 == 110L);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField4.getMaximumTextLength(locale20);
        int int23 = offsetDateTimeField4.getMinimumValue(10L);
        int int25 = offsetDateTimeField4.get((long) 35);
        org.joda.time.ReadablePartial readablePartial26 = null;
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField4.getAsText(readablePartial26, 0, locale28);
        long long32 = offsetDateTimeField4.getDifferenceAsLong(0L, 110449535523360L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5048 + "'", int25 == 5048);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-1278351L) + "'", long32 == (-1278351L));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.joda.time.Period period2 = new org.joda.time.Period((-44838633599899L), 0L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.years();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str11 = cachedDateTimeZone9.getNameKey((long) (short) -1);
        int int13 = cachedDateTimeZone9.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology14 = gregorianChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DurationField durationField15 = gregorianChronology2.seconds();
        org.joda.time.Period period16 = new org.joda.time.Period(86405049L, periodType1, (org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField43.getRangeDurationField();
        int int48 = unsupportedDateTimeField43.getDifference((long) 10, (long) (short) 100);
        org.joda.time.ReadablePartial readablePartial49 = null;
        java.util.Locale locale50 = null;
        try {
            java.lang.String str51 = unsupportedDateTimeField43.getAsShortText(readablePartial49, locale50);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
        long long46 = remainderDateTimeField42.roundHalfFloor((long) (byte) 10);
        org.joda.time.ReadablePartial readablePartial47 = null;
        java.util.Locale locale49 = null;
        java.lang.String str50 = remainderDateTimeField42.getAsText(readablePartial47, (int) (short) 0, locale49);
        org.joda.time.ReadablePartial readablePartial51 = null;
        int[] intArray53 = null;
        try {
            int[] intArray55 = remainderDateTimeField42.addWrapPartial(readablePartial51, 13, intArray53, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8640000000L + "'", long44 == 8640000000L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "0" + "'", str50.equals("0"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long16 = scaledDurationField12.getMillis((int) '#');
        long long19 = scaledDurationField12.subtract(0L, (int) ' ');
        long long21 = scaledDurationField12.getValueAsLong((long) '#');
        int int24 = scaledDurationField12.getDifference(182L, (long) (byte) 100);
        java.lang.String str25 = scaledDurationField12.getName();
        long long28 = scaledDurationField12.getMillis(101, (-85L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 110449332000000L + "'", long16 == 110449332000000L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-100982246400000L) + "'", long19 == (-100982246400000L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "hours" + "'", str25.equals("hours"));
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 318725280000000L + "'", long28 == 318725280000000L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("DateTimeField[dayOfWeek]", "10");
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 10);
        long long10 = offsetDateTimeField4.add((long) (short) -1, (int) (short) 100);
        java.lang.String str12 = offsetDateTimeField4.getAsShortText(4010105L);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField4, (-11), 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -11 for dayOfWeek must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 8639999999L + "'", long10 == 8639999999L);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5048" + "'", str12.equals("5048"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long17 = scaledDurationField12.getDifferenceAsLong((-1104537599899L), 10L);
        long long20 = scaledDurationField12.getMillis(0L, (-210858120000000L));
        long long23 = scaledDurationField12.add(0L, (int) (byte) 0);
        int int25 = scaledDurationField12.getValue(43715883600000L);
        int int28 = scaledDurationField12.getDifference((long) (-11), (long) 101);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 13 + "'", int25 == 13);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        long long12 = offsetDateTimeField4.add(0L, (long) (byte) 100);
        long long14 = offsetDateTimeField4.remainder(12622780800000L);
        java.util.Locale locale15 = null;
        int int16 = offsetDateTimeField4.getMaximumTextLength(locale15);
        int int17 = offsetDateTimeField4.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 8640000000L + "'", long12 == 8640000000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5044 + "'", int17 == 5044);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType8 = periodType7.withWeeksRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean11 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology9, (java.lang.Object) 4);
        org.joda.time.Chronology chronology12 = iSOChronology9.withUTC();
        org.joda.time.DurationField durationField13 = iSOChronology9.minutes();
        boolean boolean14 = periodType8.equals((java.lang.Object) iSOChronology9);
        org.joda.time.PeriodType periodType15 = periodType8.withMonthsRemoved();
        boolean boolean16 = lenientChronology6.equals((java.lang.Object) periodType8);
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology17, (java.lang.Object) 4);
        org.joda.time.Chronology chronology20 = iSOChronology17.withUTC();
        org.joda.time.DurationField durationField21 = iSOChronology17.minutes();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone24 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone23);
        org.joda.time.Chronology chronology25 = iSOChronology17.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) 105, periodType8, (org.joda.time.Chronology) iSOChronology17);
        org.joda.time.PeriodType periodType27 = periodType8.withMonthsRemoved();
        org.joda.time.PeriodType periodType28 = periodType27.withWeeksRemoved();
        try {
            org.joda.time.Period period29 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(cachedDateTimeZone24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        org.joda.time.Period period3 = period1.minusDays((int) (byte) 1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 1, 0L, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withSecondsRemoved();
        org.joda.time.PeriodType periodType9 = periodType8.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = periodType8.isSupported(durationFieldType10);
        org.joda.time.PeriodType periodType12 = periodType8.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period1, periodType12, (org.joda.time.Chronology) gregorianChronology13);
        int int15 = period1.getMonths();
        org.joda.time.Period period17 = period1.withDays((-8));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundCeiling((long) 1);
        org.joda.time.DurationField durationField45 = remainderDateTimeField42.getRangeDurationField();
        java.lang.String str47 = remainderDateTimeField42.getAsShortText((-100L));
        java.lang.String str48 = remainderDateTimeField42.getName();
        long long50 = remainderDateTimeField42.remainder((-210866760000000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 86400000L + "'", long44 == 86400000L);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "47" + "'", str47.equals("47"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfWeek" + "'", str48.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 43200000L + "'", long50 == 43200000L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        int int17 = scaledDurationField12.getValue((-100L), (long) 64);
        try {
            long long19 = scaledDurationField12.getMillis((-44838633599899L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -4483863359989900 * 31556952000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField4.getMinimumValue(readablePartial12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField4.getType();
        java.lang.String str15 = offsetDateTimeField4.getName();
        java.lang.String str16 = offsetDateTimeField4.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5045 + "'", int13 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfWeek" + "'", str15.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "dayOfWeek" + "'", str16.equals("dayOfWeek"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology2.minutes();
        int int8 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Period period9 = new org.joda.time.Period(1L, 10L, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DurationField durationField11 = gregorianChronology2.halfdays();
        int int12 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long21 = unsupportedDurationField20.getUnitMillis();
        boolean boolean22 = unsupportedDurationField20.isSupported();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField4.getAsShortText((int) 'a', locale10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField4.getWrappedField();
        java.lang.String str14 = offsetDateTimeField4.getAsShortText((-4L));
        long long16 = offsetDateTimeField4.roundCeiling(691200032L);
        int int18 = offsetDateTimeField4.getLeapAmount((-86400000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97" + "'", str11.equals("97"));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "5047" + "'", str14.equals("5047"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 777600000L + "'", long16 == 777600000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long17 = scaledDurationField12.getDifferenceAsLong((-1104537599899L), 10L);
        long long20 = scaledDurationField12.getMillis(0L, (-210858120000000L));
        int int23 = scaledDurationField12.getDifference((-210863736000000L), (-210863736000000L));
        long long26 = scaledDurationField12.getValueAsLong((-100973088000000L), 182L);
        boolean boolean27 = scaledDurationField12.isSupported();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31L) + "'", long26 == (-31L));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        java.lang.String str46 = unsupportedDateTimeField43.getName();
        org.joda.time.DurationField durationField47 = unsupportedDateTimeField43.getRangeDurationField();
        try {
            long long49 = unsupportedDateTimeField43.roundHalfFloor((long) 99);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "dayOfWeek" + "'", str46.equals("dayOfWeek"));
        org.junit.Assert.assertNull(durationField47);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.toString();
        long long48 = unsupportedDateTimeField43.add(99L, 31556952000000L);
        try {
            long long51 = unsupportedDateTimeField43.set((long) (-28800000), "47");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 31556952000000099L + "'", long48 == 31556952000000099L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology4.getZone();
        long long12 = zonedChronology4.getDateTimeMillis(10L, 1, (int) (short) 1, 0, 105);
        java.lang.String str13 = zonedChronology4.toString();
        org.joda.time.DateTimeField dateTimeField14 = zonedChronology4.millisOfSecond();
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology17.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology17, dateTimeZone20);
        org.joda.time.DurationField durationField22 = gregorianChronology17.minutes();
        int int23 = gregorianChronology17.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology17.dayOfYear();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology17.yearOfCentury();
        org.joda.time.Period period26 = new org.joda.time.Period(100L, 0L, (org.joda.time.Chronology) gregorianChronology17);
        org.joda.time.Hours hours27 = period26.toStandardHours();
        boolean boolean28 = zonedChronology4.equals((java.lang.Object) period26);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3660105L + "'", long12 == 3660105L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str13.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(hours27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField4.getAsShortText((int) 'a', locale10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField4.getWrappedField();
        java.lang.String str14 = offsetDateTimeField4.getAsShortText((-4L));
        long long16 = offsetDateTimeField4.roundCeiling(691200032L);
        long long18 = offsetDateTimeField4.roundHalfCeiling((-210866803200000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97" + "'", str11.equals("97"));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "5047" + "'", str14.equals("5047"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 777600000L + "'", long16 == 777600000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-210866803200000L) + "'", long18 == (-210866803200000L));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology2.minutes();
        int int8 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Period period9 = new org.joda.time.Period(1L, 10L, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField10 = gregorianChronology2.hours();
        org.joda.time.Chronology chronology11 = gregorianChronology2.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        long long10 = cachedDateTimeZone7.nextTransition((-210866673600000L));
        long long12 = cachedDateTimeZone7.previousTransition((-62103152099990L));
        long long16 = cachedDateTimeZone7.convertLocalToUTC((long) 100, false, (long) (byte) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-210866673600000L) + "'", long10 == (-210866673600000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-62103152099990L) + "'", long12 == (-62103152099990L));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        java.lang.String str5 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ISOChronology[UTC]" + "'", str5.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DurationField durationField6 = zonedChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology4.secondOfDay();
        org.joda.time.Period period9 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period11 = period9.withSeconds((int) '#');
        org.joda.time.Period period13 = period9.withHours((int) ' ');
        org.joda.time.Period period15 = period9.minusDays((int) (byte) 10);
        org.joda.time.Seconds seconds16 = period9.toStandardSeconds();
        int[] intArray18 = zonedChronology4.get((org.joda.time.ReadablePeriod) period9, 28800350L);
        org.joda.time.DurationField durationField19 = zonedChronology4.minutes();
        try {
            long long27 = zonedChronology4.getDateTimeMillis(99, 5048, (int) ' ', 350, (int) (short) 10, 5045, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 350 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(seconds16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(durationField19);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean21 = unsupportedDurationField20.isPrecise();
        java.lang.String str22 = unsupportedDurationField20.getName();
        try {
            long long25 = unsupportedDurationField20.getValueAsLong(43734067199900L, 28800350L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hours" + "'", str22.equals("hours"));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 1, 0L, periodType4);
        org.joda.time.Period period6 = period1.withPeriodType(periodType4);
        org.joda.time.Period period8 = period1.withYears((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = org.joda.time.Period.ZERO;
        boolean boolean12 = period10.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period13 = period10.normalizedStandard();
        org.joda.time.Duration duration14 = period10.toStandardDuration();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant9, (org.joda.time.ReadableDuration) duration14, periodType15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant17);
        org.joda.time.Period period19 = period8.plus((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period21 = period18.plusMillis(4);
        org.joda.time.Period period23 = period21.minusMillis((int) (byte) 0);
        org.joda.time.Period period25 = org.joda.time.Period.seconds(0);
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period29 = new org.joda.time.Period((long) 1, 0L, periodType28);
        org.joda.time.Period period30 = period25.withPeriodType(periodType28);
        org.joda.time.Period period32 = period25.withYears((int) (byte) -1);
        org.joda.time.Period period34 = period32.withHours(99);
        org.joda.time.Period period35 = period21.plus((org.joda.time.ReadablePeriod) period32);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period35);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        org.joda.time.Period period4 = new org.joda.time.Period(5051, 66, (int) ' ', 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.DurationField durationField7 = gregorianChronology0.months();
        java.lang.Class<?> wildcardClass8 = durationField7.getClass();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.weeks();
        org.joda.time.PeriodType periodType7 = null;
        org.joda.time.ReadableInterval readableInterval8 = null;
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval8);
        org.joda.time.Period period10 = new org.joda.time.Period(0L, 10L, periodType7, chronology9);
        long long13 = iSOChronology0.add((org.joda.time.ReadablePeriod) period10, (-62103152099990L), 0);
        org.joda.time.chrono.LenientChronology lenientChronology14 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-62103152099990L) + "'", long13 == (-62103152099990L));
        org.junit.Assert.assertNotNull(lenientChronology14);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        boolean boolean46 = unsupportedDateTimeField43.isSupported();
        try {
            long long49 = unsupportedDateTimeField43.set((long) (-5051), "PT35H10M350.010S");
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DurationField durationField9 = iSOChronology0.seconds();
        java.lang.String str10 = iSOChronology0.toString();
        java.lang.String str11 = iSOChronology0.toString();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[UTC]" + "'", str10.equals("ISOChronology[UTC]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ISOChronology[UTC]" + "'", str11.equals("ISOChronology[UTC]"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.halfdayOfDay();
        long long11 = gregorianChronology2.add((long) 4, (long) ' ', 0);
        org.joda.time.Period period12 = new org.joda.time.Period((-25245561600000L), (-100982246822000L), (org.joda.time.Chronology) gregorianChronology2);
        try {
            org.joda.time.Period period14 = period12.multipliedBy((-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows an int: -2400 * -28800000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4L + "'", long11 == 4L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, (long) 100, chronology3);
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        org.joda.time.Minutes minutes7 = period4.toStandardMinutes();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(minutes7);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField4.getAsShortText((int) 'a', locale10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField4.getWrappedField();
        java.lang.String str14 = offsetDateTimeField4.getAsShortText((-4L));
        long long16 = offsetDateTimeField4.roundHalfFloor(110449332000000L);
        try {
            long long19 = offsetDateTimeField4.set((-28800000L), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [5045,5051]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97" + "'", str11.equals("97"));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "5047" + "'", str14.equals("5047"));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 110449353600000L + "'", long16 == 110449353600000L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, (long) 100, chronology3);
        org.joda.time.Hours hours5 = period4.toStandardHours();
        org.joda.time.Period period7 = period4.withMonths(7);
        org.joda.time.Period period9 = period4.minusDays(350);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(hours5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test265");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
//        java.lang.String str6 = cachedDateTimeZone2.getName((-210866760000000L));
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone2.getUncachedZone();
//        java.lang.Object obj8 = null;
//        boolean boolean9 = cachedDateTimeZone2.equals(obj8);
//        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone2.getUncachedZone();
//        org.joda.time.LocalDateTime localDateTime11 = null;
//        boolean boolean12 = cachedDateTimeZone2.isLocalDateTimeGap(localDateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) 'a');
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder2.addCutover(5044, 'a', 0, 350, (int) (short) 10, true, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        boolean boolean2 = period0.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period3 = period0.normalizedStandard();
        org.joda.time.Duration duration4 = period0.toStandardDuration();
        int int5 = period0.getMillis();
        int int6 = period0.getMillis();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType10 = periodType9.withWeeksRemoved();
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration5, readableInstant8, periodType9);
        long long12 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration5);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField6 = gregorianChronology0.centuries();
        org.joda.time.DurationField durationField7 = gregorianChronology0.months();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int15 = fixedDateTimeZone13.getOffset(0L);
        int int17 = fixedDateTimeZone13.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str19 = fixedDateTimeZone13.getNameKey(0L);
        boolean boolean20 = fixedDateTimeZone13.isFixed();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.Chronology chronology23 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        boolean boolean24 = fixedDateTimeZone13.isFixed();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Millis" + "'", str19.equals("Millis"));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        java.lang.String str4 = lenientChronology3.toString();
        org.joda.time.DurationField durationField5 = lenientChronology3.weeks();
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) lenientChronology3);
        org.joda.time.DateTimeField dateTimeField7 = lenientChronology6.minuteOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str4.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(lenientChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField4.getMaximumTextLength(locale20);
        int int23 = offsetDateTimeField4.getMinimumValue(10L);
        int int24 = offsetDateTimeField4.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5044 + "'", int24 == 5044);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        org.joda.time.Chronology chronology0 = null;
        try {
            org.joda.time.chrono.LenientChronology lenientChronology1 = org.joda.time.chrono.LenientChronology.getInstance(chronology0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        java.lang.String str46 = unsupportedDateTimeField43.getName();
        int int49 = unsupportedDateTimeField43.getDifference((-86400000L), 0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "dayOfWeek" + "'", str46.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-86400) + "'", int49 == (-86400));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        long long8 = offsetDateTimeField4.addWrapField(43734067199901L, (int) (short) 1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 43734153599901L + "'", long8 == 43734153599901L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        boolean boolean2 = period0.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period3 = period0.normalizedStandard();
        org.joda.time.Duration duration4 = period0.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration4, readableInstant5);
        org.joda.time.MutablePeriod mutablePeriod7 = period6.toMutablePeriod();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period6.isSupported(durationFieldType8);
        org.joda.time.Period period11 = period6.minusMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = org.joda.time.Period.ZERO;
        boolean boolean15 = period13.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period16 = period13.normalizedStandard();
        org.joda.time.Duration duration17 = period13.toStandardDuration();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant12, (org.joda.time.ReadableDuration) duration17, periodType18);
        org.joda.time.Period period21 = period19.minusSeconds(1);
        int int22 = period19.getHours();
        org.joda.time.Period period24 = period19.withMinutes((int) (short) 10);
        org.joda.time.Period period26 = period24.plusMonths(7);
        org.joda.time.Period period28 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType30 = period28.getFieldType(4);
        int int31 = period26.get(durationFieldType30);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField32 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType30);
        org.joda.time.Period period34 = period6.withFieldAdded(durationFieldType30, 105);
        org.joda.time.Period period36 = period6.plusDays(100);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(mutablePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period36);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        boolean boolean46 = unsupportedDateTimeField43.isSupported();
        java.lang.String str47 = unsupportedDateTimeField43.getName();
        org.joda.time.ReadablePartial readablePartial48 = null;
        try {
            int int49 = unsupportedDateTimeField43.getMaximumValue(readablePartial48);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "dayOfWeek" + "'", str47.equals("dayOfWeek"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
        long long46 = remainderDateTimeField42.roundHalfFloor((long) (byte) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int48 = gregorianChronology47.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, 5044);
        org.joda.time.DurationField durationField52 = offsetDateTimeField51.getLeapDurationField();
        int int53 = offsetDateTimeField51.getMaximumValue();
        long long56 = offsetDateTimeField51.add((-1104537599899L), 1L);
        int int58 = offsetDateTimeField51.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology59 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int60 = gregorianChronology59.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology59.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField63 = new org.joda.time.field.OffsetDateTimeField(dateTimeField61, 5044);
        org.joda.time.ReadablePartial readablePartial64 = null;
        java.util.Locale locale66 = null;
        java.lang.String str67 = offsetDateTimeField63.getAsShortText(readablePartial64, 100, locale66);
        int int70 = offsetDateTimeField63.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology71 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int72 = gregorianChronology71.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField73 = gregorianChronology71.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField75 = new org.joda.time.field.OffsetDateTimeField(dateTimeField73, 5044);
        org.joda.time.ReadablePartial readablePartial76 = null;
        java.util.Locale locale78 = null;
        java.lang.String str79 = offsetDateTimeField75.getAsShortText(readablePartial76, 100, locale78);
        int int82 = offsetDateTimeField75.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial83 = null;
        int int84 = offsetDateTimeField75.getMinimumValue(readablePartial83);
        org.joda.time.DateTimeFieldType dateTimeFieldType85 = offsetDateTimeField75.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField87 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField63, dateTimeFieldType85, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField89 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField51, dateTimeFieldType85, (int) (byte) 100);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField90 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField42, dateTimeFieldType85);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8640000000L + "'", long44 == 8640000000L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(dateTimeField49);
        org.junit.Assert.assertNull(durationField52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 5051 + "'", int53 == 5051);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + (-1104451199899L) + "'", long56 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 4 + "'", int60 == 4);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "100" + "'", str67.equals("100"));
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 99 + "'", int70 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 4 + "'", int72 == 4);
        org.junit.Assert.assertNotNull(dateTimeField73);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "100" + "'", str79.equals("100"));
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 99 + "'", int82 == 99);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 5045 + "'", int84 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType85);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("PeriodType[Days]");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int3 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 5044);
        org.joda.time.ReadablePartial readablePartial7 = null;
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField6.getAsShortText(readablePartial7, 100, locale9);
        int int13 = offsetDateTimeField6.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int int15 = offsetDateTimeField6.getMinimumValue(readablePartial14);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField6.getType();
        java.lang.String str17 = offsetDateTimeField6.getName();
        jodaTimePermission1.checkGuard((java.lang.Object) offsetDateTimeField6);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "100" + "'", str10.equals("100"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 99 + "'", int13 == 99);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 5045 + "'", int15 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "dayOfWeek" + "'", str17.equals("dayOfWeek"));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-2208988799900L));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
        java.util.Locale locale45 = null;
        int int46 = remainderDateTimeField42.getMaximumTextLength(locale45);
        long long48 = remainderDateTimeField42.roundHalfEven((-210866774822000L));
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int50 = gregorianChronology49.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology49.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, 5044);
        org.joda.time.ReadablePartial readablePartial54 = null;
        java.util.Locale locale56 = null;
        java.lang.String str57 = offsetDateTimeField53.getAsShortText(readablePartial54, 100, locale56);
        int int60 = offsetDateTimeField53.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology61 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int62 = gregorianChronology61.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField63 = gregorianChronology61.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, 5044);
        org.joda.time.ReadablePartial readablePartial66 = null;
        java.util.Locale locale68 = null;
        java.lang.String str69 = offsetDateTimeField65.getAsShortText(readablePartial66, 100, locale68);
        int int72 = offsetDateTimeField65.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial73 = null;
        int int74 = offsetDateTimeField65.getMinimumValue(readablePartial73);
        org.joda.time.DateTimeFieldType dateTimeFieldType75 = offsetDateTimeField65.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField77 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField53, dateTimeFieldType75, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology78 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField79 = gregorianChronology78.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone81 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology82 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology78, dateTimeZone81);
        org.joda.time.DateTimeZone dateTimeZone84 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone85 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone84);
        java.lang.String str87 = cachedDateTimeZone85.getNameKey((long) (short) -1);
        int int89 = cachedDateTimeZone85.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology90 = gregorianChronology78.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone85);
        org.joda.time.DurationField durationField91 = gregorianChronology78.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField92 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType75, durationField91);
        org.joda.time.DateTimeFieldType dateTimeFieldType93 = unsupportedDateTimeField92.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField94 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField42, dateTimeFieldType93);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8640000000L + "'", long44 == 8640000000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-210866803200000L) + "'", long48 == (-210866803200000L));
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "100" + "'", str57.equals("100"));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 99 + "'", int60 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "100" + "'", str69.equals("100"));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 99 + "'", int72 == 99);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 5045 + "'", int74 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType75);
        org.junit.Assert.assertNotNull(gregorianChronology78);
        org.junit.Assert.assertNotNull(dateTimeField79);
        org.junit.Assert.assertNotNull(dateTimeZone81);
        org.junit.Assert.assertNotNull(zonedChronology82);
        org.junit.Assert.assertNotNull(dateTimeZone84);
        org.junit.Assert.assertNotNull(cachedDateTimeZone85);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "UTC" + "'", str87.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertNotNull(chronology90);
        org.junit.Assert.assertNotNull(durationField91);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField92);
        org.junit.Assert.assertNotNull(dateTimeFieldType93);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long8 = offsetDateTimeField4.getDifferenceAsLong((long) (short) -1, (-1104537599999L));
        long long11 = offsetDateTimeField4.add((long) 7, 35);
        java.lang.String str13 = offsetDateTimeField4.getAsText(1563650720050L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12783L + "'", long8 == 12783L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 3024000007L + "'", long11 == 3024000007L);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "5050" + "'", str13.equals("5050"));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField4.getMaximumTextLength(locale20);
        int int23 = offsetDateTimeField4.getMinimumValue(10L);
        long long26 = offsetDateTimeField4.addWrapField(35L, (int) (short) 100);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 172800035L + "'", long26 == 172800035L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        org.joda.time.DurationField durationField27 = dividedDateTimeField26.getDurationField();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26);
        long long31 = dividedDateTimeField26.add((-210858048422000L), 0L);
        long long33 = dividedDateTimeField26.roundFloor((-1271711L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-210858048422000L) + "'", long31 == (-210858048422000L));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-1104537600000L) + "'", long33 == (-1104537600000L));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        java.lang.String str46 = unsupportedDateTimeField43.toString();
        try {
            int int48 = unsupportedDateTimeField43.get((-1104451199899L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "UnsupportedDateTimeField" + "'", str46.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField2 = gregorianChronology0.months();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) 'a');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("52", (int) 'a', 105, (int) (short) 10, '#', 0, (int) (short) -1, (int) (short) -1, false, 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder13.setFixedSavings("UTC", 10);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder16.setStandardOffset((-8));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder18);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField6 = gregorianChronology0.centuries();
        org.joda.time.DurationField durationField7 = gregorianChronology0.months();
        org.joda.time.DurationField durationField8 = gregorianChronology0.seconds();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int16 = fixedDateTimeZone14.getOffset(0L);
        int int18 = fixedDateTimeZone14.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str20 = fixedDateTimeZone14.getNameKey(0L);
        boolean boolean21 = fixedDateTimeZone14.isFixed();
        int int23 = fixedDateTimeZone14.getStandardOffset((long) (byte) 1);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        java.util.TimeZone timeZone25 = fixedDateTimeZone14.toTimeZone();
        org.joda.time.Chronology chronology26 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone14);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Millis" + "'", str20.equals("Millis"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 10 + "'", int23 == 10);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        int int17 = scaledDurationField12.getValue((-100L), (long) 64);
        int int20 = scaledDurationField12.getValue(0L, 4999L);
        org.joda.time.chrono.GregorianChronology gregorianChronology21 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology21.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology25 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology21, dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology21.halfdayOfDay();
        org.joda.time.DurationField durationField27 = gregorianChronology21.years();
        org.joda.time.Period period29 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType31 = period29.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField27, durationFieldType31, (int) (byte) 100);
        int int35 = scaledDurationField33.getValue(4999L);
        long long38 = scaledDurationField33.getDifferenceAsLong((-1104537599899L), 10L);
        long long41 = scaledDurationField33.getMillis(0L, (-210858120000000L));
        int int42 = scaledDurationField12.compareTo((org.joda.time.DurationField) scaledDurationField33);
        long long44 = scaledDurationField33.getMillis((long) 5044);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(zonedChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(durationFieldType31);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 15917326588800000L + "'", long44 == 15917326588800000L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, (long) 100, chronology3);
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        org.joda.time.Period period8 = period6.withWeeks((int) (short) 100);
        org.joda.time.Period period10 = period8.withMinutes(0);
        int int11 = period8.getYears();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long17 = scaledDurationField12.add((long) (byte) -1, 0);
        java.lang.String str18 = scaledDurationField12.toString();
        int int21 = scaledDurationField12.getValue((long) (byte) 0, (-210866803200000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DurationField[hours]" + "'", str18.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.Chronology chronology7 = gregorianChronology0.withZone(dateTimeZone5);
        org.joda.time.Period period8 = org.joda.time.Period.ZERO;
        boolean boolean10 = period8.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period11 = period8.normalizedStandard();
        org.joda.time.Duration duration12 = period8.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration12, readableInstant13);
        org.joda.time.MutablePeriod mutablePeriod15 = period14.toMutablePeriod();
        org.joda.time.DurationFieldType durationFieldType16 = null;
        boolean boolean17 = period14.isSupported(durationFieldType16);
        int[] intArray20 = gregorianChronology0.get((org.joda.time.ReadablePeriod) period14, (-1104451199899L), (long) 99);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(mutablePeriod15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(dateTimeField21);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "PeriodType[Millis]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField43.getDurationField();
        boolean boolean46 = unsupportedDateTimeField43.isLenient();
        java.util.Locale locale48 = null;
        try {
            java.lang.String str49 = unsupportedDateTimeField43.getAsText(128100000, locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        org.joda.time.Period period2 = new org.joda.time.Period((long) '#', (long) '4');
        org.joda.time.Period period4 = period2.withMonths(101);
        org.joda.time.Period period6 = period2.minusYears(10);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = unsupportedDateTimeField43.getType();
        org.joda.time.DurationField durationField47 = unsupportedDateTimeField43.getRangeDurationField();
        org.joda.time.ReadablePartial readablePartial48 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField50 = gregorianChronology49.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone52 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology53 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology49, dateTimeZone52);
        org.joda.time.DateTimeField dateTimeField54 = gregorianChronology49.halfdayOfDay();
        org.joda.time.DurationField durationField55 = gregorianChronology49.years();
        org.joda.time.Chronology chronology56 = gregorianChronology49.withUTC();
        org.joda.time.DateTimeField dateTimeField57 = gregorianChronology49.secondOfMinute();
        org.joda.time.DurationField durationField58 = gregorianChronology49.weeks();
        org.joda.time.Chronology chronology59 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology49);
        org.joda.time.Period period68 = new org.joda.time.Period(0, (int) ' ', 0, (int) (short) -1, 0, (int) (short) -1, (int) (short) 1, 10);
        org.joda.time.Period period70 = period68.withMonths(8);
        int[] intArray72 = gregorianChronology49.get((org.joda.time.ReadablePeriod) period68, 3024000007L);
        try {
            int int73 = unsupportedDateTimeField43.getMinimumValue(readablePartial48, intArray72);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertNotNull(dateTimeZone52);
        org.junit.Assert.assertNotNull(zonedChronology53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(durationField55);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertNotNull(dateTimeField57);
        org.junit.Assert.assertNotNull(durationField58);
        org.junit.Assert.assertNotNull(chronology59);
        org.junit.Assert.assertNotNull(period70);
        org.junit.Assert.assertNotNull(intArray72);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
        org.joda.time.ReadablePartial readablePartial20 = null;
        int[] intArray21 = null;
        int int22 = offsetDateTimeField4.getMaximumValue(readablePartial20, intArray21);
        long long25 = offsetDateTimeField4.add(110449332000000L, 1);
        int int27 = offsetDateTimeField4.getMinimumValue((long) 66);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5051 + "'", int22 == 5051);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 110449418400000L + "'", long25 == 110449418400000L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5045 + "'", int27 == 5045);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        org.joda.time.DateTimeFieldType dateTimeFieldType34 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField38 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType34, 5045, (-19), 5049);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadablePartial readablePartial10 = null;
        try {
            int[] intArray12 = iSOChronology0.get(readablePartial10, 22089866400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone9 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone8);
        java.lang.String str11 = cachedDateTimeZone9.getNameKey((long) (short) -1);
        int int13 = cachedDateTimeZone9.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology14 = gregorianChronology2.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone9);
        org.joda.time.DurationField durationField15 = gregorianChronology2.seconds();
        org.joda.time.Period period16 = new org.joda.time.Period(20L, 1L, (org.joda.time.Chronology) gregorianChronology2);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(cachedDateTimeZone9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UTC" + "'", str11.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long21 = unsupportedDurationField20.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType22 = unsupportedDurationField20.getType();
        try {
            long long24 = unsupportedDurationField20.getValueAsLong((-1104451199799L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType22);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(0L, (long) (byte) 100, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "5047", "LenientChronology[GregorianChronology[America/Los_Angeles]]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "DateTimeField[dayOfWeek]", "Millis");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        java.util.Locale locale10 = null;
        java.lang.String str13 = defaultNameProvider0.getShortName(locale10, "ISOChronology[YearMonthDayTime]", "America/Los_Angeles");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Period period5 = period3.multipliedBy(10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(8, 'a', (int) (byte) 10, (int) (short) 100, 99, true, (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder8.setFixedSavings("5049", 2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder11);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology43 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField44 = gregorianChronology43.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology47 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology43, dateTimeZone46);
        org.joda.time.DurationField durationField48 = gregorianChronology43.minutes();
        org.joda.time.DurationField durationField49 = gregorianChronology43.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField50 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField49);
        org.joda.time.PeriodType periodType53 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period54 = new org.joda.time.Period((long) 1, 0L, periodType53);
        org.joda.time.PeriodType periodType55 = periodType53.withSecondsRemoved();
        org.joda.time.PeriodType periodType56 = periodType55.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType57 = null;
        boolean boolean58 = periodType55.isSupported(durationFieldType57);
        org.joda.time.PeriodType periodType59 = periodType55.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int61 = gregorianChronology60.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology60.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology63 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology60);
        org.joda.time.DateTimeField dateTimeField64 = lenientChronology63.era();
        org.joda.time.DurationField durationField65 = lenientChronology63.hours();
        boolean boolean66 = periodType59.equals((java.lang.Object) durationField65);
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField67 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType38, durationField65);
        java.lang.String str68 = unsupportedDateTimeField67.getName();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(gregorianChronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(zonedChronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(durationField49);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField50);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(periodType59);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 4 + "'", int61 == 4);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(lenientChronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(durationField65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "dayOfWeek" + "'", str68.equals("dayOfWeek"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        org.joda.time.Period period3 = period1.minusDays((int) (byte) 1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 1, 0L, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withSecondsRemoved();
        org.joda.time.PeriodType periodType9 = periodType8.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = periodType8.isSupported(durationFieldType10);
        org.joda.time.PeriodType periodType12 = periodType8.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period1, periodType12, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DurationField durationField15 = gregorianChronology13.millis();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.dayOfYear();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology13.dayOfWeek();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) 'a');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("52", (int) 'a', 105, (int) (short) 10, '#', 0, (int) (short) -1, (int) (short) -1, false, 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder2.setFixedSavings("PT35H10M350.010S", 1);
        java.io.OutputStream outputStream18 = null;
        try {
            dateTimeZoneBuilder16.writeTo("ISOChronology[UTC]", outputStream18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        long long7 = offsetDateTimeField4.roundHalfFloor(1L);
        long long10 = offsetDateTimeField4.addWrapField((long) (short) 0, 8);
        boolean boolean12 = offsetDateTimeField4.isLeap((long) 99);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 86400000L + "'", long10 == 86400000L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withHoursRemoved();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long8 = offsetDateTimeField4.getDifferenceAsLong((long) (short) -1, (-1104537599999L));
        long long10 = offsetDateTimeField4.remainder(32L);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, 10);
        long long15 = offsetDateTimeField4.addWrapField(5049L, (int) (byte) 1);
        int int16 = offsetDateTimeField4.getOffset();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 12783L + "'", long8 == 12783L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 32L + "'", long10 == 32L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 86405049L + "'", long15 == 86405049L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 5044 + "'", int16 == 5044);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        boolean boolean2 = period0.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period3 = period0.normalizedStandard();
        org.joda.time.Duration duration4 = period0.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration4, readableInstant5);
        org.joda.time.MutablePeriod mutablePeriod7 = period6.toMutablePeriod();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period6.isSupported(durationFieldType8);
        org.joda.time.Period period11 = period6.minusMillis((int) (short) 100);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = org.joda.time.Period.ZERO;
        boolean boolean15 = period13.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period16 = period13.normalizedStandard();
        org.joda.time.Duration duration17 = period13.toStandardDuration();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant12, (org.joda.time.ReadableDuration) duration17, periodType18);
        org.joda.time.Period period21 = period19.minusSeconds(1);
        int int22 = period19.getHours();
        org.joda.time.Period period24 = period19.withMinutes((int) (short) 10);
        org.joda.time.Period period26 = period24.plusMonths(7);
        org.joda.time.Period period28 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType30 = period28.getFieldType(4);
        int int31 = period26.get(durationFieldType30);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField32 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType30);
        org.joda.time.Period period34 = period6.withFieldAdded(durationFieldType30, 105);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(durationFieldType30, "1");
        java.lang.Number number37 = illegalFieldValueException36.getLowerBound();
        boolean boolean38 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException36);
        java.lang.String str39 = illegalFieldValueException36.getIllegalStringValue();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(mutablePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(duration17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNull(number37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "1" + "'", str39.equals("1"));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long17 = scaledDurationField12.getDifferenceAsLong((-1104537599899L), 10L);
        long long20 = scaledDurationField12.getMillis(0L, (-210858120000000L));
        int int23 = scaledDurationField12.getDifference((-210863736000000L), (-210863736000000L));
        long long26 = scaledDurationField12.getValueAsLong((-100973088000000L), 182L);
        int int29 = scaledDurationField12.getValue((-1085L), 208275926400000L);
        int int32 = scaledDurationField12.getDifference((-61273296421990L), (-210858048422000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + (-31L) + "'", long26 == (-31L));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 47 + "'", int32 == 47);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period1 = period0.negated();
        org.joda.time.Period period3 = period1.minusYears((-1));
        org.joda.time.Period period5 = period3.plusMonths((int) 'a');
        int int6 = period3.getHours();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology4.getZone();
        long long12 = zonedChronology4.getDateTimeMillis(10L, 1, (int) (short) 1, 0, 105);
        org.joda.time.Period period13 = org.joda.time.Period.ZERO;
        boolean boolean15 = period13.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period16 = period13.normalizedStandard();
        org.joda.time.Period period17 = org.joda.time.Period.ZERO;
        boolean boolean19 = period17.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period20 = period16.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = period17.indexOf(durationFieldType21);
        long long25 = zonedChronology4.add((org.joda.time.ReadablePeriod) period17, (-1L), 7);
        org.joda.time.chrono.LenientChronology lenientChronology26 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) zonedChronology4);
        org.joda.time.DateTimeField dateTimeField27 = zonedChronology4.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3660105L + "'", long12 == 3660105L);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertNotNull(lenientChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.Period period7 = new org.joda.time.Period((long) 0, (long) (byte) 0, (org.joda.time.Chronology) zonedChronology6);
        org.joda.time.Period period9 = period7.minusWeeks(0);
        org.joda.time.Period period11 = period7.plusWeeks(2);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        java.lang.String str46 = unsupportedDateTimeField43.getName();
        org.joda.time.DurationField durationField47 = unsupportedDateTimeField43.getRangeDurationField();
        org.joda.time.DurationField durationField48 = unsupportedDateTimeField43.getLeapDurationField();
        java.util.Locale locale51 = null;
        try {
            long long52 = unsupportedDateTimeField43.set((-1104537599999L), "", locale51);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "dayOfWeek" + "'", str46.equals("dayOfWeek"));
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertNull(durationField48);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey(0L);
        int int12 = fixedDateTimeZone4.getStandardOffset(864000350L);
        java.lang.String str14 = fixedDateTimeZone4.getShortName((-62102995616991L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Millis" + "'", str10.equals("Millis"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.100" + "'", str14.equals("+00:00:00.100"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period(0L, 10L, periodType2, chronology4);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.millis();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(1L, periodType7, chronology8);
        org.joda.time.Period period10 = period5.withPeriodType(periodType7);
        try {
            org.joda.time.Period period12 = period10.withWeeks((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        long long8 = offsetDateTimeField4.add((long) ' ', (long) 8);
        org.joda.time.DurationField durationField9 = offsetDateTimeField4.getLeapDurationField();
        java.lang.String str10 = offsetDateTimeField4.toString();
        org.joda.time.ReadablePartial readablePartial11 = null;
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial11);
        long long14 = offsetDateTimeField4.roundCeiling(100L);
        long long16 = offsetDateTimeField4.roundHalfCeiling((-13L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 691200032L + "'", long8 == 691200032L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str10.equals("DateTimeField[dayOfWeek]"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 86400000L + "'", long14 == 86400000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = lenientChronology3.dayOfYear();
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology3.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = zonedChronology4.year();
        java.lang.String str6 = zonedChronology4.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str6.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = zonedChronology4.year();
        org.joda.time.Chronology chronology7 = zonedChronology4.withUTC();
        long long11 = zonedChronology4.add(10L, (-1104537599899L), (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial12 = null;
        try {
            int[] intArray14 = zonedChronology4.get(readablePartial12, 28800182L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-1104537599889L) + "'", long11 == (-1104537599889L));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("LenientChronology[GregorianChronology[America/Los_Angeles]]", number1, (java.lang.Number) (-210858120000000L), (java.lang.Number) 35);
        java.lang.Number number5 = illegalFieldValueException4.getUpperBound();
        java.lang.String str6 = illegalFieldValueException4.toString();
        java.lang.String str7 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 35 + "'", number5.equals(35));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value null for LenientChronology[GregorianChronology[America/Los_Angeles]] must be in the range [-210858120000000,35]" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value null for LenientChronology[GregorianChronology[America/Los_Angeles]] must be in the range [-210858120000000,35]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "LenientChronology[GregorianChronology[America/Los_Angeles]]" + "'", str7.equals("LenientChronology[GregorianChronology[America/Los_Angeles]]"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        java.lang.String str4 = lenientChronology3.toString();
        org.joda.time.DurationField durationField5 = lenientChronology3.minutes();
        java.lang.String str6 = lenientChronology3.toString();
        org.joda.time.tz.DefaultNameProvider defaultNameProvider7 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale8 = null;
        java.lang.String str11 = defaultNameProvider7.getShortName(locale8, "1", "Coordinated Universal Time");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider7);
        boolean boolean13 = lenientChronology3.equals((java.lang.Object) defaultNameProvider7);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.Chronology chronology15 = lenientChronology3.withZone(dateTimeZone14);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str4.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "LenientChronology[GregorianChronology[UTC]]" + "'", str6.equals("LenientChronology[GregorianChronology[UTC]]"));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        long long31 = offsetDateTimeField4.addWrapField((long) 10, 5047);
        org.joda.time.ReadablePartial readablePartial32 = null;
        int int33 = offsetDateTimeField4.getMinimumValue(readablePartial32);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 10L + "'", long31 == 10L);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5045 + "'", int33 == 5045);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = zonedChronology4.yearOfEra();
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology4.getZone();
        try {
            long long14 = zonedChronology4.getDateTimeMillis(32, (int) (byte) 0, (-1), (-1), (int) (byte) 10, 10096, 99);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        org.joda.time.DurationField durationField27 = dividedDateTimeField26.getDurationField();
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField26);
        int int31 = dividedDateTimeField26.getDifference((long) (-5051), 110449296000000L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertNotNull(durationField27);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-99) + "'", int31 == (-99));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundCeiling((long) 1);
        org.joda.time.DurationField durationField45 = remainderDateTimeField42.getRangeDurationField();
        java.lang.String str47 = remainderDateTimeField42.getAsShortText((-100L));
        java.lang.String str48 = remainderDateTimeField42.getName();
        long long50 = remainderDateTimeField42.roundFloor(3660105L);
        org.joda.time.ReadablePartial readablePartial51 = null;
        int int52 = remainderDateTimeField42.getMinimumValue(readablePartial51);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 86400000L + "'", long44 == 86400000L);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "47" + "'", str47.equals("47"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfWeek" + "'", str48.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone11 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.util.Locale locale13 = null;
        java.lang.String str14 = cachedDateTimeZone11.getShortName(864000350L, locale13);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(cachedDateTimeZone11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+00:00:00.100" + "'", str14.equals("+00:00:00.100"));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        long long29 = dividedDateTimeField26.getDifferenceAsLong(12783L, (-210858048422000L));
        int int32 = dividedDateTimeField26.getDifference(0L, (-20985292800000L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 190L + "'", long29 == 190L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 18 + "'", int32 == 18);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue(32, 0, 2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            long long23 = unsupportedDurationField20.getMillis(110449332000000L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology6 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology2, dateTimeZone5);
        org.joda.time.DurationField durationField7 = gregorianChronology2.minutes();
        int int8 = gregorianChronology2.getMinimumDaysInFirstWeek();
        org.joda.time.Period period9 = new org.joda.time.Period(1L, 10L, (org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology2.yearOfCentury();
        long long14 = gregorianChronology2.add(0L, (-210866774821901L), 110);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(zonedChronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-23195345230409110L) + "'", long14 == (-23195345230409110L));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 5044);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale13 = null;
        java.lang.String str14 = offsetDateTimeField10.getAsShortText(readablePartial11, 100, locale13);
        int int17 = offsetDateTimeField10.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology18 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int19 = gregorianChronology18.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField20 = gregorianChronology18.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, 5044);
        org.joda.time.ReadablePartial readablePartial23 = null;
        java.util.Locale locale25 = null;
        java.lang.String str26 = offsetDateTimeField22.getAsShortText(readablePartial23, 100, locale25);
        int int29 = offsetDateTimeField22.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial30 = null;
        int int31 = offsetDateTimeField22.getMinimumValue(readablePartial30);
        org.joda.time.DateTimeFieldType dateTimeFieldType32 = offsetDateTimeField22.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField34 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField10, dateTimeFieldType32, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField36 = new org.joda.time.field.DividedDateTimeField(dateTimeField5, dateTimeFieldType32, 99);
        org.joda.time.IllegalFieldValueException illegalFieldValueException39 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, (java.lang.Number) (-1.0d), "+00:00:00.100");
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType32, (java.lang.Number) 0.0f, (java.lang.Number) 101, (java.lang.Number) 52L);
        boolean boolean44 = periodType2.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "100" + "'", str14.equals("100"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 99 + "'", int17 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "100" + "'", str26.equals("100"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 99 + "'", int29 == 99);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 5045 + "'", int31 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType32);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long17 = scaledDurationField12.add((long) (byte) -1, 0);
        java.lang.String str18 = scaledDurationField12.toString();
        int int19 = scaledDurationField12.getScalar();
        int int21 = scaledDurationField12.getValue((-62102995621990L));
        org.joda.time.DurationField durationField22 = scaledDurationField12.getWrappedField();
        try {
            long long25 = durationField22.subtract((long) (short) 1, 15929949369600000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -15929949369600000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DurationField[hours]" + "'", str18.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-19) + "'", int21 == (-19));
        org.junit.Assert.assertNotNull(durationField22);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        java.lang.String str46 = unsupportedDateTimeField43.getName();
        org.joda.time.DurationField durationField47 = unsupportedDateTimeField43.getRangeDurationField();
        org.joda.time.DurationField durationField48 = unsupportedDateTimeField43.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial49 = null;
        java.util.Locale locale51 = null;
        try {
            java.lang.String str52 = unsupportedDateTimeField43.getAsText(readablePartial49, 7, locale51);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "dayOfWeek" + "'", str46.equals("dayOfWeek"));
        org.junit.Assert.assertNull(durationField47);
        org.junit.Assert.assertNull(durationField48);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        boolean boolean15 = scaledDurationField12.isPrecise();
        long long17 = scaledDurationField12.getMillis(0);
        int int19 = scaledDurationField12.getValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology20.halfdayOfDay();
        org.joda.time.DurationField durationField26 = gregorianChronology20.years();
        org.joda.time.Period period28 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType30 = period28.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField32 = new org.joda.time.field.ScaledDurationField(durationField26, durationFieldType30, (int) (byte) 100);
        int int34 = scaledDurationField32.getValue(4999L);
        boolean boolean35 = scaledDurationField32.isPrecise();
        int int36 = scaledDurationField12.compareTo((org.joda.time.DurationField) scaledDurationField32);
        long long39 = scaledDurationField32.add((-210865896000000L), (int) (byte) -1);
        long long42 = scaledDurationField32.getValueAsLong((-210866774822000L), (long) 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(zonedChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-214021656000000L) + "'", long39 == (-214021656000000L));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-66L) + "'", long42 == (-66L));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        org.joda.time.Period period2 = new org.joda.time.Period(3155695200000L, (long) (short) -1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology2, (java.lang.Object) 4);
        org.joda.time.Period period5 = new org.joda.time.Period(4L, periodType1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationField durationField6 = iSOChronology2.halfdays();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType8 = periodType7.withSecondsRemoved();
        org.joda.time.PeriodType periodType9 = org.joda.time.DateTimeUtils.getPeriodType(periodType8);
        boolean boolean10 = iSOChronology2.equals((java.lang.Object) periodType8);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean36 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology34, (java.lang.Object) 4);
        org.joda.time.Chronology chronology37 = iSOChronology34.withUTC();
        org.joda.time.DurationField durationField38 = iSOChronology34.minutes();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone41 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
        org.joda.time.Chronology chronology42 = iSOChronology34.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology34.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int45 = gregorianChronology44.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology44.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, 5044);
        org.joda.time.ReadablePartial readablePartial49 = null;
        java.util.Locale locale51 = null;
        java.lang.String str52 = offsetDateTimeField48.getAsShortText(readablePartial49, 100, locale51);
        int int55 = offsetDateTimeField48.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        int int57 = offsetDateTimeField48.getMinimumValue(readablePartial56);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = offsetDateTimeField48.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField60 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType58, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField33, dateTimeFieldType58, 100);
        java.lang.String str63 = dividedDateTimeField33.getName();
        try {
            long long66 = dividedDateTimeField33.set((long) (byte) 1, "YearMonthDayTime");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"YearMonthDayTime\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(cachedDateTimeZone41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "100" + "'", str52.equals("100"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 99 + "'", int55 == 99);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 5045 + "'", int57 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "dayOfWeek" + "'", str63.equals("dayOfWeek"));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-210866774821901L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        int int5 = dateTimeZone2.getOffsetFromLocal(7L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.Period period4 = org.joda.time.Period.ZERO;
        boolean boolean6 = period4.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period7 = period4.normalizedStandard();
        org.joda.time.Duration duration8 = period4.toStandardDuration();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant3, (org.joda.time.ReadableDuration) duration8, periodType9);
        org.joda.time.Period period12 = period10.minusSeconds(1);
        int int13 = period10.getHours();
        org.joda.time.Period period15 = period10.withMinutes((int) (short) 10);
        org.joda.time.Period period17 = period15.plusMonths(7);
        org.joda.time.Period period19 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType21 = period19.getFieldType(4);
        int int22 = period17.get(durationFieldType21);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(durationFieldType21, "YearMonthDayTime");
        boolean boolean25 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (-100973088000000L), (java.lang.Object) durationFieldType21);
        org.joda.time.field.DecoratedDurationField decoratedDurationField26 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType21);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(durationFieldType21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.withSeconds((int) '#');
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = period3.isSupported(durationFieldType4);
        org.joda.time.Period period7 = period3.withMillis((int) (short) 10);
        org.joda.time.Duration duration8 = period7.toStandardDuration();
        org.joda.time.Period period10 = period7.minusMonths(5047);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(period10);
    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test349");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
//        java.lang.String str6 = cachedDateTimeZone2.getName((-210866760000000L));
//        org.joda.time.DateTimeZone dateTimeZone7 = cachedDateTimeZone2.getUncachedZone();
//        boolean boolean8 = cachedDateTimeZone2.isFixed();
//        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) cachedDateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
//    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.DurationField durationField7 = gregorianChronology0.months();
        org.joda.time.DurationField durationField8 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
        java.util.Locale locale20 = null;
        int int21 = offsetDateTimeField4.getMaximumTextLength(locale20);
        int int23 = offsetDateTimeField4.getMinimumValue(10L);
        long long26 = offsetDateTimeField4.addWrapField(3660105L, (int) '4');
        org.joda.time.DurationField durationField27 = offsetDateTimeField4.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 262860105L + "'", long26 == 262860105L);
        org.junit.Assert.assertNotNull(durationField27);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        boolean boolean15 = scaledDurationField12.isPrecise();
        long long17 = scaledDurationField12.getMillis(0);
        boolean boolean18 = scaledDurationField12.isPrecise();
        int int19 = scaledDurationField12.getScalar();
        int int21 = scaledDurationField12.getValue(110449296000000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 34 + "'", int21 == 34);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover((int) (byte) -1, '4', (int) (short) 10, 106, (int) '#', false, 4);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
        org.joda.time.ReadablePartial readablePartial8 = null;
        int[] intArray11 = new int[] { 100, (byte) -1 };
        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
        long long21 = offsetDateTimeField4.roundCeiling(100L);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField4.getAsShortText((long) 5044, locale23);
        java.lang.String str25 = offsetDateTimeField4.toString();
        boolean boolean27 = offsetDateTimeField4.isLeap(43734067200000L);
        long long29 = offsetDateTimeField4.roundCeiling(350L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 86400000L + "'", long21 == 86400000L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "5048" + "'", str24.equals("5048"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str25.equals("DateTimeField[dayOfWeek]"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 86400000L + "'", long29 == 86400000L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        org.joda.time.Period period2 = new org.joda.time.Period(0L, (long) (-1));
        int[] intArray3 = period2.getValues();
        org.joda.time.Period period5 = period2.plusSeconds((int) (short) 10);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        boolean boolean15 = scaledDurationField12.isPrecise();
        long long17 = scaledDurationField12.getMillis(0);
        boolean boolean18 = scaledDurationField12.isPrecise();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone23 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int25 = fixedDateTimeZone23.getOffset(0L);
        long long27 = fixedDateTimeZone23.nextTransition((long) 4);
        boolean boolean28 = scaledDurationField12.equals((java.lang.Object) fixedDateTimeZone23);
        long long30 = fixedDateTimeZone23.previousTransition(43734067199901L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 4L + "'", long27 == 4L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 43734067199901L + "'", long30 == 43734067199901L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) (-1.0d), "+00:00:00.100");
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 0.0f, (java.lang.Number) 101, (java.lang.Number) 52L);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology41, dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology41.halfdayOfDay();
        org.joda.time.DurationField durationField47 = gregorianChronology41.years();
        org.joda.time.Period period49 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType51 = period49.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField53 = new org.joda.time.field.ScaledDurationField(durationField47, durationFieldType51, (int) (byte) 100);
        int int55 = scaledDurationField53.getValue(4999L);
        long long58 = scaledDurationField53.add((long) (byte) -1, 0);
        java.lang.String str59 = scaledDurationField53.toString();
        int int62 = scaledDurationField53.getValue((long) 100, 3155760000000L);
        org.joda.time.DurationField durationField63 = null;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField64 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType29, (org.joda.time.DurationField) scaledDurationField53, durationField63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(zonedChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(durationFieldType51);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + (-1L) + "'", long58 == (-1L));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "DurationField[hours]" + "'", str59.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long4 = cachedDateTimeZone2.previousTransition((long) (short) 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertNotNull(gregorianChronology5);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField43.getRangeDurationField();
        int int48 = unsupportedDateTimeField43.getDifference((long) 10, (long) (short) 100);
        long long51 = unsupportedDateTimeField43.add((long) 35, (-1104537599889L));
        java.util.Locale locale53 = null;
        try {
            java.lang.String str54 = unsupportedDateTimeField43.getAsShortText((-100), locale53);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNull(durationField45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + (-1104537599888965L) + "'", long51 == (-1104537599888965L));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period1 = period0.negated();
        org.joda.time.Period period3 = period1.minusYears((-1));
        org.joda.time.Period period5 = period3.plusMonths((int) 'a');
        org.joda.time.Period period6 = period5.normalizedStandard();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        long long48 = unsupportedDateTimeField43.getDifferenceAsLong((long) 10, (long) (short) -1);
        org.joda.time.DurationField durationField49 = unsupportedDateTimeField43.getLeapDurationField();
        try {
            int int50 = unsupportedDateTimeField43.getMinimumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertNull(durationField49);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getDurationField();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = offsetDateTimeField4.getType();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeFieldType7);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) lenientChronology3);
        org.joda.time.Chronology chronology5 = lenientChronology4.withUTC();
        org.joda.time.Period period10 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period12 = period10.plusMillis(1);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.Duration duration14 = period12.toDurationTo(readableInstant13);
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.millis();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(1L, periodType17, chronology18);
        org.joda.time.PeriodType periodType20 = periodType17.withYearsRemoved();
        org.joda.time.Period period21 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant15, periodType17);
        boolean boolean22 = lenientChronology4.equals((java.lang.Object) duration14);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long21 = unsupportedDurationField20.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType22 = unsupportedDurationField20.getType();
        java.lang.String str23 = unsupportedDurationField20.getName();
        boolean boolean24 = unsupportedDurationField20.isPrecise();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "hours" + "'", str23.equals("hours"));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        try {
            long long48 = unsupportedDateTimeField43.set((-57600000L), 5049);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField43.getDurationField();
        boolean boolean46 = unsupportedDateTimeField43.isLenient();
        java.util.Locale locale47 = null;
        try {
            int int48 = unsupportedDateTimeField43.getMaximumShortTextLength(locale47);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.toString();
        java.util.Locale locale47 = null;
        try {
            java.lang.String str48 = unsupportedDateTimeField43.getAsShortText((-100982246400000L), locale47);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField4.getAsShortText((int) 'a', locale10);
        org.joda.time.DateTimeField dateTimeField12 = offsetDateTimeField4.getWrappedField();
        int int14 = offsetDateTimeField4.get(43734096000000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "97" + "'", str11.equals("97"));
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5045 + "'", int14 == 5045);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File[] fileArray2 = new java.io.File[] {};
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap3 = zoneInfoCompiler0.compile(file1, fileArray2);
        org.junit.Assert.assertNotNull(fileArray2);
        org.junit.Assert.assertNotNull(strMap3);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        org.joda.time.Period period8 = new org.joda.time.Period(0, (int) ' ', 0, (int) (short) -1, 0, (int) (short) -1, (int) (short) 1, 10);
        org.joda.time.Period period10 = period8.withDays(0);
        org.joda.time.Period period12 = period8.withYears((int) (byte) 100);
        org.joda.time.Period period14 = period12.minusHours(34);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        org.joda.time.Period period3 = period1.minusDays((int) (byte) 1);
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period7 = new org.joda.time.Period((long) 1, 0L, periodType6);
        org.joda.time.PeriodType periodType8 = periodType6.withSecondsRemoved();
        org.joda.time.PeriodType periodType9 = periodType8.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType10 = null;
        boolean boolean11 = periodType8.isSupported(durationFieldType10);
        org.joda.time.PeriodType periodType12 = periodType8.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period14 = new org.joda.time.Period((java.lang.Object) period1, periodType12, (org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.PeriodType periodType15 = periodType12.withSecondsRemoved();
        org.joda.time.PeriodType periodType16 = periodType12.withMinutesRemoved();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        boolean boolean15 = scaledDurationField12.isPrecise();
        long long17 = scaledDurationField12.getMillis(0);
        int int19 = scaledDurationField12.getValue(10L);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology20.halfdayOfDay();
        org.joda.time.DurationField durationField26 = gregorianChronology20.years();
        org.joda.time.Period period28 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType30 = period28.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField32 = new org.joda.time.field.ScaledDurationField(durationField26, durationFieldType30, (int) (byte) 100);
        int int34 = scaledDurationField32.getValue(4999L);
        boolean boolean35 = scaledDurationField32.isPrecise();
        int int36 = scaledDurationField12.compareTo((org.joda.time.DurationField) scaledDurationField32);
        int int38 = scaledDurationField32.getValue((long) 59);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(zonedChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) (-1.0d), "+00:00:00.100");
        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 0.0f, (java.lang.Number) 101, (java.lang.Number) 52L);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) 5050987L, "-1.0");
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long21 = unsupportedDurationField20.getUnitMillis();
        org.joda.time.DurationFieldType durationFieldType22 = unsupportedDurationField20.getType();
        long long23 = unsupportedDurationField20.getUnitMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
        int int6 = cachedDateTimeZone2.getOffset((-210858120000000L));
        int int8 = cachedDateTimeZone2.getOffset(720000000L);
        boolean boolean9 = cachedDateTimeZone2.isFixed();
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone2.getUncachedZone();
        org.joda.time.DateTimeZone dateTimeZone11 = cachedDateTimeZone2.getUncachedZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
        java.util.Locale locale45 = null;
        int int46 = remainderDateTimeField42.getMaximumTextLength(locale45);
        long long48 = remainderDateTimeField42.roundHalfEven((long) 5047);
        int int49 = remainderDateTimeField42.getMaximumValue();
        java.util.Locale locale51 = null;
        java.lang.String str52 = remainderDateTimeField42.getAsText((long) (-1), locale51);
        int int53 = remainderDateTimeField42.getDivisor();
        long long55 = remainderDateTimeField42.remainder(12622780800000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8640000000L + "'", long44 == 8640000000L);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 0L + "'", long48 == 0L);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 99 + "'", int49 == 99);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "47" + "'", str52.equals("47"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 100 + "'", int53 == 100);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 0L + "'", long55 == 0L);
    }
}

