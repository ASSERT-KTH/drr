import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.millis();
        try {
            org.joda.time.Period period9 = new org.joda.time.Period(0, (int) '#', (int) (byte) 1, (int) (short) 0, (int) (short) -1, (int) (byte) 100, (int) '4', 100, periodType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'months'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType8);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) '4', (long) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5044 + "'", int2 == 5044);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.millis();
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) (-1.0d), periodType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Double");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) '#', (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 350 + "'", int2 == 350);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(100.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858120000000L) + "'", long1 == (-210858120000000L));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(10L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) (short) 100, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        boolean boolean0 = org.joda.time.tz.ZoneInfoCompiler.verbose();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Throwable throwable0 = null;
        try {
            boolean boolean1 = org.joda.time.IllegalInstantException.isIllegalInstant(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 1, 0L, periodType4);
        org.joda.time.Period period6 = period1.withPeriodType(periodType4);
        try {
            int int8 = period6.getValue((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        java.lang.String str1 = periodType0.getName();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Weeks" + "'", str1.equals("Weeks"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 1, 0L, periodType4);
        org.joda.time.Period period6 = period1.withPeriodType(periodType4);
        try {
            org.joda.time.DurationFieldType durationFieldType8 = periodType4.getFieldType(350);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 350");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period(0L, 10L, periodType2, chronology4);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology(chronology4);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = null;
        try {
            org.joda.time.DateTimeUtils.setDefaultTimeZoneNames(strMap0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        boolean boolean2 = period0.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period3 = period0.normalizedStandard();
        org.joda.time.Period period5 = period3.plusDays((int) (byte) 10);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Weeks", (java.lang.Number) 1L, (java.lang.Number) 0, (java.lang.Number) (-210858120000000L));
        java.lang.String str5 = illegalFieldValueException4.getIllegalStringValue();
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (byte) -1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis(1, (int) (short) 10, (int) (byte) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) '#', (int) '#', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField3 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) 'a', 0, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 350, (java.lang.Object) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField5 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField2, durationField4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.Period period1 = new org.joda.time.Period((long) '4');
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType6, 350);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField8 = new org.joda.time.field.RemainderDateTimeField(dateTimeField5, dateTimeFieldType6, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("hi!");
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560626719070L + "'", long0 == 1560626719070L);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffset(1L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test044");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = cachedDateTimeZone2.getMillisKeepLocal(dateTimeZone3, 0L);
//        int int7 = cachedDateTimeZone2.getOffset((long) (short) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800000L + "'", long5 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Weeks", (java.lang.Number) 1L, (java.lang.Number) 0, (java.lang.Number) (-210858120000000L));
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        boolean boolean7 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        illegalFieldValueException4.prependMessage("UTC");
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 100, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "Weeks");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        try {
            long long8 = iSOChronology0.getDateTimeMillis(0L, 35, (int) ' ', (int) (short) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866673600000L) + "'", long1 == (-210866673600000L));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        try {
            long long12 = gregorianChronology0.getDateTimeMillis((int) 'a', (int) ' ', (int) (byte) 10, (int) (byte) 10, (int) (short) -1, (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560626720050L + "'", long1 == 1560626720050L);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = new org.joda.time.DurationFieldType[] { durationFieldType0 };
        try {
            org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.forFields(durationFieldTypeArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not contain null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField4 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField2, dateTimeFieldType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        try {
            long long9 = iSOChronology0.getDateTimeMillis((int) '#', 0, 4, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType1 = periodType0.withSecondsRemoved();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = periodType0.indexOf(durationFieldType2);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5000011576d + "'", double1 == 2440587.5000011576d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.joda.time.Period period1 = new org.joda.time.Period((java.lang.Object) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Short");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DurationField durationField6 = zonedChronology4.minutes();
        try {
            long long14 = zonedChronology4.getDateTimeMillis((int) (short) -1, (int) (short) 100, (int) (byte) 10, 100, (int) (short) 10, 10, 350);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfCentury();
        try {
            long long10 = iSOChronology0.getDateTimeMillis((long) 0, (int) (short) -1, 100, (int) '4', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(0L, "America/Los_Angeles");
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "Weeks");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long4 = cachedDateTimeZone2.previousTransition((long) (short) 0);
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = cachedDateTimeZone2.getOffset(readableInstant5);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DurationField durationField2 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField3 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) 10, periodType1, chronology2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField5 = new org.joda.time.field.RemainderDateTimeField(dateTimeField2, dateTimeFieldType3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 100, (-1104537599999L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1104537599899L) + "'", long2 == (-1104537599899L));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((-1L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 1, 0L, periodType4);
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.Period period8 = new org.joda.time.Period((long) 350, (-210858120000000L), periodType4, (org.joda.time.Chronology) gregorianChronology6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -210858120000350");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(1L, periodType2, chronology3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType2);
        org.joda.time.Days days6 = period5.toStandardDays();
        java.lang.Class<?> wildcardClass7 = period5.getClass();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(days6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        long long4 = cachedDateTimeZone2.previousTransition((long) (short) 0);
        long long7 = cachedDateTimeZone2.adjustOffset((long) (-1), true);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1L) + "'", long7 == (-1L));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        try {
            long long5 = iSOChronology0.getDateTimeMillis(350, (int) (byte) 10, (int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
//        java.lang.String str6 = cachedDateTimeZone2.getName((-210866760000000L));
//        int int8 = cachedDateTimeZone2.getStandardOffset((long) '4');
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000116d + "'", double1 == 2440587.500000116d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("ZonedChronology[GregorianChronology[UTC], UTC]", "hi!");
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, 1560626720050L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = new org.joda.time.DurationFieldType[] {};
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.Period period1 = org.joda.time.Period.years(10);
        try {
            org.joda.time.Days days2 = period1.toStandardDays();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Days as this period contains years and years vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 35, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField7 = new org.joda.time.field.RemainderDateTimeField(dateTimeField4, dateTimeFieldType5, 5051);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField2 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        try {
            org.joda.time.Period period4 = period2.withMillis(0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField3 = gregorianChronology2.millis();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.dayOfWeek();
        org.joda.time.DurationField durationField5 = gregorianChronology2.weeks();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField6 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField1, durationField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 5051, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4999L + "'", long2 == 4999L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        int int2 = period1.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, (int) (short) 0, (int) ' ', (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("LenientChronology[GregorianChronology[America/Los_Angeles]]", number1, (java.lang.Number) (-210858120000000L), (java.lang.Number) 35);
        illegalFieldValueException4.prependMessage("dayOfWeek");
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.field.FieldUtils.verifyValueBounds("52", 0, (int) (short) 0, (int) (short) 100);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException(4L, "LenientChronology[GregorianChronology[America/Los_Angeles]]");
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        int int1 = period0.getSeconds();
        int int2 = period0.getSeconds();
        int int3 = period0.getWeeks();
        org.joda.time.Days days4 = period0.toStandardDays();
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(days4);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
//        java.lang.String str15 = offsetDateTimeField14.getName();
//        long long17 = offsetDateTimeField14.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial18 = null;
//        int[] intArray21 = new int[] { 100, (byte) -1 };
//        int int22 = offsetDateTimeField14.getMaximumValue(readablePartial18, intArray21);
//        java.util.Locale locale24 = null;
//        try {
//            int[] intArray25 = offsetDateTimeField4.set(readablePartial8, (int) (byte) 0, intArray21, "Weeks", locale24);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Weeks\" for dayOfWeek is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(gregorianChronology10);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfWeek" + "'", str15.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800000L + "'", long17 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5051 + "'", int22 == 5051);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        int int1 = period0.getSeconds();
        int int2 = period0.getSeconds();
        org.joda.time.Seconds seconds3 = period0.toStandardSeconds();
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = period0.isSupported(durationFieldType4);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(seconds3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        long long8 = offsetDateTimeField4.add((long) ' ', (long) 8);
        org.joda.time.DurationField durationField9 = offsetDateTimeField4.getLeapDurationField();
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray12 = null;
        try {
            int[] intArray14 = offsetDateTimeField4.add(readablePartial10, (int) (byte) 0, intArray12, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 691200032L + "'", long8 == 691200032L);
        org.junit.Assert.assertNull(durationField9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks((int) (short) 1);
        org.joda.time.Period period5 = period3.withYears(8);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        try {
            long long5 = gregorianChronology0.getDateTimeMillis((int) (byte) 1, 8, (int) (short) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, 35, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        int int8 = period7.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 7 + "'", int8 == 7);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("1", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-210858120000000L), 691200032L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -210858120000000 * 691200032");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.withSeconds((int) '#');
        org.joda.time.Period period5 = period1.withHours((int) ' ');
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Duration duration7 = period5.toDurationTo(readableInstant6);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        long long8 = offsetDateTimeField4.add((long) ' ', (long) 8);
        org.joda.time.DurationField durationField9 = offsetDateTimeField4.getLeapDurationField();
        org.joda.time.DurationField durationField10 = offsetDateTimeField4.getLeapDurationField();
        try {
            long long13 = offsetDateTimeField4.set((long) 350, "ZonedChronology[GregorianChronology[UTC], UTC]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"ZonedChronology[GregorianChronology[UTC], UTC]\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 691200032L + "'", long8 == 691200032L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertNull(durationField10);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        java.io.OutputStream outputStream2 = null;
        try {
            dateTimeZoneBuilder0.writeTo("", outputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test118");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
//        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
//        long long21 = offsetDateTimeField4.roundCeiling(100L);
//        org.joda.time.ReadablePartial readablePartial22 = null;
//        java.util.Locale locale23 = null;
//        try {
//            java.lang.String str24 = offsetDateTimeField4.getAsShortText(readablePartial22, locale23);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800000L + "'", long21 == 28800000L);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DurationField durationField6 = zonedChronology4.days();
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) zonedChronology4, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) -1);
        int int2 = period1.getYears();
        int int3 = period1.getDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeField dateTimeField6 = zonedChronology4.year();
        org.joda.time.DurationField durationField7 = zonedChronology4.weekyears();
        try {
            long long13 = zonedChronology4.getDateTimeMillis(1560626719070L, 4, 5051, (-1), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5051 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology1.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology1, dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.halfdayOfDay();
        org.joda.time.DurationField durationField7 = gregorianChronology1.years();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology8.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology12 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology8, dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology8.halfdayOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology8.years();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField15 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType0, durationField7, durationField14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(zonedChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(zonedChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("hi!", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField11 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField9, dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.centuries();
        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
        long long5 = durationField2.subtract(10L, 0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial7 = null;
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = offsetDateTimeField4.getAsText(readablePartial7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("5047");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '5047' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) 'a');
        org.joda.time.DurationFieldType durationFieldType2 = null;
        int int3 = period1.indexOf(durationFieldType2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("UTC");
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 1, 0L, periodType2);
        int int4 = period3.getHours();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(4999L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        boolean boolean2 = period0.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period3 = period0.normalizedStandard();
        org.joda.time.Duration duration4 = period0.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration4, readableInstant5);
        org.joda.time.MutablePeriod mutablePeriod7 = period6.toMutablePeriod();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        boolean boolean9 = period6.isSupported(durationFieldType8);
        org.joda.time.Period period11 = period6.minusMillis((int) (short) 100);
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period6, (java.lang.Object) (short) -1);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(duration4);
        org.junit.Assert.assertNotNull(mutablePeriod7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField4 = new org.joda.time.field.ScaledDurationField(durationField1, durationFieldType2, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period8 = period7.toPeriod();
        try {
            org.joda.time.Period period10 = period7.minusWeeks(350);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, dateTimeFieldType3, 8, 8, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test138");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = periodType6.indexOf(durationFieldType8);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'YearMonthDayTime' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(timeZone9);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        long long8 = offsetDateTimeField4.add((long) ' ', (long) 8);
        long long11 = offsetDateTimeField4.add(0L, 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 691200032L + "'", long8 == 691200032L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(7, (int) (short) 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
        java.util.TimeZone timeZone5 = cachedDateTimeZone2.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "+00:00:00.100");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) 'a', 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 105 + "'", int2 == 105);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 35, 5045, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DurationField durationField6 = zonedChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology4.secondOfDay();
        org.joda.time.DurationField durationField8 = zonedChronology4.months();
        org.joda.time.DurationFieldType durationFieldType9 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField11 = new org.joda.time.field.ScaledDurationField(durationField8, durationFieldType9, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.minusSeconds(350);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(1L, periodType2, chronology3);
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType2);
        try {
            org.joda.time.Period period7 = period5.minusYears((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.Period period1 = org.joda.time.Period.hours(4);
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        java.util.Locale locale15 = null;
//        try {
//            long long16 = offsetDateTimeField4.set(1L, "UTC", locale15);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"UTC\" for dayOfWeek is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.withSeconds((int) '#');
        org.joda.time.Period period5 = period1.withHours((int) ' ');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int12 = fixedDateTimeZone10.getOffset(0L);
        int int14 = fixedDateTimeZone10.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone15 = fixedDateTimeZone10.toTimeZone();
        boolean boolean16 = period5.equals((java.lang.Object) fixedDateTimeZone10);
        int int18 = fixedDateTimeZone10.getOffset((long) 4);
        long long20 = fixedDateTimeZone10.nextTransition(28800000L);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 28800000L + "'", long20 == 28800000L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.Period period2 = new org.joda.time.Period(0L, (long) (-1));
        int int3 = period2.getYears();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
//        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
//        long long21 = offsetDateTimeField4.roundCeiling(100L);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField4.getAsShortText((long) 5044, locale23);
//        boolean boolean26 = offsetDateTimeField4.isLeap((-1104451199899L));
//        org.joda.time.ReadablePartial readablePartial27 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int30 = gregorianChronology29.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology29.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, 5044);
//        org.joda.time.DurationField durationField34 = offsetDateTimeField33.getLeapDurationField();
//        int int35 = offsetDateTimeField33.getMaximumValue();
//        org.joda.time.ReadablePartial readablePartial36 = null;
//        int[] intArray43 = new int[] { '4', (short) -1, (short) 1, 350, 5044 };
//        int[] intArray45 = offsetDateTimeField33.addWrapPartial(readablePartial36, 10, intArray43, (int) (short) 0);
//        try {
//            int[] intArray47 = offsetDateTimeField4.set(readablePartial27, (int) (byte) -1, intArray43, 5051);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800000L + "'", long21 == 28800000L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "5047" + "'", str24.equals("5047"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNull(durationField34);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 5051 + "'", int35 == 5051);
//        org.junit.Assert.assertNotNull(intArray43);
//        org.junit.Assert.assertNotNull(intArray45);
//    }

//    @Test
//    public void test156() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test156");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
//        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
//        long long21 = offsetDateTimeField4.roundCeiling(100L);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField4.getAsShortText((long) 5044, locale23);
//        boolean boolean26 = offsetDateTimeField4.isLeap((-1104451199899L));
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType27, (int) (short) 1, (int) (byte) 10, 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800000L + "'", long21 == 28800000L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "5047" + "'", str24.equals("5047"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(8668800000L, (long) 5045);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 43734096000000L + "'", long2 == 43734096000000L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone4.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forTimeZone(timeZone11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'YearMonthDayTime' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("ZonedChronology[GregorianChronology[UTC], UTC]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ZonedChronology[GregorianChronology[UTC], UTC]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(5044);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(4L, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4L) + "'", long2 == (-4L));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset(10L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.Period period4 = new org.joda.time.Period((int) '#', 10, 350, (int) (short) 10);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        boolean boolean6 = period4.isSupported(durationFieldType5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((-1L), "5047");
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.Period period7 = org.joda.time.Period.millis(100);
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) duration5, (java.lang.Object) period7);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType9);
        org.joda.time.Period period11 = period10.normalizedStandard();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period(0L, 10L, periodType2, chronology4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        boolean boolean7 = period5.isSupported(durationFieldType6);
        org.joda.time.Period period9 = period5.plusSeconds((int) (short) 100);
        org.joda.time.format.PeriodFormatter periodFormatter10 = null;
        java.lang.String str11 = period5.toString(periodFormatter10);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PT0.010S" + "'", str11.equals("PT0.010S"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.chrono.LenientChronology lenientChronology2 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            long long5 = gregorianChronology0.set(readablePartial3, (long) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(lenientChronology2);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.seconds();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology2, (java.lang.Object) 4);
        org.joda.time.Period period5 = new org.joda.time.Period(4L, periodType1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        int int7 = period5.get(durationFieldType6);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DurationField durationField6 = zonedChronology4.days();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField8 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.Period period1 = new org.joda.time.Period((long) 350);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        try {
            long long12 = zonedChronology4.getDateTimeMillis((int) (byte) -1, 5051, (-1), 0, (int) ' ', 5051, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5051 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        long long9 = durationField6.subtract((long) (byte) 1, (long) '#');
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField11 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104537599999L) + "'", long9 == (-1104537599999L));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = gregorianChronology0.eras();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("Weeks");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Weeks\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        int int1 = period0.getSeconds();
        int int2 = period0.getSeconds();
        org.joda.time.Seconds seconds3 = period0.toStandardSeconds();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = zonedChronology8.year();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
        org.joda.time.Chronology chronology13 = zonedChronology8.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone12);
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) seconds3, (java.lang.Object) chronology13);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(seconds3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField4.getMinimumValue(readablePartial12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField4.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType14, 35, (int) (short) 100, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 35 for dayOfWeek must be in the range [100,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5045 + "'", int13 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00:00.100", "5047");
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test182() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test182");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
//        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
//        long long21 = offsetDateTimeField4.roundCeiling(100L);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField4.getAsShortText((long) 5044, locale23);
//        java.util.Locale locale25 = null;
//        int int26 = offsetDateTimeField4.getMaximumShortTextLength(locale25);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800000L + "'", long21 == 28800000L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "5047" + "'", str24.equals("5047"));
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
//    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) -1);
        int int2 = period1.getMillis();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period6 = period4.plusMillis(1);
        org.joda.time.Period period8 = period6.withSeconds((int) (byte) 100);
        org.joda.time.Period period10 = period6.plusMinutes(1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
//        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
//        org.joda.time.ReadablePartial readablePartial12 = null;
//        int int13 = offsetDateTimeField4.getMinimumValue(readablePartial12);
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField4.getType();
//        long long16 = offsetDateTimeField4.remainder(0L);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5045 + "'", int13 == 5045);
//        org.junit.Assert.assertNotNull(dateTimeFieldType14);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 57600000L + "'", long16 == 57600000L);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Weeks", (java.lang.Number) 1L, (java.lang.Number) 0, (java.lang.Number) (-210858120000000L));
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number7 = illegalFieldValueException4.getUpperBound();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1L + "'", number6.equals(1L));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-210858120000000L) + "'", number7.equals((-210858120000000L)));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int10 = offsetDateTimeField4.getMinimumValue((long) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5045 + "'", int10 == 5045);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "5047");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "dayOfWeek");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) (short) 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology4.getZone();
        long long12 = zonedChronology4.getDateTimeMillis(10L, 1, (int) (short) 1, 0, 105);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology4.halfdayOfDay();
        try {
            long long18 = zonedChronology4.getDateTimeMillis(99, (int) (short) 10, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3660105L + "'", long12 == 3660105L);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(99);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType6 = periodType5.withWeeksRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology7, (java.lang.Object) 4);
        org.joda.time.Chronology chronology10 = iSOChronology7.withUTC();
        org.joda.time.DurationField durationField11 = iSOChronology7.minutes();
        boolean boolean12 = periodType6.equals((java.lang.Object) iSOChronology7);
        org.joda.time.PeriodType periodType13 = periodType6.withMonthsRemoved();
        boolean boolean14 = lenientChronology4.equals((java.lang.Object) periodType6);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean17 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology15, (java.lang.Object) 4);
        org.joda.time.Chronology chronology18 = iSOChronology15.withUTC();
        org.joda.time.DurationField durationField19 = iSOChronology15.minutes();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone21);
        org.joda.time.Chronology chronology23 = iSOChronology15.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        org.joda.time.Period period24 = new org.joda.time.Period((long) 105, periodType6, (org.joda.time.Chronology) iSOChronology15);
        int int25 = period24.getMonths();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        long long4 = durationField1.subtract(4L, 0);
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField1, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4L + "'", long4 == 4L);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("1");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '1' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.PeriodType periodType3 = periodType2.withSecondsRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        int int15 = period12.getHours();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period6 = period4.plusMillis(1);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period6.toDurationTo(readableInstant7);
        long long9 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3541001L + "'", long9 == 3541001L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.DurationFieldType durationFieldType15 = null;
        int int16 = period14.indexOf(durationFieldType15);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.File file1 = null;
        java.io.File file2 = null;
        java.io.File[] fileArray3 = new java.io.File[] { file2 };
        try {
            java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap4 = zoneInfoCompiler0.compile(file1, fileArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(fileArray3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.Period period1 = org.joda.time.Period.years(0);
        org.joda.time.Minutes minutes2 = period1.toStandardMinutes();
        org.joda.time.Period period4 = period1.withWeeks(4);
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.Period period7 = org.joda.time.Period.ZERO;
        boolean boolean9 = period7.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period10 = period7.normalizedStandard();
        org.joda.time.Duration duration11 = period7.toStandardDuration();
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant6, (org.joda.time.ReadableDuration) duration11, periodType12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType16 = periodType15.withWeeksRemoved();
        org.joda.time.Period period17 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration11, readableInstant14, periodType15);
        org.joda.time.chrono.ISOChronology iSOChronology18 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean20 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology18, (java.lang.Object) 4);
        org.joda.time.Chronology chronology21 = iSOChronology18.withUTC();
        org.joda.time.DurationField durationField22 = iSOChronology18.minutes();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone24);
        org.joda.time.Chronology chronology26 = iSOChronology18.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone25);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology18.clockhourOfDay();
        org.joda.time.Period period28 = new org.joda.time.Period((long) 105, periodType15, (org.joda.time.Chronology) iSOChronology18);
        try {
            org.joda.time.Period period29 = period4.withPeriodType(periodType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'weeks'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(minutes2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(iSOChronology18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.Period period15 = period7.withField(durationFieldType13, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey(0L);
        boolean boolean11 = fixedDateTimeZone4.isFixed();
        int int13 = fixedDateTimeZone4.getStandardOffset((long) (byte) 1);
        java.util.TimeZone timeZone14 = fixedDateTimeZone4.toTimeZone();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Millis" + "'", str10.equals("Millis"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
        org.junit.Assert.assertNotNull(timeZone14);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test206");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        try {
//            long long10 = offsetDateTimeField4.set((-210866760000000L), "1");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for dayOfWeek must be in the range [5045,5051]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology0.minutes();
        int int6 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.DurationFieldType durationFieldType4 = null;
        boolean boolean5 = period1.isSupported(durationFieldType4);
        int int6 = period1.getMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.Period period1 = org.joda.time.Period.hours((int) (short) -1);
        org.joda.time.Period period3 = period1.withDays(5044);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (byte) 0);
        java.lang.String str2 = period1.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "PT0S" + "'", str2.equals("PT0S"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-1104537599899L), 43734096000000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-44838633599899L) + "'", long2 == (-44838633599899L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(100, 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        int int7 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.clockhourOfHalfday();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int10 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, 5044);
        org.joda.time.ReadablePartial readablePartial14 = null;
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField13.getAsShortText(readablePartial14, 100, locale16);
        int int20 = offsetDateTimeField13.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int int22 = offsetDateTimeField13.getMinimumValue(readablePartial21);
        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField13.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField24 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField8, dateTimeFieldType23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "100" + "'", str17.equals("100"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 99 + "'", int20 == 99);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5045 + "'", int22 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType23);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 5044);
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText(readablePartial6, 100, locale8);
        int int12 = offsetDateTimeField5.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField5.getMinimumValue(readablePartial13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = offsetDateTimeField5.getType();
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField16 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 99 + "'", int12 == 99);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 5045 + "'", int14 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial7 = null;
        int[] intArray14 = new int[] { '4', (short) -1, (short) 1, 350, 5044 };
        int[] intArray16 = offsetDateTimeField4.addWrapPartial(readablePartial7, 10, intArray14, (int) (short) 0);
        int int18 = offsetDateTimeField4.getMinimumValue((long) ' ');
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5045 + "'", int18 == 5045);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.Period period1 = org.joda.time.Period.weeks(350);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period3 = new org.joda.time.Period((long) (short) 10, (long) 100, periodType2);
        try {
            org.joda.time.DurationFieldType durationFieldType5 = periodType2.getFieldType(5044);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (byte) -1, 1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant0);
        org.junit.Assert.assertNotNull(chronology1);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 10);
//        long long10 = offsetDateTimeField4.add((long) (short) -1, (int) (short) 100);
//        try {
//            long long13 = offsetDateTimeField4.set(4L, "PeriodType[YearMonthDayTime]");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PeriodType[YearMonthDayTime]\" for dayOfWeek is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 8639999999L + "'", long10 == 8639999999L);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (short) 100, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 101 + "'", int2 == 101);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.centuryOfEra();
        org.joda.time.DurationField durationField7 = gregorianChronology0.minutes();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) (byte) -1, (java.lang.Number) (-210858120000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField4.getMinimumValue(readablePartial12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField4.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType14, (int) (byte) -1, 350, 5045);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [350,5045]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5045 + "'", int13 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "UTC");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.days();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology2, (java.lang.Object) 4);
        org.joda.time.Period period5 = new org.joda.time.Period(4L, periodType1, (org.joda.time.Chronology) iSOChronology2);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology2.millisOfSecond();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
//        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
//        long long22 = offsetDateTimeField4.addWrapField((long) 35, 35);
//        org.joda.time.ReadablePartial readablePartial23 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int26 = gregorianChronology25.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 5044);
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology31 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int32 = gregorianChronology31.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology31.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, 5044);
//        java.lang.String str36 = offsetDateTimeField35.getName();
//        long long38 = offsetDateTimeField35.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial39 = null;
//        int[] intArray42 = new int[] { 100, (byte) -1 };
//        int int43 = offsetDateTimeField35.getMaximumValue(readablePartial39, intArray42);
//        int int44 = offsetDateTimeField29.getMaximumValue(readablePartial30, intArray42);
//        try {
//            int[] intArray46 = offsetDateTimeField4.addWrapPartial(readablePartial23, (int) (byte) 1, intArray42, 99);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 98 for dayOfWeek must be in the range [5045,5051]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
//        org.junit.Assert.assertNotNull(gregorianChronology25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(gregorianChronology31);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "dayOfWeek" + "'", str36.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 28800000L + "'", long38 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray42);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 5051 + "'", int43 == 5051);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 5051 + "'", int44 == 5051);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        java.util.Locale locale14 = null;
//        java.lang.String str15 = offsetDateTimeField4.getAsText(35L, locale14);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        int[] intArray18 = null;
//        try {
//            int[] intArray20 = offsetDateTimeField4.addWrapField(readablePartial16, 101, intArray18, 1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "5047" + "'", str15.equals("5047"));
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        boolean boolean10 = fixedDateTimeZone4.isFixed();
        int int12 = fixedDateTimeZone4.getOffset((long) 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withSecondsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.Period period2 = org.joda.time.Period.ZERO;
        org.joda.time.Period period3 = period2.negated();
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period10 = period8.plusMillis(1);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Duration duration12 = period10.toDurationTo(readableInstant11);
        org.joda.time.Period period13 = period2.minus((org.joda.time.ReadablePeriod) period10);
        long long16 = gregorianChronology0.add((org.joda.time.ReadablePeriod) period13, (-210858120000000L), 0);
        org.joda.time.Period period18 = period13.plusMonths(5051);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-210858120000000L) + "'", long16 == (-210858120000000L));
        org.junit.Assert.assertNotNull(period18);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField4.getMaximumValue(readablePartial6);
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField4.getAsShortText(101, locale9);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5051 + "'", int7 == 5051);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "101" + "'", str10.equals("101"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("52", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 5044, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5043L + "'", long2 == 5043L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        boolean boolean2 = period0.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period3 = period0.normalizedStandard();
        org.joda.time.Period period5 = period3.withWeeks(1);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType3 = periodType2.withWeeksRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withHoursRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 7, 12783L, periodType3);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField4.getMinimumValue(readablePartial12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField4.getType();
        java.lang.String str16 = offsetDateTimeField4.getAsShortText((long) (-1));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5045 + "'", int13 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "5047" + "'", str16.equals("5047"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        int int13 = period12.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology0.getZone();
        try {
            long long16 = gregorianChronology0.getDateTimeMillis(5044, 0, 100, (int) (short) 10, 5045, 10, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5045 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("+00:00:00.100");
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210863736000000L) + "'", long1 == (-210863736000000L));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("5047", (int) (byte) 1, (int) (short) 100, 5045);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1 for 5047 must be in the range [100,5045]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 1, 0L, periodType4);
        org.joda.time.Period period6 = period1.withPeriodType(periodType4);
        int int7 = period6.getMonths();
        try {
            org.joda.time.Period period9 = period6.plusDays(350);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.Period period0 = new org.joda.time.Period();
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Duration duration2 = period0.toDurationFrom(readableInstant1);
        org.junit.Assert.assertNotNull(duration2);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.Period period8 = new org.joda.time.Period(35, (int) (short) 0, 100, (int) 'a', 99, 5045, 5045, (int) (short) 10);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfEra();
        org.joda.time.ReadablePartial readablePartial5 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int7 = gregorianChronology6.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, 5044);
        org.joda.time.DurationField durationField11 = offsetDateTimeField10.getLeapDurationField();
        int int12 = offsetDateTimeField10.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial13 = null;
        int[] intArray20 = new int[] { '4', (short) -1, (short) 1, 350, 5044 };
        int[] intArray22 = offsetDateTimeField10.addWrapPartial(readablePartial13, 10, intArray20, (int) (short) 0);
        try {
            gregorianChronology0.validate(readablePartial5, intArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNull(durationField11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8) + "'", int1 == (-8));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        org.joda.time.PeriodType periodType4 = null;
        org.joda.time.ReadableInterval readableInterval5 = null;
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval5);
        org.joda.time.Period period7 = new org.joda.time.Period(0L, 10L, periodType4, chronology6);
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.millis();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(1L, periodType9, chronology10);
        org.joda.time.Period period12 = period7.withPeriodType(periodType9);
        boolean boolean13 = period1.equals((java.lang.Object) period12);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType1 = periodType0.withWeeksRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean4 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology2, (java.lang.Object) 4);
        org.joda.time.Chronology chronology5 = iSOChronology2.withUTC();
        org.joda.time.DurationField durationField6 = iSOChronology2.minutes();
        boolean boolean7 = periodType1.equals((java.lang.Object) iSOChronology2);
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.ReadableInterval readableInterval11 = null;
        org.joda.time.Chronology chronology12 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Period period13 = new org.joda.time.Period(0L, 10L, periodType10, chronology12);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.millis();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(1L, periodType15, chronology16);
        org.joda.time.Period period18 = period13.withPeriodType(periodType15);
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField20 = iSOChronology19.centuries();
        try {
            org.joda.time.Period period21 = new org.joda.time.Period((java.lang.Object) periodType1, periodType15, (org.joda.time.Chronology) iSOChronology19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(durationField20);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Weeks", (java.lang.Number) 1L, (java.lang.Number) 0, (java.lang.Number) (-210858120000000L));
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        java.lang.String str6 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        org.joda.time.DurationField durationField6 = offsetDateTimeField4.getDurationField();
        long long9 = durationField6.subtract((-1104537599999L), (int) (short) 0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104537599999L) + "'", long9 == (-1104537599999L));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "ZonedChronology[GregorianChronology[UTC], UTC]");
        org.joda.time.DurationFieldType durationFieldType3 = illegalFieldValueException2.getDurationFieldType();
        org.junit.Assert.assertNull(durationFieldType3);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            long long3 = gregorianChronology0.set(readablePartial1, 12783L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 1, 0L, periodType4);
        org.joda.time.Period period6 = period1.withPeriodType(periodType4);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int8 = gregorianChronology7.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, 5044);
        org.joda.time.DurationField durationField12 = offsetDateTimeField11.getLeapDurationField();
        int int13 = offsetDateTimeField11.getMaximumValue();
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray21 = new int[] { '4', (short) -1, (short) 1, 350, 5044 };
        int[] intArray23 = offsetDateTimeField11.addWrapPartial(readablePartial14, 10, intArray21, (int) (short) 0);
        boolean boolean24 = period6.equals((java.lang.Object) intArray21);
        org.joda.time.Seconds seconds25 = period6.toStandardSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNull(durationField12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5051 + "'", int13 == 5051);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(seconds25);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
//        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
//        long long21 = offsetDateTimeField4.roundCeiling(100L);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField4.getAsShortText((long) 5044, locale23);
//        boolean boolean26 = offsetDateTimeField4.isLeap((-1104451199899L));
//        java.util.Locale locale27 = null;
//        int int28 = offsetDateTimeField4.getMaximumTextLength(locale27);
//        java.lang.String str29 = offsetDateTimeField4.getName();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800000L + "'", long21 == 28800000L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "5047" + "'", str24.equals("5047"));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "dayOfWeek" + "'", str29.equals("dayOfWeek"));
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        long long36 = dividedDateTimeField33.getDifferenceAsLong(1560626720050L, 28800350L);
        org.joda.time.ReadablePartial readablePartial37 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology39 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField40 = gregorianChronology39.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology45 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology41, dateTimeZone44);
        org.joda.time.Chronology chronology46 = gregorianChronology39.withZone(dateTimeZone44);
        org.joda.time.Period period47 = org.joda.time.Period.ZERO;
        boolean boolean49 = period47.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period50 = period47.normalizedStandard();
        org.joda.time.Duration duration51 = period47.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant52 = null;
        org.joda.time.Period period53 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration51, readableInstant52);
        org.joda.time.MutablePeriod mutablePeriod54 = period53.toMutablePeriod();
        org.joda.time.DurationFieldType durationFieldType55 = null;
        boolean boolean56 = period53.isSupported(durationFieldType55);
        int[] intArray59 = gregorianChronology39.get((org.joda.time.ReadablePeriod) period53, (-1104451199899L), (long) 99);
        try {
            int[] intArray61 = dividedDateTimeField33.addWrapPartial(readablePartial37, 0, intArray59, (-8));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 26 for dayOfWeek must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 182L + "'", long36 == 182L);
        org.junit.Assert.assertNotNull(gregorianChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(zonedChronology45);
        org.junit.Assert.assertNotNull(chronology46);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(period50);
        org.junit.Assert.assertNotNull(duration51);
        org.junit.Assert.assertNotNull(mutablePeriod54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(intArray59);
    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test262");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str1 = iSOChronology0.toString();
//        org.joda.time.DurationField durationField2 = iSOChronology0.weeks();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str1.equals("ISOChronology[America/Los_Angeles]"));
//        org.junit.Assert.assertNotNull(durationField2);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        org.joda.time.Period period3 = period1.minusDays((int) (byte) 1);
        org.joda.time.Period period5 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period7 = period5.withSeconds((int) '#');
        org.joda.time.Period period9 = period5.withHours((int) ' ');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone14 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int16 = fixedDateTimeZone14.getOffset(0L);
        int int18 = fixedDateTimeZone14.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone19 = fixedDateTimeZone14.toTimeZone();
        boolean boolean20 = period9.equals((java.lang.Object) fixedDateTimeZone14);
        boolean boolean21 = period1.equals((java.lang.Object) boolean20);
        org.joda.time.Period period23 = period1.plusYears((int) (byte) 1);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
        org.junit.Assert.assertNotNull(timeZone19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(period23);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number3 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 101, (java.lang.Number) 1, number3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        int int1 = periodType0.size();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.years();
        org.joda.time.Period period3 = new org.joda.time.Period((long) (byte) -1, 0L, periodType2);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType1 = periodType0.withMinutesRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withMonthsRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone17 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone16);
        java.lang.String str19 = cachedDateTimeZone17.getNameKey((long) (short) -1);
        int int21 = cachedDateTimeZone17.getOffset((-210858120000000L));
        boolean boolean22 = scaledDurationField12.equals((java.lang.Object) (-210858120000000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(cachedDateTimeZone17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UTC" + "'", str19.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        try {
            int int6 = period4.getValue((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("ISOChronology[America/Los_Angeles]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"ISOChronology[America/Los_Angeles]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("LenientChronology[GregorianChronology[America/Los_Angeles]]", number1, (java.lang.Number) (-210858120000000L), (java.lang.Number) 35);
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
        int int6 = cachedDateTimeZone2.getOffset((-210858120000000L));
        int int8 = cachedDateTimeZone2.getOffset(720000000L);
        long long10 = cachedDateTimeZone2.nextTransition((long) 10);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) -1, (int) (byte) 10, (int) (byte) 10, (int) (byte) 1, 1, (int) (byte) -1, (int) (short) -1, 4);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DurationField durationField6 = zonedChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology4.secondOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) (byte) -1, (int) (byte) 10, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for secondOfDay must be in the range [10,100]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.junit.Assert.assertNotNull(periodType0);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
//        java.lang.String str4 = lenientChronology3.toString();
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        try {
//            int[] intArray7 = lenientChronology3.get(readablePartial5, (-210858120000000L));
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(lenientChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LenientChronology[GregorianChronology[America/Los_Angeles]]" + "'", str4.equals("LenientChronology[GregorianChronology[America/Los_Angeles]]"));
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, (long) 100, chronology3);
        int int5 = period4.size();
        org.joda.time.Period period7 = period4.minusYears((int) (short) 1);
        org.joda.time.Period period9 = period7.plusMonths(5051);
        org.joda.time.Period period11 = period9.minusMonths(0);
        org.joda.time.Period period13 = period9.minusDays(0);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone8 = gregorianChronology0.getZone();
        try {
            long long13 = gregorianChronology0.getDateTimeMillis(10, (int) (short) 100, (int) (short) -1, 350);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DurationField durationField6 = zonedChronology4.minutes();
        org.joda.time.DateTimeField dateTimeField7 = zonedChronology4.secondOfDay();
        org.joda.time.Chronology chronology8 = zonedChronology4.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "LenientChronology[GregorianChronology[America/Los_Angeles]]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "ZonedChronology[GregorianChronology[UTC], UTC]");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        illegalFieldValueException2.prependMessage("5047");
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException2.getDateTimeFieldType();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(dateTimeFieldType7);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        long long8 = offsetDateTimeField4.add((long) ' ', (long) 8);
        org.joda.time.DurationField durationField9 = offsetDateTimeField4.getLeapDurationField();
        java.lang.String str10 = offsetDateTimeField4.toString();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType12 = periodType11.withWeeksRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology13, (java.lang.Object) 4);
        org.joda.time.Chronology chronology16 = iSOChronology13.withUTC();
        org.joda.time.DurationField durationField17 = iSOChronology13.minutes();
        boolean boolean18 = periodType12.equals((java.lang.Object) iSOChronology13);
        org.joda.time.PeriodType periodType19 = periodType12.withMonthsRemoved();
        try {
            org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) str10, periodType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[dayOfWeek]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 691200032L + "'", long8 == 691200032L);
        org.junit.Assert.assertNull(durationField9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTimeField[dayOfWeek]" + "'", str10.equals("DateTimeField[dayOfWeek]"));
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(periodType19);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(0, 35, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.DurationField durationField29 = null;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField30 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType2 = periodType1.withWeeksRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology3, (java.lang.Object) 4);
        org.joda.time.Chronology chronology6 = iSOChronology3.withUTC();
        org.joda.time.DurationField durationField7 = iSOChronology3.minutes();
        boolean boolean8 = periodType2.equals((java.lang.Object) iSOChronology3);
        org.joda.time.PeriodType periodType9 = periodType2.withMonthsRemoved();
        org.joda.time.ReadableInterval readableInterval10 = null;
        org.joda.time.ReadableInterval readableInterval11 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval10);
        org.joda.time.ReadableInterval readableInterval12 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval11);
        org.joda.time.ReadableInterval readableInterval13 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval11);
        org.joda.time.Chronology chronology14 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval11);
        try {
            org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) 28800350L, periodType2, chronology15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(readableInterval11);
        org.junit.Assert.assertNotNull(readableInterval12);
        org.junit.Assert.assertNotNull(readableInterval13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey((long) (short) -1);
        int int11 = cachedDateTimeZone7.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology12 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DurationField durationField13 = gregorianChronology0.seconds();
        long long17 = gregorianChronology0.add((long) 7, 0L, 10);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 7L + "'", long17 == 7L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 1, 0L, periodType4);
        org.joda.time.Period period6 = period1.withPeriodType(periodType4);
        org.joda.time.Period period8 = period1.withYears((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = org.joda.time.Period.ZERO;
        boolean boolean12 = period10.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period13 = period10.normalizedStandard();
        org.joda.time.Duration duration14 = period10.toStandardDuration();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant9, (org.joda.time.ReadableDuration) duration14, periodType15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant17);
        org.joda.time.Period period19 = period8.plus((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period21 = period8.plusWeeks(350);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
//        int int6 = offsetDateTimeField4.getMaximumValue();
//        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
//        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
//        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
//        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
//        org.joda.time.ReadablePartial readablePartial36 = null;
//        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
//        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
//        long long46 = remainderDateTimeField42.roundFloor(43734096000000L);
//        long long48 = remainderDateTimeField42.roundCeiling((-210866760000000L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8668800000L + "'", long44 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43734067200000L + "'", long46 == 43734067200000L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-210866688422000L) + "'", long48 == (-210866688422000L));
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.minusSeconds(350);
        org.joda.time.Period period5 = period3.withMinutes((int) '#');
        org.joda.time.Duration duration6 = period5.toStandardDuration();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration6);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = cachedDateTimeZone2.getMillisKeepLocal(dateTimeZone3, 0L);
//        int int7 = cachedDateTimeZone2.getStandardOffset((long) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        java.lang.String str10 = dateTimeZone9.toString();
//        long long12 = cachedDateTimeZone2.getMillisKeepLocal(dateTimeZone9, (long) 350);
//        java.lang.String str13 = dateTimeZone9.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800000L + "'", long5 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800350L + "'", long12 == 28800350L);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "America/Los_Angeles" + "'", str13.equals("America/Los_Angeles"));
//    }

//    @Test
//    public void test296() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test296");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = cachedDateTimeZone2.getMillisKeepLocal(dateTimeZone3, 0L);
//        int int7 = cachedDateTimeZone2.getStandardOffset((long) (short) 10);
//        org.joda.time.DateTimeZone dateTimeZone8 = null;
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
//        java.lang.String str10 = dateTimeZone9.toString();
//        long long12 = cachedDateTimeZone2.getMillisKeepLocal(dateTimeZone9, (long) 350);
//        org.joda.time.ReadableInstant readableInstant13 = null;
//        int int14 = dateTimeZone9.getOffset(readableInstant13);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800000L + "'", long5 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800350L + "'", long12 == 28800350L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
//    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Chronology chronology7 = gregorianChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology0.yearOfCentury();
        org.joda.time.ReadablePartial readablePartial9 = null;
        try {
            int[] intArray11 = gregorianChronology0.get(readablePartial9, 1560626720050L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.Period period4 = new org.joda.time.Period((int) '#', 10, 350, (int) (short) 10);
        java.lang.String str5 = period4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PT35H10M350.010S" + "'", str5.equals("PT35H10M350.010S"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField4.getMaximumValue(readablePartial6);
        long long10 = offsetDateTimeField4.getDifferenceAsLong(0L, 0L);
        org.joda.time.ReadablePartial readablePartial11 = null;
        java.util.Locale locale12 = null;
        try {
            java.lang.String str13 = offsetDateTimeField4.getAsText(readablePartial11, locale12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5051 + "'", int7 == 5051);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test300");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
//        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology0.centuryOfEra();
//        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.dayOfWeek();
//        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int9 = gregorianChronology8.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology8.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, 5044);
//        java.lang.String str13 = offsetDateTimeField12.getName();
//        long long15 = offsetDateTimeField12.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial16 = null;
//        int[] intArray19 = new int[] { 100, (byte) -1 };
//        int int20 = offsetDateTimeField12.getMaximumValue(readablePartial16, intArray19);
//        org.joda.time.ReadablePartial readablePartial21 = null;
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField12.getAsShortText(readablePartial21, (int) '4', locale23);
//        long long27 = offsetDateTimeField12.add(28800000L, (int) (byte) 100);
//        long long30 = offsetDateTimeField12.addWrapField((long) 35, 35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType31 = offsetDateTimeField12.getType();
//        try {
//            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField32 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField7, dateTimeFieldType31);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(zonedChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(gregorianChronology8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField10);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "dayOfWeek" + "'", str13.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800000L + "'", long15 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5051 + "'", int20 == 5051);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "52" + "'", str24.equals("52"));
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 8668800000L + "'", long27 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 35L + "'", long30 == 35L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType31);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.withSeconds((int) '#');
        org.joda.time.Period period5 = period1.withHours((int) ' ');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int12 = fixedDateTimeZone10.getOffset(0L);
        int int14 = fixedDateTimeZone10.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone15 = fixedDateTimeZone10.toTimeZone();
        boolean boolean16 = period5.equals((java.lang.Object) fixedDateTimeZone10);
        java.util.TimeZone timeZone17 = fixedDateTimeZone10.toTimeZone();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone17);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) 'a');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("52", (int) 'a', 105, (int) (short) 10, '#', 0, (int) (short) -1, (int) (short) -1, false, 1);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder21 = dateTimeZoneBuilder13.addCutover((int) '4', 'a', 5045, (int) (byte) -1, (int) (short) 100, false, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: a");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            int int22 = unsupportedDurationField20.getValue((long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = zonedChronology4.year();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone8 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        org.joda.time.Chronology chronology9 = zonedChronology4.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = zonedChronology4.dayOfWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(cachedDateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("Weeks", (java.lang.Number) 1L, (java.lang.Number) 0, (java.lang.Number) (-210858120000000L));
        illegalFieldValueException4.prependMessage("");
        java.lang.String str7 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str8 = illegalFieldValueException4.getFieldName();
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Weeks" + "'", str8.equals("Weeks"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            long long23 = unsupportedDurationField20.add((long) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.ReadableInterval readableInterval2 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-1), 35, 99);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 64 + "'", int3 == 64);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.days();
        org.joda.time.PeriodType periodType3 = periodType2.withMinutesRemoved();
        int int4 = periodType2.size();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.ReadableInterval readableInterval1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Period period3 = new org.joda.time.Period((-1104537599999L), chronology2);
        org.joda.time.Period period5 = period3.plusMinutes(8);
        try {
            int int7 = period3.getValue((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period5);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test311");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
//        int int6 = offsetDateTimeField4.getMaximumValue();
//        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
//        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
//        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
//        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
//        org.joda.time.ReadablePartial readablePartial36 = null;
//        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
//        long long44 = remainderDateTimeField42.roundHalfFloor(8639999999L);
//        try {
//            long long47 = remainderDateTimeField42.set((-210866688422000L), (-1));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [0,99]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8668800000L + "'", long44 == 8668800000L);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("5047", (java.lang.Number) (-1104537599999L), (java.lang.Number) 8, (java.lang.Number) 1560626719070L);
        illegalFieldValueException4.prependMessage("ZonedChronology[GregorianChronology[UTC], UTC]");
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.minuteOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField2, (int) (short) 0, 99, (-8));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for minuteOfDay must be in the range [99,-8]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test314");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
//        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
//        org.joda.time.ReadablePartial readablePartial20 = null;
//        int[] intArray21 = null;
//        int int22 = offsetDateTimeField4.getMaximumValue(readablePartial20, intArray21);
//        java.lang.String str23 = offsetDateTimeField4.getName();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5051 + "'", int22 == 5051);
//        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "dayOfWeek" + "'", str23.equals("dayOfWeek"));
//    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        int int13 = offsetDateTimeField4.getMaximumValue();
//        boolean boolean14 = offsetDateTimeField4.isSupported();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5051 + "'", int13 == 5051);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            int int23 = unsupportedDurationField20.getDifference(0L, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = zonedChronology4.yearOfEra();
        try {
            long long10 = zonedChronology4.getDateTimeMillis(101, (-1), 10, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        long long36 = dividedDateTimeField33.getDifferenceAsLong(1560626720050L, 28800350L);
        int int39 = dividedDateTimeField33.getDifference(86400000L, (-4L));
        java.util.Locale locale40 = null;
        int int41 = dividedDateTimeField33.getMaximumShortTextLength(locale40);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 182L + "'", long36 == 182L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        try {
            long long36 = dividedDateTimeField33.set(12783L, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2 for dayOfWeek must be in the range [0,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        try {
            long long35 = dividedDateTimeField33.roundFloor(691200032L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
//        int int6 = offsetDateTimeField4.getMaximumValue();
//        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
//        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
//        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
//        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
//        org.joda.time.ReadablePartial readablePartial36 = null;
//        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
//        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
//        java.lang.String str46 = remainderDateTimeField42.getAsShortText((long) 7);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8668800000L + "'", long44 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "47" + "'", str46.equals("47"));
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException21 = new org.joda.time.IllegalFieldValueException(durationFieldType18, "America/Los_Angeles");
        org.joda.time.DateTimeFieldType dateTimeFieldType22 = illegalFieldValueException21.getDateTimeFieldType();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNull(dateTimeFieldType22);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.Period period1 = org.joda.time.Period.days((-1));
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test324");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
//        int int6 = offsetDateTimeField4.getMaximumValue();
//        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
//        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
//        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
//        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
//        org.joda.time.ReadablePartial readablePartial36 = null;
//        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
//        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
//        java.util.Locale locale45 = null;
//        int int46 = remainderDateTimeField42.getMaximumTextLength(locale45);
//        org.joda.time.ReadablePartial readablePartial47 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int50 = gregorianChronology49.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField51 = gregorianChronology49.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, 5044);
//        org.joda.time.DurationField durationField54 = offsetDateTimeField53.getLeapDurationField();
//        int int55 = offsetDateTimeField53.getMaximumValue();
//        org.joda.time.ReadablePartial readablePartial56 = null;
//        int[] intArray63 = new int[] { '4', (short) -1, (short) 1, 350, 5044 };
//        int[] intArray65 = offsetDateTimeField53.addWrapPartial(readablePartial56, 10, intArray63, (int) (short) 0);
//        try {
//            int[] intArray67 = remainderDateTimeField42.addWrapField(readablePartial47, (-1), intArray63, 2);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8668800000L + "'", long44 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 2 + "'", int46 == 2);
//        org.junit.Assert.assertNotNull(gregorianChronology49);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField51);
//        org.junit.Assert.assertNull(durationField54);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 5051 + "'", int55 == 5051);
//        org.junit.Assert.assertNotNull(intArray63);
//        org.junit.Assert.assertNotNull(intArray65);
//    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DurationField durationField4 = gregorianChronology0.minutes();
        org.joda.time.DurationField durationField5 = gregorianChronology0.millis();
        org.joda.time.chrono.LenientChronology lenientChronology6 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(lenientChronology6);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        org.joda.time.DurationField durationField43 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField45 = gregorianChronology44.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology48 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology44, dateTimeZone47);
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone51 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone50);
        java.lang.String str53 = cachedDateTimeZone51.getNameKey((long) (short) -1);
        int int55 = cachedDateTimeZone51.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology56 = gregorianChronology44.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone51);
        org.joda.time.DurationField durationField57 = gregorianChronology44.seconds();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField58 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType38, durationField43, durationField57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertNotNull(dateTimeField45);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(zonedChronology48);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(cachedDateTimeZone51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "UTC" + "'", str53.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(chronology56);
        org.junit.Assert.assertNotNull(durationField57);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey((long) (short) -1);
        int int11 = cachedDateTimeZone7.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology12 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        boolean boolean13 = cachedDateTimeZone7.isFixed();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        long long36 = dividedDateTimeField33.getDifferenceAsLong(1560626720050L, 28800350L);
        org.joda.time.DateTimeFieldType dateTimeFieldType37 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField33, dateTimeFieldType37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 182L + "'", long36 == 182L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
        int int6 = cachedDateTimeZone2.getStandardOffset((-1104537599999L));
        boolean boolean7 = cachedDateTimeZone2.isFixed();
        java.lang.String str9 = cachedDateTimeZone2.getNameKey(43734096000000L);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        int int1 = period0.getSeconds();
        int int2 = period0.getSeconds();
        org.joda.time.Seconds seconds3 = period0.toStandardSeconds();
        org.joda.time.Period period5 = period0.plusYears((int) (short) 10);
        org.joda.time.Period period7 = period0.minusMillis((-28800000));
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(seconds3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(0L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-100L) + "'", long2 == (-100L));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period6 = period4.plusMillis(1);
        org.joda.time.Period period8 = period6.withSeconds((int) (byte) 100);
        int int9 = period6.getWeeks();
        org.joda.time.Period period10 = period6.negated();
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.yearMonthDayTime();
        java.lang.String str12 = periodType11.getName();
        org.joda.time.Period period13 = period10.normalizedStandard(periodType11);
        org.joda.time.Period period15 = period10.minusMonths(5051);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "YearMonthDayTime" + "'", str12.equals("YearMonthDayTime"));
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            int int22 = unsupportedDurationField20.getValue((long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        int int8 = period7.getMonths();
        org.joda.time.Period period10 = period7.withDays((-28800000));
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis((-1));
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
//        java.lang.String str6 = cachedDateTimeZone2.getName((-210866760000000L));
//        org.joda.time.Period period12 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
//        org.joda.time.Period period14 = period12.plusMillis(1);
//        org.joda.time.Period period16 = period14.withSeconds((int) (byte) 100);
//        int int17 = period14.getWeeks();
//        org.joda.time.Period period18 = period14.negated();
//        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.yearMonthDayTime();
//        java.lang.String str20 = periodType19.getName();
//        org.joda.time.Period period21 = period18.normalizedStandard(periodType19);
//        org.joda.time.Period period22 = new org.joda.time.Period(86400000L, periodType19);
//        boolean boolean23 = cachedDateTimeZone2.equals((java.lang.Object) 86400000L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Coordinated Universal Time" + "'", str6.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertNotNull(period14);
//        org.junit.Assert.assertNotNull(period16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertNotNull(period18);
//        org.junit.Assert.assertNotNull(periodType19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "YearMonthDayTime" + "'", str20.equals("YearMonthDayTime"));
//        org.junit.Assert.assertNotNull(period21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        try {
            long long45 = unsupportedDateTimeField43.roundCeiling((long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        java.lang.String str9 = cachedDateTimeZone7.getNameKey((long) (short) -1);
        int int11 = cachedDateTimeZone7.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology12 = gregorianChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology0.weekyearOfCentury();
        int int14 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UTC" + "'", str9.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.withSeconds((int) '#');
        org.joda.time.Period period5 = period1.withHours((int) ' ');
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone10 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int12 = fixedDateTimeZone10.getOffset(0L);
        int int14 = fixedDateTimeZone10.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone15 = fixedDateTimeZone10.toTimeZone();
        boolean boolean16 = period5.equals((java.lang.Object) fixedDateTimeZone10);
        java.util.TimeZone timeZone17 = fixedDateTimeZone10.toTimeZone();
        int int19 = fixedDateTimeZone10.getStandardOffset(0L);
        java.util.TimeZone timeZone20 = fixedDateTimeZone10.toTimeZone();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertNotNull(timeZone20);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.ReadableInterval readableInterval3 = null;
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval3);
        org.joda.time.Period period5 = new org.joda.time.Period(0L, 10L, periodType2, chronology4);
        org.joda.time.DurationFieldType durationFieldType6 = null;
        boolean boolean7 = period5.isSupported(durationFieldType6);
        org.joda.time.Period period9 = period5.plusSeconds((int) (short) 100);
        int int10 = period9.size();
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
//        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
//        long long22 = offsetDateTimeField4.addWrapField((long) 35, 35);
//        try {
//            long long25 = offsetDateTimeField4.set(4999L, (-28800000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for dayOfWeek must be in the range [5045,5051]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        try {
            int int46 = unsupportedDateTimeField43.getLeapAmount((long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            long long23 = unsupportedDurationField20.getValueAsLong(3541001L, (-1104537599899L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        try {
            int int45 = unsupportedDateTimeField43.getMinimumValue((long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
//        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
//        long long22 = offsetDateTimeField4.addWrapField((long) 35, 35);
//        org.joda.time.DateTimeFieldType dateTimeFieldType23 = offsetDateTimeField4.getType();
//        try {
//            long long26 = offsetDateTimeField4.set(10L, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for dayOfWeek must be in the range [5045,5051]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 35L + "'", long22 == 35L);
//        org.junit.Assert.assertNotNull(dateTimeFieldType23);
//    }

//    @Test
//    public void test349() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test349");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 10);
//        long long10 = offsetDateTimeField4.add((long) (short) -1, (int) (short) 100);
//        long long12 = offsetDateTimeField4.roundHalfEven(0L);
//        int int13 = offsetDateTimeField4.getMaximumValue();
//        long long16 = offsetDateTimeField4.add(5043L, (long) (short) 0);
//        long long18 = offsetDateTimeField4.roundFloor((long) '4');
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 8639999999L + "'", long10 == 8639999999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 28800000L + "'", long12 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5051 + "'", int13 == 5051);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 5043L + "'", long16 == 5043L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-57600000L) + "'", long18 == (-57600000L));
//    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
//        int int6 = offsetDateTimeField4.getMaximumValue();
//        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
//        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
//        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
//        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
//        org.joda.time.ReadablePartial readablePartial36 = null;
//        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
//        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
//        long long46 = remainderDateTimeField42.roundFloor(43734096000000L);
//        try {
//            long long49 = remainderDateTimeField42.set(0L, (int) 'a');
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 5097 for dayOfWeek must be in the range [5045,5051]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8668800000L + "'", long44 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 43734067200000L + "'", long46 == 43734067200000L);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period3 = new org.joda.time.Period((long) 1, 0L, periodType2);
        try {
            org.joda.time.Period period5 = period3.minusHours(7);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.Period period8 = new org.joda.time.Period((int) (byte) 100, 100, 2, 105, (int) '4', (int) (byte) 1, 4, 8);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            long long23 = unsupportedDurationField20.getValueAsLong(4999L, 182L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology4.getZone();
        long long12 = zonedChronology4.getDateTimeMillis(10L, 1, (int) (short) 1, 0, 105);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology4.halfdayOfDay();
        org.joda.time.DurationField durationField14 = zonedChronology4.years();
        org.joda.time.DurationFieldType durationFieldType15 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField16 = new org.joda.time.field.DecoratedDurationField(durationField14, durationFieldType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3660105L + "'", long12 == 3660105L);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 99);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        org.joda.time.ReadablePartial readablePartial45 = null;
        java.util.Locale locale46 = null;
        try {
            java.lang.String str47 = unsupportedDateTimeField43.getAsShortText(readablePartial45, locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        try {
            long long47 = unsupportedDateTimeField43.roundCeiling(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean36 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology34, (java.lang.Object) 4);
        org.joda.time.Chronology chronology37 = iSOChronology34.withUTC();
        org.joda.time.DurationField durationField38 = iSOChronology34.minutes();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone41 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone40);
        org.joda.time.Chronology chronology42 = iSOChronology34.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology34.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology44 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int45 = gregorianChronology44.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology44.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, 5044);
        org.joda.time.ReadablePartial readablePartial49 = null;
        java.util.Locale locale51 = null;
        java.lang.String str52 = offsetDateTimeField48.getAsShortText(readablePartial49, 100, locale51);
        int int55 = offsetDateTimeField48.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial56 = null;
        int int57 = offsetDateTimeField48.getMinimumValue(readablePartial56);
        org.joda.time.DateTimeFieldType dateTimeFieldType58 = offsetDateTimeField48.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField60 = new org.joda.time.field.DividedDateTimeField(dateTimeField43, dateTimeFieldType58, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField33, dateTimeFieldType58, 100);
        try {
            long long65 = dividedDateTimeField33.addWrapField(86400000L, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(chronology37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(cachedDateTimeZone41);
        org.junit.Assert.assertNotNull(chronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(gregorianChronology44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "100" + "'", str52.equals("100"));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 99 + "'", int55 == 99);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 5045 + "'", int57 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType58);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.lang.String str10 = fixedDateTimeZone4.getNameKey(0L);
        int int12 = fixedDateTimeZone4.getOffset((long) 35);
        java.util.TimeZone timeZone13 = fixedDateTimeZone4.toTimeZone();
        boolean boolean14 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Millis" + "'", str10.equals("Millis"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 100 + "'", int12 == 100);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(105, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 106 + "'", int2 == 106);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        org.joda.time.ReadablePartial readablePartial6 = null;
//        int int7 = offsetDateTimeField4.getMaximumValue(readablePartial6);
//        long long10 = offsetDateTimeField4.getDifferenceAsLong(0L, 0L);
//        java.util.Locale locale11 = null;
//        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
//        long long14 = offsetDateTimeField4.roundCeiling((-210858120000000L));
//        java.lang.String str15 = offsetDateTimeField4.getName();
//        try {
//            long long18 = offsetDateTimeField4.set((-210866760000000L), (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [5045,5051]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5051 + "'", int7 == 5051);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-210858048422000L) + "'", long14 == (-210858048422000L));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "dayOfWeek" + "'", str15.equals("dayOfWeek"));
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Period period2 = org.joda.time.Period.ZERO;
        boolean boolean4 = period2.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period5 = period2.normalizedStandard();
        org.joda.time.Duration duration6 = period2.toStandardDuration();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration6, periodType7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType11 = periodType10.withWeeksRemoved();
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant9, periodType10);
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean15 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology13, (java.lang.Object) 4);
        org.joda.time.Chronology chronology16 = iSOChronology13.withUTC();
        org.joda.time.DurationField durationField17 = iSOChronology13.minutes();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone20 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone19);
        org.joda.time.Chronology chronology21 = iSOChronology13.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology13.clockhourOfDay();
        org.joda.time.Period period23 = new org.joda.time.Period((long) 105, periodType10, (org.joda.time.Chronology) iSOChronology13);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology13.weekyear();
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(cachedDateTimeZone20);
        org.junit.Assert.assertNotNull(chronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertNotNull(dateTimeField24);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("hi!", "ZonedChronology[GregorianChronology[UTC], UTC]");
        java.lang.Throwable[] throwableArray3 = illegalFieldValueException2.getSuppressed();
        boolean boolean4 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException2);
        java.lang.String str5 = illegalFieldValueException2.getFieldName();
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("UTC", (java.lang.Number) (-100L), (java.lang.Number) 35L, (java.lang.Number) (-4L));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        java.util.Locale locale45 = null;
        try {
            java.lang.String str46 = unsupportedDateTimeField43.getAsShortText((long) 106, locale45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        try {
            long long45 = unsupportedDateTimeField43.roundHalfFloor((-210863736000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        long long36 = dividedDateTimeField33.getDifferenceAsLong(1560626720050L, 28800350L);
        int int37 = dividedDateTimeField33.getDivisor();
        try {
            long long39 = dividedDateTimeField33.roundFloor(1L);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 182L + "'", long36 == 182L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 99 + "'", int37 == 99);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean21 = unsupportedDurationField20.isPrecise();
        try {
            long long23 = unsupportedDurationField20.getMillis((long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.clockhourOfDay();
        org.joda.time.ReadableInterval readableInterval12 = null;
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval12);
        org.joda.time.Period period14 = new org.joda.time.Period((long) (short) -1, (long) 100, chronology13);
        int int15 = period14.size();
        org.joda.time.Period period16 = period14.negated();
        org.joda.time.Period period18 = period14.plusHours(0);
        org.joda.time.Period period20 = org.joda.time.Period.seconds((int) (byte) -1);
        org.joda.time.Period period21 = period18.minus((org.joda.time.ReadablePeriod) period20);
        long long24 = iSOChronology0.add((org.joda.time.ReadablePeriod) period21, (-210858048422000L), (int) (byte) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 8 + "'", int15 == 8);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-210858048410990L) + "'", long24 == (-210858048410990L));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.joda.time.field.FieldUtils.verifyValueBounds("", (-8), (-8), 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("ISOChronology[America/Los_Angeles]", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) (short) 0, 110449332000000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(2);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        java.util.Locale locale48 = null;
        try {
            long long49 = unsupportedDateTimeField43.set((long) (byte) 100, "UTC", locale48);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        org.joda.time.ReadablePartial readablePartial45 = null;
        java.util.Locale locale47 = null;
        try {
            java.lang.String str48 = unsupportedDateTimeField43.getAsShortText(readablePartial45, 0, locale47);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.year();
        org.joda.time.DurationField durationField4 = gregorianChronology0.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.clockhourOfHalfday();
        try {
            long long10 = gregorianChronology0.getDateTimeMillis(35, (int) (byte) 100, 100, 101);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) 1, 0, (int) (byte) 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, 5044);
        org.joda.time.ReadablePartial readablePartial6 = null;
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField5.getAsShortText(readablePartial6, 100, locale8);
        int int12 = offsetDateTimeField5.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 5044);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField17.getAsShortText(readablePartial18, 100, locale20);
        int int24 = offsetDateTimeField17.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int int26 = offsetDateTimeField17.getMinimumValue(readablePartial25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField17.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType27, 7);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "100" + "'", str9.equals("100"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 99 + "'", int12 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "100" + "'", str21.equals("100"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 99 + "'", int24 == 99);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5045 + "'", int26 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) 'a');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setFixedSavings("47", 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder5.setFixedSavings("1", 0);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        try {
            int int46 = unsupportedDateTimeField43.getMaximumValue((long) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hi!");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        try {
            int int47 = unsupportedDateTimeField43.get(691200032L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        java.util.Locale locale45 = null;
        try {
            java.lang.String str46 = unsupportedDateTimeField43.getAsShortText((int) (byte) 10, locale45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        org.joda.time.ReadablePartial readablePartial45 = null;
        java.util.Locale locale47 = null;
        try {
            java.lang.String str48 = unsupportedDateTimeField43.getAsText(readablePartial45, (int) '#', locale47);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.Period period1 = new org.joda.time.Period(0L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        java.util.Locale locale6 = null;
        int int7 = offsetDateTimeField4.getMaximumTextLength(locale6);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) (short) 10);
        org.joda.time.Period period3 = period1.withMinutes(5044);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("1");
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology0.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, 5044);
        org.joda.time.ReadablePartial readablePartial15 = null;
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField14.getAsShortText(readablePartial15, 100, locale17);
        int int21 = offsetDateTimeField14.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField14.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeFieldType dateTimeFieldType24 = offsetDateTimeField14.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField26 = new org.joda.time.field.DividedDateTimeField(dateTimeField9, dateTimeFieldType24, (int) '#');
        java.util.Locale locale29 = null;
        try {
            long long30 = dividedDateTimeField26.set(0L, "dayOfWeek", locale29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"dayOfWeek\" for dayOfWeek is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "100" + "'", str18.equals("100"));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 99 + "'", int21 == 99);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5045 + "'", int23 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType24);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((-28800000));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean21 = unsupportedDurationField20.isPrecise();
        try {
            long long23 = unsupportedDurationField20.getValueAsLong(1560626719070L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DurationField durationField4 = iSOChronology0.minutes();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone6);
        org.joda.time.Chronology chronology8 = iSOChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone7);
        java.lang.Class<?> wildcardClass9 = cachedDateTimeZone7.getClass();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        java.util.TimeZone timeZone2 = dateTimeZone1.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.withSeconds((int) '#');
        org.joda.time.Period period5 = period3.plusDays(10);
        java.lang.Object obj6 = null;
        boolean boolean7 = period3.equals(obj6);
        org.joda.time.Period period9 = period3.withMonths((int) (byte) 0);
        org.joda.time.Period period11 = period3.minusDays(7);
        org.joda.time.Period period13 = period11.multipliedBy((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int13 = scaledDurationField12.getScalar();
        long long16 = scaledDurationField12.getDifferenceAsLong((-210866673600000L), (long) 2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-66L) + "'", long16 == (-66L));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfWeek();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period((java.lang.Object) (-57600000L), (org.joda.time.Chronology) gregorianChronology1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        boolean boolean15 = scaledDurationField12.isPrecise();
        int int16 = scaledDurationField12.getScalar();
        try {
            long long19 = scaledDurationField12.getMillis((-210858120000000L), (long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -21085812000000000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(2440587.5d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period47 = org.joda.time.Period.minutes(0);
        org.joda.time.Period period49 = period47.minusDays((int) (byte) 1);
        org.joda.time.Period period51 = period49.withDays((int) '#');
        int[] intArray52 = period49.getValues();
        try {
            int int53 = unsupportedDateTimeField43.getMinimumValue(readablePartial45, intArray52);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(period47);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertNotNull(intArray52);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.ReadablePartial readablePartial44 = null;
        int[] intArray45 = null;
        try {
            int int46 = unsupportedDateTimeField43.getMaximumValue(readablePartial44, intArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        try {
            long long45 = unsupportedDateTimeField43.roundHalfEven(35L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.Period period4 = new org.joda.time.Period((int) '#', 8, 1, (-28800000));
        org.joda.time.Days days5 = period4.toStandardDays();
        org.junit.Assert.assertNotNull(days5);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 1, 0L, periodType4);
        org.joda.time.Period period6 = period1.withPeriodType(periodType4);
        int int7 = period6.getMillis();
        try {
            org.joda.time.Period period9 = period6.minusMinutes(5044);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue((int) '4', (int) (short) 10, 0, 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        boolean boolean15 = scaledDurationField12.isPrecise();
        long long17 = scaledDurationField12.getMillis(0);
        int int19 = scaledDurationField12.getValue(10L);
        long long21 = scaledDurationField12.getMillis(1);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3155695200000L + "'", long21 == 3155695200000L);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) 'a');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("52", (int) 'a', 105, (int) (short) 10, '#', 0, (int) (short) -1, (int) (short) -1, false, 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder2.setFixedSavings("PT35H10M350.010S", 1);
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder24 = dateTimeZoneBuilder2.addCutover(101, '4', (int) (byte) 100, (int) '#', 105, false, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        try {
            long long46 = unsupportedDateTimeField43.roundHalfFloor((long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        try {
            java.lang.String str46 = unsupportedDateTimeField43.getAsText((long) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.Period period1 = org.joda.time.Period.years(0);
        int int2 = period1.getSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int10 = offsetDateTimeField4.getMaximumValue(86400000L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5051 + "'", int10 == 5051);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
        int int6 = offsetDateTimeField4.getMaximumValue();
        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
        org.joda.time.ReadablePartial readablePartial29 = null;
        java.util.Locale locale31 = null;
        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial36 = null;
        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
        org.joda.time.DurationField durationField43 = offsetDateTimeField4.getDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
        org.junit.Assert.assertNotNull(durationField43);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean21 = unsupportedDurationField20.isPrecise();
        try {
            long long24 = unsupportedDurationField20.add((long) 1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 101);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500001169d + "'", double1 == 2440587.500001169d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology4.getZone();
        long long12 = zonedChronology4.getDateTimeMillis(10L, 1, (int) (short) 1, 0, 105);
        try {
            long long17 = zonedChronology4.getDateTimeMillis(2, 8, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3660105L + "'", long12 == 3660105L);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) lenientChronology3);
        org.joda.time.DateTimeField dateTimeField5 = lenientChronology4.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(lenientChronology3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period1 = period0.negated();
        org.joda.time.Period period6 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period8 = period6.plusMillis(1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Duration duration10 = period8.toDurationTo(readableInstant9);
        org.joda.time.Period period11 = period0.minus((org.joda.time.ReadablePeriod) period8);
        org.joda.time.Period period13 = period8.withSeconds(5051);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            int int22 = unsupportedDurationField20.getValue(4L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.Period period2 = org.joda.time.Period.minutes(0);
        org.joda.time.Period period4 = period2.minusDays((int) (byte) 1);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period8 = new org.joda.time.Period((long) 1, 0L, periodType7);
        org.joda.time.PeriodType periodType9 = periodType7.withSecondsRemoved();
        org.joda.time.PeriodType periodType10 = periodType9.withHoursRemoved();
        org.joda.time.DurationFieldType durationFieldType11 = null;
        boolean boolean12 = periodType9.isSupported(durationFieldType11);
        org.joda.time.PeriodType periodType13 = periodType9.withMinutesRemoved();
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.Period period15 = new org.joda.time.Period((java.lang.Object) period2, periodType13, (org.joda.time.Chronology) gregorianChronology14);
        try {
            org.joda.time.Period period16 = new org.joda.time.Period((java.lang.Object) 5043L, (org.joda.time.Chronology) gregorianChronology14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        int int10 = fixedDateTimeZone4.getStandardOffset((long) (-1));
        java.util.Locale locale12 = null;
        java.lang.String str13 = fixedDateTimeZone4.getName(3155695200000L, locale12);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.100" + "'", str13.equals("+00:00:00.100"));
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
//        long long7 = offsetDateTimeField4.roundHalfFloor(1L);
//        long long10 = offsetDateTimeField4.addWrapField((long) (short) 0, 8);
//        long long13 = offsetDateTimeField4.getDifferenceAsLong((long) 'a', (-57600000L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 86400000L + "'", long10 == 86400000L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean6 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology4, (java.lang.Object) 4);
        org.joda.time.Chronology chronology7 = iSOChronology4.withUTC();
        org.joda.time.DurationField durationField8 = iSOChronology4.weekyears();
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology4.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int11 = gregorianChronology10.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int14 = gregorianChronology13.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology13.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, 5044);
        org.joda.time.ReadablePartial readablePartial18 = null;
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField17.getAsShortText(readablePartial18, 100, locale20);
        int int24 = offsetDateTimeField17.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology25 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int26 = gregorianChronology25.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField27 = gregorianChronology25.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, 5044);
        org.joda.time.ReadablePartial readablePartial30 = null;
        java.util.Locale locale32 = null;
        java.lang.String str33 = offsetDateTimeField29.getAsShortText(readablePartial30, 100, locale32);
        int int36 = offsetDateTimeField29.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int int38 = offsetDateTimeField29.getMinimumValue(readablePartial37);
        org.joda.time.DateTimeFieldType dateTimeFieldType39 = offsetDateTimeField29.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField17, dateTimeFieldType39, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField43 = new org.joda.time.field.DividedDateTimeField(dateTimeField12, dateTimeFieldType39, 99);
        org.joda.time.chrono.ISOChronology iSOChronology44 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean46 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology44, (java.lang.Object) 4);
        org.joda.time.Chronology chronology47 = iSOChronology44.withUTC();
        org.joda.time.DurationField durationField48 = iSOChronology44.minutes();
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone51 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone50);
        org.joda.time.Chronology chronology52 = iSOChronology44.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone51);
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology44.weekyearOfCentury();
        org.joda.time.chrono.GregorianChronology gregorianChronology54 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int55 = gregorianChronology54.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField56 = gregorianChronology54.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, 5044);
        org.joda.time.ReadablePartial readablePartial59 = null;
        java.util.Locale locale61 = null;
        java.lang.String str62 = offsetDateTimeField58.getAsShortText(readablePartial59, 100, locale61);
        int int65 = offsetDateTimeField58.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial66 = null;
        int int67 = offsetDateTimeField58.getMinimumValue(readablePartial66);
        org.joda.time.DateTimeFieldType dateTimeFieldType68 = offsetDateTimeField58.getType();
        org.joda.time.field.DividedDateTimeField dividedDateTimeField70 = new org.joda.time.field.DividedDateTimeField(dateTimeField53, dateTimeFieldType68, (int) '#');
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField72 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) dividedDateTimeField43, dateTimeFieldType68, 100);
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField74 = new org.joda.time.field.RemainderDateTimeField(dateTimeField9, dateTimeFieldType68, 2);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField76 = new org.joda.time.field.DividedDateTimeField(dateTimeField3, dateTimeFieldType68, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "100" + "'", str21.equals("100"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 99 + "'", int24 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "100" + "'", str33.equals("100"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 99 + "'", int36 == 99);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 5045 + "'", int38 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType39);
        org.junit.Assert.assertNotNull(iSOChronology44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(chronology47);
        org.junit.Assert.assertNotNull(durationField48);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(cachedDateTimeZone51);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(gregorianChronology54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "100" + "'", str62.equals("100"));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 99 + "'", int65 == 99);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 5045 + "'", int67 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType68);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        org.joda.time.ReadablePartial readablePartial45 = null;
        org.joda.time.Period period49 = new org.joda.time.Period(0L, (long) (-1));
        int[] intArray50 = period49.getValues();
        try {
            int[] intArray52 = unsupportedDateTimeField43.addWrapPartial(readablePartial45, (int) ' ', intArray50, 5047);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(intArray50);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int2 = gregorianChronology1.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.dayOfWeek();
        org.joda.time.chrono.LenientChronology lenientChronology4 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.PeriodType periodType6 = periodType5.withWeeksRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean9 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology7, (java.lang.Object) 4);
        org.joda.time.Chronology chronology10 = iSOChronology7.withUTC();
        org.joda.time.DurationField durationField11 = iSOChronology7.minutes();
        boolean boolean12 = periodType6.equals((java.lang.Object) iSOChronology7);
        org.joda.time.PeriodType periodType13 = periodType6.withMonthsRemoved();
        boolean boolean14 = lenientChronology4.equals((java.lang.Object) periodType6);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean17 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology15, (java.lang.Object) 4);
        org.joda.time.Chronology chronology18 = iSOChronology15.withUTC();
        org.joda.time.DurationField durationField19 = iSOChronology15.minutes();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone21);
        org.joda.time.Chronology chronology23 = iSOChronology15.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone22);
        org.joda.time.Period period24 = new org.joda.time.Period((long) 105, periodType6, (org.joda.time.Chronology) iSOChronology15);
        org.joda.time.PeriodType periodType25 = periodType6.withMonthsRemoved();
        java.lang.String str26 = periodType6.getName();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(lenientChronology4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
        org.junit.Assert.assertNotNull(chronology23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "YearMonthDayTime" + "'", str26.equals("YearMonthDayTime"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        java.lang.String str5 = offsetDateTimeField4.getName();
        org.joda.time.ReadablePartial readablePartial6 = null;
        int int7 = offsetDateTimeField4.getMaximumValue(readablePartial6);
        long long10 = offsetDateTimeField4.getDifferenceAsLong(0L, 0L);
        java.util.Locale locale11 = null;
        int int12 = offsetDateTimeField4.getMaximumTextLength(locale11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(0L, (long) (-1));
        int[] intArray18 = period17.getValues();
        try {
            int[] intArray20 = offsetDateTimeField4.addWrapPartial(readablePartial13, 5047, intArray18, 5044);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5047");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5051 + "'", int7 == 5051);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(intArray18);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        long long5 = cachedDateTimeZone2.getMillisKeepLocal(dateTimeZone3, 0L);
//        int int7 = cachedDateTimeZone2.getStandardOffset((long) (short) 10);
//        java.util.TimeZone timeZone8 = cachedDateTimeZone2.toTimeZone();
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 28800000L + "'", long5 == 28800000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//        org.junit.Assert.assertNotNull(timeZone8);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (short) 0, (-1104537599889L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1104537599889L + "'", long2 == 1104537599889L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology4.getZone();
        long long12 = zonedChronology4.getDateTimeMillis(10L, 1, (int) (short) 1, 0, 105);
        org.joda.time.Period period13 = org.joda.time.Period.ZERO;
        boolean boolean15 = period13.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period16 = period13.normalizedStandard();
        org.joda.time.Period period17 = org.joda.time.Period.ZERO;
        boolean boolean19 = period17.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period20 = period16.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = period17.indexOf(durationFieldType21);
        long long25 = zonedChronology4.add((org.joda.time.ReadablePeriod) period17, (-1L), 7);
        try {
            long long33 = zonedChronology4.getDateTimeMillis(5047, (int) (byte) -1, (int) '4', (int) ' ', 1, 64, 5045);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3660105L + "'", long12 == 3660105L);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
    }

//    @Test
//    public void test430() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test430");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
//        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
//        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
//        org.joda.time.ReadablePartial readablePartial24 = null;
//        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
//        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
//        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
//        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
//        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
//        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
//        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
//        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
//        java.lang.String str45 = unsupportedDateTimeField43.getName();
//        org.joda.time.ReadablePartial readablePartial46 = null;
//        org.joda.time.chrono.GregorianChronology gregorianChronology47 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int48 = gregorianChronology47.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField49 = gregorianChronology47.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField51 = new org.joda.time.field.OffsetDateTimeField(dateTimeField49, 5044);
//        java.lang.String str52 = offsetDateTimeField51.getName();
//        long long54 = offsetDateTimeField51.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial55 = null;
//        int[] intArray58 = new int[] { 100, (byte) -1 };
//        int int59 = offsetDateTimeField51.getMaximumValue(readablePartial55, intArray58);
//        org.joda.time.ReadablePartial readablePartial60 = null;
//        java.util.Locale locale62 = null;
//        java.lang.String str63 = offsetDateTimeField51.getAsShortText(readablePartial60, (int) '4', locale62);
//        long long66 = offsetDateTimeField51.add(28800000L, (int) (byte) 100);
//        java.util.Locale locale67 = null;
//        int int68 = offsetDateTimeField51.getMaximumTextLength(locale67);
//        org.joda.time.ReadablePartial readablePartial69 = null;
//        org.joda.time.Period period71 = org.joda.time.Period.minutes(0);
//        org.joda.time.Period period73 = period71.minusDays((int) (byte) 1);
//        org.joda.time.Period period75 = period73.withDays((int) '#');
//        int[] intArray76 = period73.getValues();
//        int int77 = offsetDateTimeField51.getMinimumValue(readablePartial69, intArray76);
//        try {
//            int int78 = unsupportedDateTimeField43.getMinimumValue(readablePartial46, intArray76);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
//        org.junit.Assert.assertNotNull(dateTimeFieldType26);
//        org.junit.Assert.assertNotNull(gregorianChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(zonedChronology33);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(chronology41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
//        org.junit.Assert.assertNotNull(durationField44);
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
//        org.junit.Assert.assertNotNull(gregorianChronology47);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField49);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "dayOfWeek" + "'", str52.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 28800000L + "'", long54 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 5051 + "'", int59 == 5051);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "52" + "'", str63.equals("52"));
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 8668800000L + "'", long66 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
//        org.junit.Assert.assertNotNull(period71);
//        org.junit.Assert.assertNotNull(period73);
//        org.junit.Assert.assertNotNull(period75);
//        org.junit.Assert.assertNotNull(intArray76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 5045 + "'", int77 == 5045);
//    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int13 = scaledDurationField12.getScalar();
        int int16 = scaledDurationField12.getValue(5043L, (-100982246822000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.millis();
        org.joda.time.Period period5 = new org.joda.time.Period((long) 1, 0L, periodType4);
        org.joda.time.Period period6 = period1.withPeriodType(periodType4);
        org.joda.time.Period period8 = period1.withYears((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.Period period10 = org.joda.time.Period.ZERO;
        boolean boolean12 = period10.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period13 = period10.normalizedStandard();
        org.joda.time.Duration duration14 = period10.toStandardDuration();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period16 = new org.joda.time.Period(readableInstant9, (org.joda.time.ReadableDuration) duration14, periodType15);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration14, readableInstant17);
        org.joda.time.Period period19 = period8.plus((org.joda.time.ReadablePeriod) period18);
        org.joda.time.Period period21 = period8.plusSeconds((int) (byte) 1);
        int int22 = period8.getMinutes();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        try {
            java.lang.String str47 = unsupportedDateTimeField43.getAsText((long) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
    }

//    @Test
//    public void test434() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test434");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
//        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
//        long long21 = offsetDateTimeField4.roundHalfFloor((long) (-19));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800000L + "'", long21 == 28800000L);
//    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.Period period1 = new org.joda.time.Period((long) '#');
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.Period period4 = new org.joda.time.Period(0, (int) (short) 10, (int) (byte) 0, 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        try {
            int int47 = unsupportedDateTimeField43.get(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        int int10 = fixedDateTimeZone4.getStandardOffset((long) (-1));
        java.lang.String str12 = fixedDateTimeZone4.getNameKey((-1L));
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4, 99);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 99");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Millis" + "'", str12.equals("Millis"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.Period period1 = org.joda.time.Period.months(350);
        try {
            org.joda.time.Hours hours2 = period1.toStandardHours();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Cannot convert to Hours as this period contains months and months vary in length");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test440");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.String str4 = cachedDateTimeZone2.getShortName(100L);
//        int int6 = cachedDateTimeZone2.getStandardOffset((long) (byte) 1);
//        long long10 = cachedDateTimeZone2.convertLocalToUTC((long) 350, false, 10L);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 350L + "'", long10 == 350L);
//    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long21 = unsupportedDurationField20.getUnitMillis();
        try {
            long long24 = unsupportedDurationField20.add(5043L, 1560626719070L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long17 = scaledDurationField12.add((long) (byte) -1, 0);
        int int18 = scaledDurationField12.getScalar();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
//        int int6 = offsetDateTimeField4.getMaximumValue();
//        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
//        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
//        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
//        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
//        org.joda.time.ReadablePartial readablePartial36 = null;
//        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
//        long long44 = remainderDateTimeField42.roundCeiling((long) 1);
//        org.joda.time.DurationField durationField45 = remainderDateTimeField42.getRangeDurationField();
//        java.lang.String str47 = remainderDateTimeField42.getAsShortText((-100L));
//        java.lang.String str48 = remainderDateTimeField42.getName();
//        try {
//            long long51 = remainderDateTimeField42.set((-100982246822000L), "PT0.010S");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PT0.010S\" for dayOfWeek is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 28800000L + "'", long44 == 28800000L);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "47" + "'", str47.equals("47"));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfWeek" + "'", str48.equals("dayOfWeek"));
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.Period period1 = new org.joda.time.Period((-1104537599999L));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((-1104537599999L), chronology3);
        boolean boolean5 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (-100982246822000L), (java.lang.Object) (-1104537599999L));
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.Period period1 = new org.joda.time.Period(350L);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
//        int int6 = offsetDateTimeField4.getMaximumValue();
//        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
//        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
//        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
//        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
//        org.joda.time.ReadablePartial readablePartial36 = null;
//        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
//        long long44 = remainderDateTimeField42.roundCeiling((long) 1);
//        org.joda.time.DurationField durationField45 = remainderDateTimeField42.getRangeDurationField();
//        java.lang.String str47 = remainderDateTimeField42.getAsShortText((-100L));
//        java.lang.String str48 = remainderDateTimeField42.getName();
//        java.util.Locale locale49 = null;
//        int int50 = remainderDateTimeField42.getMaximumShortTextLength(locale49);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 28800000L + "'", long44 == 28800000L);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "47" + "'", str47.equals("47"));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "dayOfWeek" + "'", str48.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.ReadableInterval readableInterval2 = null;
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval2);
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, (long) 100, chronology3);
        int int5 = period4.size();
        org.joda.time.Period period6 = period4.negated();
        org.joda.time.Period period8 = period6.withWeeks((int) (short) 100);
        org.joda.time.Period period10 = period8.withMinutes(0);
        org.joda.time.Period period12 = period8.plusWeeks((int) (byte) 1);
        int int13 = period12.getDays();
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((int) (byte) 0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder0.addCutover(8, 'a', (int) (byte) 10, (int) (short) 100, 99, true, (int) (short) 0);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder0.setStandardOffset((int) '#');
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology0, (java.lang.Object) 4);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        long long7 = iSOChronology0.add((long) (byte) 0, (long) 350, 0);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology0.minuteOfDay();
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
//        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
//        boolean boolean21 = offsetDateTimeField4.isLeap((-210863736000000L));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        java.util.Locale locale45 = null;
        try {
            java.lang.String str46 = unsupportedDateTimeField43.getAsText(0L, locale45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test454");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
//        org.joda.time.DurationField durationField5 = gregorianChronology0.minutes();
//        java.lang.String str6 = gregorianChronology0.toString();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(zonedChronology4);
//        org.junit.Assert.assertNotNull(durationField5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str6.equals("GregorianChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210866760000000L) + "'", long1 == (-210866760000000L));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        int int17 = scaledDurationField12.getValue((-100L), (long) 64);
        int int20 = scaledDurationField12.getValue(0L, 4999L);
        int int23 = scaledDurationField12.getDifference(190L, (-210863736000000L));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 66 + "'", int23 == 66);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField4.getMinimumValue(readablePartial12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField4.getType();
        org.joda.time.DurationField durationField15 = offsetDateTimeField4.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5045 + "'", int13 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("PeriodType[YearMonthDayTime]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PeriodType[YearMonthDayTime]\" is malformed at \"eriodType[YearMonthDayTime]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(0);
        org.joda.time.Period period3 = period1.minusWeeks(0);
        org.joda.time.Minutes minutes4 = period1.toStandardMinutes();
        int int5 = period1.size();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(minutes4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        org.joda.time.ReadablePartial readablePartial9 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology11.millisOfDay();
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology13.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, dateTimeZone16);
        org.joda.time.Chronology chronology18 = gregorianChronology11.withZone(dateTimeZone16);
        org.joda.time.Period period19 = org.joda.time.Period.ZERO;
        boolean boolean21 = period19.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period22 = period19.normalizedStandard();
        org.joda.time.Duration duration23 = period19.toStandardDuration();
        org.joda.time.ReadableInstant readableInstant24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration23, readableInstant24);
        org.joda.time.MutablePeriod mutablePeriod26 = period25.toMutablePeriod();
        org.joda.time.DurationFieldType durationFieldType27 = null;
        boolean boolean28 = period25.isSupported(durationFieldType27);
        int[] intArray31 = gregorianChronology11.get((org.joda.time.ReadablePeriod) period25, (-1104451199899L), (long) 99);
        try {
            int[] intArray33 = offsetDateTimeField4.addWrapField(readablePartial9, 0, intArray31, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(zonedChronology17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertNotNull(mutablePeriod26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(intArray31);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.eras();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.Period period4 = org.joda.time.Period.days((int) (byte) 10);
        long long7 = iSOChronology0.add((org.joda.time.ReadablePeriod) period4, 110449332000000L, (int) '#');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 110479572000000L + "'", long7 == 110479572000000L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(182L, 28800000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28800182L + "'", long2 == 28800182L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        org.joda.time.Period period2 = period0.withSeconds((int) (byte) 0);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.yearWeekDay();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) 10, (long) 100, periodType5);
        org.joda.time.DurationFieldType durationFieldType8 = period6.getFieldType(0);
        boolean boolean9 = period2.isSupported(durationFieldType8);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(durationFieldType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        long long21 = unsupportedDurationField20.getUnitMillis();
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.Period period23 = org.joda.time.Period.ZERO;
        boolean boolean25 = period23.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period26 = period23.normalizedStandard();
        org.joda.time.Duration duration27 = period23.toStandardDuration();
        org.joda.time.PeriodType periodType28 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period29 = new org.joda.time.Period(readableInstant22, (org.joda.time.ReadableDuration) duration27, periodType28);
        org.joda.time.Period period31 = period29.minusSeconds(1);
        int int32 = period29.getHours();
        org.joda.time.Period period34 = period29.withMinutes((int) (short) 10);
        org.joda.time.Period period36 = period34.plusMonths(7);
        org.joda.time.Period period38 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType40 = period38.getFieldType(4);
        int int41 = period36.get(durationFieldType40);
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(durationFieldType40, "YearMonthDayTime");
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField45 = new org.joda.time.field.ScaledDurationField((org.joda.time.DurationField) unsupportedDurationField20, durationFieldType40, 106);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must be supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(period23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(period26);
        org.junit.Assert.assertNotNull(duration27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(durationFieldType40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.Period period5 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period7 = period5.plusMillis(1);
        org.joda.time.Period period9 = period7.withSeconds((int) (byte) 100);
        int int10 = period7.getWeeks();
        org.joda.time.Period period11 = period7.negated();
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearMonthDayTime();
        java.lang.String str13 = periodType12.getName();
        org.joda.time.Period period14 = period11.normalizedStandard(periodType12);
        org.joda.time.Period period15 = new org.joda.time.Period(86400000L, periodType12);
        org.joda.time.PeriodType periodType16 = org.joda.time.DateTimeUtils.getPeriodType(periodType12);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "YearMonthDayTime" + "'", str13.equals("YearMonthDayTime"));
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(periodType16);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
//        int int6 = offsetDateTimeField4.getMaximumValue();
//        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
//        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
//        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
//        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
//        org.joda.time.ReadablePartial readablePartial36 = null;
//        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
//        long long44 = remainderDateTimeField42.roundHalfEven(8639999999L);
//        long long46 = remainderDateTimeField42.roundHalfFloor((long) (byte) 10);
//        long long48 = remainderDateTimeField42.roundHalfCeiling((-210866760000000L));
//        boolean boolean50 = remainderDateTimeField42.isLeap((long) (-8));
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 8668800000L + "'", long44 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 28800000L + "'", long46 == 28800000L);
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + (-210866774822000L) + "'", long48 == (-210866774822000L));
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
//        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
//        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
//        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
//        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
//        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
//        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
//        int int13 = scaledDurationField12.getScalar();
//        int int16 = scaledDurationField12.getValue((long) 1, (long) ' ');
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance();
//        java.lang.String str18 = iSOChronology17.toString();
//        try {
//            org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) 1, (org.joda.time.Chronology) iSOChronology17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(zonedChronology4);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(durationField6);
//        org.junit.Assert.assertNotNull(period8);
//        org.junit.Assert.assertNotNull(durationFieldType10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str18.equals("ISOChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        long long12 = fixedDateTimeZone4.adjustOffset(4L, false);
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        int int15 = fixedDateTimeZone4.getOffset(28800182L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4L + "'", long12 == 4L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 100 + "'", int15 == 100);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int4 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, 5044);
        org.joda.time.ReadablePartial readablePartial8 = null;
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField7.getAsShortText(readablePartial8, 100, locale10);
        int int14 = offsetDateTimeField7.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int16 = gregorianChronology15.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, 5044);
        org.joda.time.ReadablePartial readablePartial20 = null;
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField19.getAsShortText(readablePartial20, 100, locale22);
        int int26 = offsetDateTimeField19.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField19.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeFieldType dateTimeFieldType29 = offsetDateTimeField19.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField31 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField7, dateTimeFieldType29, 7);
        org.joda.time.field.DividedDateTimeField dividedDateTimeField33 = new org.joda.time.field.DividedDateTimeField(dateTimeField2, dateTimeFieldType29, 99);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType29, (java.lang.Number) (-1.0d), "+00:00:00.100");
        java.lang.Number number37 = illegalFieldValueException36.getUpperBound();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "100" + "'", str11.equals("100"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 99 + "'", int14 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "100" + "'", str23.equals("100"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 99 + "'", int26 == 99);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 5045 + "'", int28 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType29);
        org.junit.Assert.assertNull(number37);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("YearMonthDayTime", "Millis", (int) (short) 100, 10);
        int int6 = fixedDateTimeZone4.getOffset(0L);
        int int8 = fixedDateTimeZone4.getOffsetFromLocal((long) (byte) 100);
        java.util.TimeZone timeZone9 = fixedDateTimeZone4.toTimeZone();
        long long12 = fixedDateTimeZone4.adjustOffset(4L, false);
        boolean boolean13 = fixedDateTimeZone4.isFixed();
        long long15 = fixedDateTimeZone4.previousTransition(12783L);
        boolean boolean16 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 4L + "'", long12 == 4L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 12783L + "'", long15 == 12783L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField4.getMinimumValue(readablePartial12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField4.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType14, 0, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [0,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5045 + "'", int13 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.toString();
        try {
            long long47 = unsupportedDateTimeField43.roundFloor(28800010L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        org.joda.time.DurationField durationField5 = offsetDateTimeField4.getLeapDurationField();
//        int int6 = offsetDateTimeField4.getMaximumValue();
//        long long9 = offsetDateTimeField4.add((-1104537599899L), 1L);
//        int int11 = offsetDateTimeField4.getLeapAmount(43734096000000L);
//        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
//        org.joda.time.ReadablePartial readablePartial17 = null;
//        java.util.Locale locale19 = null;
//        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
//        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
//        org.joda.time.chrono.GregorianChronology gregorianChronology24 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int25 = gregorianChronology24.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField26 = gregorianChronology24.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, 5044);
//        org.joda.time.ReadablePartial readablePartial29 = null;
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = offsetDateTimeField28.getAsShortText(readablePartial29, 100, locale31);
//        int int35 = offsetDateTimeField28.getDifference(8639999999L, (long) 100);
//        org.joda.time.ReadablePartial readablePartial36 = null;
//        int int37 = offsetDateTimeField28.getMinimumValue(readablePartial36);
//        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField28.getType();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38, 7);
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType38, (int) (byte) 100);
//        long long44 = remainderDateTimeField42.roundCeiling((long) 1);
//        org.joda.time.DurationField durationField45 = remainderDateTimeField42.getRangeDurationField();
//        int int46 = remainderDateTimeField42.getDivisor();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNull(durationField5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5051 + "'", int6 == 5051);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-1104451199899L) + "'", long9 == (-1104451199899L));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
//        org.junit.Assert.assertNotNull(gregorianChronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
//        org.junit.Assert.assertNotNull(gregorianChronology24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField26);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "100" + "'", str32.equals("100"));
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 99 + "'", int35 == 99);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5045 + "'", int37 == 5045);
//        org.junit.Assert.assertNotNull(dateTimeFieldType38);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 28800000L + "'", long44 == 28800000L);
//        org.junit.Assert.assertNotNull(durationField45);
//        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 100 + "'", int46 == 100);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField43.getRangeDurationField();
        try {
            long long48 = unsupportedDateTimeField43.set((long) 66, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNull(durationField45);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        try {
            long long47 = unsupportedDateTimeField43.addWrapField(43734067200000L, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone2 = gregorianChronology0.getZone();
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.era();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long17 = scaledDurationField12.add((long) (byte) -1, 0);
        try {
            long long19 = scaledDurationField12.getMillis(1560626720050L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 156062672005000 * 31556952000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-1L) + "'", long17 == (-1L));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology4.getZone();
        long long12 = zonedChronology4.getDateTimeMillis(10L, 1, (int) (short) 1, 0, 105);
        org.joda.time.DateTimeField dateTimeField13 = zonedChronology4.halfdayOfDay();
        try {
            long long19 = zonedChronology4.getDateTimeMillis(28800000L, 66, (int) (byte) -1, (int) (short) -1, 7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 66 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3660105L + "'", long12 == 3660105L);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.millis();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period(1L, periodType1, chronology2);
        org.joda.time.Hours hours4 = period3.toStandardHours();
        org.joda.time.Period period6 = period3.minusWeeks((int) (short) 0);
        int int7 = period3.getDays();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(hours4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("+00:00:00.100", "ZonedChronology[GregorianChronology[UTC], UTC]");
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        java.lang.String str5 = zonedChronology4.toString();
        org.joda.time.DateTimeZone dateTimeZone6 = zonedChronology4.getZone();
        long long12 = zonedChronology4.getDateTimeMillis(10L, 1, (int) (short) 1, 0, 105);
        org.joda.time.Period period13 = org.joda.time.Period.ZERO;
        boolean boolean15 = period13.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period16 = period13.normalizedStandard();
        org.joda.time.Period period17 = org.joda.time.Period.ZERO;
        boolean boolean19 = period17.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period20 = period16.minus((org.joda.time.ReadablePeriod) period17);
        org.joda.time.DurationFieldType durationFieldType21 = null;
        int int22 = period17.indexOf(durationFieldType21);
        long long25 = zonedChronology4.add((org.joda.time.ReadablePeriod) period17, (-1L), 7);
        org.joda.time.Duration duration26 = period17.toStandardDuration();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ZonedChronology[GregorianChronology[UTC], UTC]" + "'", str5.equals("ZonedChronology[GregorianChronology[UTC], UTC]"));
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3660105L + "'", long12 == 3660105L);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-1L) + "'", long25 == (-1L));
        org.junit.Assert.assertNotNull(duration26);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(0);
        org.joda.time.Period period3 = period1.minusDays((int) (byte) 1);
        org.joda.time.Period period5 = period3.withDays((int) '#');
        int[] intArray6 = period3.getValues();
        int int7 = period3.getDays();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) 0);
        org.joda.time.Period period3 = period1.minusWeeks((int) (short) 1);
        int int4 = period3.getSeconds();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.DurationField durationField1 = iSOChronology0.centuries();
        org.joda.time.DurationField durationField2 = iSOChronology0.millis();
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(chronology3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.Period period0 = org.joda.time.Period.ZERO;
        int int1 = period0.getSeconds();
        int int2 = period0.getSeconds();
        org.joda.time.Seconds seconds3 = period0.toStandardSeconds();
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology4.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology8 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology4, dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology4.halfdayOfDay();
        org.joda.time.DurationField durationField10 = gregorianChronology4.years();
        org.joda.time.Period period12 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType14 = period12.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField16 = new org.joda.time.field.ScaledDurationField(durationField10, durationFieldType14, (int) (byte) 100);
        org.joda.time.Period period18 = period0.withField(durationFieldType14, 8);
        org.junit.Assert.assertNotNull(period0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(seconds3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(zonedChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(period18);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            long long22 = unsupportedDurationField20.getMillis((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        try {
            long long23 = unsupportedDurationField20.getDifferenceAsLong(12622780800000L, 43734096000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology4 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone3);
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.halfdayOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.years();
        org.joda.time.Period period8 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField12 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType10, (int) (byte) 100);
        int int14 = scaledDurationField12.getValue(4999L);
        long long16 = scaledDurationField12.getMillis((int) '#');
        long long18 = scaledDurationField12.getMillis(4);
        org.joda.time.DurationField durationField19 = scaledDurationField12.getWrappedField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(zonedChronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 110449332000000L + "'", long16 == 110449332000000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 12622780800000L + "'", long18 == 12622780800000L);
        org.junit.Assert.assertNotNull(durationField19);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
//        java.lang.String str5 = offsetDateTimeField4.getName();
//        long long7 = offsetDateTimeField4.roundHalfCeiling((long) 1);
//        org.joda.time.ReadablePartial readablePartial8 = null;
//        int[] intArray11 = new int[] { 100, (byte) -1 };
//        int int12 = offsetDateTimeField4.getMaximumValue(readablePartial8, intArray11);
//        org.joda.time.ReadablePartial readablePartial13 = null;
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = offsetDateTimeField4.getAsShortText(readablePartial13, (int) '4', locale15);
//        long long19 = offsetDateTimeField4.add(28800000L, (int) (byte) 100);
//        long long21 = offsetDateTimeField4.roundCeiling(100L);
//        java.util.Locale locale23 = null;
//        java.lang.String str24 = offsetDateTimeField4.getAsShortText((int) (short) -1, locale23);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "dayOfWeek" + "'", str5.equals("dayOfWeek"));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 28800000L + "'", long7 == 28800000L);
//        org.junit.Assert.assertNotNull(intArray11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5051 + "'", int12 == 5051);
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "52" + "'", str16.equals("52"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 8668800000L + "'", long19 == 8668800000L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 28800000L + "'", long21 == 28800000L);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "-1" + "'", str24.equals("-1"));
//    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test492");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
//        org.joda.time.chrono.LenientChronology lenientChronology3 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) gregorianChronology0);
//        java.lang.String str4 = lenientChronology3.toString();
//        org.joda.time.ReadablePartial readablePartial5 = null;
//        try {
//            int[] intArray7 = lenientChronology3.get(readablePartial5, 28800000L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(lenientChronology3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "LenientChronology[GregorianChronology[America/Los_Angeles]]" + "'", str4.equals("LenientChronology[GregorianChronology[America/Los_Angeles]]"));
//    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.Period period1 = org.joda.time.Period.days((int) '4');
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Duration duration3 = period1.toDurationTo(readableInstant2);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(duration3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int13 = gregorianChronology12.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology12.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, 5044);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField16.getAsShortText(readablePartial17, 100, locale19);
        int int23 = offsetDateTimeField16.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField16.getMinimumValue(readablePartial24);
        org.joda.time.DateTimeFieldType dateTimeFieldType26 = offsetDateTimeField16.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType26, 7);
        org.joda.time.chrono.GregorianChronology gregorianChronology29 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology29.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology33 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology29, dateTimeZone32);
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone36 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone35);
        java.lang.String str38 = cachedDateTimeZone36.getNameKey((long) (short) -1);
        int int40 = cachedDateTimeZone36.getOffset((-210858120000000L));
        org.joda.time.Chronology chronology41 = gregorianChronology29.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone36);
        org.joda.time.DurationField durationField42 = gregorianChronology29.seconds();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType26, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        java.lang.String str45 = unsupportedDateTimeField43.getName();
        try {
            int int46 = unsupportedDateTimeField43.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: dayOfWeek field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "100" + "'", str20.equals("100"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 99 + "'", int23 == 99);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 5045 + "'", int25 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType26);
        org.junit.Assert.assertNotNull(gregorianChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(zonedChronology33);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(cachedDateTimeZone36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UTC" + "'", str38.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(chronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfWeek" + "'", str45.equals("dayOfWeek"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        int int1 = gregorianChronology0.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfWeek();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, 5044);
        org.joda.time.ReadablePartial readablePartial5 = null;
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField4.getAsShortText(readablePartial5, 100, locale7);
        int int11 = offsetDateTimeField4.getDifference(8639999999L, (long) 100);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int int13 = offsetDateTimeField4.getMinimumValue(readablePartial12);
        org.joda.time.DateTimeFieldType dateTimeFieldType14 = offsetDateTimeField4.getType();
        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField16 = gregorianChronology15.millis();
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology15.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology15.year();
        org.joda.time.DurationField durationField19 = gregorianChronology15.weekyears();
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.millisOfDay();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.chrono.ZonedChronology zonedChronology24 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology20, dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology20.halfdayOfDay();
        org.joda.time.DurationField durationField26 = gregorianChronology20.years();
        org.joda.time.Period period28 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType30 = period28.getFieldType(4);
        org.joda.time.field.ScaledDurationField scaledDurationField32 = new org.joda.time.field.ScaledDurationField(durationField26, durationFieldType30, (int) (byte) 100);
        int int34 = scaledDurationField32.getValue(4999L);
        boolean boolean35 = scaledDurationField32.isPrecise();
        long long37 = scaledDurationField32.getMillis(0);
        boolean boolean38 = scaledDurationField32.isPrecise();
        try {
            org.joda.time.field.PreciseDateTimeField preciseDateTimeField39 = new org.joda.time.field.PreciseDateTimeField(dateTimeFieldType14, durationField19, (org.joda.time.DurationField) scaledDurationField32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unit duration field must be precise");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "100" + "'", str8.equals("100"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 99 + "'", int11 == 99);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5045 + "'", int13 == 5045);
        org.junit.Assert.assertNotNull(dateTimeFieldType14);
        org.junit.Assert.assertNotNull(gregorianChronology15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(zonedChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(durationFieldType30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone2 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str4 = cachedDateTimeZone2.getNameKey((long) (short) -1);
        int int6 = cachedDateTimeZone2.getStandardOffset((-1104537599999L));
        boolean boolean7 = cachedDateTimeZone2.isFixed();
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone2, 106);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 106");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(cachedDateTimeZone2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UTC" + "'", str4.equals("UTC"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.Period period4 = new org.joda.time.Period((int) (byte) 1, (int) (byte) -1, (int) (byte) 1, 0);
        org.joda.time.Period period6 = period4.plusMillis(1);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Duration duration8 = period6.toDurationTo(readableInstant7);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.millis();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(1L, periodType11, chronology12);
        org.joda.time.PeriodType periodType14 = periodType11.withYearsRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant9, periodType11);
        org.joda.time.PeriodType periodType16 = periodType11.withMinutesRemoved();
        org.joda.time.PeriodType periodType17 = periodType11.withSecondsRemoved();
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType17);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        org.joda.time.DurationFieldType[] durationFieldTypeArray10 = period9.getFieldTypes();
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) iSOChronology11, (java.lang.Object) 4);
        boolean boolean14 = org.joda.time.field.FieldUtils.equals((java.lang.Object) durationFieldTypeArray10, (java.lang.Object) boolean13);
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.forFields(durationFieldTypeArray10);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(durationFieldTypeArray10);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(periodType15);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((int) 'a');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder2.addRecurringSavings("52", (int) 'a', 105, (int) (short) 10, '#', 0, (int) (short) -1, (int) (short) -1, false, 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder16 = dateTimeZoneBuilder2.setFixedSavings("PT35H10M350.010S", 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder18 = dateTimeZoneBuilder2.setStandardOffset(5044);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder13);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder16);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder18);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Period period1 = org.joda.time.Period.ZERO;
        boolean boolean3 = period1.equals((java.lang.Object) (byte) 0);
        org.joda.time.Period period4 = period1.normalizedStandard();
        org.joda.time.Duration duration5 = period1.toStandardDuration();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.yearMonthDayTime();
        org.joda.time.Period period7 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration5, periodType6);
        org.joda.time.Period period9 = period7.minusSeconds(1);
        int int10 = period7.getHours();
        org.joda.time.Period period12 = period7.withMinutes((int) (short) 10);
        org.joda.time.Period period14 = period12.plusMonths(7);
        org.joda.time.Period period16 = org.joda.time.Period.minutes((int) (byte) 1);
        org.joda.time.DurationFieldType durationFieldType18 = period16.getFieldType(4);
        int int19 = period14.get(durationFieldType18);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField20 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType18);
        boolean boolean21 = unsupportedDurationField20.isPrecise();
        org.joda.time.ReadableInterval readableInterval24 = null;
        org.joda.time.Chronology chronology25 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval24);
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, (long) 100, chronology25);
        int int27 = period26.size();
        org.joda.time.Period period28 = period26.negated();
        org.joda.time.Period period30 = period28.withWeeks((int) (short) 100);
        org.joda.time.Period period32 = period30.withMinutes(0);
        org.joda.time.Period period34 = period30.plusWeeks((int) (byte) 1);
        boolean boolean35 = unsupportedDurationField20.equals((java.lang.Object) period34);
        try {
            int int37 = unsupportedDurationField20.getValue(28800000L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(duration5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(unsupportedDurationField20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 8 + "'", int27 == 8);
        org.junit.Assert.assertNotNull(period28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }
}

