import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(19);
        boolean boolean3 = dateTimeFormatter2.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.plusMinutes((-32));
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.joda.time.DateTime dateTime6 = property5.withMaximumValue();
        org.joda.time.DateTime.Property property7 = dateTime6.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusWeeks((int) (short) -1);
//        org.joda.time.DateTime.Property property3 = dateTime0.millisOfSecond();
//        java.lang.String str4 = property3.getAsShortText();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "27" + "'", str4.equals("27"));
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("299");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"299/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt(1560636461676L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560636461676");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(19);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        int int10 = fixedDateTimeZone7.getOffsetFromLocal(1560636441304L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "16:00:00-08:00");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DurationFieldType durationFieldType5 = illegalFieldValueException2.getDurationFieldType();
        java.lang.String str6 = illegalFieldValueException2.getIllegalStringValue();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "16:00:00-08:00" + "'", str3.equals("16:00:00-08:00"));
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertNull(durationFieldType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "16:00:00-08:00" + "'", str6.equals("16:00:00-08:00"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        int int7 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.weekOfWeekyear();
        java.lang.String str12 = gregorianChronology10.toString();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.centuryOfEra();
        int int14 = dateTime9.get(dateTimeField13);
        org.joda.time.DateTime dateTime16 = dateTime9.minusMillis((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        boolean boolean18 = property17.isLeap();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str12.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean8 = dateTimeFormatter7.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = dateTimeFormatter7.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter14 = dateTimeFormatter10.withChronology((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.secondOfMinute();
        org.joda.time.Chronology chronology16 = iSOChronology12.withUTC();
        try {
            org.joda.time.DateTime dateTime17 = new org.joda.time.DateTime(907, 52, 292278993, 72, 72, (int) (byte) 0, (-1372750000), chronology16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 72 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeFormatter14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray11 = new int[] {};
        int int12 = offsetDateTimeField4.getMinimumValue(readablePartial10, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField4.getMinimumValue(readablePartial13);
        long long16 = offsetDateTimeField4.roundCeiling(100L);
        int int18 = offsetDateTimeField4.getLeapAmount((long) 1969);
        long long21 = offsetDateTimeField4.add(1560636445397L, 4);
        int int23 = offsetDateTimeField4.getLeapAmount((long) (-25200000));
        long long25 = offsetDateTimeField4.roundHalfCeiling(1560031645303L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560809245397L + "'", long21 == 1560809245397L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560020400000L + "'", long25 == 1560020400000L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0, 365);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        long long6 = gregorianChronology2.add(readablePeriod3, 1560636438373L, (int) (short) 10);
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology2.weekyear();
        org.joda.time.DurationField durationField8 = gregorianChronology2.millis();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560636438373L + "'", long6 == 1560636438373L);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        int int7 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.Instant instant10 = dateTime9.toInstant();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(instant10);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PST", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("", 166);
        java.io.OutputStream outputStream8 = null;
        try {
            dateTimeZoneBuilder3.writeTo("", outputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.lang.String str2 = dateTimeFormatter0.print(1560636483941L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "20190615" + "'", str2.equals("20190615"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        try {
            long long22 = zonedChronology14.getDateTimeMillis((-48), 2922789, 100, 52, 999, (-1), 2021);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.lang.String str2 = dateTimeFormatter0.print((long) 2019);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = dateTime3.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        org.joda.time.DateTime.Property property7 = dateTime5.yearOfEra();
        java.lang.String str8 = property7.getAsText();
        org.joda.time.DateTime dateTime9 = property7.withMinimumValue();
        int int10 = property7.getMaximumValue();
        org.joda.time.DateTime dateTime11 = property7.getDateTime();
        boolean boolean12 = dateTime11.isAfterNow();
        org.joda.time.DateTime.Property property13 = dateTime11.secondOfDay();
        java.lang.String str14 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime11);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "16" + "'", str2.equals("16"));
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1969" + "'", str8.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292278993 + "'", int10 == 292278993);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "16" + "'", str14.equals("16"));
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.plusWeeks((int) (short) -1);
//        long long3 = dateTime2.getMillis();
//        int int4 = dateTime2.getMonthOfYear();
//        int int5 = dateTime2.getWeekyear();
//        org.joda.time.DateTime.Property property6 = dateTime2.dayOfMonth();
//        java.util.Locale locale8 = null;
//        try {
//            org.joda.time.DateTime dateTime9 = property6.setCopy("halfdayOfDay", locale8);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"halfdayOfDay\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560031697012L + "'", long3 == 1560031697012L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//        org.junit.Assert.assertNotNull(property6);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        long long6 = dateTimeZone3.adjustOffset((long) 1, true);
//        long long9 = dateTimeZone3.convertLocalToUTC((long) 1969, true);
//        java.lang.String str10 = dateTimeZone3.getID();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560636497046L + "'", long1 == 1560636497046L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28801969L + "'", long9 == 28801969L);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "America/Los_Angeles" + "'", str10.equals("America/Los_Angeles"));
//    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withPivotYear((java.lang.Integer) 0);
//        java.io.Writer writer3 = null;
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) (short) 10);
//        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
//        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
//        java.lang.String str9 = property8.getAsText();
//        org.joda.time.DateTime dateTime10 = property8.withMinimumValue();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime13 = dateTime11.minusDays((int) (short) 100);
//        org.joda.time.DateTime.Property property14 = dateTime13.weekyear();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        long long16 = dateTime15.getMillis();
//        org.joda.time.DateMidnight dateMidnight17 = dateTime15.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone18 = dateTime15.getZone();
//        long long19 = property14.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.DateTime dateTime20 = property14.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime22 = dateTime20.withMillisOfDay(19);
//        boolean boolean24 = dateTime22.isAfter((long) (short) -1);
//        int int25 = dateTime10.compareTo((org.joda.time.ReadableInstant) dateTime22);
//        try {
//            dateTimeFormatter2.printTo(writer3, (org.joda.time.ReadableInstant) dateTime10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969" + "'", str9.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560636497065L + "'", long16 == 1560636497065L);
//        org.junit.Assert.assertNotNull(dateMidnight17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
//    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone16);
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        org.joda.time.DateTime dateTime4 = dateTime0.toDateTime();
//        try {
//            org.joda.time.DateTime dateTime6 = dateTime0.withMinuteOfHour(2922789);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2922789 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560636497365L + "'", long1 == 1560636497365L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560636477565L, (-54446517));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 1560636477565 * -54446517");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, 1);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.secondOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.halfdayOfDay();
        org.joda.time.DateTimeZone dateTimeZone6 = gregorianChronology3.getZone();
        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1560636489684L, dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property6 = dateTime0.year();
//        org.joda.time.DateTime dateTime7 = property6.roundHalfFloorCopy();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560636498047L + "'", long1 == 1560636498047L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(dateTime7);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        long long3 = dateTime2.getMillis();
//        org.joda.time.DateMidnight dateMidnight4 = dateTime2.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime2.getZone();
//        long long8 = dateTimeZone5.adjustOffset((long) 1, true);
//        long long11 = dateTimeZone5.convertLocalToUTC((long) 1969, true);
//        int int13 = dateTimeZone5.getOffsetFromLocal(1560636442663L);
//        java.util.Locale locale15 = null;
//        java.lang.String str16 = dateTimeZone5.getName(1560636461432L, locale15);
//        org.joda.time.chrono.ZonedChronology zonedChronology17 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone5);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560636498230L + "'", long3 == 1560636498230L);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 28801969L + "'", long11 == 28801969L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-25200000) + "'", int13 == (-25200000));
//        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "Pacific Daylight Time" + "'", str16.equals("Pacific Daylight Time"));
//        org.junit.Assert.assertNotNull(zonedChronology17);
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
//        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
//        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
//        org.joda.time.DateTime dateTime8 = dateTime2.withDurationAdded((long) 2019, 24);
//        org.joda.time.DateTime.Property property9 = dateTime2.millisOfSecond();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime12 = dateTime10.withMillis((long) (short) 10);
//        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
//        org.joda.time.DateTime.Property property14 = dateTime12.yearOfEra();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime17 = dateTime15.plusWeeks((int) (short) -1);
//        int int18 = property14.compareTo((org.joda.time.ReadableInstant) dateTime17);
//        int int19 = dateTime17.getHourOfDay();
//        long long20 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime17);
//        java.util.Locale locale21 = null;
//        java.lang.String str22 = property9.getAsShortText(locale21);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-1560031698253L) + "'", long20 == (-1560031698253L));
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "10" + "'", str22.equals("10"));
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
//        long long2 = dateTime1.getMillis();
//        org.joda.time.DateMidnight dateMidnight3 = dateTime1.toDateMidnight();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        long long5 = dateTime4.getMillis();
//        boolean boolean6 = dateTime1.isAfter((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.ReadableDuration readableDuration7 = null;
//        org.joda.time.DateTime dateTime8 = dateTime4.minus(readableDuration7);
//        org.joda.time.DateTime dateTime10 = dateTime8.minusMonths(166);
//        org.joda.time.DateTime dateTime12 = dateTime10.plus((long) (short) -1);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone17 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
//        org.joda.time.MutableDateTime mutableDateTime18 = dateTime12.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone17);
//        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.hourOfHalfday();
//        org.joda.time.DateTimeField dateTimeField21 = iSOChronology19.weekyear();
//        int int22 = mutableDateTime18.get(dateTimeField21);
//        int int25 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime18, "(\"org.joda.time.JodaTimePermission\" \"53\")", 54480694);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560636498495L + "'", long2 == 1560636498495L);
//        org.junit.Assert.assertNotNull(dateMidnight3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560636498496L + "'", long5 == 1560636498496L);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(mutableDateTime18);
//        org.junit.Assert.assertNotNull(iSOChronology19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2005 + "'", int22 == 2005);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-54480695) + "'", int25 == (-54480695));
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PST", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder3.setStandardOffset((-32));
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder13 = dateTimeZoneBuilder3.addCutover(734, ' ', 100, 9, 999, false, 735);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode:  ");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "16:00:00-08:00");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        java.lang.Number number6 = illegalFieldValueException2.getUpperBound();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "16:00:00-08:00" + "'", str3.equals("16:00:00-08:00"));
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        long long7 = dateTimeZone4.convertLocalToUTC(1560636446204L, true);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime10 = dateTime8.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime10.toDateTime();
        org.joda.time.DateTime.Property property12 = dateTime10.yearOfEra();
        java.lang.String str13 = property12.getName();
        org.joda.time.DateTime dateTime15 = property12.addToCopy((int) '4');
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        int int17 = dateTime15.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.plus(readableDuration18);
        org.joda.time.DateTime dateTime21 = dateTime19.minusMinutes(72);
        int int22 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime19);
        int int23 = dateTime19.getDayOfMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560661646204L + "'", long7 == 1560661646204L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "yearOfEra" + "'", str13.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-28800000) + "'", int22 == (-28800000));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 31 + "'", int23 == 31);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 216000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.withPeriodAdded(readablePeriod7, (-32));
        org.joda.time.DateTime.Property property10 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime12 = dateTime2.withYear((int) (short) 10);
        org.joda.time.ReadableInstant readableInstant13 = null;
        try {
            int int14 = dateTime12.compareTo(readableInstant13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology2.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1075L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean12 = fixedDateTimeZone11.isFixed();
        java.util.TimeZone timeZone13 = fixedDateTimeZone11.toTimeZone();
        boolean boolean15 = fixedDateTimeZone11.equals((java.lang.Object) "2019");
        int int17 = fixedDateTimeZone11.getOffset(1560636445078L);
        try {
            org.joda.time.DateTime dateTime18 = new org.joda.time.DateTime((int) (short) 100, (int) (byte) 100, (int) (byte) 100, 15, 24, 0, (int) (short) -1, (org.joda.time.DateTimeZone) fixedDateTimeZone11);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        int int8 = offsetDateTimeField4.getLeapAmount((long) (-32));
        java.lang.String str10 = offsetDateTimeField4.getAsShortText(1560636443904L);
        long long12 = offsetDateTimeField4.roundHalfFloor(1560636441304L);
        long long15 = offsetDateTimeField4.add((long) 4, 24);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField4.getAsShortText((int) (short) -1, locale17);
        int int20 = offsetDateTimeField4.getMaximumValue(0L);
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField4.getAsText(1560636461053L, locale22);
        int int25 = offsetDateTimeField4.getLeapAmount(1560636495278L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "53" + "'", str10.equals("53"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560625200000L + "'", long12 == 1560625200000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1036800004L + "'", long15 == 1036800004L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1" + "'", str18.equals("-1"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 53 + "'", int20 == 53);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "53" + "'", str23.equals("53"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        boolean boolean4 = dateTime2.equals((java.lang.Object) 1560600445078L);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime2.minus(readablePeriod5);
        long long7 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime2);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 10L + "'", long7 == 10L);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
//        int int3 = dateTime0.getWeekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 24 + "'", int3 == 24);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        try {
            long long2 = dateTimeFormatter0.parseMillis("+10:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+10:00\" is malformed at \":00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTime3.toString("1969", locale5);
//        org.joda.time.DateTime dateTime8 = dateTime3.minusDays(734);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillis((long) (short) 10);
//        org.joda.time.DateTime dateTime12 = dateTime11.toDateTime();
//        org.joda.time.DateTime.Property property13 = dateTime11.yearOfEra();
//        java.lang.String str14 = property13.getAsText();
//        org.joda.time.DateTime dateTime15 = property13.withMinimumValue();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime18 = dateTime16.minusDays((int) (short) 100);
//        org.joda.time.DateTime.Property property19 = dateTime18.weekyear();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
//        long long21 = dateTime20.getMillis();
//        org.joda.time.DateMidnight dateMidnight22 = dateTime20.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone23 = dateTime20.getZone();
//        long long24 = property19.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.DateTime dateTime25 = property19.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime27 = dateTime25.withMillisOfDay(19);
//        boolean boolean29 = dateTime27.isAfter((long) (short) -1);
//        int int30 = dateTime15.compareTo((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.DateTimeZone dateTimeZone31 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
//        org.joda.time.DateTimeField dateTimeField33 = iSOChronology32.halfdayOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) '4');
//        java.util.Locale locale37 = null;
//        java.lang.String str38 = offsetDateTimeField35.getAsShortText(53, locale37);
//        int int40 = offsetDateTimeField35.getLeapAmount(1560636442281L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = offsetDateTimeField35.getType();
//        boolean boolean42 = dateTime27.isSupported(dateTimeFieldType41);
//        int int43 = dateTime8.get(dateTimeFieldType41);
//        org.joda.time.DateTime.Property property44 = dateTime8.monthOfYear();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(property13);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1969" + "'", str14.equals("1969"));
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(property19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560636499060L + "'", long21 == 1560636499060L);
//        org.junit.Assert.assertNotNull(dateMidnight22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
//        org.junit.Assert.assertNotNull(iSOChronology32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "53" + "'", str38.equals("53"));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(property44);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime2.plus(0L);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        long long5 = dateTime4.getMillis();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
//        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTimeZone dateTimeZone10 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
//        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.halfdayOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) '4');
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = offsetDateTimeField14.getAsShortText(53, locale16);
//        int int19 = offsetDateTimeField14.getLeapAmount(1560636442281L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField14.getType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (byte) 100, "GregorianChronology[America/Los_Angeles]");
//        boolean boolean24 = dateTime9.isSupported(dateTimeFieldType20);
//        int int25 = dateTime9.getSecondOfMinute();
//        try {
//            org.joda.time.DateTime dateTime27 = dateTime9.withMinuteOfHour((-25200000));
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560636499773L + "'", long5 == 1560636499773L);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertNotNull(dateTimeField12);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "53" + "'", str17.equals("53"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(dateTimeFieldType20);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-32), 907, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        long long7 = offsetDateTimeField4.getDifferenceAsLong(1560636445932L, (-1L));
        int int9 = offsetDateTimeField4.getLeapAmount(1560031645303L);
        long long12 = offsetDateTimeField4.add(0L, (long) 5);
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField4.getAsText(365, locale14);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 36125L + "'", long7 == 36125L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 216000000L + "'", long12 == 216000000L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "365" + "'", str15.equals("365"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test050");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime dateTime4 = dateTime2.plus(1560636439434L);
//        int int5 = dateTime4.getMinuteOfDay();
//        java.util.GregorianCalendar gregorianCalendar6 = dateTime4.toGregorianCalendar();
//        org.joda.time.DateTime.Property property7 = dateTime4.dayOfWeek();
//        int int8 = property7.getMinimumValue();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 735 + "'", int5 == 735);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
//    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        long long4 = dateTime3.getMillis();
//        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
//        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(1560636445170L);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.hourOfHalfday();
//        org.joda.time.Chronology chronology16 = iSOChronology14.withUTC();
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology14.yearOfCentury();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560636499939L + "'", long1 == 1560636499939L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560636499940L + "'", long4 == 1560636499940L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("AD");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"AD\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime dateTime4 = dateTime2.plus(1560636439434L);
//        int int5 = dateTime4.getMinuteOfDay();
//        java.util.GregorianCalendar gregorianCalendar6 = dateTime4.toGregorianCalendar();
//        org.joda.time.DateTime.Property property7 = dateTime4.dayOfYear();
//        org.joda.time.DateTime dateTime8 = property7.roundCeilingCopy();
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 735 + "'", int5 == 735);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNotNull(property7);
//        org.junit.Assert.assertNotNull(dateTime8);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        long long6 = dateTimeZone3.adjustOffset((long) 1, true);
//        long long9 = dateTimeZone3.convertLocalToUTC((long) 1969, true);
//        int int11 = dateTimeZone3.getOffsetFromLocal(1560636442663L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
//        org.joda.time.DateTime.Property property16 = dateTime13.millisOfSecond();
//        boolean boolean17 = cachedDateTimeZone12.equals((java.lang.Object) property16);
//        long long19 = cachedDateTimeZone12.previousTransition(1560636469481L);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560636500119L + "'", long1 == 1560636500119L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28801969L + "'", long9 == 28801969L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1552211999999L + "'", long19 == 1552211999999L);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.lang.String str5 = offsetDateTimeField4.getName();
        long long7 = offsetDateTimeField4.roundHalfCeiling(1560636445932L);
        java.util.Locale locale9 = null;
        java.lang.String str10 = offsetDateTimeField4.getAsShortText(4, locale9);
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField4.getAsText(1560636475970L, locale12);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "halfdayOfDay" + "'", str5.equals("halfdayOfDay"));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560625200000L + "'", long7 == 1560625200000L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4" + "'", str10.equals("4"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "53" + "'", str13.equals("53"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondFraction();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        int int7 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.weekOfWeekyear();
        java.lang.String str12 = gregorianChronology10.toString();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.centuryOfEra();
        int int14 = dateTime9.get(dateTimeField13);
        org.joda.time.DateTime dateTime16 = dateTime9.minusMillis((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        try {
            org.joda.time.DateTime dateTime19 = dateTime16.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str12.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        long long5 = dateTime4.getMillis();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
//        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfDay(19);
//        boolean boolean13 = dateTime11.isAfter((long) (short) -1);
//        org.joda.time.DateTime dateTime15 = dateTime11.withEra((int) (short) 1);
//        org.joda.time.DurationFieldType durationFieldType16 = null;
//        try {
//            org.joda.time.DateTime dateTime18 = dateTime15.withFieldAdded(durationFieldType16, (-54480695));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560636500285L + "'", long5 == 1560636500285L);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.DurationField durationField5 = gregorianChronology0.hours();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        long long4 = dateTime3.getMillis();
//        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfSecond(12);
//        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime13 = dateTime11.withMillis((long) (short) 10);
//        org.joda.time.DateTime dateTime14 = dateTime13.toDateTime();
//        org.joda.time.DateTime.Property property15 = dateTime13.yearOfEra();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime18 = dateTime16.plusWeeks((int) (short) -1);
//        int int19 = property15.compareTo((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.DateTime dateTime22 = dateTime18.minusDays(2018);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560636500766L + "'", long1 == 1560636500766L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560636500790L + "'", long4 == 1560636500790L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(property10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(property15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(chronology20);
//        org.junit.Assert.assertNotNull(dateTime22);
//    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateTime dateTime3 = dateTime0.minusMillis(19);
//        org.joda.time.DateTime.Property property4 = dateTime3.hourOfDay();
//        org.joda.time.DateTime dateTime6 = dateTime3.withWeekyear((int) '#');
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560636501032L + "'", long1 == 1560636501032L);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray6 = iSOChronology0.get(readablePeriod3, (long) 907, 36125L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
//        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
//        org.joda.time.DateTime dateTime4 = dateTime2.plus(1560636439434L);
//        int int5 = dateTime4.getMinuteOfDay();
//        java.util.GregorianCalendar gregorianCalendar6 = dateTime4.toGregorianCalendar();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime9 = dateTime7.withMillis((long) (short) 10);
//        org.joda.time.DateTime dateTime11 = dateTime9.minusHours((int) ' ');
//        org.joda.time.DateTime dateTime13 = dateTime9.minusMillis((int) (byte) 10);
//        org.joda.time.DateTime.Property property14 = dateTime9.hourOfDay();
//        org.joda.time.DateTime dateTime15 = property14.withMaximumValue();
//        int int16 = dateTime15.getYearOfCentury();
//        org.joda.time.DateTime dateTime18 = dateTime15.withMillisOfDay(0);
//        boolean boolean19 = dateTime4.isBefore((org.joda.time.ReadableInstant) dateTime18);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 735 + "'", int5 == 735);
//        org.junit.Assert.assertNotNull(gregorianCalendar6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 69 + "'", int16 == 69);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 1560636461613L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, (int) '4');
        long long51 = offsetDateTimeField48.getDifferenceAsLong(1560636445932L, (-1L));
        int int53 = offsetDateTimeField48.getMaximumValue(1560636443974L);
        org.joda.time.DateTime dateTime54 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime56 = dateTime54.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime57 = dateTime56.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay58 = dateTime57.toYearMonthDay();
        int int59 = offsetDateTimeField48.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay58);
        org.joda.time.DateTimeZone dateTimeZone61 = null;
        org.joda.time.chrono.ISOChronology iSOChronology62 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone61);
        org.joda.time.DateTimeField dateTimeField63 = iSOChronology62.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField65 = new org.joda.time.field.OffsetDateTimeField(dateTimeField63, (int) '4');
        java.util.Locale locale67 = null;
        java.lang.String str68 = offsetDateTimeField65.getAsShortText(53, locale67);
        int int70 = offsetDateTimeField65.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial71 = null;
        int[] intArray72 = new int[] {};
        int int73 = offsetDateTimeField65.getMinimumValue(readablePartial71, intArray72);
        try {
            int[] intArray75 = unsupportedDateTimeField43.set((org.joda.time.ReadablePartial) yearMonthDay58, 53, intArray72, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 36125L + "'", long51 == 36125L);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 53 + "'", int53 == 53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(yearMonthDay58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 53 + "'", int59 == 53);
        org.junit.Assert.assertNotNull(iSOChronology62);
        org.junit.Assert.assertNotNull(dateTimeField63);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "53" + "'", str68.equals("53"));
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 52 + "'", int73 == 52);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
//        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
//        java.util.Locale locale5 = null;
//        java.lang.String str6 = dateTime3.toString("1969", locale5);
//        int int7 = dateTime3.getDayOfYear();
//        java.util.Locale locale9 = null;
//        try {
//            java.lang.String str10 = dateTime3.toString("DateTimeField[halfdayOfDay]", locale9);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 166 + "'", int7 == 166);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField5 = gregorianChronology1.weeks();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
        int int9 = dateTime8.getYearOfCentury();
        org.joda.time.DateTime dateTime11 = dateTime8.withMillisOfDay(0);
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        org.joda.time.DateTime dateTime14 = dateTime11.withPeriodAdded(readablePeriod12, (int) (byte) -1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 69 + "'", int9 == 69);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, readableInstant7);
        org.joda.time.DateTime.Property property9 = dateTime5.millisOfSecond();
        try {
            org.joda.time.DateTime dateTime14 = dateTime5.withTime(0, 166, (-54480695), 2922789);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        long long4 = dateTime3.getMillis();
//        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
//        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(1560636445170L);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.hourOfHalfday();
//        org.joda.time.Chronology chronology16 = iSOChronology14.withUTC();
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        long long19 = dateTime18.getMillis();
//        org.joda.time.DateMidnight dateMidnight20 = dateTime18.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTime18.getZone();
//        long long24 = dateTimeZone21.adjustOffset((long) 1, true);
//        long long27 = dateTimeZone21.convertLocalToUTC((long) 1969, true);
//        org.joda.time.Chronology chronology28 = iSOChronology14.withZone(dateTimeZone21);
//        try {
//            long long34 = iSOChronology14.getDateTimeMillis((long) (byte) 0, 6, (int) (short) 100, (-53), (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560636501479L + "'", long1 == 1560636501479L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560636501480L + "'", long4 == 1560636501480L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560636501505L + "'", long19 == 1560636501505L);
//        org.junit.Assert.assertNotNull(dateMidnight20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28801969L + "'", long27 == 28801969L);
//        org.junit.Assert.assertNotNull(chronology28);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(1560636441620L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        long long7 = fixedDateTimeZone4.nextTransition((long) 24);
        long long10 = fixedDateTimeZone4.convertLocalToUTC(0L, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 24L + "'", long7 == 24L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-100L) + "'", long10 == (-100L));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        int int7 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        int int10 = property4.getMaximumValueOverall();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 292278993 + "'", int10 == 292278993);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        long long5 = dateTime4.getMillis();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
//        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
//        java.lang.String str9 = property3.getAsString();
//        boolean boolean11 = property3.equals((java.lang.Object) 1560636444857L);
//        org.joda.time.DateTime dateTime12 = property3.roundHalfEvenCopy();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560636501625L + "'", long5 == 1560636501625L);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019" + "'", str9.equals("2019"));
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DurationField durationField15 = zonedChronology14.centuries();
        org.joda.time.DateTimeField dateTimeField16 = zonedChronology14.weekyear();
        java.lang.String str17 = zonedChronology14.toString();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 19]" + "'", str17.equals("ZonedChronology[GregorianChronology[UTC], 19]"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        int int11 = offsetDateTimeField4.getLeapAmount(0L);
        long long13 = offsetDateTimeField4.roundCeiling(1562882867997L);
        int int16 = offsetDateTimeField4.getDifference(1560640040801L, 1560636479344L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1562914800000L + "'", long13 == 1562914800000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("53", number1, (java.lang.Number) 1560636444857L, (java.lang.Number) 1L);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1L + "'", number6.equals(1L));
        org.junit.Assert.assertNull(dateTimeFieldType7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.era();
        org.joda.time.DurationField durationField3 = iSOChronology1.days();
        try {
            long long6 = durationField3.subtract(1560636484760L, 1560636461614L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: -1560636461614 * 86400000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.withHourOfDay(0);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField6 = gregorianChronology5.millis();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology5.year();
        org.joda.time.DateTime dateTime8 = dateTime4.withChronology((org.joda.time.Chronology) gregorianChronology5);
        org.joda.time.TimeOfDay timeOfDay9 = dateTime8.toTimeOfDay();
        org.joda.time.DateTime dateTime10 = dateTime8.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(timeOfDay9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(19);
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
//        long long10 = dateTime9.getMillis();
//        org.joda.time.DateMidnight dateMidnight11 = dateTime9.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTime9.getZone();
//        long long15 = dateTimeZone12.adjustOffset((long) 1, true);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter2.withZone(dateTimeZone12);
//        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter2);
//        org.junit.Assert.assertNotNull(dateTimeFormatter8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560636501901L + "'", long10 == 1560636501901L);
//        org.junit.Assert.assertNotNull(dateMidnight11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(gregorianChronology17);
//    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
//        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
//        boolean boolean10 = fixedDateTimeZone9.isFixed();
//        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
//        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
//        long long16 = dateTime15.getMillis();
//        org.joda.time.DateMidnight dateMidnight17 = dateTime15.toDateMidnight();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        long long19 = dateTime18.getMillis();
//        boolean boolean20 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.ReadableDuration readableDuration21 = null;
//        org.joda.time.DateTime dateTime22 = dateTime18.minus(readableDuration21);
//        org.joda.time.DateTime dateTime24 = dateTime18.plusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime26 = dateTime24.plus(1560636445170L);
//        org.joda.time.DateTimeZone dateTimeZone27 = null;
//        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone27);
//        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.hourOfHalfday();
//        org.joda.time.Chronology chronology31 = iSOChronology29.withUTC();
//        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime((org.joda.time.Chronology) iSOChronology29);
//        org.joda.time.DateTime.Property property33 = dateTime32.era();
//        boolean boolean34 = zonedChronology14.equals((java.lang.Object) property33);
//        org.joda.time.DateTimeZone dateTimeZone35 = null;
//        org.joda.time.Chronology chronology36 = zonedChronology14.withZone(dateTimeZone35);
//        org.joda.time.DateTimeField dateTimeField37 = zonedChronology14.centuryOfEra();
//        try {
//            long long43 = zonedChronology14.getDateTimeMillis(1560636465130L, 19, 788, 69, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 788 for minuteOfHour must be in the range [0,59]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560636501985L + "'", long16 == 1560636501985L);
//        org.junit.Assert.assertNotNull(dateMidnight17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560636501985L + "'", long19 == 1560636501985L);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(iSOChronology29);
//        org.junit.Assert.assertNotNull(dateTimeField30);
//        org.junit.Assert.assertNotNull(chronology31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(chronology36);
//        org.junit.Assert.assertNotNull(dateTimeField37);
//    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(1560636443698L, dateTimeZone2);
        int int5 = dateTimeZone2.getOffsetFromLocal(3121272891539L);
        java.util.TimeZone timeZone6 = dateTimeZone2.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertNotNull(timeZone6);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        long long5 = dateTime4.getMillis();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
//        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis(10);
//        org.joda.time.DateTime dateTime13 = dateTime9.plusYears((int) (byte) 1);
//        org.joda.time.DateTime dateTime15 = dateTime13.withYear(0);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560636502017L + "'", long5 == 1560636502017L);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        long long5 = dateTime4.getMillis();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
//        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis(10);
//        org.joda.time.DateTime dateTime12 = dateTime11.toDateTime();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560636502175L + "'", long5 == 1560636502175L);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0L, (-1372750000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
//        long long3 = dateTime2.getMillis();
//        org.joda.time.DateMidnight dateMidnight4 = dateTime2.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone5 = dateTime2.getZone();
//        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(1560636467599L, dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1560636440801L, dateTimeZone5);
//        java.util.Locale locale8 = null;
//        java.util.Calendar calendar9 = dateTime7.toCalendar(locale8);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560636502250L + "'", long3 == 1560636502250L);
//        org.junit.Assert.assertNotNull(dateMidnight4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(calendar9);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        try {
            int int44 = unsupportedDateTimeField43.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        java.lang.String str6 = property4.getAsShortText();
        int int7 = property4.get();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean13 = fixedDateTimeZone12.isFixed();
        java.util.TimeZone timeZone14 = fixedDateTimeZone12.toTimeZone();
        long long16 = fixedDateTimeZone12.nextTransition(0L);
        boolean boolean17 = property4.equals((java.lang.Object) fixedDateTimeZone12);
        org.joda.time.Interval interval18 = property4.toInterval();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(interval18);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
//        int int3 = dateTime2.getYearOfCentury();
//        org.joda.time.DateTime dateTime5 = dateTime2.plusWeeks(166);
//        org.joda.time.DateTime dateTime7 = dateTime2.plusYears(1969);
//        int int8 = dateTime2.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 19 + "'", int3 == 19);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 22 + "'", int8 == 22);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        long long6 = dateTimeZone3.adjustOffset((long) 1, true);
//        long long9 = dateTimeZone3.convertLocalToUTC((long) 1969, true);
//        int int11 = dateTimeZone3.getOffsetFromLocal(1560636442663L);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone3);
//        long long15 = dateTimeZone3.adjustOffset(1560636482553L, true);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560636502437L + "'", long1 == 1560636502437L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28801969L + "'", long9 == 28801969L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560636482553L + "'", long15 == 1560636482553L);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray11 = new int[] {};
        int int12 = offsetDateTimeField4.getMinimumValue(readablePartial10, intArray11);
        java.lang.String str13 = offsetDateTimeField4.toString();
        int int15 = offsetDateTimeField4.getMinimumValue(1560668400000L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[halfdayOfDay]" + "'", str13.equals("DateTimeField[halfdayOfDay]"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 52 + "'", int15 == 52);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        long long19 = fixedDateTimeZone9.adjustOffset(0L, false);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        long long5 = dateTime4.getMillis();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
//        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfDay(19);
//        org.joda.time.DateTime.Property property12 = dateTime11.dayOfMonth();
//        org.joda.time.DateMidnight dateMidnight13 = dateTime11.toDateMidnight();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560636502588L + "'", long5 == 1560636502588L);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(property12);
//        org.junit.Assert.assertNotNull(dateMidnight13);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTime3.toString("1969", locale5);
        org.joda.time.DateTime dateTime8 = dateTime3.minusDays(734);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeUtils.getZone(dateTimeZone10);
        org.joda.time.DateTime dateTime12 = dateTime8.toDateTime(dateTimeZone10);
        java.util.GregorianCalendar gregorianCalendar13 = dateTime12.toGregorianCalendar();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianCalendar13);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray11 = new int[] {};
        int int12 = offsetDateTimeField4.getMinimumValue(readablePartial10, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField4.getMinimumValue(readablePartial13);
        long long16 = offsetDateTimeField4.roundCeiling(100L);
        int int18 = offsetDateTimeField4.getLeapAmount((long) 1969);
        long long21 = offsetDateTimeField4.add(1560636445397L, 4);
        int int23 = offsetDateTimeField4.getMinimumValue((long) (byte) 0);
        java.lang.String str24 = offsetDateTimeField4.getName();
        java.lang.String str25 = offsetDateTimeField4.getName();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560809245397L + "'", long21 == 1560809245397L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "halfdayOfDay" + "'", str24.equals("halfdayOfDay"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "halfdayOfDay" + "'", str25.equals("halfdayOfDay"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        java.util.Locale locale45 = null;
        try {
            java.lang.String str46 = unsupportedDateTimeField43.getAsShortText(2922789, locale45);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (byte) 10);
//        org.joda.time.DateTime.Property property6 = dateTime0.year();
//        org.joda.time.DurationField durationField7 = property6.getLeapDurationField();
//        try {
//            long long10 = durationField7.subtract(1560636460530L, 1560636440970L);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: -1560636440970 * 86400000");
//        } catch (java.lang.ArithmeticException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560636503254L + "'", long1 == 1560636503254L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(property6);
//        org.junit.Assert.assertNotNull(durationField7);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        long long4 = dateTime3.getMillis();
//        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
//        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
//        int int9 = dateTime7.getWeekyear();
//        org.joda.time.DateTime.Property property10 = dateTime7.secondOfMinute();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560636503266L + "'", long1 == 1560636503266L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560636503267L + "'", long4 == 1560636503267L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//        org.junit.Assert.assertNotNull(property10);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        java.lang.Appendable appendable1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.Integer int3 = dateTimeFormatter2.getPivotYear();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) '4');
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField8.getAsShortText(53, locale10);
        int int13 = offsetDateTimeField8.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial14 = null;
        int[] intArray15 = new int[] {};
        int int16 = offsetDateTimeField8.getMinimumValue(readablePartial14, intArray15);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int int18 = offsetDateTimeField8.getMinimumValue(readablePartial17);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime22 = dateTime21.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay23 = dateTime22.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) '4');
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField28.getAsShortText(53, locale30);
        int int33 = offsetDateTimeField28.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray35 = new int[] {};
        int int36 = offsetDateTimeField28.getMinimumValue(readablePartial34, intArray35);
        int int37 = offsetDateTimeField8.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay23, intArray35);
        java.lang.String str38 = dateTimeFormatter2.print((org.joda.time.ReadablePartial) yearMonthDay23);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadablePartial) yearMonthDay23);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNull(int3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "53" + "'", str11.equals("53"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(yearMonthDay23);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "53" + "'", str31.equals("53"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 52 + "'", int36 == 52);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 53 + "'", int37 == 53);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "����W���" + "'", str38.equals("����W���"));
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        long long6 = dateTimeZone3.adjustOffset((long) 1, true);
//        long long9 = dateTimeZone3.convertLocalToUTC((long) 1969, true);
//        int int11 = dateTimeZone3.getOffsetFromLocal(1560636442663L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime15 = dateTime13.plusWeeks((int) (short) -1);
//        org.joda.time.DateTime.Property property16 = dateTime13.millisOfSecond();
//        boolean boolean17 = cachedDateTimeZone12.equals((java.lang.Object) property16);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter18 = org.joda.time.format.ISODateTimeFormat.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = dateTimeFormatter18.withZoneUTC();
//        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter21 = dateTimeFormatter19.withChronology((org.joda.time.Chronology) gregorianChronology20);
//        org.joda.time.format.DateTimePrinter dateTimePrinter22 = dateTimeFormatter19.getPrinter();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
//        org.joda.time.format.DateTimeParser dateTimeParser24 = dateTimeFormatter23.getParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter22, dateTimeParser24);
//        boolean boolean26 = cachedDateTimeZone12.equals((java.lang.Object) dateTimeParser24);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560636503368L + "'", long1 == 1560636503368L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28801969L + "'", long9 == 28801969L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(gregorianChronology20);
//        org.junit.Assert.assertNotNull(dateTimeFormatter21);
//        org.junit.Assert.assertNotNull(dateTimePrinter22);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertNotNull(dateTimeParser24);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        java.util.Locale locale2 = dateTimeFormatter0.getLocale();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        java.util.Locale locale44 = null;
        try {
            int int45 = unsupportedDateTimeField43.getMaximumTextLength(locale44);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        try {
            long long45 = unsupportedDateTimeField43.roundFloor((long) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.plus((long) (short) 10);
        int int7 = dateTime2.getDayOfYear();
        org.joda.time.DateTime dateTime9 = dateTime2.minusWeeks(0);
        int int10 = dateTime2.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 365 + "'", int7 == 365);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 69 + "'", int10 == 69);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
//        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
//        long long5 = dateTime4.getMillis();
//        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
//        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
//        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
//        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfDay(19);
//        boolean boolean13 = dateTime11.isAfter((long) (short) -1);
//        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
//        org.joda.time.DateTimeField dateTimeField15 = property14.getField();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(property3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560636503794L + "'", long5 == 1560636503794L);
//        org.junit.Assert.assertNotNull(dateMidnight6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = dateTime3.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        org.joda.time.DateTime dateTime8 = dateTime5.minusMinutes((int) ' ');
        org.joda.time.MutableDateTime mutableDateTime9 = dateTime8.toMutableDateTime();
        int int12 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime9, "166", 54480694);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(mutableDateTime9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-54480695) + "'", int12 == (-54480695));
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
//        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
//        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
//        java.lang.String str5 = property4.getName();
//        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
//        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
//        int int9 = dateTime7.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
//        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
//        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
//        java.lang.String str17 = property16.getName();
//        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
//        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
//        org.joda.time.DateTimeZone dateTimeZone22 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
//        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
//        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
//        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
//        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
//        boolean boolean35 = dateTimeFormatter34.isParser();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
//        org.joda.time.DateTimeZone dateTimeZone38 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
//        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
//        org.joda.time.DurationField durationField42 = iSOChronology39.years();
//        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
//        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime46 = dateTime44.plusWeeks((int) (short) -1);
//        int int47 = dateTime44.getMillisOfDay();
//        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime50 = dateTime48.withMillis((long) (short) 10);
//        org.joda.time.DateTime dateTime51 = dateTime50.toDateTime();
//        org.joda.time.DateTime.Property property52 = dateTime50.yearOfEra();
//        int int53 = dateTime50.getMonthOfYear();
//        org.joda.time.DateMidnight dateMidnight54 = dateTime50.toDateMidnight();
//        org.joda.time.TimeOfDay timeOfDay55 = dateTime50.toTimeOfDay();
//        org.joda.time.DateTime dateTime56 = dateTime44.withFields((org.joda.time.ReadablePartial) timeOfDay55);
//        java.util.Locale locale57 = null;
//        try {
//            java.lang.String str58 = unsupportedDateTimeField43.getAsShortText((org.joda.time.ReadablePartial) timeOfDay55, locale57);
//            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
//        } catch (java.lang.UnsupportedOperationException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(property4);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(chronology8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(property16);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(iSOChronology23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNotNull(dateTimeFormatter37);
//        org.junit.Assert.assertNotNull(iSOChronology39);
//        org.junit.Assert.assertNotNull(dateTimeField40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
//        org.junit.Assert.assertNotNull(dateTime44);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 54504124 + "'", int47 == 54504124);
//        org.junit.Assert.assertNotNull(dateTime48);
//        org.junit.Assert.assertNotNull(dateTime50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(property52);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
//        org.junit.Assert.assertNotNull(dateMidnight54);
//        org.junit.Assert.assertNotNull(timeOfDay55);
//        org.junit.Assert.assertNotNull(dateTime56);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfHour();
        org.joda.time.DateTime.Property property7 = dateTime5.weekyear();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) '4');
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField12.getAsShortText(53, locale14);
        int int17 = offsetDateTimeField12.getLeapAmount(1560636442281L);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = offsetDateTimeField12.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException22 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType18, (java.lang.Number) 1560636460726L, (java.lang.Number) 1560636463902L, (java.lang.Number) 15);
        try {
            org.joda.time.DateTime dateTime24 = dateTime5.withField(dateTimeFieldType18, 999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for halfdayOfDay must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "53" + "'", str15.equals("53"));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.weekyear();
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField9 = gregorianChronology8.hours();
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime2.toMutableDateTime((org.joda.time.Chronology) gregorianChronology8);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        long long9 = offsetDateTimeField4.add(1560636443718L, (int) (byte) 100);
        long long12 = offsetDateTimeField4.add(1560636467997L, (int) '4');
        java.util.Locale locale14 = null;
        java.lang.String str15 = offsetDateTimeField4.getAsShortText(292278993, locale14);
        long long17 = offsetDateTimeField4.roundHalfFloor(1560636461613L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1564956443718L + "'", long9 == 1564956443718L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1562882867997L + "'", long12 == 1562882867997L);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "292278993" + "'", str15.equals("292278993"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560625200000L + "'", long17 == 1560625200000L);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        try {
//            org.joda.time.DateTime dateTime5 = dateTime0.withDayOfMonth(734);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 734 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560636504292L + "'", long1 == 1560636504292L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        long long7 = offsetDateTimeField4.getDifferenceAsLong(1560636445932L, (-1L));
        int int9 = offsetDateTimeField4.getLeapAmount(1560031645303L);
        long long12 = offsetDateTimeField4.add(1560636439501L, 20);
        long long14 = offsetDateTimeField4.roundHalfCeiling(1560636440801L);
        int int16 = offsetDateTimeField4.getMaximumValue(1560636447601L);
        try {
            long long19 = offsetDateTimeField4.set((long) 20, "19");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 19 for halfdayOfDay must be in the range [52,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 36125L + "'", long7 == 36125L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561500439501L + "'", long12 == 1561500439501L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560625200000L + "'", long14 == 1560625200000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        long long8 = offsetDateTimeField4.roundCeiling(1560636441304L);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime11 = dateTime9.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime12 = dateTime11.toDateTime();
        org.joda.time.DateTime.Property property13 = dateTime11.yearOfEra();
        org.joda.time.DateTime dateTime15 = dateTime11.plus(0L);
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime18 = dateTime16.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime19 = dateTime18.toDateTime();
        org.joda.time.DateTime.Property property20 = dateTime18.yearOfEra();
        org.joda.time.DateTime dateTime21 = property20.withMaximumValue();
        int int22 = dateTime11.compareTo((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.LocalTime localTime23 = dateTime11.toLocalTime();
        int int24 = offsetDateTimeField4.getMinimumValue((org.joda.time.ReadablePartial) localTime23);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, 735);
        long long28 = offsetDateTimeField26.roundHalfFloor((long) 31);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560668400000L + "'", long8 == 1560668400000L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(localTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + (-14400000L) + "'", long28 == (-14400000L));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.plusMinutes((-32));
        org.joda.time.DateTimeField dateTimeField5 = null;
        try {
            int int6 = dateTime4.get(dateTimeField5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeField must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(31, 0, (int) (short) 100, (-25200000), 4, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        long long7 = dateTimeZone4.convertLocalToUTC(1560636446204L, true);
        long long10 = dateTimeZone4.convertLocalToUTC(28800000L, false);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560661646204L + "'", long7 == 1560661646204L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 57600000L + "'", long10 == 57600000L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDate();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(0L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "16:00:00-08:00");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField9 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, (int) '4');
        int int11 = offsetDateTimeField9.getMaximumValue(0L);
        int int13 = offsetDateTimeField9.getLeapAmount((long) (-32));
        java.lang.String str15 = offsetDateTimeField9.getAsShortText(1560636443904L);
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = offsetDateTimeField9.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, "");
        java.lang.String str19 = illegalFieldValueException18.toString();
        illegalFieldValueException2.addSuppressed((java.lang.Throwable) illegalFieldValueException18);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "16:00:00-08:00" + "'", str3.equals("16:00:00-08:00"));
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 53 + "'", int11 == 53);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "53" + "'", str15.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for halfdayOfDay is not supported" + "'", str19.equals("org.joda.time.IllegalFieldValueException: Value \"\" for halfdayOfDay is not supported"));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        long long16 = dateTime15.getMillis();
        org.joda.time.DateMidnight dateMidnight17 = dateTime15.toDateMidnight();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        long long19 = dateTime18.getMillis();
        boolean boolean20 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.minus(readableDuration21);
        org.joda.time.DateTime dateTime24 = dateTime18.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime26 = dateTime24.plus(1560636445170L);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone27);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.hourOfHalfday();
        org.joda.time.Chronology chronology31 = iSOChronology29.withUTC();
        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.DateTime.Property property33 = dateTime32.era();
        boolean boolean34 = zonedChronology14.equals((java.lang.Object) property33);
        java.lang.String str35 = zonedChronology14.toString();
        long long39 = zonedChronology14.add(0L, 1560636443718L, (-53));
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 19]" + "'", str35.equals("ZonedChronology[GregorianChronology[UTC], 19]"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-82713731517054L) + "'", long39 == (-82713731517054L));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (int) (byte) 1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.withPeriodAdded(readablePeriod7, (-32));
        org.joda.time.DateTime.Property property10 = dateTime9.minuteOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.withDayOfMonth(20);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime dateTime10 = dateTime7.minusSeconds((-35));
        int int11 = dateTime10.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 52 + "'", int11 == 52);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        int int7 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.minus(readablePeriod9);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.plus(1560636439434L);
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime2.toYearMonthDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.withMillis(100L);
        long long10 = dateTime7.getMillis();
        org.joda.time.DateTime dateTime12 = dateTime7.withWeekyear(365);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1640995200010L + "'", long10 == 1640995200010L);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, (int) '4');
        int int50 = offsetDateTimeField48.getMaximumValue(0L);
        long long52 = offsetDateTimeField48.roundCeiling(1560636441304L);
        org.joda.time.DateTime dateTime53 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime55 = dateTime53.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime56 = dateTime55.toDateTime();
        org.joda.time.DateTime.Property property57 = dateTime55.yearOfEra();
        org.joda.time.DateTime dateTime59 = dateTime55.plus(0L);
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime62 = dateTime60.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime63 = dateTime62.toDateTime();
        org.joda.time.DateTime.Property property64 = dateTime62.yearOfEra();
        org.joda.time.DateTime dateTime65 = property64.withMaximumValue();
        int int66 = dateTime55.compareTo((org.joda.time.ReadableInstant) dateTime65);
        org.joda.time.LocalTime localTime67 = dateTime55.toLocalTime();
        int int68 = offsetDateTimeField48.getMinimumValue((org.joda.time.ReadablePartial) localTime67);
        org.joda.time.DateTimeZone dateTimeZone70 = null;
        org.joda.time.chrono.ISOChronology iSOChronology71 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone70);
        org.joda.time.DateTimeField dateTimeField72 = iSOChronology71.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField74 = new org.joda.time.field.OffsetDateTimeField(dateTimeField72, (int) '4');
        java.util.Locale locale76 = null;
        java.lang.String str77 = offsetDateTimeField74.getAsShortText(53, locale76);
        int int79 = offsetDateTimeField74.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial80 = null;
        int[] intArray81 = new int[] {};
        int int82 = offsetDateTimeField74.getMinimumValue(readablePartial80, intArray81);
        try {
            int[] intArray84 = unsupportedDateTimeField43.addWrapPartial((org.joda.time.ReadablePartial) localTime67, (-35), intArray81, 54469861);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 53 + "'", int50 == 53);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1560668400000L + "'", long52 == 1560668400000L);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(property57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertNotNull(localTime67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 52 + "'", int68 == 52);
        org.junit.Assert.assertNotNull(iSOChronology71);
        org.junit.Assert.assertNotNull(dateTimeField72);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "53" + "'", str77.equals("53"));
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 52 + "'", int82 == 52);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 788, 788);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("0");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("53");
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) '4');
        long long11 = offsetDateTimeField8.getDifferenceAsLong(1560636445932L, (-1L));
        boolean boolean12 = jodaTimePermission3.equals((java.lang.Object) long11);
        java.lang.String str13 = jodaTimePermission3.getName();
        java.lang.String str14 = jodaTimePermission3.toString();
        boolean boolean15 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.security.PermissionCollection permissionCollection16 = jodaTimePermission3.newPermissionCollection();
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 36125L + "'", long11 == 36125L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "53" + "'", str13.equals("53"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"53\")" + "'", str14.equals("(\"org.joda.time.JodaTimePermission\" \"53\")"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(permissionCollection16);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        java.lang.String str9 = property8.toString();
        org.joda.time.DateTime dateTime10 = property8.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[era]" + "'", str9.equals("Property[era]"));
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray11 = new int[] {};
        int int12 = offsetDateTimeField4.getMinimumValue(readablePartial10, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField4.getMinimumValue(readablePartial13);
        long long16 = offsetDateTimeField4.roundCeiling(100L);
        boolean boolean18 = org.joda.time.field.FieldUtils.equals((java.lang.Object) 100L, (java.lang.Object) 1560636503794L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours(0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DurationField durationField3 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.yearOfEra();
        java.lang.String str6 = property5.getName();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((int) '4');
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime8.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime12 = dateTime8.minusMonths(4);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField14 = gregorianChronology13.hours();
        org.joda.time.DateTime dateTime15 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology13);
        org.joda.time.DateTime dateTime17 = dateTime15.plus(1560636439434L);
        org.joda.time.DateTimeZone dateTimeZone18 = null;
        org.joda.time.chrono.ISOChronology iSOChronology19 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone18);
        org.joda.time.DateTimeField dateTimeField20 = iSOChronology19.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField22 = new org.joda.time.field.OffsetDateTimeField(dateTimeField20, (int) '4');
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField22.getAsShortText(53, locale24);
        int int27 = offsetDateTimeField22.getLeapAmount(1560636442281L);
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField22.getType();
        org.joda.time.DateTime.Property property29 = dateTime15.property(dateTimeFieldType28);
        int int30 = dateTime8.get(dateTimeFieldType28);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField32 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType28, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "yearOfEra" + "'", str6.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(iSOChronology19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "53" + "'", str25.equals("53"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        boolean boolean10 = offsetDateTimeField4.isLenient();
        long long13 = offsetDateTimeField4.add((-100L), (-43200032L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1866241382822100L) + "'", long13 == (-1866241382822100L));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsShortText(1560636444182L, locale8);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime12 = dateTime10.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
        org.joda.time.DateTime.Property property14 = dateTime12.yearOfEra();
        java.lang.String str15 = property14.getAsText();
        org.joda.time.DateTime dateTime16 = property14.withMinimumValue();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime19 = dateTime17.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property20 = dateTime19.weekyear();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        long long22 = dateTime21.getMillis();
        org.joda.time.DateMidnight dateMidnight23 = dateTime21.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime21.getZone();
        long long25 = property20.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime21);
        org.joda.time.DateTime dateTime26 = property20.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime28 = dateTime26.withMillisOfDay(19);
        boolean boolean30 = dateTime28.isAfter((long) (short) -1);
        int int31 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.DateTimeZone dateTimeZone32 = null;
        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone32);
        org.joda.time.DateTimeField dateTimeField34 = iSOChronology33.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField36 = new org.joda.time.field.OffsetDateTimeField(dateTimeField34, (int) '4');
        java.util.Locale locale38 = null;
        java.lang.String str39 = offsetDateTimeField36.getAsShortText(53, locale38);
        int int41 = offsetDateTimeField36.getLeapAmount(1560636442281L);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField36.getType();
        boolean boolean43 = dateTime28.isSupported(dateTimeFieldType42);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType42, 10);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "53" + "'", str9.equals("53"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1969" + "'", str15.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "53" + "'", str39.equals("53"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        java.lang.String str6 = property4.getAsShortText();
        java.util.Locale locale8 = null;
        org.joda.time.DateTime dateTime9 = property4.setCopy("1969", locale8);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        int int7 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(292278993);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime dateTime17 = dateTime14.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property18 = dateTime17.minuteOfHour();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime22 = dateTime21.toDateTime();
        org.joda.time.DateTime.Property property23 = dateTime21.yearOfEra();
        java.lang.String str24 = property23.getAsText();
        org.joda.time.DateTime dateTime25 = property23.withMinimumValue();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime28 = dateTime26.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property29 = dateTime28.weekyear();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
        long long31 = dateTime30.getMillis();
        org.joda.time.DateMidnight dateMidnight32 = dateTime30.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone33 = dateTime30.getZone();
        long long34 = property29.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime35 = property29.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfDay(19);
        boolean boolean39 = dateTime37.isAfter((long) (short) -1);
        int int40 = dateTime25.compareTo((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = offsetDateTimeField45.getType();
        boolean boolean47 = dateTime25.isSupported(dateTimeFieldType46);
        org.joda.time.DateTime.Property property48 = dateTime17.property(dateTimeFieldType46);
        org.joda.time.DateTime.Property property49 = dateTime11.property(dateTimeFieldType46);
        org.joda.time.DateTime dateTime50 = property49.roundCeilingCopy();
        org.joda.time.DateTime dateTime52 = dateTime50.withMillisOfDay((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        int int18 = fixedDateTimeZone9.getOffset(97L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        try {
            long long45 = unsupportedDateTimeField43.roundHalfCeiling(1560636486736L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = offsetDateTimeField4.getType();
        int int7 = offsetDateTimeField4.getLeapAmount(1560636443974L);
        int int8 = offsetDateTimeField4.getOffset();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '4');
        java.util.Locale locale15 = null;
        java.lang.String str16 = offsetDateTimeField13.getAsShortText(53, locale15);
        int int18 = offsetDateTimeField13.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial19 = null;
        int[] intArray20 = new int[] {};
        int int21 = offsetDateTimeField13.getMinimumValue(readablePartial19, intArray20);
        org.joda.time.ReadablePartial readablePartial22 = null;
        int int23 = offsetDateTimeField13.getMinimumValue(readablePartial22);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) '4');
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField28.getAsShortText(53, locale30);
        int int33 = offsetDateTimeField28.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray35 = new int[] {};
        int int36 = offsetDateTimeField28.getMinimumValue(readablePartial34, intArray35);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int int38 = offsetDateTimeField28.getMinimumValue(readablePartial37);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime41 = dateTime39.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime42 = dateTime41.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay43 = dateTime42.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, (int) '4');
        java.util.Locale locale50 = null;
        java.lang.String str51 = offsetDateTimeField48.getAsShortText(53, locale50);
        int int53 = offsetDateTimeField48.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial54 = null;
        int[] intArray55 = new int[] {};
        int int56 = offsetDateTimeField48.getMinimumValue(readablePartial54, intArray55);
        int int57 = offsetDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay43, intArray55);
        org.joda.time.DateTimeZone dateTimeZone58 = null;
        org.joda.time.chrono.ISOChronology iSOChronology59 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone58);
        org.joda.time.DateTimeField dateTimeField60 = iSOChronology59.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField62 = new org.joda.time.field.OffsetDateTimeField(dateTimeField60, (int) '4');
        java.util.Locale locale64 = null;
        java.lang.String str65 = offsetDateTimeField62.getAsShortText(53, locale64);
        int int67 = offsetDateTimeField62.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial68 = null;
        int[] intArray69 = new int[] {};
        int int70 = offsetDateTimeField62.getMinimumValue(readablePartial68, intArray69);
        org.joda.time.ReadablePartial readablePartial71 = null;
        int int72 = offsetDateTimeField62.getMinimumValue(readablePartial71);
        org.joda.time.DateTime dateTime73 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime75 = dateTime73.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime76 = dateTime75.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay77 = dateTime76.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone78 = null;
        org.joda.time.chrono.ISOChronology iSOChronology79 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone78);
        org.joda.time.DateTimeField dateTimeField80 = iSOChronology79.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField82 = new org.joda.time.field.OffsetDateTimeField(dateTimeField80, (int) '4');
        java.util.Locale locale84 = null;
        java.lang.String str85 = offsetDateTimeField82.getAsShortText(53, locale84);
        int int87 = offsetDateTimeField82.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial88 = null;
        int[] intArray89 = new int[] {};
        int int90 = offsetDateTimeField82.getMinimumValue(readablePartial88, intArray89);
        int int91 = offsetDateTimeField62.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay77, intArray89);
        int int92 = offsetDateTimeField13.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay43, intArray89);
        java.util.Locale locale94 = null;
        java.lang.String str95 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay43, 166, locale94);
        java.util.Locale locale96 = null;
        int int97 = offsetDateTimeField4.getMaximumTextLength(locale96);
        int int99 = offsetDateTimeField4.getMinimumValue(1560636473775L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "53" + "'", str16.equals("53"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 52 + "'", int21 == 52);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "53" + "'", str31.equals("53"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 52 + "'", int36 == 52);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 52 + "'", int38 == 52);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(yearMonthDay43);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "53" + "'", str51.equals("53"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 52 + "'", int56 == 52);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 53 + "'", int57 == 53);
        org.junit.Assert.assertNotNull(iSOChronology59);
        org.junit.Assert.assertNotNull(dateTimeField60);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "53" + "'", str65.equals("53"));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 52 + "'", int70 == 52);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 52 + "'", int72 == 52);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(dateTime75);
        org.junit.Assert.assertNotNull(dateTime76);
        org.junit.Assert.assertNotNull(yearMonthDay77);
        org.junit.Assert.assertNotNull(iSOChronology79);
        org.junit.Assert.assertNotNull(dateTimeField80);
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "53" + "'", str85.equals("53"));
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 52 + "'", int90 == 52);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 53 + "'", int91 == 53);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 52 + "'", int92 == 52);
        org.junit.Assert.assertTrue("'" + str95 + "' != '" + "166" + "'", str95.equals("166"));
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 2 + "'", int97 == 2);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 52 + "'", int99 == 52);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.plusMinutes((-32));
        int int5 = dateTime0.getDayOfWeek();
        try {
            org.joda.time.DateTime dateTime7 = dateTime0.withDayOfMonth(788);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 788 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 1560031680303L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime46 = dateTime44.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property47 = dateTime46.weekyear();
        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
        long long49 = dateTime48.getMillis();
        org.joda.time.DateMidnight dateMidnight50 = dateTime48.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone51 = dateTime48.getZone();
        long long52 = property47.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime48);
        org.joda.time.DateTime dateTime54 = dateTime48.withCenturyOfEra((int) (byte) 100);
        org.joda.time.LocalDate localDate55 = dateTime48.toLocalDate();
        try {
            int int56 = unsupportedDateTimeField43.getMaximumValue((org.joda.time.ReadablePartial) localDate55);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 0L + "'", long49 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight50);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 0L + "'", long52 == 0L);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(localDate55);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("(\"org.joda.time.JodaTimePermission\" \"53\")");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"(\"org.joda.time.JodaTimePermission\" \"53\")/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsShortText(1560636444182L, locale8);
        long long11 = offsetDateTimeField4.roundHalfCeiling((long) 72);
        long long13 = offsetDateTimeField4.roundCeiling(1560636474694L);
        long long15 = offsetDateTimeField4.roundFloor(1560636495433L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "53" + "'", str9.equals("53"));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-14400000L) + "'", long11 == (-14400000L));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560668400000L + "'", long13 == 1560668400000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560625200000L + "'", long15 == 1560625200000L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.yearOfEra();
        java.lang.String str6 = property5.getAsText();
        org.joda.time.DateTime dateTime7 = property5.withMinimumValue();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime10 = dateTime8.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property11 = dateTime10.weekyear();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        long long13 = dateTime12.getMillis();
        org.joda.time.DateMidnight dateMidnight14 = dateTime12.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime12.getZone();
        long long16 = property11.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime17 = property11.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime19 = dateTime17.withMillisOfDay(19);
        boolean boolean21 = dateTime19.isAfter((long) (short) -1);
        int int22 = dateTime7.compareTo((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime24 = dateTime19.minusMinutes(1);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime27 = dateTime25.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property28 = dateTime27.weekyear();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now();
        long long30 = dateTime29.getMillis();
        org.joda.time.DateMidnight dateMidnight31 = dateTime29.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime29.getZone();
        long long33 = property28.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime34 = property28.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime36 = dateTime34.plusMillis(10);
        org.joda.time.DateTime dateTime38 = dateTime34.withCenturyOfEra((int) (byte) 0);
        org.joda.time.Chronology chronology39 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime24, (org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.DateTime dateTime40 = dateTime0.toDateTime(chronology39);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(property28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(chronology39);
        org.junit.Assert.assertNotNull(dateTime40);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        long long16 = dateTime15.getMillis();
        org.joda.time.DateMidnight dateMidnight17 = dateTime15.toDateMidnight();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        long long19 = dateTime18.getMillis();
        boolean boolean20 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.minus(readableDuration21);
        org.joda.time.DateTime dateTime24 = dateTime18.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime26 = dateTime24.plus(1560636445170L);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone27);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.hourOfHalfday();
        org.joda.time.Chronology chronology31 = iSOChronology29.withUTC();
        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.DateTime.Property property33 = dateTime32.era();
        boolean boolean34 = zonedChronology14.equals((java.lang.Object) property33);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.Chronology chronology36 = zonedChronology14.withZone(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = zonedChronology14.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField38 = zonedChronology14.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.plus((long) (short) 10);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.hours();
        org.joda.time.DurationField durationField9 = gregorianChronology7.days();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.secondOfDay();
        org.joda.time.DurationField durationField11 = gregorianChronology7.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean17 = fixedDateTimeZone16.isFixed();
        java.util.TimeZone timeZone18 = fixedDateTimeZone16.toTimeZone();
        boolean boolean20 = fixedDateTimeZone16.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DurationField durationField22 = zonedChronology21.centuries();
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (int) '4');
        long long30 = offsetDateTimeField27.getDifferenceAsLong(1560636445932L, (-1L));
        int int32 = offsetDateTimeField27.getMaximumValue(1560636443974L);
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime35 = dateTime33.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime36 = dateTime35.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay37 = dateTime36.toYearMonthDay();
        int int38 = offsetDateTimeField27.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay37);
        boolean boolean39 = zonedChronology21.equals((java.lang.Object) offsetDateTimeField27);
        org.joda.time.Chronology chronology40 = zonedChronology21.withUTC();
        java.lang.String str41 = zonedChronology21.toString();
        org.joda.time.MutableDateTime mutableDateTime42 = dateTime6.toMutableDateTime((org.joda.time.Chronology) zonedChronology21);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 36125L + "'", long30 == 36125L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 53 + "'", int32 == 53);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(yearMonthDay37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 53 + "'", int38 == 53);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 19]" + "'", str41.equals("ZonedChronology[GregorianChronology[UTC], 19]"));
        org.junit.Assert.assertNotNull(mutableDateTime42);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusWeeks((int) (short) -1);
        long long3 = dateTime2.getMillis();
        int int4 = dateTime2.getMonthOfYear();
        boolean boolean5 = dateTime2.isBeforeNow();
        try {
            org.joda.time.DateTime dateTime7 = dateTime2.withYearOfCentury(54445);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54445 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-604800000L) + "'", long3 == (-604800000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.hourOfDay();
        org.joda.time.TimeOfDay timeOfDay8 = dateTime2.toTimeOfDay();
        org.joda.time.DateTime dateTime9 = dateTime2.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(timeOfDay8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        long long5 = dateTime4.getMillis();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime10 = dateTime4.withCenturyOfEra((int) (byte) 100);
        org.joda.time.Chronology chronology11 = dateTime10.getChronology();
        org.joda.time.DateTime dateTime13 = dateTime10.withMillisOfDay(999);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readableDuration14);
        org.joda.time.DurationFieldType durationFieldType16 = null;
        try {
            org.joda.time.DateTime dateTime18 = dateTime15.withFieldAdded(durationFieldType16, 2021);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        boolean boolean3 = dateTimeFormatter0.isParser();
        org.joda.time.chrono.ISOChronology iSOChronology4 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology5 = iSOChronology4.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean7 = iSOChronology4.equals((java.lang.Object) dateTimeFormatter6);
        org.joda.time.Chronology chronology8 = iSOChronology4.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone13 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean14 = fixedDateTimeZone13.isFixed();
        java.util.TimeZone timeZone15 = fixedDateTimeZone13.toTimeZone();
        java.lang.String str17 = fixedDateTimeZone13.getName((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology18 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology4, (org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter20 = dateTimeFormatter0.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone13);
        java.io.Writer writer21 = null;
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime24 = dateTime22.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTime();
        org.joda.time.DateTime.Property property26 = dateTime24.yearOfEra();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime29 = dateTime27.plusWeeks((int) (short) -1);
        int int30 = property26.compareTo((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime31 = property26.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
        long long33 = dateTime32.getMillis();
        org.joda.time.DateMidnight dateMidnight34 = dateTime32.toDateMidnight();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
        long long36 = dateTime35.getMillis();
        boolean boolean37 = dateTime32.isAfter((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime35.minus(readableDuration38);
        org.joda.time.DateTime dateTime41 = dateTime35.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime43 = dateTime41.plusMonths(166);
        org.joda.time.LocalDate localDate44 = dateTime43.toLocalDate();
        int int45 = property26.compareTo((org.joda.time.ReadablePartial) localDate44);
        try {
            dateTimeFormatter0.printTo(writer21, (org.joda.time.ReadablePartial) localDate44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(iSOChronology4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "+00:00:00.100" + "'", str17.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(zonedChronology18);
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertNotNull(dateTimeFormatter20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property3 = dateTime0.millisOfSecond();
        org.joda.time.DateTime dateTime5 = dateTime0.minusYears((-25200000));
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology6.hourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = iSOChronology6.add(readablePeriod8, (long) 72, (int) (short) 100);
        org.joda.time.Chronology chronology12 = iSOChronology6.withUTC();
        org.joda.time.DateTime dateTime13 = dateTime0.withChronology(chronology12);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 72L + "'", long11 == 72L);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.lang.String str6 = offsetDateTimeField4.getAsText(1560636440970L);
        int int8 = offsetDateTimeField4.getMinimumValue((long) 1);
        org.joda.time.DateTimeField dateTimeField9 = offsetDateTimeField4.getWrappedField();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology12 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10, 1);
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology12.secondOfDay();
        org.joda.time.DurationField durationField14 = gregorianChronology12.weekyears();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology12.yearOfEra();
        try {
            org.joda.time.DateTime dateTime16 = new org.joda.time.DateTime((java.lang.Object) offsetDateTimeField4, (org.joda.time.Chronology) gregorianChronology12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.field.OffsetDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "53" + "'", str6.equals("53"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(gregorianChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
        java.util.Locale locale2 = dateTimeFormatter1.getLocale();
        try {
            org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.parse("-1", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"-1\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        boolean boolean6 = fixedDateTimeZone4.isFixed();
        int int8 = fixedDateTimeZone4.getOffsetFromLocal(1560636444182L);
        long long10 = fixedDateTimeZone4.nextTransition((long) 28);
        long long12 = fixedDateTimeZone4.nextTransition(1560636479239L);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 100 + "'", int8 == 100);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 28L + "'", long10 == 28L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560636479239L + "'", long12 == 1560636479239L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime2.plus(0L);
        boolean boolean8 = dateTime6.isBefore((long) 54446517);
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime6.toYearMonthDay();
        try {
            org.joda.time.DateTime dateTime11 = dateTime6.withEra((int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(yearMonthDay9);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        boolean boolean17 = dateTimeZone15.isStandardOffset(0L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 0);
//        java.util.Locale locale7 = null;
//        java.lang.String str8 = dateTimeZone3.getShortName((long) (byte) 10, locale7);
//        java.lang.String str9 = dateTimeZone3.getID();
//        int int11 = dateTimeZone3.getOffsetFromLocal(1560636490687L);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PST" + "'", str8.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "America/Los_Angeles" + "'", str9.equals("America/Los_Angeles"));
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        int int8 = offsetDateTimeField4.getLeapAmount((long) (-32));
        java.lang.String str10 = offsetDateTimeField4.getAsShortText(1560636443904L);
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) '4');
        long long18 = offsetDateTimeField15.getDifferenceAsLong(1560636445932L, (-1L));
        int int20 = offsetDateTimeField15.getLeapAmount(1560031645303L);
        long long23 = offsetDateTimeField15.add(0L, (long) 5);
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) '4');
        int int30 = offsetDateTimeField28.getMaximumValue(0L);
        int int32 = offsetDateTimeField28.getLeapAmount((long) (-32));
        java.lang.String str34 = offsetDateTimeField28.getAsShortText(1560636443904L);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = offsetDateTimeField28.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField37 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField15, dateTimeFieldType35, 735);
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime40 = dateTime38.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime41 = dateTime40.toDateTime();
        org.joda.time.DateTime dateTime43 = dateTime40.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property44 = dateTime40.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod45 = null;
        org.joda.time.DateTime dateTime47 = dateTime40.withPeriodAdded(readablePeriod45, (-32));
        org.joda.time.DateTime dateTime49 = dateTime47.withWeekyear((-32));
        org.joda.time.DateTime dateTime50 = dateTime49.toDateTime();
        org.joda.time.LocalTime localTime51 = dateTime49.toLocalTime();
        int int52 = offsetDateTimeField37.getMaximumValue((org.joda.time.ReadablePartial) localTime51);
        org.joda.time.DateTimeZone dateTimeZone54 = null;
        org.joda.time.chrono.ISOChronology iSOChronology55 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone54);
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology55.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField58 = new org.joda.time.field.OffsetDateTimeField(dateTimeField56, (int) '4');
        java.util.Locale locale60 = null;
        java.lang.String str61 = offsetDateTimeField58.getAsShortText(53, locale60);
        int int63 = offsetDateTimeField58.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial64 = null;
        int[] intArray65 = new int[] {};
        int int66 = offsetDateTimeField58.getMinimumValue(readablePartial64, intArray65);
        org.joda.time.ReadablePartial readablePartial67 = null;
        int int68 = offsetDateTimeField58.getMinimumValue(readablePartial67);
        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime71 = dateTime69.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime72 = dateTime71.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay73 = dateTime72.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone74 = null;
        org.joda.time.chrono.ISOChronology iSOChronology75 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone74);
        org.joda.time.DateTimeField dateTimeField76 = iSOChronology75.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField78 = new org.joda.time.field.OffsetDateTimeField(dateTimeField76, (int) '4');
        java.util.Locale locale80 = null;
        java.lang.String str81 = offsetDateTimeField78.getAsShortText(53, locale80);
        int int83 = offsetDateTimeField78.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial84 = null;
        int[] intArray85 = new int[] {};
        int int86 = offsetDateTimeField78.getMinimumValue(readablePartial84, intArray85);
        int int87 = offsetDateTimeField58.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay73, intArray85);
        try {
            int[] intArray89 = offsetDateTimeField4.addWrapPartial((org.joda.time.ReadablePartial) localTime51, 2019, intArray85, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2019");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "53" + "'", str10.equals("53"));
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 36125L + "'", long18 == 36125L);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 216000000L + "'", long23 == 216000000L);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 53 + "'", int30 == 53);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "53" + "'", str34.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(property44);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(localTime51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 788 + "'", int52 == 788);
        org.junit.Assert.assertNotNull(iSOChronology55);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "53" + "'", str61.equals("53"));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 52 + "'", int66 == 52);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 52 + "'", int68 == 52);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(yearMonthDay73);
        org.junit.Assert.assertNotNull(iSOChronology75);
        org.junit.Assert.assertNotNull(dateTimeField76);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "53" + "'", str81.equals("53"));
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 52 + "'", int86 == 52);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 53 + "'", int87 == 53);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.toDateTime(dateTimeZone3);
        long long5 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime4.getZone();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths((int) (byte) 1);
        boolean boolean10 = dateTime9.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.DateTime.Property property8 = dateTime7.era();
        org.joda.time.DateTime.Property property9 = dateTime7.dayOfMonth();
        int int10 = property9.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        int int8 = offsetDateTimeField4.getLeapAmount((long) (-32));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsText(readablePartial9, 0, locale11);
        int int14 = offsetDateTimeField4.getLeapAmount(1560636461675L);
        java.lang.String str15 = offsetDateTimeField4.getName();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "halfdayOfDay" + "'", str15.equals("halfdayOfDay"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime7.minusMonths(166);
        org.joda.time.DateTime dateTime11 = dateTime9.plus((long) (short) -1);
        org.joda.time.DateTime dateTime13 = dateTime11.withYearOfEra((int) (byte) 100);
        boolean boolean14 = dateTime13.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime8 = dateTime2.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime2.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) cachedDateTimeZone16);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean23 = fixedDateTimeZone22.isFixed();
        long long25 = fixedDateTimeZone22.nextTransition((long) 24);
        java.util.TimeZone timeZone26 = fixedDateTimeZone22.toTimeZone();
        long long28 = cachedDateTimeZone16.getMillisKeepLocal((org.joda.time.DateTimeZone) fixedDateTimeZone22, 1560636484472L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24L + "'", long25 == 24L);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560636484472L + "'", long28 == 1560636484472L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = offsetDateTimeField4.getType();
        int int7 = offsetDateTimeField4.getLeapAmount(1560636443974L);
        int int8 = offsetDateTimeField4.getOffset();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField13 = new org.joda.time.field.OffsetDateTimeField(dateTimeField11, (int) '4');
        long long16 = offsetDateTimeField13.getDifferenceAsLong(1560636445932L, (-1L));
        int int18 = offsetDateTimeField13.getMaximumValue(1560636443974L);
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime22 = dateTime21.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay23 = dateTime22.toYearMonthDay();
        int int24 = offsetDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay23);
        int int25 = offsetDateTimeField13.getOffset();
        long long27 = offsetDateTimeField13.roundCeiling(3121272891539L);
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime30 = dateTime28.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime31 = dateTime30.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime31.toYearMonthDay();
        int[] intArray33 = null;
        int int34 = offsetDateTimeField13.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay32, intArray33);
        org.joda.time.DateTimeZone dateTimeZone36 = null;
        org.joda.time.chrono.ISOChronology iSOChronology37 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone36);
        org.joda.time.DateTimeField dateTimeField38 = iSOChronology37.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField40 = new org.joda.time.field.OffsetDateTimeField(dateTimeField38, (int) '4');
        java.util.Locale locale42 = null;
        java.lang.String str43 = offsetDateTimeField40.getAsShortText(53, locale42);
        int int45 = offsetDateTimeField40.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial46 = null;
        int[] intArray47 = new int[] {};
        int int48 = offsetDateTimeField40.getMinimumValue(readablePartial46, intArray47);
        org.joda.time.ReadablePartial readablePartial49 = null;
        int int50 = offsetDateTimeField40.getMinimumValue(readablePartial49);
        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime53 = dateTime51.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime54 = dateTime53.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay55 = dateTime54.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone56 = null;
        org.joda.time.chrono.ISOChronology iSOChronology57 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone56);
        org.joda.time.DateTimeField dateTimeField58 = iSOChronology57.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField60 = new org.joda.time.field.OffsetDateTimeField(dateTimeField58, (int) '4');
        java.util.Locale locale62 = null;
        java.lang.String str63 = offsetDateTimeField60.getAsShortText(53, locale62);
        int int65 = offsetDateTimeField60.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial66 = null;
        int[] intArray67 = new int[] {};
        int int68 = offsetDateTimeField60.getMinimumValue(readablePartial66, intArray67);
        int int69 = offsetDateTimeField40.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay55, intArray67);
        try {
            int[] intArray71 = offsetDateTimeField4.addWrapField((org.joda.time.ReadablePartial) yearMonthDay32, (-53), intArray67, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -53");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 36125L + "'", long16 == 36125L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 53 + "'", int18 == 53);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(yearMonthDay23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 53 + "'", int24 == 53);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 3121315200000L + "'", long27 == 3121315200000L);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 53 + "'", int34 == 53);
        org.junit.Assert.assertNotNull(iSOChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "53" + "'", str43.equals("53"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 52 + "'", int48 == 52);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 52 + "'", int50 == 52);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime53);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(yearMonthDay55);
        org.junit.Assert.assertNotNull(iSOChronology57);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "53" + "'", str63.equals("53"));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 52 + "'", int68 == 52);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 53 + "'", int69 == 53);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        int int5 = property4.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTime();
        org.joda.time.DateTime.Property property7 = dateTime5.millisOfDay();
        org.joda.time.DateTime dateTime9 = dateTime5.withMinuteOfHour(6);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PST", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder3.setStandardOffset((-32));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder7 = dateTimeZoneBuilder5.setStandardOffset((-54446517));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder7);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        long long5 = dateTime4.getMillis();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
        int int10 = dateTime9.getMinuteOfDay();
        org.joda.time.DateTime dateTime12 = dateTime9.minusMonths((int) (short) 10);
        int int13 = dateTime9.getYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1969 + "'", int13 == 1969);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime.Property property12 = dateTime7.secondOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = null;
        try {
            org.joda.time.DateTime dateTime15 = dateTime7.withField(dateTimeFieldType13, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        try {
            int int46 = unsupportedDateTimeField43.getLeapAmount(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        long long16 = dateTime15.getMillis();
        org.joda.time.DateMidnight dateMidnight17 = dateTime15.toDateMidnight();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        long long19 = dateTime18.getMillis();
        boolean boolean20 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.minus(readableDuration21);
        org.joda.time.DateTime dateTime24 = dateTime18.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime26 = dateTime24.plus(1560636445170L);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone27);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.hourOfHalfday();
        org.joda.time.Chronology chronology31 = iSOChronology29.withUTC();
        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.DateTime.Property property33 = dateTime32.era();
        boolean boolean34 = zonedChronology14.equals((java.lang.Object) property33);
        try {
            long long40 = zonedChronology14.getDateTimeMillis(1560636503304L, (int) (short) 10, 734, (int) (short) -1, (-1372750000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 734 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        long long47 = unsupportedDateTimeField43.getDifferenceAsLong(97L, 1560636463902L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-49L) + "'", long47 == (-49L));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(54446517);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-54446517) + "'", int1 == (-54446517));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        try {
            int int45 = unsupportedDateTimeField43.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, readableInstant7);
        org.joda.time.DateTime.Property property9 = dateTime5.millisOfSecond();
        int int10 = dateTime5.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        try {
            int int1 = org.joda.time.field.FieldUtils.safeToInt(1560636477565L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560636477565");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, readableInstant2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getSecondOfMinute();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.withPeriodAdded(readablePeriod7, (-32));
        org.joda.time.DateTime.Property property10 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime12 = dateTime2.withYear((int) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime2.withDayOfMonth((int) (short) 1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeUtils.getZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone16 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone9);
        java.lang.String str18 = fixedDateTimeZone9.getNameKey(1560636477423L);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(cachedDateTimeZone16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "0" + "'", str18.equals("0"));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.plus(1560636439434L);
        int int5 = dateTime4.getMinuteOfDay();
        java.util.GregorianCalendar gregorianCalendar6 = dateTime4.toGregorianCalendar();
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfWeek();
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withDayOfMonth((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for dayOfMonth must be in the range [1,30]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 907 + "'", int5 == 907);
        org.junit.Assert.assertNotNull(gregorianCalendar6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, (java.lang.Number) (byte) 100, "GregorianChronology[America/Los_Angeles]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException17 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType10, (java.lang.Number) 1560636463294L, (java.lang.Number) 10.0d, (java.lang.Number) 1560636445397L);
        java.lang.String str18 = illegalFieldValueException17.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType10);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "1560636463294" + "'", str18.equals("1560636463294"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.Instant instant6 = dateTime5.toInstant();
        org.joda.time.DateTime dateTime7 = dateTime5.toDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(instant6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        boolean boolean3 = iSOChronology1.equals((java.lang.Object) 1560636476505L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        boolean boolean4 = dateTime0.isAfter((long) (short) 0);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime0.withDurationAdded(readableDuration5, 0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("299");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '299' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.joda.time.Chronology chronology7 = null;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (byte) 10, (int) (short) 100, 54446517, 907, 5, (-1372750000), 72, chronology7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 907 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.lang.String str6 = offsetDateTimeField4.getAsText(1560636440970L);
        int int8 = offsetDateTimeField4.getMinimumValue((long) 1);
        int int10 = offsetDateTimeField4.getMaximumValue(1560636464511L);
        org.joda.time.DurationField durationField11 = offsetDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "53" + "'", str6.equals("53"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 53 + "'", int10 == 53);
        org.junit.Assert.assertNull(durationField11);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        long long5 = dateTime4.getMillis();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime10 = dateTime4.withCenturyOfEra((int) (byte) 100);
        org.joda.time.Chronology chronology11 = dateTime10.getChronology();
        org.joda.time.DateTime dateTime13 = dateTime10.withMillisOfDay(999);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readableDuration14);
        java.util.Date date16 = dateTime15.toDate();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        int int9 = dateTime7.getMonthOfYear();
        org.joda.time.DateTime dateTime11 = dateTime7.withCenturyOfEra((int) '4');
        org.joda.time.DateTime.Property property12 = dateTime11.weekOfWeekyear();
        long long13 = property12.remainder();
        int int14 = property12.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 144000000L + "'", long13 == 144000000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology2.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.era();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        long long6 = dateTimeZone3.adjustOffset((long) 1, true);
//        long long9 = dateTimeZone3.convertLocalToUTC((long) 1969, true);
//        int int11 = dateTimeZone3.getOffsetFromLocal(1560636442663L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        int int14 = cachedDateTimeZone12.getStandardOffset(1560636478487L);
//        long long16 = cachedDateTimeZone12.nextTransition(24L);
//        java.lang.String str18 = cachedDateTimeZone12.getName(0L);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28801969L + "'", long9 == 28801969L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 9972000000L + "'", long16 == 9972000000L);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Pacific Standard Time" + "'", str18.equals("Pacific Standard Time"));
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property3 = dateTime0.millisOfSecond();
        org.joda.time.DateTime dateTime5 = dateTime0.minusYears((-25200000));
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) '4');
        java.util.Locale locale12 = null;
        java.lang.String str13 = offsetDateTimeField10.getAsShortText(53, locale12);
        int int15 = offsetDateTimeField10.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial16 = null;
        int[] intArray17 = new int[] {};
        int int18 = offsetDateTimeField10.getMinimumValue(readablePartial16, intArray17);
        org.joda.time.ReadablePartial readablePartial19 = null;
        int int20 = offsetDateTimeField10.getMinimumValue(readablePartial19);
        int int21 = dateTime5.get((org.joda.time.DateTimeField) offsetDateTimeField10);
        long long23 = offsetDateTimeField10.roundCeiling(1560636495717L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "53" + "'", str13.equals("53"));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 52 + "'", int18 == 52);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 53 + "'", int21 == 53);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560668400000L + "'", long23 == 1560668400000L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfSecond(12);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime11.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime13.toDateTime();
        org.joda.time.DateTime.Property property15 = dateTime13.yearOfEra();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime18 = dateTime16.plusWeeks((int) (short) -1);
        int int19 = property15.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime22 = dateTime18.withCenturyOfEra(6);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        java.lang.String str25 = iSOChronology24.toString();
        org.joda.time.DateTimeZone dateTimeZone26 = iSOChronology24.getZone();
        org.joda.time.DateTime dateTime27 = dateTime18.toDateTime(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str25.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime3 = dateTime1.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime3.toDateTime();
        org.joda.time.DateTime.Property property5 = dateTime3.yearOfEra();
        java.lang.String str6 = property5.getName();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((int) '4');
        org.joda.time.Chronology chronology9 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime8);
        int int10 = dateTime8.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime12 = dateTime8.minusMonths(4);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime15 = dateTime13.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime16 = dateTime15.toDateTime();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfEra();
        java.lang.String str18 = property17.getName();
        org.joda.time.DateTime dateTime20 = property17.addToCopy((int) '4');
        org.joda.time.DateTime dateTime22 = dateTime20.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone23 = null;
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone23);
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology24.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField(dateTimeField25, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = offsetDateTimeField27.getType();
        boolean boolean29 = dateTime22.isSupported(dateTimeFieldType28);
        boolean boolean30 = dateTime12.isSupported(dateTimeFieldType28);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType28, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter35 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean36 = dateTimeFormatter35.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter38 = dateTimeFormatter35.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone39 = null;
        org.joda.time.chrono.ISOChronology iSOChronology40 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone39);
        org.joda.time.DateTimeField dateTimeField41 = iSOChronology40.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter42 = dateTimeFormatter38.withChronology((org.joda.time.Chronology) iSOChronology40);
        org.joda.time.DurationField durationField43 = iSOChronology40.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField44 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType28, durationField43);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "yearOfEra" + "'", str6.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 52 + "'", int10 == 52);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "yearOfEra" + "'", str18.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertNotNull(dateTimeFieldType28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter38);
        org.junit.Assert.assertNotNull(iSOChronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(dateTimeFormatter42);
        org.junit.Assert.assertNotNull(durationField43);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField44);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) ' ');
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime.Property property6 = dateTime4.year();
        org.joda.time.DateTime dateTime7 = property6.withMaximumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.dayOfMonth();
        org.joda.time.DurationField durationField3 = gregorianChronology0.halfdays();
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        try {
            org.joda.time.chrono.ZonedChronology zonedChronology5 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, dateTimeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTimeZone must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(durationField3);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property4.withMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.getDateTime();
        org.joda.time.DurationField durationField7 = property4.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNull(durationField7);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        long long7 = offsetDateTimeField4.getDifferenceAsLong(1560636445932L, (-1L));
        int int9 = offsetDateTimeField4.getLeapAmount(1560031645303L);
        long long12 = offsetDateTimeField4.add(1560636439501L, 20);
        long long14 = offsetDateTimeField4.roundHalfCeiling(1560636440801L);
        int int16 = offsetDateTimeField4.getMaximumValue(1560636447601L);
        int int17 = offsetDateTimeField4.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 36125L + "'", long7 == 36125L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561500439501L + "'", long12 == 1561500439501L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560625200000L + "'", long14 == 1560625200000L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.toString();
        try {
            int int46 = unsupportedDateTimeField43.getMaximumValue();
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        int int8 = offsetDateTimeField4.getLeapAmount((long) (-32));
        java.lang.String str10 = offsetDateTimeField4.getAsShortText(1560636443904L);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField4.getType();
        org.joda.time.ReadablePartial readablePartial12 = null;
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) '4');
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField18.getAsShortText(53, locale20);
        int int23 = offsetDateTimeField18.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int[] intArray25 = new int[] {};
        int int26 = offsetDateTimeField18.getMinimumValue(readablePartial24, intArray25);
        org.joda.time.ReadablePartial readablePartial27 = null;
        int int28 = offsetDateTimeField18.getMinimumValue(readablePartial27);
        org.joda.time.DateTimeZone dateTimeZone29 = null;
        org.joda.time.chrono.ISOChronology iSOChronology30 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = iSOChronology30.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField33 = new org.joda.time.field.OffsetDateTimeField(dateTimeField31, (int) '4');
        java.util.Locale locale35 = null;
        java.lang.String str36 = offsetDateTimeField33.getAsShortText(53, locale35);
        int int38 = offsetDateTimeField33.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial39 = null;
        int[] intArray40 = new int[] {};
        int int41 = offsetDateTimeField33.getMinimumValue(readablePartial39, intArray40);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int int43 = offsetDateTimeField33.getMinimumValue(readablePartial42);
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime46 = dateTime44.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime47 = dateTime46.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay48 = dateTime47.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone49 = null;
        org.joda.time.chrono.ISOChronology iSOChronology50 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone49);
        org.joda.time.DateTimeField dateTimeField51 = iSOChronology50.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField53 = new org.joda.time.field.OffsetDateTimeField(dateTimeField51, (int) '4');
        java.util.Locale locale55 = null;
        java.lang.String str56 = offsetDateTimeField53.getAsShortText(53, locale55);
        int int58 = offsetDateTimeField53.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial59 = null;
        int[] intArray60 = new int[] {};
        int int61 = offsetDateTimeField53.getMinimumValue(readablePartial59, intArray60);
        int int62 = offsetDateTimeField33.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay48, intArray60);
        org.joda.time.DateTimeZone dateTimeZone63 = null;
        org.joda.time.chrono.ISOChronology iSOChronology64 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone63);
        org.joda.time.DateTimeField dateTimeField65 = iSOChronology64.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField67 = new org.joda.time.field.OffsetDateTimeField(dateTimeField65, (int) '4');
        java.util.Locale locale69 = null;
        java.lang.String str70 = offsetDateTimeField67.getAsShortText(53, locale69);
        int int72 = offsetDateTimeField67.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial73 = null;
        int[] intArray74 = new int[] {};
        int int75 = offsetDateTimeField67.getMinimumValue(readablePartial73, intArray74);
        org.joda.time.ReadablePartial readablePartial76 = null;
        int int77 = offsetDateTimeField67.getMinimumValue(readablePartial76);
        org.joda.time.DateTime dateTime78 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime80 = dateTime78.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime81 = dateTime80.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay82 = dateTime81.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone83 = null;
        org.joda.time.chrono.ISOChronology iSOChronology84 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone83);
        org.joda.time.DateTimeField dateTimeField85 = iSOChronology84.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField87 = new org.joda.time.field.OffsetDateTimeField(dateTimeField85, (int) '4');
        java.util.Locale locale89 = null;
        java.lang.String str90 = offsetDateTimeField87.getAsShortText(53, locale89);
        int int92 = offsetDateTimeField87.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial93 = null;
        int[] intArray94 = new int[] {};
        int int95 = offsetDateTimeField87.getMinimumValue(readablePartial93, intArray94);
        int int96 = offsetDateTimeField67.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay82, intArray94);
        int int97 = offsetDateTimeField18.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay48, intArray94);
        int[] intArray99 = offsetDateTimeField4.add(readablePartial12, 735, intArray94, (int) (byte) 0);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "53" + "'", str10.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "53" + "'", str21.equals("53"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 52 + "'", int26 == 52);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 52 + "'", int28 == 52);
        org.junit.Assert.assertNotNull(iSOChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "53" + "'", str36.equals("53"));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 52 + "'", int41 == 52);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 52 + "'", int43 == 52);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(yearMonthDay48);
        org.junit.Assert.assertNotNull(iSOChronology50);
        org.junit.Assert.assertNotNull(dateTimeField51);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "53" + "'", str56.equals("53"));
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 52 + "'", int61 == 52);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 53 + "'", int62 == 53);
        org.junit.Assert.assertNotNull(iSOChronology64);
        org.junit.Assert.assertNotNull(dateTimeField65);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "53" + "'", str70.equals("53"));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 52 + "'", int75 == 52);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 52 + "'", int77 == 52);
        org.junit.Assert.assertNotNull(dateTime78);
        org.junit.Assert.assertNotNull(dateTime80);
        org.junit.Assert.assertNotNull(dateTime81);
        org.junit.Assert.assertNotNull(yearMonthDay82);
        org.junit.Assert.assertNotNull(iSOChronology84);
        org.junit.Assert.assertNotNull(dateTimeField85);
        org.junit.Assert.assertTrue("'" + str90 + "' != '" + "53" + "'", str90.equals("53"));
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 52 + "'", int95 == 52);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 53 + "'", int96 == 53);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 52 + "'", int97 == 52);
        org.junit.Assert.assertNotNull(intArray99);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.halfdayOfDay();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = gregorianChronology2.get(readablePeriod5, (long) '4', (long) (-48));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.TimeOfDay timeOfDay6 = dateTime5.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(timeOfDay6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DateTime dateTime44 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime46 = dateTime44.plusWeeks((int) (short) -1);
        int int47 = dateTime44.getMillisOfDay();
        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime50 = dateTime48.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime51 = dateTime50.toDateTime();
        org.joda.time.DateTime.Property property52 = dateTime50.yearOfEra();
        int int53 = dateTime50.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight54 = dateTime50.toDateMidnight();
        org.joda.time.TimeOfDay timeOfDay55 = dateTime50.toTimeOfDay();
        org.joda.time.DateTime dateTime56 = dateTime44.withFields((org.joda.time.ReadablePartial) timeOfDay55);
        int[] intArray58 = null;
        try {
            int[] intArray60 = unsupportedDateTimeField43.addWrapField((org.joda.time.ReadablePartial) timeOfDay55, 16, intArray58, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 57600000 + "'", int47 == 57600000);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(property52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 12 + "'", int53 == 12);
        org.junit.Assert.assertNotNull(dateMidnight54);
        org.junit.Assert.assertNotNull(timeOfDay55);
        org.junit.Assert.assertNotNull(dateTime56);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
        int int9 = dateTime8.getYearOfCentury();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime12 = dateTime10.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
        org.joda.time.DateTime dateTime15 = dateTime12.minusMinutes((int) ' ');
        org.joda.time.MutableDateTime mutableDateTime16 = dateTime15.toMutableDateTime();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        long long18 = dateTime17.getMillis();
        org.joda.time.DateMidnight dateMidnight19 = dateTime17.toDateMidnight();
        boolean boolean20 = dateTime15.isEqual((org.joda.time.ReadableInstant) dateTime17);
        int int21 = dateTime8.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField26.getAsShortText(53, locale28);
        int int31 = offsetDateTimeField26.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial32 = null;
        int[] intArray33 = new int[] {};
        int int34 = offsetDateTimeField26.getMinimumValue(readablePartial32, intArray33);
        org.joda.time.ReadablePartial readablePartial35 = null;
        int int36 = offsetDateTimeField26.getMinimumValue(readablePartial35);
        long long38 = offsetDateTimeField26.roundCeiling(100L);
        int int40 = offsetDateTimeField26.getLeapAmount((long) 1969);
        int int42 = offsetDateTimeField26.getMaximumValue(1560636442663L);
        int int43 = dateTime15.get((org.joda.time.DateTimeField) offsetDateTimeField26);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 69 + "'", int9 == 69);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(mutableDateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "53" + "'", str29.equals("53"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 52 + "'", int36 == 52);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 28800000L + "'", long38 == 28800000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 53 + "'", int42 == 53);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 53 + "'", int43 == 53);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.plusDays((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) 'a');
        int int7 = dateTime6.getEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = dateTime2.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
        org.joda.time.DateTime dateTime7 = dateTime4.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property8 = dateTime4.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        org.joda.time.DateTime dateTime11 = dateTime4.withPeriodAdded(readablePeriod9, (-32));
        org.joda.time.DateTime.Property property12 = dateTime4.weekyear();
        org.joda.time.DateTime dateTime14 = dateTime4.withYear((int) (short) 10);
        java.lang.String str15 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime14);
        org.joda.time.DateTime.Property property16 = dateTime14.hourOfDay();
        org.joda.time.DateTime dateTime18 = dateTime14.minus(1560636490687L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "16:00:00.010-07:52:58" + "'", str15.equals("16:00:00.010-07:52:58"));
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str8 = fixedDateTimeZone4.getName((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str11 = fixedDateTimeZone4.getNameKey(1560600445078L);
        java.lang.String str12 = fixedDateTimeZone4.toString();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.100" + "'", str8.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "19" + "'", str12.equals("19"));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        try {
            boolean boolean46 = unsupportedDateTimeField43.isLeap(3121272891539L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths(166);
        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter13 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        java.lang.Integer int14 = dateTimeFormatter13.getPivotYear();
        java.lang.String str15 = dateTime11.toString(dateTimeFormatter13);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(dateTimeFormatter13);
        org.junit.Assert.assertNull(int14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "T16:00:00-08:00" + "'", str15.equals("T16:00:00-08:00"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.dayOfYear();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusWeeks((int) (short) -1);
        long long3 = dateTime2.getMillis();
        int int4 = dateTime2.getMonthOfYear();
        int int5 = dateTime2.getWeekyear();
        org.joda.time.DateTime dateTime7 = dateTime2.withYearOfEra(2);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-604800000L) + "'", long3 == (-604800000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1969 + "'", int5 == 1969);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.withMinimumValue();
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime.Property property7 = dateTime5.dayOfWeek();
        int int8 = dateTime5.getWeekyear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.plusMinutes((-32));
        java.lang.String str5 = dateTime0.toString();
        org.joda.time.DateTime.Property property6 = dateTime0.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31T16:00:00.000-08:00" + "'", str5.equals("1969-12-31T16:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(property6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime9 = dateTime7.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property10 = dateTime9.weekyear();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        long long12 = dateTime11.getMillis();
        org.joda.time.DateMidnight dateMidnight13 = dateTime11.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone14 = dateTime11.getZone();
        long long15 = property10.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime16 = property10.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime18 = dateTime16.withMillisOfDay(19);
        boolean boolean20 = dateTime18.isAfter((long) (short) -1);
        int int21 = dateTime6.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime6.isSupported(dateTimeFieldType27);
        org.joda.time.DateTime.Property property29 = dateTime6.dayOfMonth();
        org.joda.time.DateTime dateTime31 = dateTime6.plusDays(0);
        java.util.Date date32 = dateTime6.toDate();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        long long7 = offsetDateTimeField4.getDifferenceAsLong(1560636445932L, (-1L));
        int int9 = offsetDateTimeField4.getMaximumValue(1560636443974L);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime12 = dateTime10.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
        int int15 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay14);
        long long17 = offsetDateTimeField4.roundHalfCeiling(0L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 36125L + "'", long7 == 36125L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-14400000L) + "'", long17 == (-14400000L));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("166");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"166/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(54446517, 54446517, 0, (int) (byte) 1, 788);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 788 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(788, 10, (-25200000), 5, 0, (-32), chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -32 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "01:11:18-08:00", "GregorianChronology[America/Los_Angeles]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getName(locale5, "1969-12-31T16:00:00.000-08:00", "+10:00");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        long long5 = dateTime4.getMillis();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = property3.getFieldType();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray10 = new org.joda.time.DateTimeFieldType[] { dateTimeFieldType9 };
        java.util.ArrayList<org.joda.time.DateTimeFieldType> dateTimeFieldTypeList11 = new java.util.ArrayList<org.joda.time.DateTimeFieldType>();
        boolean boolean12 = java.util.Collections.addAll((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList11, dateTimeFieldTypeArray10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter15 = org.joda.time.format.ISODateTimeFormat.forFields((java.util.Collection<org.joda.time.DateTimeFieldType>) dateTimeFieldTypeList11, true, true);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter15);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PST", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder3.setStandardOffset((-32));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder5.setFixedSavings("", 69);
        java.io.OutputStream outputStream10 = null;
        try {
            dateTimeZoneBuilder5.writeTo("1970W013T160000-0800", outputStream10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        long long8 = offsetDateTimeField5.getDifferenceAsLong(1560636445932L, (-1L));
        int int10 = offsetDateTimeField5.getLeapAmount(1560031645303L);
        long long13 = offsetDateTimeField5.add(0L, (long) 5);
        org.joda.time.DateTimeZone dateTimeZone14 = null;
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone14);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology15.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField16, (int) '4');
        int int20 = offsetDateTimeField18.getMaximumValue(0L);
        int int22 = offsetDateTimeField18.getLeapAmount((long) (-32));
        java.lang.String str24 = offsetDateTimeField18.getAsShortText(1560636443904L);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField18.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField27 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField5, dateTimeFieldType25, 735);
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField28 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 36125L + "'", long8 == 36125L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 216000000L + "'", long13 == 216000000L);
        org.junit.Assert.assertNotNull(iSOChronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 53 + "'", int20 == 53);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "53" + "'", str24.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfSecond(12);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime11.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime13.toDateTime();
        org.joda.time.DateTime.Property property15 = dateTime13.yearOfEra();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime18 = dateTime16.plusWeeks((int) (short) -1);
        int int19 = property15.compareTo((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.Chronology chronology20 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime9, (org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime22 = dateTime18.withCenturyOfEra(6);
        int int23 = dateTime18.getEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(chronology20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        int int10 = dateTime7.getDayOfWeek();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DurationField durationField15 = zonedChronology14.centuries();
        java.lang.String str16 = zonedChronology14.toString();
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology14.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 19]" + "'", str16.equals("ZonedChronology[GregorianChronology[UTC], 19]"));
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.time();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        long long3 = dateTime2.getMillis();
        org.joda.time.DateMidnight dateMidnight4 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        long long6 = dateTime5.getMillis();
        boolean boolean7 = dateTime2.isAfter((org.joda.time.ReadableInstant) dateTime5);
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime5.minus(readableDuration8);
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfSecond(12);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfMinute();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime15 = dateTime13.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime16 = dateTime15.toDateTime();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfEra();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime20 = dateTime18.plusWeeks((int) (short) -1);
        int int21 = property17.compareTo((org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.Chronology chronology22 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime11, (org.joda.time.ReadableInstant) dateTime20);
        org.joda.time.DateTime dateTime24 = dateTime20.withCenturyOfEra(6);
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        long long26 = dateTime25.getMillis();
        org.joda.time.DateMidnight dateMidnight27 = dateTime25.toDateMidnight();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
        long long29 = dateTime28.getMillis();
        boolean boolean30 = dateTime25.isAfter((org.joda.time.ReadableInstant) dateTime28);
        org.joda.time.ReadableDuration readableDuration31 = null;
        org.joda.time.DateTime dateTime32 = dateTime28.minus(readableDuration31);
        org.joda.time.DateTime dateTime34 = dateTime28.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime36 = dateTime34.plus(1560636445170L);
        int int37 = dateTime20.compareTo((org.joda.time.ReadableInstant) dateTime34);
        java.lang.String str38 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime34);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter0.withPivotYear(2);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(chronology22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "16:00:00.000-08:00" + "'", str38.equals("16:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("AD", "Pacific Daylight Time", (-19), (int) 'a');
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        long long7 = offsetDateTimeField4.getDifferenceAsLong(1560636445932L, (-1L));
        int int9 = offsetDateTimeField4.getMaximumValue(1560636443974L);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime12 = dateTime10.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
        int int15 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay14);
        int int16 = offsetDateTimeField4.getOffset();
        boolean boolean18 = offsetDateTimeField4.isLeap(1560636497046L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 36125L + "'", long7 == 36125L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        org.joda.time.format.DateTimeParser dateTimeParser1 = dateTimeFormatter0.getParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeParser1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        long long5 = dateTime4.getMillis();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) '4');
        java.util.Locale locale16 = null;
        java.lang.String str17 = offsetDateTimeField14.getAsShortText(53, locale16);
        int int19 = offsetDateTimeField14.getLeapAmount(1560636442281L);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField14.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException23 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) (byte) 100, "GregorianChronology[America/Los_Angeles]");
        boolean boolean24 = dateTime9.isSupported(dateTimeFieldType20);
        org.joda.time.DateTime dateTime26 = dateTime9.withYear(100);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "53" + "'", str17.equals("53"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        boolean boolean6 = property4.equals((java.lang.Object) 1560636475949L);
        try {
            org.joda.time.DateTime dateTime8 = property4.setCopy("Property[yearOfEra]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Property[yearOfEra]\" for centuryOfEra is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfSecond(12);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
        java.util.Locale locale11 = null;
        java.lang.String str12 = property10.getAsText(locale11);
        long long13 = property10.remainder();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 12L + "'", long13 == 12L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str8 = fixedDateTimeZone4.getName((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        java.lang.String str11 = fixedDateTimeZone4.getNameKey(1560600445078L);
        int int13 = fixedDateTimeZone4.getOffset(0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.100" + "'", str8.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "0" + "'", str11.equals("0"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.plusDays((int) '#');
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.lang.String str6 = dateTime0.toString(dateTimeFormatter5);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1970-W01-3" + "'", str6.equals("1970-W01-3"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField4.getAsShortText(1560636444182L, locale8);
        org.joda.time.DateTimeField dateTimeField10 = offsetDateTimeField4.getWrappedField();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "53" + "'", str9.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        org.joda.time.DateTime dateTime6 = dateTime2.plus(0L);
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays(54469861);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.plusMinutes((-32));
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        java.util.Locale locale7 = null;
        int int8 = property5.getMaximumTextLength(locale7);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PST", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder6 = dateTimeZoneBuilder3.setFixedSavings("", 166);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder9 = dateTimeZoneBuilder3.setFixedSavings("", 10);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder6);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder9);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        long long5 = dateTime4.getMillis();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        int int9 = dateTime4.getDayOfYear();
        org.joda.time.DateTime dateTime11 = dateTime4.minusMinutes(19);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        int int5 = dateTime2.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 69 + "'", int5 == 69);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.DateTime.Property property8 = dateTime7.secondOfMinute();
        org.joda.time.DateTime dateTime10 = property8.setCopy(0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        try {
            java.lang.String str46 = unsupportedDateTimeField43.getAsText((long) (-35));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.plusDays((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) 'a');
        org.joda.time.Chronology chronology7 = dateTime4.getChronology();
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str8 = fixedDateTimeZone4.getName((-1L));
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        long long11 = fixedDateTimeZone4.nextTransition(1560636462915L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.100" + "'", str8.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560636462915L + "'", long11 == 1560636462915L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.plus(1560636439434L);
        org.joda.time.ReadableInstant readableInstant5 = null;
        boolean boolean6 = dateTime2.isEqual(readableInstant5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField4 = gregorianChronology3.millis();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.dayOfMonth();
        org.joda.time.DateTime dateTime6 = dateTime0.toDateTime((org.joda.time.Chronology) gregorianChronology3);
        org.joda.time.Chronology chronology7 = dateTime0.getChronology();
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology9.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField12 = new org.joda.time.field.OffsetDateTimeField(dateTimeField10, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType13 = offsetDateTimeField12.getType();
        try {
            org.joda.time.DateTime dateTime15 = dateTime0.withField(dateTimeFieldType13, 16);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 16 for halfdayOfDay must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeFieldType13);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        java.util.TimeZone timeZone6 = fixedDateTimeZone4.toTimeZone();
        java.lang.String str8 = fixedDateTimeZone4.getName((-1L));
        int int10 = fixedDateTimeZone4.getOffsetFromLocal(12L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+00:00:00.100" + "'", str8.equals("+00:00:00.100"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, 1);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gregorianChronology6.add(readablePeriod7, 1560636438373L, (int) (short) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gregorianChronology6);
        java.util.Locale locale12 = dateTimeFormatter11.getLocale();
        try {
            org.joda.time.MutableDateTime mutableDateTime14 = dateTimeFormatter11.parseMutableDateTime("16:00:00.000-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"16:00:00.000-08:00\" is malformed at \":00:00.000-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560636438373L + "'", long10 == 1560636438373L);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNull(locale12);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DurationField durationField8 = iSOChronology5.years();
        org.joda.time.DurationField durationField9 = iSOChronology5.halfdays();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now((org.joda.time.Chronology) iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test263() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test263");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusDays((int) '#');
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        long long6 = dateTime5.getMillis();
//        org.joda.time.DateMidnight dateMidnight7 = dateTime5.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 0);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getShortName((long) (byte) 10, locale12);
//        org.joda.time.DateTime dateTime14 = dateTime4.withZoneRetainFields(dateTimeZone8);
//        int int15 = dateTime14.getYearOfCentury();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PST" + "'", str13.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 70 + "'", int15 == 70);
//    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(3, 735, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DurationField durationField3 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.yearOfEra();
        org.joda.time.DurationField durationField5 = gregorianChronology0.years();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(durationField5);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        java.util.TimeZone timeZone1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        org.joda.time.DateTime dateTime3 = new org.joda.time.DateTime(1560636443698L, dateTimeZone2);
        int int5 = dateTimeZone2.getOffsetFromLocal(3121272891539L);
        java.lang.String str6 = dateTimeZone2.getID();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-28800000) + "'", int5 == (-28800000));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "America/Los_Angeles" + "'", str6.equals("America/Los_Angeles"));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.hourOfDay();
        org.joda.time.TimeOfDay timeOfDay8 = dateTime2.toTimeOfDay();
        org.joda.time.DateTime.Property property9 = dateTime2.dayOfWeek();
        java.lang.String str10 = property9.getName();
        java.lang.String str11 = property9.toString();
        int int12 = property9.getMinimumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(timeOfDay8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "dayOfWeek" + "'", str10.equals("dayOfWeek"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[dayOfWeek]" + "'", str11.equals("Property[dayOfWeek]"));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.plus(1560636445170L);
        int int12 = dateTime11.getMinuteOfDay();
        org.joda.time.DateTime dateTime13 = dateTime11.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 907 + "'", int12 == 907);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        org.joda.time.DateTime dateTime7 = property4.roundHalfEvenCopy();
        int int8 = property4.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.halfdayOfDay();
        org.joda.time.Chronology chronology5 = gregorianChronology2.withUTC();
        org.joda.time.DurationField durationField6 = gregorianChronology2.weekyears();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(chronology5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DurationField durationField3 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.weekyearOfCentury();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField4, 2018, 16, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2018 for weekyearOfCentury must be in the range [16,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 267, 16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
//        long long4 = dateTime3.getMillis();
//        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
//        org.joda.time.ReadableDuration readableDuration6 = null;
//        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
//        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths((int) (byte) 1);
//        org.joda.time.DateTime dateTime11 = dateTime9.plus(1560636445170L);
//        org.joda.time.DateTimeZone dateTimeZone12 = null;
//        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone12);
//        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.hourOfHalfday();
//        org.joda.time.Chronology chronology16 = iSOChronology14.withUTC();
//        org.joda.time.DateTime dateTime17 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology14);
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
//        long long19 = dateTime18.getMillis();
//        org.joda.time.DateMidnight dateMidnight20 = dateTime18.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTime18.getZone();
//        long long24 = dateTimeZone21.adjustOffset((long) 1, true);
//        long long27 = dateTimeZone21.convertLocalToUTC((long) 1969, true);
//        org.joda.time.Chronology chronology28 = iSOChronology14.withZone(dateTimeZone21);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeUtils.getZone(dateTimeZone21);
//        java.util.Locale locale31 = null;
//        java.lang.String str32 = dateTimeZone21.getName((long) (-25200000), locale31);
//        int int34 = dateTimeZone21.getOffsetFromLocal((long) (short) 1);
//        try {
//            org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone21, 267);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 267");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(iSOChronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(chronology16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
//        org.junit.Assert.assertNotNull(dateMidnight20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28801969L + "'", long27 == 28801969L);
//        org.junit.Assert.assertNotNull(chronology28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "Pacific Standard Time" + "'", str32.equals("Pacific Standard Time"));
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-28800000) + "'", int34 == (-28800000));
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        long long6 = dateTimeZone3.adjustOffset((long) 1, true);
        long long9 = dateTimeZone3.convertLocalToUTC((long) 1969, true);
        long long11 = dateTimeZone3.convertUTCToLocal(1560636463293L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28801969L + "'", long9 == 28801969L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560611263293L + "'", long11 == 1560611263293L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        java.util.Locale locale6 = null;
        java.lang.String str7 = fixedDateTimeZone4.getName((long) (byte) 10, locale6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "+00:00:00.100" + "'", str7.equals("+00:00:00.100"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DurationField durationField15 = zonedChronology14.centuries();
        org.joda.time.DateTimeZone dateTimeZone16 = null;
        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) '4');
        long long23 = offsetDateTimeField20.getDifferenceAsLong(1560636445932L, (-1L));
        int int25 = offsetDateTimeField20.getMaximumValue(1560636443974L);
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime28 = dateTime26.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime29 = dateTime28.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay30 = dateTime29.toYearMonthDay();
        int int31 = offsetDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay30);
        boolean boolean32 = zonedChronology14.equals((java.lang.Object) offsetDateTimeField20);
        try {
            long long38 = zonedChronology14.getDateTimeMillis(1560636475949L, (-1), (-25200000), 10, 19);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(iSOChronology17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 36125L + "'", long23 == 36125L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 53 + "'", int25 == 53);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(yearMonthDay30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 53 + "'", int31 == 53);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        long long5 = dateTime4.getMillis();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfDay(19);
        org.joda.time.LocalTime localTime12 = dateTime11.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localTime12);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        long long47 = unsupportedDateTimeField43.add(12L, (-1));
        org.joda.time.ReadablePartial readablePartial48 = null;
        try {
            int int49 = unsupportedDateTimeField43.getMaximumValue(readablePartial48);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-31535999988L) + "'", long47 == (-31535999988L));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        int int8 = offsetDateTimeField4.getLeapAmount((long) (-32));
        org.joda.time.ReadablePartial readablePartial9 = null;
        java.util.Locale locale11 = null;
        java.lang.String str12 = offsetDateTimeField4.getAsText(readablePartial9, 0, locale11);
        long long15 = offsetDateTimeField4.set(1560636480996L, 52);
        long long18 = offsetDateTimeField4.getDifferenceAsLong(1560636464326L, 1560636473557L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560593280996L + "'", long15 == 1560593280996L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.plusMillis(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.withZoneRetainFields(dateTimeZone5);
        org.joda.time.DateTime.Property property7 = dateTime4.centuryOfEra();
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            int int9 = property7.compareTo(readablePartial8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        org.joda.time.MutableDateTime mutableDateTime5 = dateTime2.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(mutableDateTime5);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        long long5 = dateTime4.getMillis();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.withMillisOfDay(19);
        org.joda.time.Instant instant12 = dateTime11.toInstant();
        org.joda.time.Chronology chronology13 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime15 = dateTime11.minusDays(0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(instant12);
        org.junit.Assert.assertNotNull(chronology13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime0.year();
        java.lang.Object obj7 = null;
        boolean boolean8 = property6.equals(obj7);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        long long16 = dateTime15.getMillis();
        org.joda.time.DateMidnight dateMidnight17 = dateTime15.toDateMidnight();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        long long19 = dateTime18.getMillis();
        boolean boolean20 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.minus(readableDuration21);
        org.joda.time.DateTime dateTime24 = dateTime18.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime26 = dateTime24.plus(1560636445170L);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone27);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.hourOfHalfday();
        org.joda.time.Chronology chronology31 = iSOChronology29.withUTC();
        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.DateTime.Property property33 = dateTime32.era();
        boolean boolean34 = zonedChronology14.equals((java.lang.Object) property33);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.Chronology chronology36 = zonedChronology14.withZone(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = zonedChronology14.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField38 = zonedChronology14.year();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray11 = new int[] {};
        int int12 = offsetDateTimeField4.getMinimumValue(readablePartial10, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField4.getMinimumValue(readablePartial13);
        long long16 = offsetDateTimeField4.roundCeiling(100L);
        int int18 = offsetDateTimeField4.getLeapAmount((long) 1969);
        int int20 = offsetDateTimeField4.getMaximumValue(1560636442663L);
        int int22 = offsetDateTimeField4.getMinimumValue((long) ' ');
        long long24 = offsetDateTimeField4.roundHalfEven(1560636495437L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 53 + "'", int20 == 53);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560625200000L + "'", long24 == 1560625200000L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.plus(readableDuration10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMinutes(72);
        org.joda.time.DateTime dateTime15 = dateTime13.minusMinutes(100);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 1560636475949L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getActions();
        java.security.PermissionCollection permissionCollection4 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 12, 1969);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0, 54446517);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.lang.String str6 = offsetDateTimeField4.getAsText(1560636440970L);
        int int8 = offsetDateTimeField4.getMinimumValue((long) 1);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        long long12 = offsetDateTimeField4.roundHalfCeiling((long) 9);
        org.joda.time.DateTimeZone dateTimeZone13 = null;
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) '4');
        java.util.Locale locale19 = null;
        java.lang.String str20 = offsetDateTimeField17.getAsShortText(53, locale19);
        int int22 = offsetDateTimeField17.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int[] intArray24 = new int[] {};
        int int25 = offsetDateTimeField17.getMinimumValue(readablePartial23, intArray24);
        java.lang.String str26 = offsetDateTimeField17.toString();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime29 = dateTime27.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime30 = dateTime29.toDateTime();
        org.joda.time.DateTime.Property property31 = dateTime29.yearOfEra();
        org.joda.time.DateTime dateTime33 = dateTime29.plus(0L);
        boolean boolean35 = dateTime33.isBefore((long) 54446517);
        org.joda.time.YearMonthDay yearMonthDay36 = dateTime33.toYearMonthDay();
        int int37 = offsetDateTimeField17.getMinimumValue((org.joda.time.ReadablePartial) yearMonthDay36);
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField4.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay36, (-35), locale39);
        long long42 = offsetDateTimeField4.roundHalfCeiling((-14400000L));
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "53" + "'", str6.equals("53"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-14400000L) + "'", long10 == (-14400000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-14400000L) + "'", long12 == (-14400000L));
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "53" + "'", str20.equals("53"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "DateTimeField[halfdayOfDay]" + "'", str26.equals("DateTimeField[halfdayOfDay]"));
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(yearMonthDay36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 52 + "'", int37 == 52);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "-35" + "'", str40.equals("-35"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + (-14400000L) + "'", long42 == (-14400000L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        long long47 = unsupportedDateTimeField43.add(12L, (-1));
        org.joda.time.DateTimeZone dateTimeZone48 = null;
        org.joda.time.chrono.ISOChronology iSOChronology49 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone48);
        org.joda.time.DateTimeField dateTimeField50 = iSOChronology49.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField52 = new org.joda.time.field.OffsetDateTimeField(dateTimeField50, (int) '4');
        java.util.Locale locale54 = null;
        java.lang.String str55 = offsetDateTimeField52.getAsShortText(53, locale54);
        org.joda.time.DateTime dateTime56 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime58 = dateTime56.plusWeeks((int) (short) -1);
        int int59 = dateTime56.getMillisOfDay();
        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime62 = dateTime60.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime63 = dateTime62.toDateTime();
        org.joda.time.DateTime.Property property64 = dateTime62.yearOfEra();
        int int65 = dateTime62.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight66 = dateTime62.toDateMidnight();
        org.joda.time.TimeOfDay timeOfDay67 = dateTime62.toTimeOfDay();
        org.joda.time.DateTime dateTime68 = dateTime56.withFields((org.joda.time.ReadablePartial) timeOfDay67);
        int int69 = offsetDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) timeOfDay67);
        java.util.Locale locale71 = null;
        try {
            java.lang.String str72 = unsupportedDateTimeField43.getAsText((org.joda.time.ReadablePartial) timeOfDay67, 166, locale71);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-31535999988L) + "'", long47 == (-31535999988L));
        org.junit.Assert.assertNotNull(iSOChronology49);
        org.junit.Assert.assertNotNull(dateTimeField50);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "53" + "'", str55.equals("53"));
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 57600000 + "'", int59 == 57600000);
        org.junit.Assert.assertNotNull(dateTime60);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 12 + "'", int65 == 12);
        org.junit.Assert.assertNotNull(dateMidnight66);
        org.junit.Assert.assertNotNull(timeOfDay67);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 52 + "'", int69 == 52);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, 1);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gregorianChronology6.add(readablePeriod7, 1560636438373L, (int) (short) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTimeFormatter2.getZone();
        java.lang.String str14 = dateTimeFormatter2.print(1560636499939L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560636438373L + "'", long10 == 1560636438373L);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019-06-15T15:08:19" + "'", str14.equals("2019-06-15T15:08:19"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.toString();
        try {
            long long48 = unsupportedDateTimeField43.add(1560636438003L, 1560031666876L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 1560031666876");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(365, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minus(1560636485020L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        long long5 = dateTime4.getMillis();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis(10);
        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra((int) (byte) 0);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        long long15 = dateTime14.getMillis();
        org.joda.time.DateMidnight dateMidnight16 = dateTime14.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime14.getZone();
        long long20 = dateTimeZone17.adjustOffset((long) 1, true);
        long long23 = dateTimeZone17.convertLocalToUTC((long) 1969, true);
        int int25 = dateTimeZone17.getOffsetFromLocal(1560636442663L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone26 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone17);
        long long28 = cachedDateTimeZone26.nextTransition(1560661646204L);
        long long30 = cachedDateTimeZone26.previousTransition((long) 2018);
        java.lang.Number number32 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException35 = new org.joda.time.IllegalFieldValueException("53", number32, (java.lang.Number) 1560636444857L, (java.lang.Number) 1L);
        java.lang.Number number36 = illegalFieldValueException35.getIllegalNumberValue();
        java.lang.Number number37 = illegalFieldValueException35.getUpperBound();
        boolean boolean38 = cachedDateTimeZone26.equals((java.lang.Object) illegalFieldValueException35);
        org.joda.time.DateTimeZone dateTimeZone39 = cachedDateTimeZone26.getUncachedZone();
        int int41 = cachedDateTimeZone26.getStandardOffset(1560636480550L);
        org.joda.time.MutableDateTime mutableDateTime42 = dateTime9.toMutableDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone26);
        int int43 = mutableDateTime42.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1L + "'", long20 == 1L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 28801969L + "'", long23 == 28801969L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-25200000) + "'", int25 == (-25200000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1572771600000L + "'", long28 == 1572771600000L);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + (-5756400001L) + "'", long30 == (-5756400001L));
        org.junit.Assert.assertNull(number36);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 1L + "'", number37.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-28800000) + "'", int41 == (-28800000));
        org.junit.Assert.assertNotNull(mutableDateTime42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 363 + "'", int43 == 363);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateTime dateTime3 = dateTime0.minusMillis(19);
        org.joda.time.DateTime.Property property4 = dateTime3.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property9 = dateTime8.weekyear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        long long11 = dateTime10.getMillis();
        org.joda.time.DateMidnight dateMidnight12 = dateTime10.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone13 = dateTime10.getZone();
        long long14 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime15 = property9.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime17 = dateTime15.plusMillis(10);
        org.joda.time.DateTime dateTime19 = dateTime15.plusYears((int) (byte) 1);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime22 = dateTime20.minusDays((int) (short) 100);
        int int23 = dateTime22.getYearOfCentury();
        org.joda.time.DateTime dateTime25 = dateTime22.plusWeeks(166);
        org.joda.time.DateTime dateTime27 = dateTime22.plusYears(1969);
        org.joda.time.Chronology chronology28 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime15, (org.joda.time.ReadableInstant) dateTime27);
        long long29 = property5.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime15);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 69 + "'", int23 == 69);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(chronology28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray11 = new int[] {};
        int int12 = offsetDateTimeField4.getMinimumValue(readablePartial10, intArray11);
        java.lang.String str13 = offsetDateTimeField4.toString();
        java.lang.String str15 = offsetDateTimeField4.getAsText(1560636464327L);
        long long17 = offsetDateTimeField4.roundCeiling(1560636495191L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "DateTimeField[halfdayOfDay]" + "'", str13.equals("DateTimeField[halfdayOfDay]"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "53" + "'", str15.equals("53"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560668400000L + "'", long17 == 1560668400000L);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = dateTime3.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        org.joda.time.DateTime.Property property7 = dateTime5.yearOfEra();
        java.lang.String str8 = property7.getName();
        org.joda.time.DateTime dateTime10 = property7.addToCopy((int) '4');
        org.joda.time.Chronology chronology11 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime10);
        int int12 = dateTime10.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime14 = dateTime10.minusMonths(4);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime17 = dateTime15.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
        org.joda.time.DateTime.Property property19 = dateTime17.yearOfEra();
        java.lang.String str20 = property19.getName();
        org.joda.time.DateTime dateTime22 = property19.addToCopy((int) '4');
        org.joda.time.DateTime dateTime24 = dateTime22.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone25 = null;
        org.joda.time.chrono.ISOChronology iSOChronology26 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone25);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology26.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField29 = new org.joda.time.field.OffsetDateTimeField(dateTimeField27, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = offsetDateTimeField29.getType();
        boolean boolean31 = dateTime24.isSupported(dateTimeFieldType30);
        boolean boolean32 = dateTime14.isSupported(dateTimeFieldType30);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType30, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean38 = dateTimeFormatter37.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter40 = dateTimeFormatter37.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter44 = dateTimeFormatter40.withChronology((org.joda.time.Chronology) iSOChronology42);
        org.joda.time.DurationField durationField45 = iSOChronology42.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField46 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType30, durationField45);
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = unsupportedDateTimeField46.getType();
        boolean boolean48 = dateTime2.isSupported(dateTimeFieldType47);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(property19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "yearOfEra" + "'", str20.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(iSOChronology26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter40);
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFormatter44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.yearOfCentury();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray11 = new int[] {};
        int int12 = offsetDateTimeField4.getMinimumValue(readablePartial10, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField4.getMinimumValue(readablePartial13);
        long long16 = offsetDateTimeField4.roundCeiling(100L);
        int int18 = offsetDateTimeField4.getLeapAmount((long) 1969);
        long long21 = offsetDateTimeField4.add(1560636445397L, 4);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField4.getAsShortText(5, locale23);
        org.joda.time.DurationField durationField25 = offsetDateTimeField4.getDurationField();
        long long28 = durationField25.subtract(1560636461432L, 49);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560809245397L + "'", long21 == 1560809245397L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "5" + "'", str24.equals("5"));
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1558519661432L + "'", long28 == 1558519661432L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "166");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime2.withDurationAdded((long) 2019, 24);
        int int9 = dateTime2.getDayOfMonth();
        org.joda.time.LocalDate localDate10 = dateTime2.toLocalDate();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 31 + "'", int9 == 31);
        org.junit.Assert.assertNotNull(localDate10);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        try {
            long long2 = dateTimeFormatter0.parseMillis("UnsupportedDateTimeField");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"UnsupportedDateTimeField\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        long long6 = dateTimeZone3.adjustOffset((long) 1, true);
        long long9 = dateTimeZone3.convertLocalToUTC((long) 1969, true);
        int int11 = dateTimeZone3.getOffsetFromLocal(1560636442663L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
        long long14 = cachedDateTimeZone12.nextTransition(1560661646204L);
        long long16 = cachedDateTimeZone12.previousTransition((long) 2018);
        long long18 = cachedDateTimeZone12.nextTransition(1560636445078L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28801969L + "'", long9 == 28801969L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1572771600000L + "'", long14 == 1572771600000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-5756400001L) + "'", long16 == (-5756400001L));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1572771600000L + "'", long18 == 1572771600000L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.plus(readableDuration10);
        org.joda.time.DateTime dateTime12 = dateTime7.toDateTimeISO();
        org.joda.time.DateTime dateTime14 = dateTime12.minusSeconds(2021);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.lang.String str5 = offsetDateTimeField4.getName();
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology7.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField8, (int) '4');
        java.lang.String str11 = offsetDateTimeField10.getName();
        long long13 = offsetDateTimeField10.roundHalfFloor(0L);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime16 = dateTime14.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime17 = dateTime16.toDateTime();
        org.joda.time.DateTime.Property property18 = dateTime16.yearOfEra();
        org.joda.time.DateTime dateTime20 = dateTime16.plus(0L);
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime23 = dateTime21.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime24 = dateTime23.toDateTime();
        org.joda.time.DateTime.Property property25 = dateTime23.yearOfEra();
        org.joda.time.DateTime dateTime26 = property25.withMaximumValue();
        int int27 = dateTime16.compareTo((org.joda.time.ReadableInstant) dateTime26);
        org.joda.time.LocalTime localTime28 = dateTime16.toLocalTime();
        int[] intArray29 = null;
        int int30 = offsetDateTimeField10.getMaximumValue((org.joda.time.ReadablePartial) localTime28, intArray29);
        int int31 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) localTime28);
        long long33 = offsetDateTimeField4.roundHalfCeiling(1L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "halfdayOfDay" + "'", str5.equals("halfdayOfDay"));
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "halfdayOfDay" + "'", str11.equals("halfdayOfDay"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-14400000L) + "'", long13 == (-14400000L));
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(localTime28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 53 + "'", int30 == 53);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 53 + "'", int31 == 53);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + (-14400000L) + "'", long33 == (-14400000L));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        org.joda.time.DateTime dateTime5 = property4.withMinimumValue();
        org.joda.time.DateTime.Property property6 = dateTime5.secondOfDay();
        org.joda.time.DateTime dateTime8 = dateTime5.minus(9972000000L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        org.joda.time.DateMidnight dateMidnight7 = dateTime2.toDateMidnight();
        org.joda.time.DateTime dateTime10 = dateTime2.withDurationAdded(1560661646204L, 28);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateMidnight7);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        int int7 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(292278993);
        org.joda.time.DateTime.Property property12 = dateTime9.centuryOfEra();
        boolean boolean14 = property12.equals((java.lang.Object) "org.joda.time.IllegalFieldValueException: Value 100.0 for PST must be in the range [10,1560636442663]");
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("-54446517");
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.plus(1560636445170L);
        org.joda.time.DateTimeZone dateTimeZone12 = null;
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone12);
        org.joda.time.chrono.ISOChronology iSOChronology14 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology14.hourOfHalfday();
        org.joda.time.Chronology chronology16 = iSOChronology14.withUTC();
        org.joda.time.DateTime dateTime17 = dateTime13.toDateTime((org.joda.time.Chronology) iSOChronology14);
        org.joda.time.DateTime.Property property18 = dateTime17.era();
        int int19 = dateTime17.getSecondOfDay();
        org.joda.time.DateTime.Property property20 = dateTime17.era();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(iSOChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 54445 + "'", int19 == 54445);
        org.junit.Assert.assertNotNull(property20);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property4.withMinimumValue();
        java.util.Date date6 = dateTime5.toDate();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone11 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean12 = fixedDateTimeZone11.isFixed();
        java.util.TimeZone timeZone13 = fixedDateTimeZone11.toTimeZone();
        boolean boolean15 = fixedDateTimeZone11.equals((java.lang.Object) "2019");
        int int17 = fixedDateTimeZone11.getOffset(1560636445078L);
        org.joda.time.MutableDateTime mutableDateTime18 = dateTime5.toMutableDateTime((org.joda.time.DateTimeZone) fixedDateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertNotNull(mutableDateTime18);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        org.joda.time.DateTime dateTime8 = property4.addToCopy((long) ' ');
        java.util.Locale locale9 = null;
        java.lang.String str10 = property4.getAsText(locale9);
        org.joda.time.DateTime dateTime12 = property4.addToCopy((long) (byte) 0);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "19" + "'", str10.equals("19"));
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        java.lang.StringBuffer stringBuffer2 = null;
        org.joda.time.ReadablePartial readablePartial3 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer2, readablePartial3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTimeZone dateTimeZone3 = null;
        org.joda.time.DateTime dateTime4 = dateTime0.toDateTime(dateTimeZone3);
        long long5 = org.joda.time.DateTimeUtils.getInstantMillis((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime7 = dateTime4.withYearOfEra(2922789);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime10 = property8.addWrapFieldToCopy(28);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        long long6 = dateTimeZone3.adjustOffset((long) 1, true);
//        long long9 = dateTimeZone3.convertLocalToUTC((long) 1969, true);
//        int int11 = dateTimeZone3.getOffsetFromLocal(1560636442663L);
//        java.util.Locale locale13 = null;
//        java.lang.String str14 = dateTimeZone3.getName(1560636461432L, locale13);
//        org.joda.time.chrono.GregorianChronology gregorianChronology15 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28801969L + "'", long9 == 28801969L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Pacific Daylight Time" + "'", str14.equals("Pacific Daylight Time"));
//        org.junit.Assert.assertNotNull(gregorianChronology15);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        int int3 = dateTime2.getYearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime2.plusWeeks(166);
        org.joda.time.DateTime dateTime7 = dateTime2.plusYears(1969);
        int int8 = dateTime2.getYear();
        int int9 = dateTime2.getMillisOfSecond();
        org.joda.time.DateTime dateTime11 = dateTime2.plusYears(49);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.Number number1 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("53", number1, (java.lang.Number) 1560636444857L, (java.lang.Number) 1L);
        java.lang.Number number5 = illegalFieldValueException4.getIllegalNumberValue();
        java.lang.Number number6 = illegalFieldValueException4.getUpperBound();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1L + "'", number6.equals(1L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "null" + "'", str7.equals("null"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "16:00:00-08:00");
        java.lang.String str3 = illegalFieldValueException2.getIllegalStringValue();
        java.lang.String str4 = illegalFieldValueException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "16:00:00-08:00" + "'", str3.equals("16:00:00-08:00"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"16:00:00-08:00\" for  is not supported" + "'", str4.equals("org.joda.time.IllegalFieldValueException: Value \"16:00:00-08:00\" for  is not supported"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.plus(1560636439434L);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        org.joda.time.DateTime dateTime6 = dateTime4.plus(readablePeriod5);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.secondOfMinute();
        org.joda.time.DurationField durationField9 = iSOChronology5.weekyears();
        org.joda.time.DateTimeZone dateTimeZone10 = null;
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone10);
        org.joda.time.DateTimeField dateTimeField12 = iSOChronology11.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField14 = new org.joda.time.field.OffsetDateTimeField(dateTimeField12, (int) '4');
        long long17 = offsetDateTimeField14.getDifferenceAsLong(1560636445932L, (-1L));
        int int19 = offsetDateTimeField14.getMaximumValue(1560636443974L);
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField14.getAsText((-54446517), locale21);
        int int23 = offsetDateTimeField14.getOffset();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime26 = dateTime24.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime27 = dateTime26.toDateTime();
        org.joda.time.DateTime dateTime29 = dateTime26.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property30 = dateTime26.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod31 = null;
        org.joda.time.DateTime dateTime33 = dateTime26.withPeriodAdded(readablePeriod31, (-32));
        org.joda.time.DateTime dateTime35 = dateTime33.withWeekyear((-32));
        org.joda.time.DateTime dateTime36 = dateTime35.toDateTime();
        org.joda.time.LocalTime localTime37 = dateTime35.toLocalTime();
        java.util.Locale locale39 = null;
        java.lang.String str40 = offsetDateTimeField14.getAsText((org.joda.time.ReadablePartial) localTime37, 20, locale39);
        boolean boolean41 = iSOChronology5.equals((java.lang.Object) offsetDateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 36125L + "'", long17 == 36125L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 53 + "'", int19 == 53);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "-54446517" + "'", str22.equals("-54446517"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(localTime37);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "20" + "'", str40.equals("20"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.plusDays((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime4.withMillisOfSecond((int) 'a');
        org.joda.time.ReadableDuration readableDuration7 = null;
        org.joda.time.DateTime dateTime9 = dateTime6.withDurationAdded(readableDuration7, (-54446517));
        int int10 = dateTime9.getYearOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1970 + "'", int10 == 1970);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.centuries();
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        try {
            int[] intArray8 = gregorianChronology0.get(readablePeriod5, (long) 1969, 1560636443292L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        java.util.Locale locale5 = null;
        java.lang.String str6 = property4.getAsText(locale5);
        org.joda.time.DateTime dateTime8 = property4.addToCopy((long) ' ');
        org.joda.time.DateTime dateTime10 = property4.setCopy(15);
        try {
            org.joda.time.DateTime dateTime12 = property4.addToCopy(1560636486136L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 156063648613600");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "19" + "'", str6.equals("19"));
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4, 1);
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        long long10 = gregorianChronology6.add(readablePeriod7, 1560636438373L, (int) (short) 10);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter11 = dateTimeFormatter2.withChronology((org.joda.time.Chronology) gregorianChronology6);
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology6.halfdayOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560636438373L + "'", long10 == 1560636438373L);
        org.junit.Assert.assertNotNull(dateTimeFormatter11);
        org.junit.Assert.assertNotNull(dateTimeField12);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.plusMinutes((-32));
        org.joda.time.DateTime.Property property5 = dateTime4.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = property5.getField();
        org.joda.time.DateTime dateTime8 = property5.addToCopy((int) (short) -1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.lang.String str5 = offsetDateTimeField4.getName();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime8 = dateTime6.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime9 = dateTime8.toDateTime();
        org.joda.time.DateTime dateTime11 = dateTime8.minusMinutes((int) ' ');
        org.joda.time.MutableDateTime mutableDateTime12 = dateTime11.toMutableDateTime();
        org.joda.time.LocalDateTime localDateTime13 = dateTime11.toLocalDateTime();
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) '4');
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField19.getAsShortText(53, locale21);
        int int24 = offsetDateTimeField19.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int[] intArray26 = new int[] {};
        int int27 = offsetDateTimeField19.getMinimumValue(readablePartial25, intArray26);
        org.joda.time.ReadablePartial readablePartial28 = null;
        int int29 = offsetDateTimeField19.getMinimumValue(readablePartial28);
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime32 = dateTime30.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime33 = dateTime32.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay34 = dateTime33.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) '4');
        java.util.Locale locale41 = null;
        java.lang.String str42 = offsetDateTimeField39.getAsShortText(53, locale41);
        int int44 = offsetDateTimeField39.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial45 = null;
        int[] intArray46 = new int[] {};
        int int47 = offsetDateTimeField39.getMinimumValue(readablePartial45, intArray46);
        int int48 = offsetDateTimeField19.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay34, intArray46);
        java.util.Locale locale50 = null;
        try {
            int[] intArray51 = offsetDateTimeField4.set((org.joda.time.ReadablePartial) localDateTime13, 2, intArray46, "16", locale50);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 16 for halfdayOfDay must be in the range [52,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "halfdayOfDay" + "'", str5.equals("halfdayOfDay"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(mutableDateTime12);
        org.junit.Assert.assertNotNull(localDateTime13);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "53" + "'", str22.equals("53"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 52 + "'", int27 == 52);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 52 + "'", int29 == 52);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(yearMonthDay34);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "53" + "'", str42.equals("53"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 52 + "'", int47 == 52);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 53 + "'", int48 == 53);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime5 = property3.setCopy(54445);
        org.joda.time.DateTime dateTime8 = dateTime5.withDurationAdded((long) 16, 363);
        int int9 = dateTime5.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 268 + "'", int9 == 268);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime8 = dateTime2.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property9 = dateTime8.secondOfMinute();
        org.joda.time.DurationField durationField10 = property9.getDurationField();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) ' ');
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime7 = dateTime2.withDurationAdded(readableDuration5, 49);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        int int7 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.weekOfWeekyear();
        java.lang.String str12 = gregorianChronology10.toString();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.centuryOfEra();
        int int14 = dateTime9.get(dateTimeField13);
        org.joda.time.DateTime dateTime16 = dateTime9.minusMillis((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime20 = dateTime18.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTime();
        org.joda.time.DateTime dateTime23 = dateTime20.minusMinutes((int) ' ');
        org.joda.time.DateTime dateTime26 = dateTime20.withDurationAdded((long) 2019, 24);
        org.joda.time.DateTime.Property property27 = dateTime20.millisOfSecond();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime30 = dateTime28.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime31 = dateTime30.toDateTime();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfEra();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime35 = dateTime33.plusWeeks((int) (short) -1);
        int int36 = property32.compareTo((org.joda.time.ReadableInstant) dateTime35);
        int int37 = dateTime35.getHourOfDay();
        long long38 = property27.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime35);
        boolean boolean39 = dateTime16.isAfter((org.joda.time.ReadableInstant) dateTime35);
        try {
            org.joda.time.DateTime dateTime44 = dateTime16.withTime(1969, (-1), 69, (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str12.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 16 + "'", int37 == 16);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 604800010L + "'", long38 == 604800010L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        org.joda.time.DateTimeZone dateTimeZone7 = null;
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone7);
        org.joda.time.DateTimeField dateTimeField9 = iSOChronology8.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField11 = new org.joda.time.field.OffsetDateTimeField(dateTimeField9, (int) '4');
        long long14 = offsetDateTimeField11.getDifferenceAsLong(1560636445932L, (-1L));
        int int16 = offsetDateTimeField11.getMaximumValue(1560636443974L);
        java.util.Locale locale18 = null;
        java.lang.String str19 = offsetDateTimeField11.getAsText((-54446517), locale18);
        int int20 = offsetDateTimeField11.getOffset();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime23 = dateTime21.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime24 = dateTime23.toDateTime();
        org.joda.time.DateTime dateTime26 = dateTime23.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property27 = dateTime23.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime30 = dateTime23.withPeriodAdded(readablePeriod28, (-32));
        org.joda.time.DateTime dateTime32 = dateTime30.withWeekyear((-32));
        org.joda.time.DateTime dateTime33 = dateTime32.toDateTime();
        org.joda.time.LocalTime localTime34 = dateTime32.toLocalTime();
        java.util.Locale locale36 = null;
        java.lang.String str37 = offsetDateTimeField11.getAsText((org.joda.time.ReadablePartial) localTime34, 20, locale36);
        int[] intArray44 = new int[] { 267, 52, 24, (byte) 1, 54446517 };
        java.util.Locale locale46 = null;
        try {
            int[] intArray47 = offsetDateTimeField4.set((org.joda.time.ReadablePartial) localTime34, 28, intArray44, "292278993", locale46);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 292278993 for halfdayOfDay must be in the range [52,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 36125L + "'", long14 == 36125L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 53 + "'", int16 == 53);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "-54446517" + "'", str19.equals("-54446517"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 52 + "'", int20 == 52);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(localTime34);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "20" + "'", str37.equals("20"));
        org.junit.Assert.assertNotNull(intArray44);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTime();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInstant) dateTime5, readableInstant7);
        org.joda.time.DateTime.Property property9 = dateTime5.millisOfSecond();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime12 = dateTime10.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime14 = dateTime10.plusDays((int) '#');
        org.joda.time.DateTime dateTime16 = dateTime14.withMillisOfSecond((int) 'a');
        int int17 = property9.compareTo((org.joda.time.ReadableInstant) dateTime14);
        java.util.Locale locale18 = null;
        java.lang.String str19 = property9.getAsText(locale18);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "10" + "'", str19.equals("10"));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray11 = new int[] {};
        int int12 = offsetDateTimeField4.getMinimumValue(readablePartial10, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField4.getMinimumValue(readablePartial13);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime17 = dateTime15.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime18 = dateTime17.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime18.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone20 = null;
        org.joda.time.chrono.ISOChronology iSOChronology21 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone20);
        org.joda.time.DateTimeField dateTimeField22 = iSOChronology21.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField22, (int) '4');
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField24.getAsShortText(53, locale26);
        int int29 = offsetDateTimeField24.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial30 = null;
        int[] intArray31 = new int[] {};
        int int32 = offsetDateTimeField24.getMinimumValue(readablePartial30, intArray31);
        int int33 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay19, intArray31);
        long long36 = offsetDateTimeField4.addWrapField((long) '4', 24);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertNotNull(iSOChronology21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "53" + "'", str27.equals("53"));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 52 + "'", int32 == 52);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 53 + "'", int33 == 53);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 52L + "'", long36 == 52L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("1970W013T160000-0800");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970W013T160000-0800" + "'", str2.equals("1970W013T160000-0800"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField8 = gregorianChronology7.hours();
        org.joda.time.DurationField durationField9 = gregorianChronology7.days();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.secondOfDay();
        org.joda.time.DurationField durationField11 = gregorianChronology7.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone16 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean17 = fixedDateTimeZone16.isFixed();
        java.util.TimeZone timeZone18 = fixedDateTimeZone16.toTimeZone();
        boolean boolean20 = fixedDateTimeZone16.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology7, (org.joda.time.DateTimeZone) fixedDateTimeZone16);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        long long23 = dateTime22.getMillis();
        org.joda.time.DateMidnight dateMidnight24 = dateTime22.toDateMidnight();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now();
        long long26 = dateTime25.getMillis();
        boolean boolean27 = dateTime22.isAfter((org.joda.time.ReadableInstant) dateTime25);
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime29 = dateTime25.minus(readableDuration28);
        org.joda.time.DateTime dateTime31 = dateTime25.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime33 = dateTime31.plus(1560636445170L);
        org.joda.time.DateTimeZone dateTimeZone34 = null;
        org.joda.time.DateTime dateTime35 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone34);
        org.joda.time.chrono.ISOChronology iSOChronology36 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField37 = iSOChronology36.hourOfHalfday();
        org.joda.time.Chronology chronology38 = iSOChronology36.withUTC();
        org.joda.time.DateTime dateTime39 = dateTime35.toDateTime((org.joda.time.Chronology) iSOChronology36);
        org.joda.time.DateTime.Property property40 = dateTime39.era();
        boolean boolean41 = zonedChronology21.equals((java.lang.Object) property40);
        org.joda.time.DateTimeZone dateTimeZone42 = null;
        org.joda.time.Chronology chronology43 = zonedChronology21.withZone(dateTimeZone42);
        org.joda.time.DateTimeField dateTimeField44 = zonedChronology21.centuryOfEra();
        try {
            org.joda.time.DateTime dateTime45 = new org.joda.time.DateTime((-32), 267, 999, (int) (short) 10, 5, 2005, 0, (org.joda.time.Chronology) zonedChronology21);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2005 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(durationField11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(iSOChronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(chronology43);
        org.junit.Assert.assertNotNull(dateTimeField44);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("53");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        long long9 = offsetDateTimeField6.getDifferenceAsLong(1560636445932L, (-1L));
        boolean boolean10 = jodaTimePermission1.equals((java.lang.Object) long9);
        java.lang.String str11 = jodaTimePermission1.getName();
        org.joda.time.JodaTimePermission jodaTimePermission13 = new org.joda.time.JodaTimePermission("10");
        boolean boolean14 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission13);
        java.security.PermissionCollection permissionCollection15 = jodaTimePermission13.newPermissionCollection();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 36125L + "'", long9 == 36125L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "53" + "'", str11.equals("53"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(permissionCollection15);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        long long5 = dateTime4.getMillis();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime10 = dateTime4.withCenturyOfEra((int) (byte) 100);
        org.joda.time.Chronology chronology11 = dateTime10.getChronology();
        org.joda.time.DateTime dateTime13 = dateTime10.withMillisOfDay(999);
        org.joda.time.DateTime dateTime14 = dateTime10.toDateTimeISO();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(chronology11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        java.lang.Object obj2 = null;
        boolean boolean3 = gregorianChronology0.equals(obj2);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DurationField durationField3 = gregorianChronology0.years();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology0.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology0.months();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, 1560636486736L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DateTimeField dateTimeField8 = iSOChronology5.secondOfMinute();
        org.joda.time.Chronology chronology9 = iSOChronology5.withUTC();
        org.joda.time.DurationField durationField10 = iSOChronology5.seconds();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        long long5 = dateTime4.getMillis();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis(10);
        org.joda.time.DateTime dateTime13 = dateTime9.plusYears((int) (byte) 1);
        org.joda.time.DateTime dateTime15 = dateTime13.withMinuteOfHour(0);
        org.joda.time.DateTime.Property property16 = dateTime15.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(54445);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(1560636443974L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        int int5 = dateTime2.getMonthOfYear();
        org.joda.time.DateTime dateTime7 = dateTime2.withYearOfCentury((int) (short) 1);
        int int8 = dateTime7.getDayOfYear();
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField10 = gregorianChronology9.millis();
        int int11 = gregorianChronology9.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology9.secondOfMinute();
        org.joda.time.DateTime dateTime13 = dateTime7.toDateTime((org.joda.time.Chronology) gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 12 + "'", int5 == 12);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths(166);
        org.joda.time.LocalDate localDate12 = dateTime11.toLocalDate();
        int int13 = dateTime11.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 19 + "'", int13 == 19);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DurationField durationField15 = zonedChronology14.centuries();
        java.lang.String str16 = zonedChronology14.toString();
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology14.millisOfSecond();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 19]" + "'", str16.equals("ZonedChronology[GregorianChronology[UTC], 19]"));
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, 1561673240970L, 2019);
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) iSOChronology0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561673240970L + "'", long5 == 1561673240970L);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "5");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTimeISO();
        org.joda.time.DateTime dateTime11 = dateTime10.toDateTime();
        boolean boolean12 = dateTime11.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        int int3 = dateTime2.getYearOfCentury();
        org.joda.time.DateTime dateTime5 = dateTime2.plusWeeks(166);
        org.joda.time.DateTime dateTime7 = dateTime2.plusYears(1969);
        org.joda.time.DateTime dateTime9 = dateTime2.plusDays(24);
        org.joda.time.DurationFieldType durationFieldType10 = null;
        try {
            org.joda.time.DateTime dateTime12 = dateTime2.withFieldAdded(durationFieldType10, 166);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 69 + "'", int3 == 69);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.toString();
        org.joda.time.DurationField durationField46 = unsupportedDateTimeField43.getRangeDurationField();
        try {
            int int48 = unsupportedDateTimeField43.getMinimumValue(1560636475078L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField46);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.plus(readableDuration10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMinutes(72);
        org.joda.time.ReadableDuration readableDuration14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withDurationAdded(readableDuration14, (int) (byte) 1);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        long long7 = offsetDateTimeField4.getDifferenceAsLong(1560636445932L, (-1L));
        int int9 = offsetDateTimeField4.getMaximumValue(1560636443974L);
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime12 = dateTime10.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime13 = dateTime12.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime13.toYearMonthDay();
        int int15 = offsetDateTimeField4.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay14);
        int int16 = offsetDateTimeField4.getOffset();
        long long18 = offsetDateTimeField4.roundCeiling(3121272891539L);
        org.joda.time.DurationField durationField19 = offsetDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 36125L + "'", long7 == 36125L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 53 + "'", int9 == 53);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 53 + "'", int15 == 53);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 3121315200000L + "'", long18 == 3121315200000L);
        org.junit.Assert.assertNull(durationField19);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = null;
        try {
            org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.parse("5", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime dateTime5 = dateTime0.plusDays((int) (byte) 10);
        org.joda.time.DateTime.Property property6 = dateTime0.year();
        java.util.Locale locale7 = null;
        java.util.Calendar calendar8 = dateTime0.toCalendar(locale7);
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime0.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(calendar8);
        org.junit.Assert.assertNotNull(yearMonthDay9);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusWeeks((int) (short) -1);
        int int3 = dateTime0.getMillisOfDay();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime6 = dateTime4.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTime();
        org.joda.time.DateTime.Property property8 = dateTime6.yearOfEra();
        int int9 = dateTime6.getMonthOfYear();
        org.joda.time.DateMidnight dateMidnight10 = dateTime6.toDateMidnight();
        org.joda.time.TimeOfDay timeOfDay11 = dateTime6.toTimeOfDay();
        org.joda.time.DateTime dateTime12 = dateTime0.withFields((org.joda.time.ReadablePartial) timeOfDay11);
        org.joda.time.DateTime dateTime14 = dateTime12.plus(0L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 57600000 + "'", int3 == 57600000);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(timeOfDay11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property7 = dateTime2.hourOfDay();
        org.joda.time.DateTime dateTime8 = property7.withMaximumValue();
        int int9 = dateTime8.getYearOfCentury();
        org.joda.time.LocalTime localTime10 = dateTime8.toLocalTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 69 + "'", int9 == 69);
        org.junit.Assert.assertNotNull(localTime10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField4 = gregorianChronology2.years();
        try {
            long long9 = gregorianChronology2.getDateTimeMillis(365, 54445, 363, 54445);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54445 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks((int) (short) -1);
        int int8 = property4.compareTo((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime10 = dateTime7.minusMillis((int) ' ');
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime6 = dateTime3.minusDays(788);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-35));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        long long16 = dateTime15.getMillis();
        org.joda.time.DateMidnight dateMidnight17 = dateTime15.toDateMidnight();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        long long19 = dateTime18.getMillis();
        boolean boolean20 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.minus(readableDuration21);
        org.joda.time.DateTime dateTime24 = dateTime18.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime26 = dateTime24.plus(1560636445170L);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone27);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.hourOfHalfday();
        org.joda.time.Chronology chronology31 = iSOChronology29.withUTC();
        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.DateTime.Property property33 = dateTime32.era();
        boolean boolean34 = zonedChronology14.equals((java.lang.Object) property33);
        try {
            org.joda.time.DateTime dateTime36 = property33.addToCopy(1560636473366L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: eras field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        int int7 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(292278993);
        org.joda.time.DateTime.Property property12 = dateTime11.secondOfDay();
        org.joda.time.DateTime dateTime13 = property12.getDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.withPeriodAdded(readablePeriod7, (-32));
        org.joda.time.DateTime.Property property10 = dateTime2.weekyear();
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.DateTime dateTime12 = dateTime2.minus(readableDuration11);
        int int13 = dateTime2.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 57600 + "'", int13 == 57600);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        java.lang.String str13 = fixedDateTimeZone9.getName((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DurationField durationField15 = iSOChronology0.centuries();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.100" + "'", str13.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        long long16 = dateTime15.getMillis();
        org.joda.time.DateMidnight dateMidnight17 = dateTime15.toDateMidnight();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        long long19 = dateTime18.getMillis();
        boolean boolean20 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.minus(readableDuration21);
        org.joda.time.DateTime dateTime24 = dateTime18.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime26 = dateTime24.plus(1560636445170L);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone27);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.hourOfHalfday();
        org.joda.time.Chronology chronology31 = iSOChronology29.withUTC();
        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.DateTime.Property property33 = dateTime32.era();
        boolean boolean34 = zonedChronology14.equals((java.lang.Object) property33);
        org.joda.time.DateTimeZone dateTimeZone35 = null;
        org.joda.time.Chronology chronology36 = zonedChronology14.withZone(dateTimeZone35);
        org.joda.time.DateTimeField dateTimeField37 = zonedChronology14.centuryOfEra();
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now((org.joda.time.Chronology) zonedChronology14);
        try {
            long long44 = zonedChronology14.getDateTimeMillis((long) (byte) 100, (int) (short) 1, 54445, (-53), 20);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 54445 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(chronology36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTime38);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter2.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        java.lang.String str13 = fixedDateTimeZone9.getName((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeField dateTimeField15 = zonedChronology14.dayOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.100" + "'", str13.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(dateTimeZone3);
        java.util.TimeZone timeZone6 = null;
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forTimeZone(timeZone6);
        org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime(1560636443698L, dateTimeZone7);
        long long10 = dateTimeZone3.getMillisKeepLocal(dateTimeZone7, 1560636478487L);
        long long13 = dateTimeZone7.adjustOffset((long) 1, false);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560636478487L + "'", long10 == 1560636478487L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.withMillis(100L);
        int int10 = dateTime7.getWeekyear();
        org.joda.time.DateTime.Property property11 = dateTime7.weekyear();
        int int12 = dateTime7.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2021 + "'", int10 == 2021);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600010 + "'", int12 == 57600010);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime11 = dateTime9.plusMonths(166);
        org.joda.time.DateTime.Property property12 = dateTime11.year();
        boolean boolean14 = dateTime11.isEqual(0L);
        org.joda.time.DateTimeZone dateTimeZone15 = null;
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology16.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField19 = new org.joda.time.field.OffsetDateTimeField(dateTimeField17, (int) '4');
        java.util.Locale locale21 = null;
        java.lang.String str22 = offsetDateTimeField19.getAsShortText(53, locale21);
        int int24 = offsetDateTimeField19.getLeapAmount(1560636442281L);
        org.joda.time.DateTimeFieldType dateTimeFieldType25 = offsetDateTimeField19.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) (byte) 100, "GregorianChronology[America/Los_Angeles]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException32 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType25, (java.lang.Number) 1560636463294L, (java.lang.Number) 10.0d, (java.lang.Number) 1560636445397L);
        org.joda.time.DateTime.Property property33 = dateTime11.property(dateTimeFieldType25);
        org.joda.time.DateTime dateTime34 = property33.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "53" + "'", str22.equals("53"));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType25);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertNotNull(dateTime34);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField43.getRangeDurationField();
        java.util.Locale locale46 = null;
        try {
            int int47 = unsupportedDateTimeField43.getMaximumShortTextLength(locale46);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNull(durationField45);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.toString();
        org.joda.time.DurationField durationField46 = unsupportedDateTimeField43.getRangeDurationField();
        java.util.Locale locale47 = null;
        try {
            int int48 = unsupportedDateTimeField43.getMaximumTextLength(locale47);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField46);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        int int7 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.weekOfWeekyear();
        java.lang.String str12 = gregorianChronology10.toString();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.centuryOfEra();
        int int14 = dateTime9.get(dateTimeField13);
        org.joda.time.DateTime dateTime16 = dateTime9.minusMillis((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime20 = dateTime18.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTime();
        org.joda.time.DateTime dateTime23 = dateTime20.minusMinutes((int) ' ');
        org.joda.time.DateTime dateTime26 = dateTime20.withDurationAdded((long) 2019, 24);
        org.joda.time.DateTime.Property property27 = dateTime20.millisOfSecond();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime30 = dateTime28.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime31 = dateTime30.toDateTime();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfEra();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime35 = dateTime33.plusWeeks((int) (short) -1);
        int int36 = property32.compareTo((org.joda.time.ReadableInstant) dateTime35);
        int int37 = dateTime35.getHourOfDay();
        long long38 = property27.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime35);
        boolean boolean39 = dateTime16.isAfter((org.joda.time.ReadableInstant) dateTime35);
        boolean boolean41 = dateTime35.isEqual(28800000L);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str12.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 16 + "'", int37 == 16);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 604800010L + "'", long38 == 604800010L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusWeeks((int) (short) -1);
        long long3 = dateTime2.getMillis();
        org.joda.time.DateTime dateTime5 = dateTime2.plusMonths(0);
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime8 = dateTime6.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property9 = dateTime8.weekyear();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now();
        long long11 = dateTime10.getMillis();
        org.joda.time.DateMidnight dateMidnight12 = dateTime10.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone13 = dateTime10.getZone();
        long long14 = property9.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.DateTime dateTime15 = property9.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime17 = dateTime15.plusMillis(10);
        org.joda.time.DateTime dateTime19 = dateTime15.withCenturyOfEra((int) (byte) 0);
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now();
        long long21 = dateTime20.getMillis();
        org.joda.time.DateMidnight dateMidnight22 = dateTime20.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone23 = dateTime20.getZone();
        long long26 = dateTimeZone23.adjustOffset((long) 1, true);
        long long29 = dateTimeZone23.convertLocalToUTC((long) 1969, true);
        int int31 = dateTimeZone23.getOffsetFromLocal(1560636442663L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone32 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone23);
        long long34 = cachedDateTimeZone32.nextTransition(1560661646204L);
        long long36 = cachedDateTimeZone32.previousTransition((long) 2018);
        java.lang.Number number38 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException41 = new org.joda.time.IllegalFieldValueException("53", number38, (java.lang.Number) 1560636444857L, (java.lang.Number) 1L);
        java.lang.Number number42 = illegalFieldValueException41.getIllegalNumberValue();
        java.lang.Number number43 = illegalFieldValueException41.getUpperBound();
        boolean boolean44 = cachedDateTimeZone32.equals((java.lang.Object) illegalFieldValueException41);
        org.joda.time.DateTimeZone dateTimeZone45 = cachedDateTimeZone32.getUncachedZone();
        int int47 = cachedDateTimeZone32.getStandardOffset(1560636480550L);
        org.joda.time.MutableDateTime mutableDateTime48 = dateTime15.toMutableDateTime((org.joda.time.DateTimeZone) cachedDateTimeZone32);
        org.joda.time.DateTime dateTime49 = dateTime2.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone32);
        java.lang.String str50 = cachedDateTimeZone32.getID();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-604800000L) + "'", long3 == (-604800000L));
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 28801969L + "'", long29 == 28801969L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-25200000) + "'", int31 == (-25200000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone32);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1572771600000L + "'", long34 == 1572771600000L);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-5756400001L) + "'", long36 == (-5756400001L));
        org.junit.Assert.assertNull(number42);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 1L + "'", number43.equals(1L));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-28800000) + "'", int47 == (-28800000));
        org.junit.Assert.assertNotNull(mutableDateTime48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "America/Los_Angeles" + "'", str50.equals("America/Los_Angeles"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.DateTime dateTime9 = dateTime7.withMillis(100L);
        org.joda.time.DateTime dateTime11 = dateTime7.withYearOfEra(12);
        int int12 = dateTime11.getHourOfDay();
        java.util.Locale locale14 = null;
        java.lang.String str15 = dateTime11.toString("20190615", locale14);
        int int16 = dateTime11.getMillisOfSecond();
        org.joda.time.DateTime.Property property17 = dateTime11.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "20190615" + "'", str15.equals("20190615"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
        org.junit.Assert.assertNotNull(property17);
    }

//    @Test
//    public void test388() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test388");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
//        org.joda.time.DateTime dateTime4 = dateTime0.plusDays((int) '#');
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
//        long long6 = dateTime5.getMillis();
//        org.joda.time.DateMidnight dateMidnight7 = dateTime5.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime5.getZone();
//        java.lang.String str10 = dateTimeZone8.getShortName((long) 0);
//        java.util.Locale locale12 = null;
//        java.lang.String str13 = dateTimeZone8.getShortName((long) (byte) 10, locale12);
//        org.joda.time.DateTime dateTime14 = dateTime4.withZoneRetainFields(dateTimeZone8);
//        java.util.Date date15 = dateTime4.toDate();
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(dateMidnight7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PST" + "'", str10.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PST" + "'", str13.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(date15);
//    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime3.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime10 = dateTime9.toDateTimeISO();
        org.joda.time.DateTime dateTime12 = dateTime10.plusWeeks((int) 'a');
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, 4);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology2.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField3, (int) '4');
        java.util.Locale locale7 = null;
        java.lang.String str8 = offsetDateTimeField5.getAsShortText(53, locale7);
        int int10 = offsetDateTimeField5.getLeapAmount(1560636442281L);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField5.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException14 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) (byte) 100, "GregorianChronology[America/Los_Angeles]");
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, (java.lang.Number) 1560636463294L, (java.lang.Number) 10.0d, (java.lang.Number) 1560636445397L);
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField19 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "53" + "'", str8.equals("53"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        int int7 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.weekOfWeekyear();
        java.lang.String str12 = gregorianChronology10.toString();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.centuryOfEra();
        int int14 = dateTime9.get(dateTimeField13);
        org.joda.time.DateTime dateTime16 = dateTime9.minusMillis((int) 'a');
        org.joda.time.DateTime.Property property17 = dateTime16.yearOfEra();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime20 = dateTime18.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTime();
        org.joda.time.DateTime dateTime23 = dateTime20.minusMinutes((int) ' ');
        org.joda.time.DateTime dateTime26 = dateTime20.withDurationAdded((long) 2019, 24);
        org.joda.time.DateTime.Property property27 = dateTime20.millisOfSecond();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime30 = dateTime28.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime31 = dateTime30.toDateTime();
        org.joda.time.DateTime.Property property32 = dateTime30.yearOfEra();
        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime35 = dateTime33.plusWeeks((int) (short) -1);
        int int36 = property32.compareTo((org.joda.time.ReadableInstant) dateTime35);
        int int37 = dateTime35.getHourOfDay();
        long long38 = property27.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime35);
        boolean boolean39 = dateTime16.isAfter((org.joda.time.ReadableInstant) dateTime35);
        int int40 = dateTime16.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str12.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(property27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 16 + "'", int37 == 16);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 604800010L + "'", long38 == 604800010L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 15 + "'", int40 == 15);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        long long16 = dateTime15.getMillis();
        org.joda.time.DateMidnight dateMidnight17 = dateTime15.toDateMidnight();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        long long19 = dateTime18.getMillis();
        boolean boolean20 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.minus(readableDuration21);
        org.joda.time.DateTime dateTime24 = dateTime18.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime26 = dateTime24.plus(1560636445170L);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone27);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.hourOfHalfday();
        org.joda.time.Chronology chronology31 = iSOChronology29.withUTC();
        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.DateTime.Property property33 = dateTime32.era();
        boolean boolean34 = zonedChronology14.equals((java.lang.Object) property33);
        org.joda.time.DateTimeZone dateTimeZone35 = zonedChronology14.getZone();
        org.joda.time.DateTimeZone dateTimeZone36 = zonedChronology14.getZone();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (int) (byte) 1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        int int11 = offsetDateTimeField4.getLeapAmount(0L);
        org.joda.time.DurationField durationField12 = offsetDateTimeField4.getDurationField();
        long long15 = durationField12.subtract(604800010L, (int) (byte) 1);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 561600010L + "'", long15 == 561600010L);
    }

//    @Test
//    public void test395() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test395");
//        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
//        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
//        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
//        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
//        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
//        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
//        boolean boolean10 = fixedDateTimeZone9.isFixed();
//        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
//        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
//        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
//        org.joda.time.DurationField durationField15 = zonedChronology14.centuries();
//        org.joda.time.DateTimeZone dateTimeZone16 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology17 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone16);
//        org.joda.time.DateTimeField dateTimeField18 = iSOChronology17.halfdayOfDay();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField20 = new org.joda.time.field.OffsetDateTimeField(dateTimeField18, (int) '4');
//        long long23 = offsetDateTimeField20.getDifferenceAsLong(1560636445932L, (-1L));
//        int int25 = offsetDateTimeField20.getMaximumValue(1560636443974L);
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
//        org.joda.time.DateTime dateTime28 = dateTime26.withMillis((long) (short) 10);
//        org.joda.time.DateTime dateTime29 = dateTime28.toDateTime();
//        org.joda.time.YearMonthDay yearMonthDay30 = dateTime29.toYearMonthDay();
//        int int31 = offsetDateTimeField20.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay30);
//        boolean boolean32 = zonedChronology14.equals((java.lang.Object) offsetDateTimeField20);
//        org.joda.time.Chronology chronology33 = zonedChronology14.withUTC();
//        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now();
//        long long35 = dateTime34.getMillis();
//        org.joda.time.DateMidnight dateMidnight36 = dateTime34.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone37 = dateTime34.getZone();
//        java.lang.String str39 = dateTimeZone37.getShortName((long) 0);
//        org.joda.time.Chronology chronology40 = zonedChronology14.withZone(dateTimeZone37);
//        org.joda.time.chrono.ISOChronology iSOChronology41 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone37);
//        org.junit.Assert.assertNotNull(gregorianChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertNotNull(durationField2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertNotNull(durationField4);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(zonedChronology14);
//        org.junit.Assert.assertNotNull(durationField15);
//        org.junit.Assert.assertNotNull(iSOChronology17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 36125L + "'", long23 == 36125L);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 53 + "'", int25 == 53);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(yearMonthDay30);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 53 + "'", int31 == 53);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(chronology33);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
//        org.junit.Assert.assertNotNull(dateMidnight36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "PST" + "'", str39.equals("PST"));
//        org.junit.Assert.assertNotNull(chronology40);
//        org.junit.Assert.assertNotNull(iSOChronology41);
//    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        org.joda.time.DurationField durationField45 = unsupportedDateTimeField43.getDurationField();
        boolean boolean46 = unsupportedDateTimeField43.isSupported();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertNotNull(durationField45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((int) (byte) 10);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeUtils.getZone(dateTimeZone1);
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime5 = dateTime3.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime6 = dateTime5.toDateTime();
        org.joda.time.DateTime.Property property7 = dateTime5.yearOfEra();
        java.lang.String str8 = property7.getName();
        org.joda.time.DateTime dateTime10 = property7.addToCopy((int) '4');
        org.joda.time.DateTime.Property property11 = dateTime10.era();
        org.joda.time.DateTime dateTime13 = dateTime10.minusSeconds((-35));
        int int14 = dateTimeZone1.getOffset((org.joda.time.ReadableInstant) dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "yearOfEra" + "'", str8.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 36000000 + "'", int14 == 36000000);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PST", (int) (byte) 1);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray11 = new int[] {};
        int int12 = offsetDateTimeField4.getMinimumValue(readablePartial10, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField4.getMinimumValue(readablePartial13);
        long long16 = offsetDateTimeField4.roundCeiling(100L);
        int int18 = offsetDateTimeField4.getLeapAmount((long) 1969);
        long long21 = offsetDateTimeField4.add(1560636445397L, 4);
        int int23 = offsetDateTimeField4.getLeapAmount((long) (-25200000));
        java.lang.String str25 = offsetDateTimeField4.getAsText((long) 53);
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime28 = dateTime26.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property29 = dateTime28.weekyear();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
        long long31 = dateTime30.getMillis();
        org.joda.time.DateMidnight dateMidnight32 = dateTime30.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone33 = dateTime30.getZone();
        long long34 = property29.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTimeFieldType dateTimeFieldType35 = property29.getFieldType();
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField37 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField4, dateTimeFieldType35, (-1372750000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The divisor must be at least 2");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560809245397L + "'", long21 == 1560809245397L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "53" + "'", str25.equals("53"));
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTimeFieldType35);
    }

//    @Test
//    public void test400() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test400");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        long long6 = dateTimeZone3.adjustOffset((long) 1, true);
//        long long9 = dateTimeZone3.convertLocalToUTC((long) 1969, true);
//        int int11 = dateTimeZone3.getOffsetFromLocal(1560636442663L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        int int14 = cachedDateTimeZone12.getStandardOffset(1560636478487L);
//        java.lang.Object obj15 = null;
//        boolean boolean16 = cachedDateTimeZone12.equals(obj15);
//        long long18 = cachedDateTimeZone12.nextTransition(1560636489683L);
//        java.util.Locale locale20 = null;
//        java.lang.String str21 = cachedDateTimeZone12.getName(3121272891457L, locale20);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28801969L + "'", long9 == 28801969L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1572771600000L + "'", long18 == 1572771600000L);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pacific Standard Time" + "'", str21.equals("Pacific Standard Time"));
//    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        int int11 = offsetDateTimeField4.getLeapAmount(0L);
        org.joda.time.DurationField durationField12 = offsetDateTimeField4.getDurationField();
        long long15 = offsetDateTimeField4.add(1560636475078L, 2019);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1647857275078L + "'", long15 == 1647857275078L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology2.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.dayOfMonth();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime5 = property4.withMinimumValue();
        org.joda.time.DateTime dateTime6 = property4.getDateTime();
        org.joda.time.DateTime dateTime8 = dateTime6.minusSeconds((-32));
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffsetFromLocal(1560636440801L);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime10 = dateTime8.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime10.toDateTime();
        org.joda.time.DateTime.Property property12 = dateTime10.yearOfEra();
        int int13 = dateTime10.getMonthOfYear();
        boolean boolean14 = fixedDateTimeZone4.equals((java.lang.Object) dateTime10);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.centuries();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        int int7 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMinutes(292278993);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime dateTime17 = dateTime14.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property18 = dateTime17.minuteOfHour();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime22 = dateTime21.toDateTime();
        org.joda.time.DateTime.Property property23 = dateTime21.yearOfEra();
        java.lang.String str24 = property23.getAsText();
        org.joda.time.DateTime dateTime25 = property23.withMinimumValue();
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime28 = dateTime26.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property29 = dateTime28.weekyear();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now();
        long long31 = dateTime30.getMillis();
        org.joda.time.DateMidnight dateMidnight32 = dateTime30.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone33 = dateTime30.getZone();
        long long34 = property29.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime30);
        org.joda.time.DateTime dateTime35 = property29.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime37 = dateTime35.withMillisOfDay(19);
        boolean boolean39 = dateTime37.isAfter((long) (short) -1);
        int int40 = dateTime25.compareTo((org.joda.time.ReadableInstant) dateTime37);
        org.joda.time.DateTimeZone dateTimeZone41 = null;
        org.joda.time.chrono.ISOChronology iSOChronology42 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone41);
        org.joda.time.DateTimeField dateTimeField43 = iSOChronology42.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField45 = new org.joda.time.field.OffsetDateTimeField(dateTimeField43, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType46 = offsetDateTimeField45.getType();
        boolean boolean47 = dateTime25.isSupported(dateTimeFieldType46);
        org.joda.time.DateTime.Property property48 = dateTime17.property(dateTimeFieldType46);
        org.joda.time.DateTime.Property property49 = dateTime11.property(dateTimeFieldType46);
        org.joda.time.DateTime dateTime50 = property49.roundCeilingCopy();
        org.joda.time.DateTime dateTime51 = property49.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(property23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "1969" + "'", str24.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight32);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(iSOChronology42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(property48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(1L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now();
        long long16 = dateTime15.getMillis();
        org.joda.time.DateMidnight dateMidnight17 = dateTime15.toDateMidnight();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now();
        long long19 = dateTime18.getMillis();
        boolean boolean20 = dateTime15.isAfter((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.DateTime dateTime22 = dateTime18.minus(readableDuration21);
        org.joda.time.DateTime dateTime24 = dateTime18.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime26 = dateTime24.plus(1560636445170L);
        org.joda.time.DateTimeZone dateTimeZone27 = null;
        org.joda.time.DateTime dateTime28 = new org.joda.time.DateTime((java.lang.Object) 1560636445170L, dateTimeZone27);
        org.joda.time.chrono.ISOChronology iSOChronology29 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField30 = iSOChronology29.hourOfHalfday();
        org.joda.time.Chronology chronology31 = iSOChronology29.withUTC();
        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime((org.joda.time.Chronology) iSOChronology29);
        org.joda.time.DateTime.Property property33 = dateTime32.era();
        boolean boolean34 = zonedChronology14.equals((java.lang.Object) property33);
        java.lang.String str35 = zonedChronology14.toString();
        org.joda.time.Chronology chronology36 = zonedChronology14.withUTC();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 0L + "'", long19 == 0L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(iSOChronology29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(chronology31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(property33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 19]" + "'", str35.equals("ZonedChronology[GregorianChronology[UTC], 19]"));
        org.junit.Assert.assertNotNull(chronology36);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.plus(1560636439434L);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime5.withYear((int) (byte) 100);
        org.joda.time.DateTime.Property property8 = dateTime5.yearOfEra();
        org.joda.time.DurationField durationField9 = property8.getRangeDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNull(durationField9);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.joda.time.chrono.GregorianChronology gregorianChronology1 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField2 = gregorianChronology1.millis();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology1.year();
        org.joda.time.DateTime dateTime4 = new org.joda.time.DateTime(0L, (org.joda.time.Chronology) gregorianChronology1);
        org.joda.time.DurationField durationField5 = gregorianChronology1.hours();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology1.hourOfHalfday();
        org.junit.Assert.assertNotNull(gregorianChronology1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        int int46 = unsupportedDateTimeField43.getDifference(1560636459708L, (long) (byte) 1);
        try {
            long long49 = unsupportedDateTimeField43.addWrapField((long) (-28800000), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 49 + "'", int46 == 49);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.withPeriodAdded(readablePeriod7, (-32));
        org.joda.time.DateTime.Property property10 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime12 = dateTime2.withYear((int) (short) 10);
        try {
            org.joda.time.DateTime dateTime14 = dateTime12.withSecondOfMinute(999);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 999 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 2021, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DateTimeFieldType dateTimeFieldType44 = unsupportedDateTimeField43.getType();
        java.lang.String str45 = unsupportedDateTimeField43.toString();
        org.joda.time.DurationField durationField46 = unsupportedDateTimeField43.getRangeDurationField();
        java.lang.String str47 = unsupportedDateTimeField43.toString();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeFieldType44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "UnsupportedDateTimeField" + "'", str45.equals("UnsupportedDateTimeField"));
        org.junit.Assert.assertNull(durationField46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "UnsupportedDateTimeField" + "'", str47.equals("UnsupportedDateTimeField"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        int int46 = unsupportedDateTimeField43.getDifference(1560636459708L, (long) (byte) 1);
        java.lang.String str47 = unsupportedDateTimeField43.getName();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 49 + "'", int46 == 49);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "halfdayOfDay" + "'", str47.equals("halfdayOfDay"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateTime dateTime3 = dateTime0.minusMillis(19);
        org.joda.time.MutableDateTime mutableDateTime4 = dateTime0.toMutableDateTime();
        java.lang.String str5 = mutableDateTime4.toString();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969-12-31T16:00:00.000-08:00" + "'", str5.equals("1969-12-31T16:00:00.000-08:00"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology2.halfdayOfDay();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.clockhourOfDay();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property3 = dateTime2.era();
        java.util.Locale locale5 = null;
        try {
            org.joda.time.DateTime dateTime6 = property3.setCopy("", locale5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("53");
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        long long9 = offsetDateTimeField6.getDifferenceAsLong(1560636445932L, (-1L));
        boolean boolean10 = jodaTimePermission1.equals((java.lang.Object) long9);
        java.lang.String str11 = jodaTimePermission1.getName();
        java.lang.String str12 = jodaTimePermission1.getActions();
        jodaTimePermission1.checkGuard((java.lang.Object) 1560636475970L);
        java.lang.String str15 = jodaTimePermission1.getName();
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 36125L + "'", long9 == 36125L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "53" + "'", str11.equals("53"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "53" + "'", str15.equals("53"));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.plus(1560636439434L);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.Chronology chronology6 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime4);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 1);
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology2.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology2.weekyears();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology2.yearOfEra();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology2.minuteOfHour();
        org.joda.time.DurationField durationField7 = gregorianChronology2.years();
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        java.lang.String str3 = dateTimeFormatter0.print(1560636469622L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "15" + "'", str3.equals("15"));
    }

//    @Test
//    public void test425() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test425");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        java.lang.String str5 = dateTimeZone3.getShortName((long) 0);
//        long long9 = dateTimeZone3.convertLocalToUTC(1560636441304L, true, 1560636486709L);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "PST" + "'", str5.equals("PST"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560661641304L + "'", long9 == 1560661641304L);
//    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.lang.String str6 = offsetDateTimeField4.getAsText(1560636440970L);
        int int8 = offsetDateTimeField4.getMinimumValue((long) 1);
        org.joda.time.DateTimeField dateTimeField9 = offsetDateTimeField4.getWrappedField();
        long long12 = offsetDateTimeField4.add(1560636468483L, 0);
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime15 = dateTime13.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime16 = dateTime15.toDateTime();
        org.joda.time.DateTime.Property property17 = dateTime15.yearOfEra();
        org.joda.time.DateTime dateTime19 = dateTime15.plus(0L);
        boolean boolean21 = dateTime19.isBefore((long) 54446517);
        org.joda.time.YearMonthDay yearMonthDay22 = dateTime19.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone24 = null;
        org.joda.time.chrono.ISOChronology iSOChronology25 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone24);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology25.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField28 = new org.joda.time.field.OffsetDateTimeField(dateTimeField26, (int) '4');
        java.util.Locale locale30 = null;
        java.lang.String str31 = offsetDateTimeField28.getAsShortText(53, locale30);
        int int33 = offsetDateTimeField28.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial34 = null;
        int[] intArray35 = new int[] {};
        int int36 = offsetDateTimeField28.getMinimumValue(readablePartial34, intArray35);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int int38 = offsetDateTimeField28.getMinimumValue(readablePartial37);
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime41 = dateTime39.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime42 = dateTime41.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay43 = dateTime42.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone44 = null;
        org.joda.time.chrono.ISOChronology iSOChronology45 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone44);
        org.joda.time.DateTimeField dateTimeField46 = iSOChronology45.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, (int) '4');
        java.util.Locale locale50 = null;
        java.lang.String str51 = offsetDateTimeField48.getAsShortText(53, locale50);
        int int53 = offsetDateTimeField48.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial54 = null;
        int[] intArray55 = new int[] {};
        int int56 = offsetDateTimeField48.getMinimumValue(readablePartial54, intArray55);
        int int57 = offsetDateTimeField28.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay43, intArray55);
        try {
            int[] intArray59 = offsetDateTimeField4.addWrapField((org.joda.time.ReadablePartial) yearMonthDay22, 1970, intArray55, 268);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1970");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "53" + "'", str6.equals("53"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560636468483L + "'", long12 == 1560636468483L);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(yearMonthDay22);
        org.junit.Assert.assertNotNull(iSOChronology25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "53" + "'", str31.equals("53"));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 52 + "'", int36 == 52);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 52 + "'", int38 == 52);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(yearMonthDay43);
        org.junit.Assert.assertNotNull(iSOChronology45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "53" + "'", str51.equals("53"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 52 + "'", int56 == 52);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 53 + "'", int57 == 53);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.hourOfHalfday();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, 0L, (int) '4');
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("PST", (int) (byte) 1);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder3.setStandardOffset((-32));
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder8 = dateTimeZoneBuilder5.setFixedSavings("", 69);
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder10 = dateTimeZoneBuilder8.setStandardOffset((int) (byte) 100);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder10);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray11 = new int[] {};
        int int12 = offsetDateTimeField4.getMinimumValue(readablePartial10, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField4.getMinimumValue(readablePartial13);
        long long16 = offsetDateTimeField4.roundCeiling(100L);
        int int18 = offsetDateTimeField4.getLeapAmount((long) 1969);
        long long21 = offsetDateTimeField4.add(1560636445397L, 4);
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime24 = dateTime22.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime25 = dateTime24.toDateTime();
        org.joda.time.DateTime.Property property26 = dateTime24.yearOfEra();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime29 = dateTime27.plusWeeks((int) (short) -1);
        int int30 = property26.compareTo((org.joda.time.ReadableInstant) dateTime29);
        org.joda.time.DateTime dateTime31 = property26.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now();
        long long33 = dateTime32.getMillis();
        org.joda.time.DateMidnight dateMidnight34 = dateTime32.toDateMidnight();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now();
        long long36 = dateTime35.getMillis();
        boolean boolean37 = dateTime32.isAfter((org.joda.time.ReadableInstant) dateTime35);
        org.joda.time.ReadableDuration readableDuration38 = null;
        org.joda.time.DateTime dateTime39 = dateTime35.minus(readableDuration38);
        org.joda.time.DateTime dateTime41 = dateTime35.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime43 = dateTime41.plusMonths(166);
        org.joda.time.LocalDate localDate44 = dateTime43.toLocalDate();
        int int45 = property26.compareTo((org.joda.time.ReadablePartial) localDate44);
        int[] intArray48 = new int[] { 1969 };
        try {
            int[] intArray50 = offsetDateTimeField4.add((org.joda.time.ReadablePartial) localDate44, 0, intArray48, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Maximum value exceeded for add");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560809245397L + "'", long21 == 1560809245397L);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 0L + "'", long33 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 0L + "'", long36 == 0L);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(intArray48);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime11 = dateTime7.minusMonths(4);
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime14 = dateTime12.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime14.toDateTime();
        org.joda.time.DateTime.Property property16 = dateTime14.yearOfEra();
        java.lang.String str17 = property16.getName();
        org.joda.time.DateTime dateTime19 = property16.addToCopy((int) '4');
        org.joda.time.DateTime dateTime21 = dateTime19.withMillis(100L);
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = offsetDateTimeField26.getType();
        boolean boolean28 = dateTime21.isSupported(dateTimeFieldType27);
        boolean boolean29 = dateTime11.isSupported(dateTimeFieldType27);
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType27, 72, (-19), 166);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter34 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean35 = dateTimeFormatter34.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter37 = dateTimeFormatter34.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone38 = null;
        org.joda.time.chrono.ISOChronology iSOChronology39 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone38);
        org.joda.time.DateTimeField dateTimeField40 = iSOChronology39.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = dateTimeFormatter37.withChronology((org.joda.time.Chronology) iSOChronology39);
        org.joda.time.DurationField durationField42 = iSOChronology39.years();
        org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField43 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType27, durationField42);
        org.joda.time.DurationField durationField44 = unsupportedDateTimeField43.getDurationField();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime47 = dateTime45.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime48 = dateTime47.toDateTime();
        org.joda.time.DateTime.Property property49 = dateTime47.yearOfEra();
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime52 = dateTime50.plusWeeks((int) (short) -1);
        int int53 = property49.compareTo((org.joda.time.ReadableInstant) dateTime52);
        org.joda.time.DateTime dateTime54 = property49.roundHalfCeilingCopy();
        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now();
        long long56 = dateTime55.getMillis();
        org.joda.time.DateMidnight dateMidnight57 = dateTime55.toDateMidnight();
        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now();
        long long59 = dateTime58.getMillis();
        boolean boolean60 = dateTime55.isAfter((org.joda.time.ReadableInstant) dateTime58);
        org.joda.time.ReadableDuration readableDuration61 = null;
        org.joda.time.DateTime dateTime62 = dateTime58.minus(readableDuration61);
        org.joda.time.DateTime dateTime64 = dateTime58.plusMonths((int) (byte) 1);
        org.joda.time.DateTime dateTime66 = dateTime64.plusMonths(166);
        org.joda.time.LocalDate localDate67 = dateTime66.toLocalDate();
        int int68 = property49.compareTo((org.joda.time.ReadablePartial) localDate67);
        int[] intArray75 = new int[] { (byte) 100, 72, 19, 363, 10 };
        try {
            int[] intArray77 = unsupportedDateTimeField43.addWrapPartial((org.joda.time.ReadablePartial) localDate67, 54480694, intArray75, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: halfdayOfDay field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "yearOfEra" + "'", str17.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFieldType27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter37);
        org.junit.Assert.assertNotNull(iSOChronology39);
        org.junit.Assert.assertNotNull(dateTimeField40);
        org.junit.Assert.assertNotNull(dateTimeFormatter41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(unsupportedDateTimeField43);
        org.junit.Assert.assertNotNull(durationField44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(property49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dateTime54);
        org.junit.Assert.assertNotNull(dateTime55);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight57);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 0L + "'", long59 == 0L);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertNotNull(intArray75);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone5 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(cachedDateTimeZone5);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        org.joda.time.DateTime dateTime6 = property4.withMinimumValue();
        int int7 = property4.getMaximumValue();
        org.joda.time.DateTime dateTime8 = property4.getDateTime();
        org.joda.time.DateTime dateTime9 = property4.getDateTime();
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.weekOfWeekyear();
        java.lang.String str12 = gregorianChronology10.toString();
        org.joda.time.DateTimeField dateTimeField13 = gregorianChronology10.centuryOfEra();
        int int14 = dateTime9.get(dateTimeField13);
        org.joda.time.DateTime dateTime16 = dateTime9.minusMillis((int) 'a');
        org.joda.time.DateTime dateTime18 = dateTime9.minusSeconds(36000000);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 292278993 + "'", int7 == 292278993);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "GregorianChronology[America/Los_Angeles]" + "'", str12.equals("GregorianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 20 + "'", int14 == 20);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("0");
        org.joda.time.JodaTimePermission jodaTimePermission3 = new org.joda.time.JodaTimePermission("53");
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, (int) '4');
        long long11 = offsetDateTimeField8.getDifferenceAsLong(1560636445932L, (-1L));
        boolean boolean12 = jodaTimePermission3.equals((java.lang.Object) long11);
        java.lang.String str13 = jodaTimePermission3.getName();
        java.lang.String str14 = jodaTimePermission3.toString();
        boolean boolean15 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission3);
        java.lang.String str16 = jodaTimePermission3.getActions();
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 36125L + "'", long11 == 36125L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "53" + "'", str13.equals("53"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"53\")" + "'", str14.equals("(\"org.joda.time.JodaTimePermission\" \"53\")"));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray11 = new int[] {};
        int int12 = offsetDateTimeField4.getMinimumValue(readablePartial10, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField4.getMinimumValue(readablePartial13);
        long long16 = offsetDateTimeField4.roundCeiling(100L);
        int int18 = offsetDateTimeField4.getLeapAmount((long) 1969);
        long long21 = offsetDateTimeField4.add(1560636445397L, 4);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField4.getAsShortText(5, locale23);
        int int26 = offsetDateTimeField4.getLeapAmount(1560636502175L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560809245397L + "'", long21 == 1560809245397L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "5" + "'", str24.equals("5"));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(19);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        long long10 = dateTime9.getMillis();
        org.joda.time.DateMidnight dateMidnight11 = dateTime9.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime9.getZone();
        long long15 = dateTimeZone12.adjustOffset((long) 1, true);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter2.withZone(dateTimeZone12);
        java.io.Writer writer17 = null;
        try {
            dateTimeFormatter2.printTo(writer17, 1560636464093L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        java.lang.Class<?> wildcardClass1 = iSOChronology0.getClass();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.format.DateTimePrinter dateTimePrinter4 = dateTimeFormatter1.getPrinter();
        try {
            org.joda.time.LocalTime localTime6 = dateTimeFormatter1.parseLocalTime("16:00:00-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"16:00:00-08:00\" is malformed at \":00:00-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimePrinter4);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("T16:00:00-08:00", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"T16:00:00-08:00/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTime dateTime2 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DateTime dateTime4 = dateTime2.plus(1560636439434L);
        org.joda.time.DateTime dateTime5 = dateTime4.withLaterOffsetAtOverlap();
        org.joda.time.DateTime.Property property6 = dateTime4.dayOfMonth();
        org.joda.time.DurationField durationField7 = property6.getLeapDurationField();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNull(durationField7);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.DateTime.Property property6 = dateTime2.minuteOfDay();
        org.joda.time.ReadablePeriod readablePeriod7 = null;
        org.joda.time.DateTime dateTime9 = dateTime2.withPeriodAdded(readablePeriod7, (-32));
        org.joda.time.DateTime dateTime11 = dateTime9.withWeekyear((-32));
        org.joda.time.DateTime dateTime12 = dateTime11.toDateTime();
        org.joda.time.LocalTime localTime13 = dateTime11.toLocalTime();
        org.joda.time.DateTime.Property property14 = dateTime11.secondOfMinute();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(localTime13);
        org.junit.Assert.assertNotNull(property14);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateTime dateTime3 = dateTime0.minusMillis(19);
        org.joda.time.DateTime.Property property4 = dateTime3.hourOfDay();
        org.joda.time.DateTime.Property property5 = dateTime3.centuryOfEra();
        org.joda.time.DateTime dateTime7 = dateTime3.minusMillis((int) 'a');
        boolean boolean9 = dateTime3.isEqual((-14400000L));
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.millis();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.year();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        java.util.Locale locale5 = null;
        java.lang.String str6 = dateTime3.toString("1969", locale5);
        int int7 = dateTime3.getDayOfYear();
        int int8 = dateTime3.getSecondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 365 + "'", int7 == 365);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(19);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone7 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter2.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone7);
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now();
        long long10 = dateTime9.getMillis();
        org.joda.time.DateMidnight dateMidnight11 = dateTime9.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime9.getZone();
        long long15 = dateTimeZone12.adjustOffset((long) 1, true);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = dateTimeFormatter2.withZone(dateTimeZone12);
        org.joda.time.Chronology chronology17 = dateTimeFormatter16.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertNotNull(dateTimeFormatter16);
        org.junit.Assert.assertNull(chronology17);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.plusDays((int) '#');
        org.joda.time.DateTime dateTime6 = dateTime0.plusMinutes(2019);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        long long5 = dateTime4.getMillis();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis(10);
        org.joda.time.DateTime dateTime13 = dateTime9.withCenturyOfEra((int) (byte) 0);
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime16 = dateTime14.minusDays((int) (short) 100);
        int int17 = dateTime16.getYearOfCentury();
        org.joda.time.DateTime dateTime19 = dateTime16.plusWeeks(166);
        org.joda.time.DateTime dateTime21 = dateTime16.plusYears(1969);
        int int22 = dateTime9.compareTo((org.joda.time.ReadableInstant) dateTime21);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 69 + "'", int17 == 69);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        int int8 = offsetDateTimeField4.getLeapAmount((long) (-32));
        java.lang.String str10 = offsetDateTimeField4.getAsShortText(1560636443904L);
        org.joda.time.DurationField durationField11 = offsetDateTimeField4.getLeapDurationField();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "53" + "'", str10.equals("53"));
        org.junit.Assert.assertNull(durationField11);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        boolean boolean13 = fixedDateTimeZone9.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DurationField durationField15 = zonedChronology14.centuries();
        java.lang.String str16 = zonedChronology14.toString();
        org.joda.time.DateTimeField dateTimeField17 = zonedChronology14.secondOfMinute();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ZonedChronology[GregorianChronology[UTC], 19]" + "'", str16.equals("ZonedChronology[GregorianChronology[UTC], 19]"));
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        int int8 = offsetDateTimeField4.getLeapAmount((long) (-32));
        java.lang.String str10 = offsetDateTimeField4.getAsShortText(1560636443904L);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = offsetDateTimeField4.getType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException13 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType11, "");
        java.lang.String str14 = illegalFieldValueException13.toString();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = illegalFieldValueException13.getDateTimeFieldType();
        java.lang.String str16 = illegalFieldValueException13.getIllegalValueAsString();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "53" + "'", str10.equals("53"));
        org.junit.Assert.assertNotNull(dateTimeFieldType11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"\" for halfdayOfDay is not supported" + "'", str14.equals("org.joda.time.IllegalFieldValueException: Value \"\" for halfdayOfDay is not supported"));
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.withWeekOfWeekyear((int) '4');
        org.joda.time.DateTime.Property property6 = dateTime5.minuteOfHour();
        org.joda.time.DateTime.Property property7 = dateTime5.weekyear();
        org.joda.time.Instant instant8 = dateTime5.toInstant();
        int int9 = dateTime5.getYear();
        try {
            org.joda.time.DateTime dateTime11 = dateTime5.withDayOfMonth(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,28]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(instant8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1970 + "'", int9 == 1970);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "16:00:00-08:00");
        java.lang.String str3 = illegalFieldValueException2.getIllegalValueAsString();
        org.joda.time.DateTimeFieldType dateTimeFieldType4 = illegalFieldValueException2.getDateTimeFieldType();
        java.lang.Throwable[] throwableArray5 = illegalFieldValueException2.getSuppressed();
        java.lang.String str6 = illegalFieldValueException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "16:00:00-08:00" + "'", str3.equals("16:00:00-08:00"));
        org.junit.Assert.assertNull(dateTimeFieldType4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.joda.time.IllegalFieldValueException: Value \"16:00:00-08:00\" for  is not supported" + "'", str6.equals("org.joda.time.IllegalFieldValueException: Value \"16:00:00-08:00\" for  is not supported"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology3.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, (int) '4');
        java.util.Locale locale8 = null;
        java.lang.String str9 = offsetDateTimeField6.getAsShortText(53, locale8);
        int int11 = offsetDateTimeField6.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial12 = null;
        int[] intArray13 = new int[] {};
        int int14 = offsetDateTimeField6.getMinimumValue(readablePartial12, intArray13);
        org.joda.time.ReadablePartial readablePartial15 = null;
        int int16 = offsetDateTimeField6.getMinimumValue(readablePartial15);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime19 = dateTime17.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime20 = dateTime19.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay21 = dateTime20.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone22 = null;
        org.joda.time.chrono.ISOChronology iSOChronology23 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology23.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField26 = new org.joda.time.field.OffsetDateTimeField(dateTimeField24, (int) '4');
        java.util.Locale locale28 = null;
        java.lang.String str29 = offsetDateTimeField26.getAsShortText(53, locale28);
        int int31 = offsetDateTimeField26.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial32 = null;
        int[] intArray33 = new int[] {};
        int int34 = offsetDateTimeField26.getMinimumValue(readablePartial32, intArray33);
        int int35 = offsetDateTimeField6.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay21, intArray33);
        java.lang.String str36 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) yearMonthDay21);
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime39 = dateTime37.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime40 = dateTime39.toDateTime();
        org.joda.time.DateTime dateTime42 = dateTime39.minusMinutes((int) ' ');
        org.joda.time.MutableDateTime mutableDateTime43 = dateTime42.toMutableDateTime();
        int int46 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime43, "Pacific Daylight Time", 9);
        int int47 = dateTimeFormatter0.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(iSOChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "53" + "'", str9.equals("53"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 52 + "'", int16 == 52);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(yearMonthDay21);
        org.junit.Assert.assertNotNull(iSOChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "53" + "'", str29.equals("53"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 52 + "'", int34 == 52);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 53 + "'", int35 == 53);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "����W���" + "'", str36.equals("����W���"));
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(mutableDateTime43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-10) + "'", int46 == (-10));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2000 + "'", int47 == 2000);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone4 = null;
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology5.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = dateTimeFormatter3.withChronology((org.joda.time.Chronology) iSOChronology5);
        org.joda.time.DurationField durationField8 = iSOChronology5.years();
        long long11 = durationField8.subtract(0L, (-48));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1514764800000L + "'", long11 == 1514764800000L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusWeeks((int) (short) -1);
        org.joda.time.DateTime.Property property3 = dateTime0.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.plusWeeks((int) (short) -1);
        org.joda.time.DateTime dateTime4 = dateTime0.plusDays((int) (byte) 1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean6 = dateTimeFormatter5.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = dateTimeFormatter5.withDefaultYear((int) '4');
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology10.halfdayOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter8.withChronology((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology10.secondOfMinute();
        org.joda.time.DurationField durationField14 = iSOChronology10.weekyears();
        org.joda.time.DurationField durationField15 = iSOChronology10.weekyears();
        org.joda.time.DateTime dateTime16 = dateTime0.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = offsetDateTimeField4.getType();
        int int7 = offsetDateTimeField4.getLeapAmount(1560636443974L);
        java.lang.String str8 = offsetDateTimeField4.getName();
        java.util.Locale locale10 = null;
        java.lang.String str11 = offsetDateTimeField4.getAsShortText(1560636478487L, locale10);
        long long13 = offsetDateTimeField4.roundHalfCeiling((long) 18);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeFieldType5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "halfdayOfDay" + "'", str8.equals("halfdayOfDay"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "53" + "'", str11.equals("53"));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-14400000L) + "'", long13 == (-14400000L));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        int int6 = offsetDateTimeField4.getMaximumValue(0L);
        int int8 = offsetDateTimeField4.getLeapAmount((long) (-32));
        java.lang.String str10 = offsetDateTimeField4.getAsShortText(1560636443904L);
        long long12 = offsetDateTimeField4.roundHalfFloor(1560636441304L);
        long long15 = offsetDateTimeField4.add((long) 4, 24);
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField4.getAsShortText((int) (short) -1, locale17);
        int int20 = offsetDateTimeField4.getMaximumValue(0L);
        int int22 = offsetDateTimeField4.get(28800000L);
        int int24 = offsetDateTimeField4.getMinimumValue(1560636488662L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 53 + "'", int6 == 53);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "53" + "'", str10.equals("53"));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560625200000L + "'", long12 == 1560625200000L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1036800004L + "'", long15 == 1036800004L);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "-1" + "'", str18.equals("-1"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 53 + "'", int20 == 53);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 52 + "'", int22 == 52);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 52 + "'", int24 == 52);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.util.Locale locale6 = null;
        java.lang.String str7 = offsetDateTimeField4.getAsShortText(53, locale6);
        int int9 = offsetDateTimeField4.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial10 = null;
        int[] intArray11 = new int[] {};
        int int12 = offsetDateTimeField4.getMinimumValue(readablePartial10, intArray11);
        org.joda.time.ReadablePartial readablePartial13 = null;
        int int14 = offsetDateTimeField4.getMinimumValue(readablePartial13);
        long long16 = offsetDateTimeField4.roundCeiling(100L);
        int int18 = offsetDateTimeField4.getLeapAmount((long) 1969);
        long long21 = offsetDateTimeField4.add(1560636445397L, 4);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField4.getAsShortText(5, locale23);
        org.joda.time.DurationField durationField25 = offsetDateTimeField4.getDurationField();
        org.joda.time.ReadablePartial readablePartial26 = null;
        int int27 = offsetDateTimeField4.getMaximumValue(readablePartial26);
        java.util.Locale locale29 = null;
        java.lang.String str30 = offsetDateTimeField4.getAsShortText((-35), locale29);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "53" + "'", str7.equals("53"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 52 + "'", int14 == 52);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28800000L + "'", long16 == 28800000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560809245397L + "'", long21 == 1560809245397L);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "5" + "'", str24.equals("5"));
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 53 + "'", int27 == 53);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "-35" + "'", str30.equals("-35"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.lang.String str6 = offsetDateTimeField4.getAsText(1560636440970L);
        int int8 = offsetDateTimeField4.getMinimumValue((long) 1);
        long long10 = offsetDateTimeField4.roundHalfFloor(0L);
        long long12 = offsetDateTimeField4.roundHalfFloor(1560636443001L);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "53" + "'", str6.equals("53"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-14400000L) + "'", long10 == (-14400000L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560625200000L + "'", long12 == 1560625200000L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime3.centuryOfEra();
        boolean boolean6 = property4.equals((java.lang.Object) 1560636475949L);
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        long long8 = dateTime7.getMillis();
        org.joda.time.DateMidnight dateMidnight9 = dateTime7.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime7.getZone();
        long long13 = dateTimeZone10.adjustOffset((long) 1, true);
        long long16 = dateTimeZone10.convertLocalToUTC((long) 1969, true);
        int int18 = dateTimeZone10.getOffsetFromLocal(1560636442663L);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone19 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone10);
        int int21 = cachedDateTimeZone19.getStandardOffset(1560636478487L);
        java.lang.Object obj22 = null;
        boolean boolean23 = cachedDateTimeZone19.equals(obj22);
        try {
            org.joda.time.DateTime dateTime24 = new org.joda.time.DateTime((java.lang.Object) property4, (org.joda.time.DateTimeZone) cachedDateTimeZone19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.DateTime$Property");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 28801969L + "'", long16 == 28801969L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-25200000) + "'", int18 == (-25200000));
        org.junit.Assert.assertNotNull(cachedDateTimeZone19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.joda.time.DateTimeZone dateTimeZone6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(12, 268, 267, 363, 734, 54480694, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 363 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime.Property property8 = dateTime7.weekOfWeekyear();
        org.joda.time.DateTime dateTime9 = dateTime7.withEarlierOffsetAtOverlap();
        try {
            org.joda.time.DateTime dateTime11 = dateTime9.withDayOfMonth(2019);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2019 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("2019");
        java.lang.String str2 = jodaTimePermission1.getName();
        java.lang.String str3 = jodaTimePermission1.getActions();
        java.lang.String str4 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology2.getZone();
        long long7 = dateTimeZone4.convertLocalToUTC(1560636446204L, true);
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime10 = dateTime8.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime11 = dateTime10.toDateTime();
        org.joda.time.DateTime.Property property12 = dateTime10.yearOfEra();
        java.lang.String str13 = property12.getName();
        org.joda.time.DateTime dateTime15 = property12.addToCopy((int) '4');
        org.joda.time.Chronology chronology16 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime15);
        int int17 = dateTime15.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime15.plus(readableDuration18);
        org.joda.time.DateTime dateTime21 = dateTime19.minusMinutes(72);
        int int22 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime19);
        org.joda.time.DateTime dateTime24 = dateTime19.withCenturyOfEra(2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560661646204L + "'", long7 == 1560661646204L);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(property12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "yearOfEra" + "'", str13.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(chronology16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 52 + "'", int17 == 52);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-28800000) + "'", int22 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime24);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology2);
        org.joda.time.DurationField durationField4 = gregorianChronology2.years();
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone5);
        java.lang.String str7 = iSOChronology6.toString();
        org.joda.time.DateTimeZone dateTimeZone8 = iSOChronology6.getZone();
        org.joda.time.Chronology chronology9 = gregorianChronology2.withZone(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str7.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(chronology9);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField4 = new org.joda.time.field.OffsetDateTimeField(dateTimeField2, (int) '4');
        java.lang.String str6 = offsetDateTimeField4.getAsText(1560636440970L);
        int int8 = offsetDateTimeField4.getMinimumValue((long) 1);
        org.joda.time.DateTimeField dateTimeField9 = offsetDateTimeField4.getWrappedField();
        long long12 = offsetDateTimeField4.add(1560636468483L, 0);
        int int14 = offsetDateTimeField4.get(0L);
        org.joda.time.DurationField durationField15 = offsetDateTimeField4.getRangeDurationField();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "53" + "'", str6.equals("53"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 52 + "'", int8 == 52);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560636468483L + "'", long12 == 1560636468483L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 53 + "'", int14 == 53);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getAsText();
        java.lang.String str6 = property4.getAsShortText();
        int int7 = property4.get();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone12 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean13 = fixedDateTimeZone12.isFixed();
        java.util.TimeZone timeZone14 = fixedDateTimeZone12.toTimeZone();
        long long16 = fixedDateTimeZone12.nextTransition(0L);
        boolean boolean17 = property4.equals((java.lang.Object) fixedDateTimeZone12);
        org.joda.time.DateTime dateTime18 = property4.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1969" + "'", str5.equals("1969"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1969" + "'", str6.equals("1969"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DateTimeField dateTimeField2 = gregorianChronology0.era();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.dayOfYear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now((org.joda.time.Chronology) gregorianChronology0);
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTime4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.plusMinutes((-32));
        org.joda.time.DateMidnight dateMidnight5 = dateTime0.toDateMidnight();
        org.joda.time.chrono.GregorianChronology gregorianChronology6 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology6.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology6.hourOfDay();
        boolean boolean9 = dateTime0.equals((java.lang.Object) gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateMidnight5);
        org.junit.Assert.assertNotNull(gregorianChronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        long long1 = dateTime0.getMillis();
        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now();
        long long4 = dateTime3.getMillis();
        boolean boolean5 = dateTime0.isAfter((org.joda.time.ReadableInstant) dateTime3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.DateTime dateTime7 = dateTime3.minus(readableDuration6);
        org.joda.time.DateTime dateTime9 = dateTime7.withMillisOfSecond(12);
        org.joda.time.DateTime.Property property10 = dateTime9.secondOfMinute();
        long long11 = property10.remainder();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 12L + "'", long11 == 12L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        java.lang.String str2 = dateTimeFormatter0.print((long) 2019);
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronolgy();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "16" + "'", str2.equals("16"));
        org.junit.Assert.assertNull(chronology3);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test472");
//        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
//        long long1 = dateTime0.getMillis();
//        org.joda.time.DateMidnight dateMidnight2 = dateTime0.toDateMidnight();
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime0.getZone();
//        long long6 = dateTimeZone3.adjustOffset((long) 1, true);
//        long long9 = dateTimeZone3.convertLocalToUTC((long) 1969, true);
//        int int11 = dateTimeZone3.getOffsetFromLocal(1560636442663L);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone12 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone3);
//        int int14 = cachedDateTimeZone12.getStandardOffset(1560636478487L);
//        java.lang.Object obj15 = null;
//        boolean boolean16 = cachedDateTimeZone12.equals(obj15);
//        long long18 = cachedDateTimeZone12.nextTransition(1560636489683L);
//        java.lang.String str20 = cachedDateTimeZone12.getShortName((long) 20);
//        org.junit.Assert.assertNotNull(dateTime0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
//        org.junit.Assert.assertNotNull(dateMidnight2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 28801969L + "'", long9 == 28801969L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-25200000) + "'", int11 == (-25200000));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone12);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1572771600000L + "'", long18 == 1572771600000L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PST" + "'", str20.equals("PST"));
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(1560636440801L, 1560636443292L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: The calculation caused an overflow: 1560636440801 * 1560636443292");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime0.withHourOfDay(0);
        boolean boolean5 = dateTime4.isEqualNow();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        boolean boolean3 = iSOChronology0.equals((java.lang.Object) dateTimeFormatter2);
        org.joda.time.Chronology chronology4 = iSOChronology0.withUTC();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone9 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean10 = fixedDateTimeZone9.isFixed();
        java.util.TimeZone timeZone11 = fixedDateTimeZone9.toTimeZone();
        java.lang.String str13 = fixedDateTimeZone9.getName((-1L));
        org.joda.time.chrono.ZonedChronology zonedChronology14 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.DateTimeZone) fixedDateTimeZone9);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.hourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "+00:00:00.100" + "'", str13.equals("+00:00:00.100"));
        org.junit.Assert.assertNotNull(zonedChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withOffsetParsed();
        org.joda.time.DateTimeZone dateTimeZone2 = null;
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, 1);
        org.joda.time.ReadablePeriod readablePeriod5 = null;
        long long8 = gregorianChronology4.add(readablePeriod5, 1560636438373L, (int) (short) 10);
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology4.weekyear();
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology4.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology4.millisOfSecond();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter12 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) gregorianChronology4);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField14 = gregorianChronology13.hours();
        org.joda.time.DurationField durationField15 = gregorianChronology13.days();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology13.secondOfDay();
        org.joda.time.DurationField durationField17 = gregorianChronology13.seconds();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone22 = new org.joda.time.tz.FixedDateTimeZone("19", "0", (int) (short) 100, 52);
        boolean boolean23 = fixedDateTimeZone22.isFixed();
        java.util.TimeZone timeZone24 = fixedDateTimeZone22.toTimeZone();
        boolean boolean26 = fixedDateTimeZone22.equals((java.lang.Object) "2019");
        org.joda.time.chrono.ZonedChronology zonedChronology27 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, (org.joda.time.DateTimeZone) fixedDateTimeZone22);
        org.joda.time.DurationField durationField28 = zonedChronology27.centuries();
        org.joda.time.DateTimeField dateTimeField29 = zonedChronology27.weekyear();
        org.joda.time.DateTimeField dateTimeField30 = zonedChronology27.hourOfDay();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter1.withChronology((org.joda.time.Chronology) zonedChronology27);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560636438373L + "'", long8 == 1560636438373L);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeFormatter12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(timeZone24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(zonedChronology27);
        org.junit.Assert.assertNotNull(durationField28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.MutableDateTime mutableDateTime6 = dateTime5.toMutableDateTime();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now();
        long long8 = dateTime7.getMillis();
        org.joda.time.DateMidnight dateMidnight9 = dateTime7.toDateMidnight();
        boolean boolean10 = dateTime5.isEqual((org.joda.time.ReadableInstant) dateTime7);
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime13 = dateTime11.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime15 = dateTime13.minusHours((int) ' ');
        org.joda.time.DateTime dateTime17 = dateTime13.minusMillis((int) (byte) 10);
        org.joda.time.DateTime.Property property18 = dateTime13.hourOfDay();
        org.joda.time.TimeOfDay timeOfDay19 = dateTime13.toTimeOfDay();
        boolean boolean20 = dateTime5.isBefore((org.joda.time.ReadableInstant) dateTime13);
        org.joda.time.DateTime.Property property21 = dateTime5.minuteOfDay();
        org.joda.time.DateTime.Property property22 = dateTime5.dayOfYear();
        org.joda.time.ReadableInstant readableInstant23 = null;
        boolean boolean24 = dateTime5.isBefore(readableInstant23);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(mutableDateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(property18);
        org.junit.Assert.assertNotNull(timeOfDay19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(property22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendTimeZoneId();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder6 = dateTimeFormatterBuilder2.appendTwoDigitYear(735, false);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder6);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = iSOChronology0.withUTC();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime4 = dateTime2.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime5 = dateTime4.toDateTime();
        org.joda.time.DateTime.Property property6 = dateTime4.yearOfEra();
        int int7 = dateTime4.getMonthOfYear();
        org.joda.time.DateTime dateTime9 = dateTime4.withYearOfCentury((int) (short) 1);
        org.joda.time.TimeOfDay timeOfDay10 = dateTime4.toTimeOfDay();
        org.joda.time.DateTimeZone dateTimeZone11 = null;
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone11);
        org.joda.time.DateTimeField dateTimeField13 = iSOChronology12.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField15 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, (int) '4');
        java.util.Locale locale17 = null;
        java.lang.String str18 = offsetDateTimeField15.getAsShortText(53, locale17);
        int int20 = offsetDateTimeField15.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial21 = null;
        int[] intArray22 = new int[] {};
        int int23 = offsetDateTimeField15.getMinimumValue(readablePartial21, intArray22);
        org.joda.time.ReadablePartial readablePartial24 = null;
        int int25 = offsetDateTimeField15.getMinimumValue(readablePartial24);
        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime28 = dateTime26.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime29 = dateTime28.toDateTime();
        org.joda.time.YearMonthDay yearMonthDay30 = dateTime29.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone31 = null;
        org.joda.time.chrono.ISOChronology iSOChronology32 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone31);
        org.joda.time.DateTimeField dateTimeField33 = iSOChronology32.halfdayOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) '4');
        java.util.Locale locale37 = null;
        java.lang.String str38 = offsetDateTimeField35.getAsShortText(53, locale37);
        int int40 = offsetDateTimeField35.getLeapAmount(1560636442281L);
        org.joda.time.ReadablePartial readablePartial41 = null;
        int[] intArray42 = new int[] {};
        int int43 = offsetDateTimeField35.getMinimumValue(readablePartial41, intArray42);
        int int44 = offsetDateTimeField15.getMaximumValue((org.joda.time.ReadablePartial) yearMonthDay30, intArray42);
        try {
            iSOChronology0.validate((org.joda.time.ReadablePartial) timeOfDay10, intArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(timeOfDay10);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "53" + "'", str18.equals("53"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 52 + "'", int23 == 52);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(yearMonthDay30);
        org.junit.Assert.assertNotNull(iSOChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "53" + "'", str38.equals("53"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 52 + "'", int43 == 52);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 53 + "'", int44 == 53);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime dateTime5 = dateTime2.minusMinutes((int) ' ');
        org.joda.time.DateTime dateTime8 = dateTime2.withDurationAdded((long) 2019, 24);
        org.joda.time.DateTime.Property property9 = dateTime2.millisOfSecond();
        org.joda.time.DateTime dateTime10 = property9.getDateTime();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime4 = dateTime2.minusHours((int) ' ');
        org.joda.time.DateTime dateTime6 = dateTime2.minusMillis((int) (byte) 10);
        int int7 = dateTime6.getYearOfCentury();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 69 + "'", int7 == 69);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.hours();
        org.joda.time.DurationField durationField2 = gregorianChronology0.days();
        org.joda.time.DateTimeField dateTimeField3 = gregorianChronology0.secondOfDay();
        org.joda.time.DurationField durationField4 = gregorianChronology0.seconds();
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((org.joda.time.Chronology) gregorianChronology0);
        org.joda.time.DurationField durationField6 = gregorianChronology0.days();
        try {
            long long11 = gregorianChronology0.getDateTimeMillis((int) (short) 1, 2005, 907, 54445);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2005 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(durationField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.withMillis((long) (short) 10);
        org.joda.time.DateTime dateTime3 = dateTime2.toDateTime();
        org.joda.time.DateTime.Property property4 = dateTime2.yearOfEra();
        java.lang.String str5 = property4.getName();
        org.joda.time.DateTime dateTime7 = property4.addToCopy((int) '4');
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        int int9 = dateTime7.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.DateTime dateTime11 = dateTime7.plus(readableDuration10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMinutes(72);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime16 = dateTime13.withPeriodAdded(readablePeriod14, 15);
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(property4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "yearOfEra" + "'", str5.equals("yearOfEra"));
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 52 + "'", int9 == 52);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime16);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime2 = dateTime0.minusDays((int) (short) 100);
        org.joda.time.DateTime.Property property3 = dateTime2.weekyear();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now();
        long long5 = dateTime4.getMillis();
        org.joda.time.DateMidnight dateMidnight6 = dateTime4.toDateMidnight();
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime4.getZone();
        long long8 = property3.getDifferenceAsLong((org.joda.time.ReadableInstant) dateTime4);
        org.joda.time.DateTime dateTime9 = property3.roundHalfEvenCopy();
        org.joda.time.DateTime dateTime11 = dateTime9.plusMillis(10);
        int int12 = dateTime9.getMinuteOfHour();
        org.joda.time.DateTime.Property property13 = dateTime9.dayOfYear();
        org.junit.Assert.assertNotNull(dateTime0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateMidnight6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(property13);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder0 = new org.joda.time.format.DateTimeFormatterBuilder();
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder2 = dateTimeFormatterBuilder0.appendMillisOfDay(0);
        org.joda.time.format.DateTimeFormatterBuilder dateTimeFormatterBuilder3 = dateTimeFormatterBuilder2.appendHalfdayOfDayText();
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder2);
        org.junit.Assert.assertNotNull(dateTimeFormatterBuilder3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "org.joda.time.IllegalFieldValueException: Value 100.0 for PST must be in the range [10,1560636442663]", "UnsupportedDateTimeField");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "+00:00:00.100", "1970-W01-3");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getShortName(locale9, "100.0", "halfdayOfDay");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = dateTimeFormatter0.getPrinter();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimePrinter1);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeParser3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withDefaultYear((int) '4');
        java.lang.StringBuffer stringBuffer4 = null;
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now();
        org.joda.time.DateTime dateTime7 = dateTime5.plusWeeks((int) (short) -1);
        long long8 = dateTime7.getMillis();
        org.joda.time.LocalDateTime localDateTime9 = dateTime7.toLocalDateTime();
        try {
            dateTimeFormatter3.printTo(stringBuffer4, (org.joda.time.ReadablePartial) localDateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-604800000L) + "'", long8 == (-604800000L));
        org.junit.Assert.assertNotNull(localDateTime9);
    }
}

