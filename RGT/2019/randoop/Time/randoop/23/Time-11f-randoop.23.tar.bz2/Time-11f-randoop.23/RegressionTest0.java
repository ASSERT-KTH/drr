import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField3 = new org.joda.time.field.RemainderDateTimeField(dateTimeField0, dateTimeFieldType1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        org.joda.time.DurationFieldType[] durationFieldTypeArray1 = new org.joda.time.DurationFieldType[] { durationFieldType0 };
        try {
            org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.forFields(durationFieldTypeArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not contain null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationFieldTypeArray1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.fieldDifference(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField3 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField6 = new org.joda.time.field.DecoratedDurationField(durationField4, durationFieldType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (byte) 0, (java.lang.Number) (-1.0d), (java.lang.Number) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField7 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType5, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        boolean boolean2 = periodType0.equals((java.lang.Object) (-1));
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 1, 10L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test012");
//        org.joda.time.ReadableInstant readableInstant0 = null;
//        long long1 = org.joda.time.DateTimeUtils.getInstantMillis(readableInstant0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560629155109L + "'", long1 == 1560629155109L);
//    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test014");
//        org.joda.time.DurationFieldType durationFieldType0 = null;
//        try {
//            org.joda.time.field.UnsupportedDurationField unsupportedDurationField1 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType0);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.ReadablePartial readablePartial0 = null;
        try {
            boolean boolean1 = org.joda.time.DateTimeUtils.isContiguous(readablePartial0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', (-1L), chronology4);
        int[] intArray6 = period5.getValues();
        try {
            iSOChronology0.validate(readablePartial1, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (short) 10, (java.lang.Number) 1560629155109L, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(1);
        try {
            org.joda.time.DurationFieldType durationFieldType8 = period3.getFieldType((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(10, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 520 + "'", int2 == 520);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply(0L, 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.PeriodType periodType1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) (byte) 100, periodType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Byte");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField7 = new org.joda.time.field.DividedDateTimeField(dateTimeField4, dateTimeFieldType5, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearMonthDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DurationField durationField6 = gregorianChronology3.halfdays();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField8 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.minutes();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.DurationFieldType durationFieldType5 = null;
        try {
            org.joda.time.Period period7 = period3.withFieldAdded(durationFieldType5, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period6.minusMillis((int) (byte) -1);
        int int9 = period6.getMonths();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.monthOfYear();
        java.lang.Class<?> wildcardClass7 = dateTimeField6.getClass();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField10 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType8, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) '4', "");
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        try {
            org.joda.time.Period period4 = period2.withDays(0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (byte) 10);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("hi!", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hi!/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField6 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The offset cannot be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekyear();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.clockhourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.tz.Provider provider0 = null;
        org.joda.time.DateTimeZone.setProvider(provider0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.ReadablePartial readablePartial5 = null;
        try {
            long long7 = gregorianChronology3.set(readablePartial5, (long) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusMinutes((int) 'a');
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period3.withYears(0);
        org.joda.time.DurationFieldType durationFieldType10 = period8.getFieldType((int) (short) 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldType10);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekyear();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.millisOfSecond();
        org.joda.time.ReadablePartial readablePartial7 = null;
        try {
            long long9 = gregorianChronology3.set(readablePartial7, 1560629155109L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 10, (int) (short) -1, 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        try {
            org.joda.time.Period period6 = period4.minusYears(520);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((int) (byte) 0, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period3.plusSeconds(0);
        try {
            org.joda.time.DurationFieldType durationFieldType10 = period3.getFieldType(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) (short) -1, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9L + "'", long2 == 9L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
        try {
            long long10 = gregorianChronology3.getDateTimeMillis(187200000, (int) ' ', (int) (byte) -1, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("org.joda.time.IllegalFieldValueException: Hours: Value 1 for hi! must be in the range [0,10.0]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"org.joda.time.IllegalFieldValueException: Hours: Value 1 for hi! must be in the range [0,10.0]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField8 = new org.joda.time.field.OffsetDateTimeField(dateTimeField5, dateTimeFieldType6, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.ReadableInstant readableInstant4 = null;
        int int5 = dateTimeZone3.getOffset(readableInstant4);
        boolean boolean6 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) readableInstant4);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 187200000 + "'", int5 == 187200000);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.withDays((int) '4');
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withHoursRemoved();
        org.joda.time.PeriodType periodType3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getInstantChronology(readableInstant4);
        try {
            org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) periodType2, periodType3, chronology5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(1);
        org.joda.time.Period period8 = period6.withMillis(520);
        int int9 = period8.getWeeks();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(10, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14 + "'", int2 == 14);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'hi!' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfDay();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 187200000, (java.lang.Number) 8, (java.lang.Number) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DurationField durationField1 = org.joda.time.field.MillisDurationField.INSTANCE;
        try {
            org.joda.time.field.UnsupportedDateTimeField unsupportedDateTimeField2 = org.joda.time.field.UnsupportedDateTimeField.getInstance(dateTimeFieldType0, durationField1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DurationField durationField6 = gregorianChronology3.halfdays();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.ReadablePartial readablePartial8 = null;
        try {
            int[] intArray10 = gregorianChronology3.get(readablePartial8, (long) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        int int6 = gregorianChronology3.getMinimumDaysInFirstWeek();
        try {
            long long14 = gregorianChronology3.getDateTimeMillis(14, 0, 100, 1, (int) (byte) 1, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException3 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 1, "1");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period(readablePartial0, readablePartial1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekyear();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.centuryOfEra();
        org.joda.time.DurationField durationField8 = gregorianChronology3.halfdays();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(durationField8);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("PT0H", 10, (int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10 for PT0H must be in the range [0,-1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds("+52:00", (int) (short) -1, 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for +52:00 must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        long long5 = iSOChronology0.add((long) (short) 10, 0L, 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 10L + "'", long5 == 10L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(1);
        org.joda.time.Period period8 = period6.withMillis(520);
        org.joda.time.Period period10 = period8.plusMillis(0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("+52:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"+52:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstanceUTC();
        org.joda.time.PeriodType periodType1 = null;
        org.joda.time.chrono.ISOChronology iSOChronology2 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology4 = iSOChronology2.withZone(dateTimeZone3);
        org.joda.time.Chronology chronology5 = iSOChronology2.withUTC();
        try {
            org.joda.time.Period period6 = new org.joda.time.Period((java.lang.Object) gregorianChronology0, periodType1, (org.joda.time.Chronology) iSOChronology2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(iSOChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.millis();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(3155759999999L, 9L, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -3155759999990");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period3.withMillis(10);
        org.joda.time.DurationFieldType[] durationFieldTypeArray9 = period3.getFieldTypes();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(durationFieldTypeArray9);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) (byte) 10, 3155759999999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3155759999989L) + "'", long2 == (-3155759999989L));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekyear();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.centuryOfEra();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField7, (int) 'a', (int) (short) 100, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for centuryOfEra must be in the range [100,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean11 = dateTimeZone8.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone12);
        try {
            long long19 = zonedChronology13.getDateTimeMillis(187199999L, 520, (int) (short) 100, 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 520 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 8, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 60L + "'", long2 == 60L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 9L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865982400000L) + "'", long1 == (-210865982400000L));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType8 = periodType7.withYearsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableDuration5, readableInstant6, periodType7);
        org.joda.time.Period period10 = period4.withPeriodType(periodType7);
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DurationField durationField15 = gregorianChronology14.centuries();
        org.joda.time.DurationField durationField16 = gregorianChronology14.years();
        org.joda.time.DurationField durationField17 = gregorianChronology14.halfdays();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology14.clockhourOfHalfday();
        try {
            org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) periodType7, (org.joda.time.Chronology) gregorianChronology14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(durationField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        org.joda.time.DurationField durationField39 = null;
        try {
            int int40 = scaledDurationField33.compareTo(durationField39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.tz.ZoneInfoCompiler zoneInfoCompiler0 = new org.joda.time.tz.ZoneInfoCompiler();
        java.io.BufferedReader bufferedReader1 = null;
        try {
            zoneInfoCompiler0.parseDataFile(bufferedReader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.PeriodType periodType3 = periodType1.withMonthsRemoved();
        org.joda.time.PeriodType periodType4 = periodType1.withMinutesRemoved();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.PeriodType periodType3 = periodType1.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.yearOfEra();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology7.secondOfMinute();
        boolean boolean10 = periodType3.equals((java.lang.Object) dateTimeField9);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField9, 100, 0, 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfMinute must be in the range [0,97]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-28799999L), (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-28800051L) + "'", long2 == (-28800051L));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.Period period6 = period4.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray7 = period4.getFieldTypes();
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) -1, periodType9);
        org.joda.time.PeriodType periodType11 = periodType9.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType13 = periodType9.getFieldType((int) (short) 0);
        org.joda.time.Period period15 = period4.withFieldAdded(durationFieldType13, 0);
        int int16 = period1.get(durationFieldType13);
        org.joda.time.Period period17 = period1.toPeriod();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(durationFieldTypeArray7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(durationFieldType13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(period17);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.DurationFieldType durationFieldType34 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField36 = new org.joda.time.field.ScaledDurationField((org.joda.time.DurationField) scaledDurationField33, durationFieldType34, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.centuryOfEra();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField10 = new org.joda.time.field.RemainderDateTimeField(dateTimeField7, dateTimeFieldType8, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.PeriodType periodType1 = null;
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) 1.0f, periodType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Float");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            int[] intArray8 = iSOChronology0.get(readablePartial6, (-3155759999989L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        try {
            org.joda.time.DurationFieldType durationFieldType7 = period5.getFieldType((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        org.joda.time.PeriodType periodType6 = periodType3.withYearsRemoved();
        java.lang.String str7 = periodType3.getName();
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Hours" + "'", str7.equals("Hours"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "hi!", "");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number1 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, number1, (java.lang.Number) (short) 0, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = gregorianChronology3.getZone();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            long long8 = gregorianChronology3.set(readablePartial6, (long) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfMinute();
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.PeriodType periodType9 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period10 = new org.joda.time.Period((long) (short) -1, periodType9);
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant6, readableInstant7, periodType9);
        int int12 = period11.getMonths();
        boolean boolean13 = gregorianChronology3.equals((java.lang.Object) int12);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period3.plusSeconds(0);
        int int9 = period3.getMonths();
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType13 = periodType12.withYearsRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration10, readableInstant11, periodType12);
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType18 = periodType17.withYearsRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period(readableDuration15, readableInstant16, periodType17);
        org.joda.time.Period period20 = period14.withPeriodType(periodType17);
        org.joda.time.Period period21 = period3.minus((org.joda.time.ReadablePeriod) period14);
        int int22 = period21.getMinutes();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-28800051L), (long) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1008001785) + "'", int2 == (-1008001785));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("org.joda.time.IllegalFieldValueException: Hours: Value 1 for hi! must be in the range [0,10.0]", (int) '4');
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder3.writeTo("", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period3.plusSeconds(0);
        org.joda.time.Minutes minutes9 = period8.toStandardMinutes();
        org.joda.time.Period period11 = period8.plusMonths((int) (short) 0);
        int int12 = period8.getMinutes();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(minutes9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, (int) (short) 100, (-1008001785), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for secondOfDay must be in the range [-1008001785,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay(0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period5 = period3.normalizedStandard();
        org.joda.time.Duration duration6 = period5.toStandardDuration();
        org.joda.time.Period period8 = period5.withWeeks(0);
        org.joda.time.Period period10 = period5.minusDays((int) (byte) 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.5d + "'", double1 == 2440587.5d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.secondOfDay();
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period6, (java.lang.Object) dateTimeField12);
        org.joda.time.Period period15 = period6.plusMillis((int) (short) 10);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekyear();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) '4', (-1L), chronology8);
        int int10 = period9.getMonths();
        org.joda.time.Period period12 = period9.plusDays(1);
        org.joda.time.Period period14 = period9.withSeconds((-1));
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant15, readableDuration16);
        org.joda.time.Period period19 = period17.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray20 = period17.getFieldTypes();
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.forFields(durationFieldTypeArray20);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology24 = iSOChronology22.withZone(dateTimeZone23);
        org.joda.time.Period period25 = new org.joda.time.Period((java.lang.Object) period14, periodType21, (org.joda.time.Chronology) iSOChronology22);
        try {
            org.joda.time.Period period26 = new org.joda.time.Period((java.lang.Object) dateTimeField5, periodType21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(durationFieldTypeArray20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        long long40 = scaledDurationField33.getValueAsLong((long) ' ');
        try {
            long long42 = scaledDurationField33.getMillis((-1008001785));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -52416092820 * 3155695200000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period2.getFieldTypes();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType7);
        org.joda.time.PeriodType periodType9 = periodType7.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType11 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period13 = period2.withFieldAdded(durationFieldType11, 0);
        org.joda.time.PeriodType periodType14 = period2.getPeriodType();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("GregorianChronology[+52:00]");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"GregorianChronology[+52:00]/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test113");
//        long long0 = org.joda.time.DateTimeUtils.currentTimeMillis();
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 1560629169769L + "'", long0 == 1560629169769L);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', (-1L), chronology3);
        int[] intArray5 = period4.getValues();
        org.joda.time.Period period6 = period4.normalizedStandard();
        org.joda.time.Duration duration7 = period6.toStandardDuration();
        long long8 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration7);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType13 = periodType12.withYearsRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration10, readableInstant11, periodType12);
        org.joda.time.PeriodType periodType15 = period14.getPeriodType();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) 100, periodType15, chronology16);
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7, periodType15);
        int int19 = period18.size();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-53L) + "'", long8 == (-53L));
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.DateTimeUtils.setCurrentMillisSystem();
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.Period period2 = new org.joda.time.Period((-28799999L), (long) (-3600000));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period2.getFieldTypes();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType7);
        org.joda.time.PeriodType periodType9 = periodType7.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType11 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period13 = period2.withFieldAdded(durationFieldType11, 0);
        int int14 = period13.getMinutes();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.halfdays();
        try {
            org.joda.time.Period period5 = new org.joda.time.Period((java.lang.Object) gregorianChronology3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((-1));
        org.joda.time.Period period6 = period4.plusMillis((int) (byte) 100);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        int int5 = period2.getYears();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) '4', (-1L), chronology8);
        int[] intArray10 = period9.getValues();
        org.joda.time.Period period12 = period9.minusDays((int) 'a');
        org.joda.time.Period period14 = period9.withYears(0);
        org.joda.time.MutablePeriod mutablePeriod15 = period14.toMutablePeriod();
        try {
            org.joda.time.Period period16 = period2.plus((org.joda.time.ReadablePeriod) period14);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(mutablePeriod15);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearWeekDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        try {
            org.joda.time.Period period5 = period2.minusMonths((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.year();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.era();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 587L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210816043200000L) + "'", long1 == (-210816043200000L));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period3.withYears(0);
        org.joda.time.Period period10 = period3.withWeeks(187200000);
        org.joda.time.MutablePeriod mutablePeriod11 = period10.toMutablePeriod();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(mutablePeriod11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField5 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType1, (int) (short) -1, 0, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.io.DataInput dataInput0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(dataInput0, "PT0H");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        org.joda.time.PeriodType periodType6 = periodType3.withSecondsRemoved();
        org.joda.time.PeriodType periodType7 = org.joda.time.DateTimeUtils.getPeriodType(periodType6);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        org.joda.time.PeriodType periodType10 = periodType9.withDaysRemoved();
        boolean boolean11 = periodType7.equals((java.lang.Object) periodType10);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
//        boolean boolean4 = dateTimeZone1.isStandardOffset((long) 97);
//        long long6 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
//        java.lang.String str7 = dateTimeZone1.getID();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-28799999L) + "'", long6 == (-28799999L));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "America/Los_Angeles" + "'", str7.equals("America/Los_Angeles"));
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType3);
        org.joda.time.PeriodType periodType6 = period5.getPeriodType();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) 100, periodType6, chronology7);
        try {
            org.joda.time.Period period10 = period8.plusSeconds((-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.DurationFieldType[] durationFieldTypeArray0 = null;
        try {
            org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.forFields(durationFieldTypeArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Types array must not be null or empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period6.minusMillis((int) (byte) -1);
        org.joda.time.Days days9 = period6.toStandardDays();
        int int10 = period6.getWeeks();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(days9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        java.lang.String str37 = scaledDurationField33.toString();
        java.lang.String str38 = scaledDurationField33.toString();
        long long41 = scaledDurationField33.getDifferenceAsLong((long) 1, (long) (-25200000));
        int int44 = scaledDurationField33.getDifference((long) (short) 0, 1L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DurationField[hours]" + "'", str37.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "DurationField[hours]" + "'", str38.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(1);
        org.joda.time.Period period8 = period3.withSeconds((-1));
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.forFields(durationFieldTypeArray14);
        org.joda.time.chrono.ISOChronology iSOChronology16 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology18 = iSOChronology16.withZone(dateTimeZone17);
        org.joda.time.Period period19 = new org.joda.time.Period((java.lang.Object) period8, periodType15, (org.joda.time.Chronology) iSOChronology16);
        org.joda.time.ReadableDuration readableDuration21 = null;
        org.joda.time.ReadableInstant readableInstant22 = null;
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType24);
        org.joda.time.Period period26 = new org.joda.time.Period(readableDuration21, readableInstant22, periodType24);
        org.joda.time.Period period27 = new org.joda.time.Period((long) (byte) 10, periodType24);
        boolean boolean28 = iSOChronology16.equals((java.lang.Object) (byte) 10);
        org.joda.time.ReadablePartial readablePartial29 = null;
        try {
            int[] intArray31 = iSOChronology16.get(readablePartial29, (-53L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(iSOChronology16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(chronology18);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        try {
            org.joda.time.Period period7 = period5.withDays((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.Period period1 = org.joda.time.Period.years((int) (short) 1);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getName(locale1, "America/Los_Angeles", "ISOChronology[+52:00]");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("ISOChronology[+52:00]", "Coordinated Universal Time", (int) (byte) -1, 187200000);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("PT0H");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'PT0H' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.Period period1 = org.joda.time.Period.years((-97));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(1);
        int int7 = period3.getMinutes();
        int int8 = period3.getMonths();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DurationField durationField6 = gregorianChronology3.halfdays();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.clockhourOfHalfday();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant8, readableDuration9);
        org.joda.time.Period period12 = period10.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray13 = period10.getFieldTypes();
        long long16 = gregorianChronology3.add((org.joda.time.ReadablePeriod) period10, (long) (short) 0, 100);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology3.year();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(durationFieldTypeArray13);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        java.lang.String str39 = scaledDurationField33.toString();
        int int41 = scaledDurationField33.getValue((long) 187200000);
        long long43 = scaledDurationField33.getMillis((long) '#');
        long long46 = scaledDurationField33.getValueAsLong((long) 14, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[hours]" + "'", str39.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 5743365264000000L + "'", long43 == 5743365264000000L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(97L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay((double) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210858379200000L) + "'", long1 == (-210858379200000L));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getMaximumValue((long) 'a');
        try {
            long long21 = offsetDateTimeField16.set((long) 4, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfDay must be in the range [1,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86400000 + "'", int18 == 86400000);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test147");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
//        boolean boolean4 = dateTimeZone1.isStandardOffset((long) 97);
//        long long6 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
//        java.lang.Object obj8 = null;
//        boolean boolean9 = cachedDateTimeZone7.equals(obj8);
//        java.lang.String str11 = cachedDateTimeZone7.getNameKey(1560629169769L);
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-28799999L) + "'", long6 == (-28799999L));
//        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PDT" + "'", str11.equals("PDT"));
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 8);
        org.joda.time.ReadablePartial readablePartial19 = null;
        int[] intArray23 = new int[] { (short) 100, (short) -1 };
        try {
            int[] intArray25 = offsetDateTimeField16.addWrapField(readablePartial19, (int) (byte) -1, intArray23, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray23);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusWeeks(0);
        org.joda.time.MutablePeriod mutablePeriod5 = period2.toMutablePeriod();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(mutablePeriod5);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period(readableInstant2, readableDuration3);
        org.joda.time.Period period6 = period4.plusWeeks((-1));
        org.joda.time.chrono.ISOChronology iSOChronology7 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField8 = iSOChronology7.hours();
        boolean boolean9 = period4.equals((java.lang.Object) durationField8);
        java.lang.Object obj10 = null;
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType12 = periodType11.withYearsRemoved();
        org.joda.time.PeriodType periodType13 = periodType11.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        org.joda.time.DurationField durationField18 = gregorianChronology17.centuries();
        java.lang.Class<?> wildcardClass19 = durationField18.getClass();
        long long22 = durationField18.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType24);
        java.lang.String str26 = periodType24.getName();
        java.lang.String str27 = periodType24.getName();
        org.joda.time.Period period29 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant30 = null;
        org.joda.time.ReadableDuration readableDuration31 = null;
        org.joda.time.Period period32 = new org.joda.time.Period(readableInstant30, readableDuration31);
        org.joda.time.Period period34 = period32.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray35 = period32.getFieldTypes();
        org.joda.time.PeriodType periodType37 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period38 = new org.joda.time.Period((long) (short) -1, periodType37);
        org.joda.time.PeriodType periodType39 = periodType37.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType41 = periodType37.getFieldType((int) (short) 0);
        org.joda.time.Period period43 = period32.withFieldAdded(durationFieldType41, 0);
        int int44 = period29.get(durationFieldType41);
        int int45 = periodType24.indexOf(durationFieldType41);
        org.joda.time.field.ScaledDurationField scaledDurationField47 = new org.joda.time.field.ScaledDurationField(durationField18, durationFieldType41, (int) '4');
        int int48 = periodType13.indexOf(durationFieldType41);
        org.joda.time.Period period49 = new org.joda.time.Period(obj10, periodType13);
        org.joda.time.Period period50 = period4.withPeriodType(periodType13);
        org.joda.time.Period period51 = new org.joda.time.Period((long) '#', (long) 97, periodType13);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(iSOChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertNotNull(durationField18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 3155759999999L + "'", long22 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Hours" + "'", str26.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Hours" + "'", str27.equals("Hours"));
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertNotNull(period34);
        org.junit.Assert.assertNotNull(durationFieldTypeArray35);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(durationFieldType41);
        org.junit.Assert.assertNotNull(period43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(period50);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.seconds();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        try {
            org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder11 = dateTimeZoneBuilder0.addRecurringSavings("", (int) '4', (-1), (-1), '4', 1, (int) (short) 100, (int) (short) 0, false, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown mode: 4");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        java.lang.String str37 = scaledDurationField33.toString();
        long long40 = scaledDurationField33.add((long) '#', (long) 97);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DurationField[hours]" + "'", str37.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 15917326588800035L + "'", long40 == 15917326588800035L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(1);
        org.joda.time.Period period8 = period3.withMonths((int) (byte) 0);
        org.joda.time.Period period9 = period3.toPeriod();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period6.minusMillis((int) (byte) -1);
        org.joda.time.Period period10 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period11 = period6.plus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period10.plusMillis((int) (byte) 1);
        org.joda.time.Period period15 = period10.minusMinutes((int) (byte) 1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField7 = new org.joda.time.field.OffsetDateTimeField(dateTimeField4, dateTimeFieldType5, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.joda.time.Period period1 = org.joda.time.Period.hours(100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean11 = dateTimeZone8.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone12);
        try {
            long long21 = zonedChronology13.getDateTimeMillis(0, (-1008001785), (-25200000), (-1008001785), (int) '#', 0, 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1008001785 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekyear();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeFieldType dateTimeFieldType7 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField9 = new org.joda.time.field.RemainderDateTimeField(dateTimeField6, dateTimeFieldType7, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
//        java.lang.String str2 = iSOChronology0.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(durationField1);
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str2.equals("ISOChronology[America/Los_Angeles]"));
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(86400000, 52, (-28378000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        java.util.Locale locale24 = null;
        java.lang.String str25 = offsetDateTimeField16.getAsShortText(52, locale24);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "52" + "'", str25.equals("52"));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField2 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.millisOfSecond();
        org.joda.time.ReadablePartial readablePartial6 = null;
        try {
            int[] intArray8 = gregorianChronology3.get(readablePartial6, 164096150400000L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "DurationField[hours]", "1");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "1", "PT0H");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "PT0H", "PDT");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean11 = dateTimeZone8.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone12);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) '4', (-1L), chronology16);
        int[] intArray18 = period17.getValues();
        org.joda.time.Period period19 = period17.normalizedStandard();
        org.joda.time.Duration duration20 = period19.toStandardDuration();
        long long21 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration20);
        boolean boolean22 = zonedChronology13.equals((java.lang.Object) long21);
        try {
            long long30 = zonedChronology13.getDateTimeMillis((int) (short) 100, 100, 100, (int) (short) -1, (-1), (int) (byte) -1, 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(duration20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-53L) + "'", long21 == (-53L));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) ' ');
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period6.minusMillis((int) (byte) -1);
        org.joda.time.Period period10 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period11 = period6.plus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period10.plusMillis((int) (byte) 1);
        org.joda.time.Period period15 = period13.plusSeconds(97);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (byte) 10, periodType1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.format.PeriodFormatter periodFormatter1 = null;
        try {
            org.joda.time.Period period2 = org.joda.time.Period.parse("52", periodFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.DurationField durationField0 = org.joda.time.field.MillisDurationField.INSTANCE;
        long long3 = durationField0.subtract((long) (-1008001785), (long) (short) 0);
        org.junit.Assert.assertNotNull(durationField0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-1008001785L) + "'", long3 == (-1008001785L));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        boolean boolean4 = dateTimeZone1.isStandardOffset((long) 97);
        long long6 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        java.lang.String str9 = dateTimeZone1.getShortName((long) (byte) 0);
        java.lang.String str11 = dateTimeZone1.getName((long) 86400000);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-3599999L) + "'", long6 == (-3599999L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-01:00" + "'", str9.equals("-01:00"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "-01:00" + "'", str11.equals("-01:00"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period6.minusMillis((int) (byte) -1);
        org.joda.time.Period period10 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period11 = period6.plus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period10.minusHours(86400000);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = offsetDateTimeField16.getMinimumValue(readablePartial23);
        long long27 = offsetDateTimeField16.add(1640961504000000L, (-53L));
        org.joda.time.ReadablePartial readablePartial28 = null;
        org.joda.time.Chronology chronology32 = null;
        org.joda.time.Period period33 = new org.joda.time.Period((long) '4', (-1L), chronology32);
        int[] intArray34 = period33.getValues();
        org.joda.time.Period period36 = period33.minusDays((int) 'a');
        org.joda.time.Period period38 = period36.minusMillis((int) (byte) -1);
        org.joda.time.Period period40 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period41 = period36.plus((org.joda.time.ReadablePeriod) period40);
        int[] intArray42 = period40.getValues();
        java.util.Locale locale44 = null;
        try {
            int[] intArray45 = offsetDateTimeField16.set(readablePartial28, 4, intArray42, "+52:00", locale44);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"+52:00\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1640961503999947L + "'", long27 == 1640961503999947L);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(period38);
        org.junit.Assert.assertNotNull(period40);
        org.junit.Assert.assertNotNull(period41);
        org.junit.Assert.assertNotNull(intArray42);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        java.lang.String str5 = dateTimeZone2.getShortName((long) 10);
        java.lang.String str6 = dateTimeZone2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+52:00" + "'", str5.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "+52:00" + "'", str6.equals("+52:00"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 97, (java.lang.Number) 187200000, (java.lang.Number) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.Chronology chronology5 = org.joda.time.DateTimeUtils.getChronology((org.joda.time.Chronology) gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.clockhourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.ReadableInstant readableInstant5 = null;
        int int6 = dateTimeZone4.getOffset(readableInstant5);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 187200000 + "'", int6 == 187200000);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((int) (short) 0, (int) (short) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.hours();
        org.joda.time.Chronology chronology2 = iSOChronology0.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType0, 97, 97, 520);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("ISOChronology[+52:00]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[+52:00]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.lang.Number number3 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("", (java.lang.Number) (-3155759999989L), (java.lang.Number) (-3600000L), number3);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        boolean boolean5 = dateTimeZone1.isStandardOffset((long) (short) -1);
        long long7 = dateTimeZone1.convertUTCToLocal((long) (short) 0);
        java.util.Locale locale9 = null;
        java.lang.String str10 = dateTimeZone1.getShortName(1640961503999947L, locale9);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-3600000) + "'", int3 == (-3600000));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-3600000L) + "'", long7 == (-3600000L));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-01:00" + "'", str10.equals("-01:00"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType1 = periodType0.withMinutesRemoved();
        try {
            org.joda.time.Period period2 = new org.joda.time.Period((java.lang.Object) periodType1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.PeriodType");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField16.getMaximumTextLength(locale23);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField16.getAsShortText(10, locale26);
        org.joda.time.DurationField durationField28 = offsetDateTimeField16.getLeapDurationField();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "10" + "'", str27.equals("10"));
        org.junit.Assert.assertNull(durationField28);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = gregorianChronology7.centuries();
        org.joda.time.DurationField durationField9 = gregorianChronology7.years();
        org.joda.time.DurationField durationField10 = gregorianChronology7.halfdays();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (byte) -1, periodType1, (org.joda.time.Chronology) gregorianChronology7);
        try {
            org.joda.time.Period period13 = period11.withMonths(0);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = offsetDateTimeField16.getMinimumValue(readablePartial23);
        try {
            long long27 = offsetDateTimeField16.set(187200000L, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [1,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        java.lang.Object obj6 = new java.lang.Object();
        boolean boolean7 = periodType3.equals(obj6);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        int int6 = period5.getMonths();
        try {
            org.joda.time.Period period8 = period5.withMinutes((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant8, readableDuration9, periodType10);
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((-97), (int) (short) 0, (-1), (int) (short) 0, (int) ' ', (int) (short) 100, (int) ' ', (-25200000), periodType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'years'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType10);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        java.lang.String str6 = iSOChronology0.toString();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period((long) '4', (-1L), chronology9);
        int int11 = period10.getMonths();
        org.joda.time.Period period13 = period10.plusDays(1);
        org.joda.time.Period period15 = period10.withMonths((int) (byte) 0);
        int[] intArray17 = iSOChronology0.get((org.joda.time.ReadablePeriod) period15, (-3155759999989L));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[GregorianChronology[+52:00]]" + "'", str6.equals("ISOChronology[GregorianChronology[+52:00]]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(intArray17);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.hourOfHalfday();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = offsetDateTimeField16.getMinimumValue(readablePartial23);
        long long27 = offsetDateTimeField16.add(1640961504000000L, (-53L));
        int int29 = offsetDateTimeField16.get(97L);
        try {
            long long32 = offsetDateTimeField16.set((-28799999L), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfDay must be in the range [1,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1640961503999947L + "'", long27 == 1640961503999947L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 14400098 + "'", int29 == 14400098);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.ReadablePeriod readablePeriod6 = null;
        try {
            int[] intArray9 = lenientChronology5.get(readablePeriod6, (long) 4, 9L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField8 = gregorianChronology7.centuries();
        org.joda.time.DurationField durationField9 = gregorianChronology7.years();
        org.joda.time.DurationField durationField10 = gregorianChronology7.halfdays();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (byte) -1, periodType1, (org.joda.time.Chronology) gregorianChronology7);
        org.joda.time.Period period12 = period11.toPeriod();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType27 = periodType26.withYearsRemoved();
        org.joda.time.PeriodType periodType28 = periodType26.withHoursRemoved();
        org.joda.time.PeriodType periodType29 = periodType28.withMillisRemoved();
        org.joda.time.PeriodType periodType30 = periodType28.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.yearOfEra();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.secondOfMinute();
        org.joda.time.Period period37 = new org.joda.time.Period((long) 1, periodType28, (org.joda.time.Chronology) gregorianChronology34);
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology34.getZone();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology34.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int[] intArray46 = new int[] { 4, ' ', (byte) 1 };
        int int47 = offsetDateTimeField41.getMinimumValue(readablePartial42, intArray46);
        try {
            int[] intArray49 = offsetDateTimeField16.add(readablePartial23, 97, intArray46, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean11 = dateTimeZone8.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone12);
        org.joda.time.Period period15 = org.joda.time.Period.seconds((int) ' ');
        org.joda.time.Period period17 = period15.withMonths((-1));
        org.joda.time.Period period19 = period15.withMillis(0);
        org.joda.time.Days days20 = period15.toStandardDays();
        boolean boolean21 = zonedChronology13.equals((java.lang.Object) days20);
        try {
            long long29 = zonedChronology13.getDateTimeMillis(14, (int) (byte) 1, 14400098, (int) (short) 0, (int) (byte) 0, (int) 'a', (-28378000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertNotNull(days20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        java.util.TimeZone timeZone2 = dateTimeZone0.toTimeZone();
        try {
            org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forTimeZone(timeZone2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id 'GregorianChronology[+52:00]' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(timeZone2);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-100) + "'", int1 == (-100));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withHoursRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withYearsRemoved();
        try {
            org.joda.time.DurationFieldType durationFieldType6 = periodType4.getFieldType(0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology5.centuries();
        org.joda.time.DurationField durationField7 = gregorianChronology5.years();
        org.joda.time.DurationField durationField8 = gregorianChronology5.halfdays();
        org.joda.time.DateTimeField dateTimeField9 = gregorianChronology5.clockhourOfHalfday();
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period(readableInstant10, readableDuration11);
        org.joda.time.Period period14 = period12.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray15 = period12.getFieldTypes();
        long long18 = gregorianChronology5.add((org.joda.time.ReadablePeriod) period12, (long) (short) 0, 100);
        org.joda.time.Period period19 = new org.joda.time.Period(0L, (long) 86400000, (org.joda.time.Chronology) gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(dateTimeField9);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(durationFieldTypeArray15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000116d + "'", double1 == 2440587.500000116d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.Period period2 = new org.joda.time.Period(100L, 15917326588800035L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 187200000, (java.lang.Number) 52, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.joda.time.Period period1 = org.joda.time.Period.hours(0);
        int int2 = period1.getHours();
        java.lang.String str3 = period1.toString();
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PT0S" + "'", str3.equals("PT0S"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.yearOfEra();
        boolean boolean9 = period2.equals((java.lang.Object) gregorianChronology7);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology7.weekyear();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-1), (int) (byte) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) ' ', 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period5 = period3.normalizedStandard();
        org.joda.time.Duration duration6 = period5.toStandardDuration();
        org.joda.time.Period period8 = period5.withWeeks(0);
        org.joda.time.Period period10 = period5.withMonths(0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 8);
        int int20 = offsetDateTimeField16.getMinimumValue((-210858379200000L));
        java.util.Locale locale21 = null;
        int int22 = offsetDateTimeField16.getMaximumShortTextLength(locale21);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = offsetDateTimeField16.getMinimumValue(readablePartial23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int[] intArray28 = new int[] { (short) -1, (-25200000) };
        int int29 = offsetDateTimeField16.getMaximumValue(readablePartial25, intArray28);
        long long31 = offsetDateTimeField16.roundFloor(187200000L);
        org.joda.time.ReadablePartial readablePartial32 = null;
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology37 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone36);
        org.joda.time.DateTimeField dateTimeField38 = gregorianChronology37.monthOfYear();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology37.secondOfDay();
        org.joda.time.Chronology chronology40 = gregorianChronology37.withUTC();
        org.joda.time.DateTimeField dateTimeField41 = gregorianChronology37.era();
        org.joda.time.Chronology chronology44 = null;
        org.joda.time.Period period45 = new org.joda.time.Period((long) '4', (-1L), chronology44);
        int[] intArray47 = gregorianChronology37.get((org.joda.time.ReadablePeriod) period45, (long) 1);
        try {
            int[] intArray49 = offsetDateTimeField16.add(readablePartial32, 8, intArray47, (-28378000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 8");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86400000 + "'", int29 == 86400000);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 187200000L + "'", long31 == 187200000L);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(gregorianChronology37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(chronology40);
        org.junit.Assert.assertNotNull(dateTimeField41);
        org.junit.Assert.assertNotNull(intArray47);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withHoursRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMinutesRemoved();
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        java.lang.String str6 = periodType4.toString();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PeriodType[HoursNoHours]" + "'", str6.equals("PeriodType[HoursNoHours]"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-1));
        org.joda.time.DateTimeZone dateTimeZone5 = dateTimeZoneBuilder0.toDateTimeZone("", false);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "Coordinated Universal Time");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInstant0, readableInstant1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withHoursRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withMillisRemoved();
        try {
            org.joda.time.Period period6 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.yearOfEra();
        boolean boolean9 = period2.equals((java.lang.Object) gregorianChronology7);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType11 = periodType10.withYearsRemoved();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology14 = iSOChronology12.withZone(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology12.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology12.era();
        org.joda.time.chrono.LenientChronology lenientChronology17 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology12);
        java.lang.String str18 = lenientChronology17.toString();
        org.joda.time.Chronology chronology19 = lenientChronology17.withUTC();
        try {
            org.joda.time.Period period20 = new org.joda.time.Period((java.lang.Object) gregorianChronology7, periodType10, (org.joda.time.Chronology) lenientChronology17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.GregorianChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(chronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(lenientChronology17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "LenientChronology[ISOChronology[GregorianChronology[+52:00]]]" + "'", str18.equals("LenientChronology[ISOChronology[GregorianChronology[+52:00]]]"));
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(187200000, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Minutes out of range: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = period4.plusMillis((int) (short) 0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("", "DurationField[hours]");
        java.lang.Number number3 = illegalFieldValueException2.getIllegalNumberValue();
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        long long35 = scaledDurationField33.getMillis((int) (byte) 0);
        boolean boolean36 = scaledDurationField33.isSupported();
        long long39 = scaledDurationField33.getDifferenceAsLong((long) (short) 10, (long) 52);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) '4', (-1L), chronology10);
        int int12 = period11.getMonths();
        org.joda.time.Period period14 = period11.plusDays(1);
        org.joda.time.Period period16 = period11.withSeconds((-1));
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray22 = period19.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.forFields(durationFieldTypeArray22);
        org.joda.time.chrono.ISOChronology iSOChronology24 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology26 = iSOChronology24.withZone(dateTimeZone25);
        org.joda.time.Period period27 = new org.joda.time.Period((java.lang.Object) period16, periodType23, (org.joda.time.Chronology) iSOChronology24);
        org.joda.time.Period period28 = new org.joda.time.Period((-1008001785), (int) (short) 1, 8, (int) ' ', (int) (byte) 100, 187200000, 10, (int) (byte) 100, periodType23);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(durationFieldTypeArray22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(iSOChronology24);
        org.junit.Assert.assertNotNull(dateTimeZone25);
        org.junit.Assert.assertNotNull(chronology26);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = offsetDateTimeField16.getMinimumValue(readablePartial23);
        long long27 = offsetDateTimeField16.add(1640961504000000L, (-53L));
        int int29 = offsetDateTimeField16.get(97L);
        org.joda.time.ReadablePartial readablePartial30 = null;
        org.joda.time.PeriodType periodType33 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType34 = periodType33.withYearsRemoved();
        org.joda.time.PeriodType periodType35 = periodType33.withHoursRemoved();
        org.joda.time.PeriodType periodType36 = periodType35.withMillisRemoved();
        org.joda.time.PeriodType periodType37 = periodType35.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone40 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology41 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone40);
        org.joda.time.DateTimeField dateTimeField42 = gregorianChronology41.yearOfEra();
        org.joda.time.DateTimeField dateTimeField43 = gregorianChronology41.secondOfMinute();
        org.joda.time.Period period44 = new org.joda.time.Period((long) 1, periodType35, (org.joda.time.Chronology) gregorianChronology41);
        org.joda.time.DateTimeZone dateTimeZone45 = gregorianChronology41.getZone();
        org.joda.time.DateTimeField dateTimeField46 = gregorianChronology41.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField48 = new org.joda.time.field.OffsetDateTimeField(dateTimeField46, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial49 = null;
        int[] intArray53 = new int[] { 4, ' ', (byte) 1 };
        int int54 = offsetDateTimeField48.getMinimumValue(readablePartial49, intArray53);
        org.joda.time.ReadablePartial readablePartial55 = null;
        int int56 = offsetDateTimeField48.getMinimumValue(readablePartial55);
        org.joda.time.ReadablePartial readablePartial57 = null;
        int[] intArray60 = new int[] { (short) -1, (-25200000) };
        int int61 = offsetDateTimeField48.getMaximumValue(readablePartial57, intArray60);
        org.joda.time.ReadablePartial readablePartial62 = null;
        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology67 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone66);
        org.joda.time.DateTimeField dateTimeField68 = gregorianChronology67.monthOfYear();
        org.joda.time.DateTimeField dateTimeField69 = gregorianChronology67.secondOfDay();
        org.joda.time.Chronology chronology70 = gregorianChronology67.withUTC();
        org.joda.time.DateTimeField dateTimeField71 = gregorianChronology67.era();
        org.joda.time.Chronology chronology74 = null;
        org.joda.time.Period period75 = new org.joda.time.Period((long) '4', (-1L), chronology74);
        int[] intArray77 = gregorianChronology67.get((org.joda.time.ReadablePeriod) period75, (long) 1);
        int[] intArray79 = offsetDateTimeField48.add(readablePartial62, 0, intArray77, 0);
        try {
            int[] intArray81 = offsetDateTimeField16.addWrapField(readablePartial30, (int) '#', intArray77, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1640961503999947L + "'", long27 == 1640961503999947L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 14400098 + "'", int29 == 14400098);
        org.junit.Assert.assertNotNull(periodType33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(periodType37);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(gregorianChronology41);
        org.junit.Assert.assertNotNull(dateTimeField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTimeField46);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 86400000 + "'", int61 == 86400000);
        org.junit.Assert.assertNotNull(dateTimeZone66);
        org.junit.Assert.assertNotNull(gregorianChronology67);
        org.junit.Assert.assertNotNull(dateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertNotNull(chronology70);
        org.junit.Assert.assertNotNull(dateTimeField71);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray79);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean5 = dateTimeZone2.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        java.lang.String str8 = dateTimeZone6.getShortName(1L);
        long long10 = dateTimeZone6.convertUTCToLocal((long) 'a');
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "+52:00" + "'", str8.equals("+52:00"));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 187200097L + "'", long10 == 187200097L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = offsetDateTimeField16.getMinimumValue(readablePartial23);
        long long27 = offsetDateTimeField16.add(1640961504000000L, (-53L));
        int int29 = offsetDateTimeField16.get(97L);
        java.util.Locale locale32 = null;
        try {
            long long33 = offsetDateTimeField16.set((long) 8, "PT0H", locale32);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PT0H\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1640961503999947L + "'", long27 == 1640961503999947L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 14400098 + "'", int29 == 14400098);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-97) + "'", int1 == (-97));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        java.lang.String str37 = scaledDurationField33.toString();
        long long40 = scaledDurationField33.getMillis((long) (short) 1, (long) '4');
        long long42 = scaledDurationField33.getValueAsLong((long) 1);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology46 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone45);
        org.joda.time.DurationField durationField47 = gregorianChronology46.centuries();
        java.lang.Class<?> wildcardClass48 = durationField47.getClass();
        long long51 = durationField47.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType53 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period54 = new org.joda.time.Period((long) (short) -1, periodType53);
        java.lang.String str55 = periodType53.getName();
        java.lang.String str56 = periodType53.getName();
        org.joda.time.Period period58 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant59 = null;
        org.joda.time.ReadableDuration readableDuration60 = null;
        org.joda.time.Period period61 = new org.joda.time.Period(readableInstant59, readableDuration60);
        org.joda.time.Period period63 = period61.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray64 = period61.getFieldTypes();
        org.joda.time.PeriodType periodType66 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period67 = new org.joda.time.Period((long) (short) -1, periodType66);
        org.joda.time.PeriodType periodType68 = periodType66.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType70 = periodType66.getFieldType((int) (short) 0);
        org.joda.time.Period period72 = period61.withFieldAdded(durationFieldType70, 0);
        int int73 = period58.get(durationFieldType70);
        int int74 = periodType53.indexOf(durationFieldType70);
        org.joda.time.field.ScaledDurationField scaledDurationField76 = new org.joda.time.field.ScaledDurationField(durationField47, durationFieldType70, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology77 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField78 = iSOChronology77.hours();
        int int79 = scaledDurationField76.compareTo(durationField78);
        long long81 = scaledDurationField76.getValueAsLong((long) '#');
        java.lang.String str82 = scaledDurationField76.toString();
        int int83 = scaledDurationField33.compareTo((org.joda.time.DurationField) scaledDurationField76);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DurationField[hours]" + "'", str37.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 164096150400000L + "'", long40 == 164096150400000L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(gregorianChronology46);
        org.junit.Assert.assertNotNull(durationField47);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 3155759999999L + "'", long51 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType53);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "Hours" + "'", str55.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Hours" + "'", str56.equals("Hours"));
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertNotNull(period63);
        org.junit.Assert.assertNotNull(durationFieldTypeArray64);
        org.junit.Assert.assertNotNull(periodType66);
        org.junit.Assert.assertNotNull(periodType68);
        org.junit.Assert.assertNotNull(durationFieldType70);
        org.junit.Assert.assertNotNull(period72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(iSOChronology77);
        org.junit.Assert.assertNotNull(durationField78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1 + "'", int79 == 1);
        org.junit.Assert.assertTrue("'" + long81 + "' != '" + 0L + "'", long81 == 0L);
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "DurationField[hours]" + "'", str82.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(0L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDay();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetHours((-1));
        org.joda.time.ReadableInstant readableInstant2 = null;
        int int3 = dateTimeZone1.getOffset(readableInstant2);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1, (-100));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-3600000) + "'", int3 == (-3600000));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        try {
            int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((-1008001785L), (-28800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 29030451408000000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField5, 4, (-97), 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for secondOfDay must be in the range [-97,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        try {
            int int28 = unsupportedDurationField25.getValue(187199999L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1, (java.lang.Number) 0, (java.lang.Number) 10.0d);
        illegalFieldValueException4.prependMessage("Hours");
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.String str8 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str9 = illegalFieldValueException4.toString();
        illegalFieldValueException4.prependMessage("LenientChronology[ISOChronology[GregorianChronology[+52:00]]]");
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Hours: Value 1 for hi! must be in the range [0,10.0]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Hours: Value 1 for hi! must be in the range [0,10.0]"));
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.joda.time.IllegalFieldValueException: Hours: Value 1 for hi! must be in the range [0,10.0]" + "'", str9.equals("org.joda.time.IllegalFieldValueException: Hours: Value 1 for hi! must be in the range [0,10.0]"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType4);
        org.joda.time.PeriodType periodType7 = periodType4.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField12 = gregorianChronology11.centuries();
        org.joda.time.DurationField durationField13 = gregorianChronology11.years();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        boolean boolean19 = dateTimeZone16.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology11, dateTimeZone20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        org.joda.time.Chronology chronology27 = zonedChronology21.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.Period period28 = new org.joda.time.Period((-3155759999989L), periodType4, (org.joda.time.Chronology) zonedChronology21);
        org.joda.time.DateTimeZone dateTimeZone29 = zonedChronology21.getZone();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(0, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.PeriodType periodType5 = period4.getPeriodType();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) '4', (-1L), chronology8);
        int[] intArray10 = period9.getValues();
        org.joda.time.Period period12 = period9.minusDays((int) 'a');
        org.joda.time.Period period14 = period9.plusSeconds(0);
        int int15 = period9.getMonths();
        try {
            org.joda.time.Period period16 = period4.plus((org.joda.time.ReadablePeriod) period9);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.Period period4 = new org.joda.time.Period((int) ' ', (-25200000), 1, (int) (byte) 1);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 8);
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = offsetDateTimeField16.getType();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeFieldType19, (int) (byte) 0, (-1), (-1008001785));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfDay must be in the range [-1,-1008001785]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        java.util.TimeZone timeZone5 = fixedDateTimeZone4.toTimeZone();
        int int7 = fixedDateTimeZone4.getOffset((-100L));
        java.util.Locale locale9 = null;
        java.lang.String str10 = fixedDateTimeZone4.getShortName((-28378000L), locale9);
        org.junit.Assert.assertNotNull(timeZone5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-3600000) + "'", int7 == (-3600000));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-01:00" + "'", str10.equals("-01:00"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        java.lang.Object obj1 = null;
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) provider0, obj1);
        org.joda.time.DateTimeZone.setProvider(provider0);
        org.junit.Assert.assertNotNull(provider0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.joda.time.chrono.LenientChronology lenientChronology5 = org.joda.time.chrono.LenientChronology.getInstance((org.joda.time.Chronology) iSOChronology0);
        org.joda.time.Chronology chronology6 = lenientChronology5.withUTC();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(lenientChronology5);
        org.junit.Assert.assertNotNull(chronology6);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.weeks();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 8);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField16.getAsShortText(0L, locale20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField16.getAsShortText((long) 0, locale23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.monthOfYear();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.secondOfDay();
        org.joda.time.Chronology chronology33 = gregorianChronology30.withUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology30.era();
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) '4', (-1L), chronology37);
        int[] intArray40 = gregorianChronology30.get((org.joda.time.ReadablePeriod) period38, (long) 1);
        try {
            int[] intArray42 = offsetDateTimeField16.addWrapPartial(readablePartial25, 10800001, intArray40, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10800001");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "14400001" + "'", str21.equals("14400001"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "14400001" + "'", str24.equals("14400001"));
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        java.lang.String str37 = scaledDurationField33.toString();
        java.lang.String str38 = scaledDurationField33.toString();
        long long41 = scaledDurationField33.getDifferenceAsLong((long) 1, (long) (-25200000));
        java.lang.String str42 = scaledDurationField33.toString();
        boolean boolean44 = scaledDurationField33.equals((java.lang.Object) "");
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DurationField[hours]" + "'", str37.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "DurationField[hours]" + "'", str38.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "DurationField[hours]" + "'", str42.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((-25200000));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        java.util.Locale locale18 = null;
        try {
            java.lang.String str19 = offsetDateTimeField16.getAsText(readablePartial17, locale18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1, (java.lang.Number) 0, (java.lang.Number) 10.0d);
        illegalFieldValueException4.prependMessage("Hours");
        java.lang.Throwable[] throwableArray7 = illegalFieldValueException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        try {
            long long12 = gregorianChronology3.getDateTimeMillis(520, (int) (byte) 0, 4, 0, 52, 86400000, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86400000 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval0);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.Period period1 = org.joda.time.Period.seconds(8);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        org.joda.time.DurationFieldType durationFieldType26 = unsupportedDurationField25.getType();
        try {
            long long29 = unsupportedDurationField25.getDifferenceAsLong((long) 187200000, (long) 10800001);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertNotNull(durationFieldType26);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean11 = dateTimeZone8.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone12);
        java.lang.String str14 = dateTimeZone12.getID();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "+52:00" + "'", str14.equals("+52:00"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean11 = dateTimeZone8.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone12);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        org.joda.time.Chronology chronology19 = zonedChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        try {
            long long27 = zonedChronology13.getDateTimeMillis(9, (int) '4', (int) (byte) 1, (int) (byte) 100, 8, (int) ' ', 97);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(chronology19);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        long long35 = scaledDurationField33.getMillis((int) (byte) 0);
        boolean boolean36 = scaledDurationField33.isSupported();
        java.lang.Object obj37 = null;
        boolean boolean38 = scaledDurationField33.equals(obj37);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', (-1L), chronology4);
        int[] intArray6 = period5.getValues();
        org.joda.time.Period period7 = period5.normalizedStandard();
        org.joda.time.Duration duration8 = period7.toStandardDuration();
        long long9 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        org.joda.time.PeriodType periodType10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration8, periodType10);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration8, readableInstant12);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period(readableInstant14, readableDuration15, periodType16);
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8, periodType16);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-53L) + "'", long9 == (-53L));
        org.junit.Assert.assertNotNull(periodType16);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = offsetDateTimeField16.getMinimumValue(readablePartial23);
        long long27 = offsetDateTimeField16.add(1640961504000000L, (-53L));
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField16, (int) '4', 9, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for millisOfDay must be in the range [9,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1640961503999947L + "'", long27 == 1640961503999947L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 8);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField16.getAsShortText(0L, locale20);
        long long24 = offsetDateTimeField16.getDifferenceAsLong((long) 1, 1560629169769L);
        org.joda.time.ReadablePartial readablePartial25 = null;
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology30 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone29);
        org.joda.time.DateTimeField dateTimeField31 = gregorianChronology30.monthOfYear();
        org.joda.time.DateTimeField dateTimeField32 = gregorianChronology30.secondOfDay();
        org.joda.time.Chronology chronology33 = gregorianChronology30.withUTC();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology30.era();
        org.joda.time.Chronology chronology37 = null;
        org.joda.time.Period period38 = new org.joda.time.Period((long) '4', (-1L), chronology37);
        int[] intArray40 = gregorianChronology30.get((org.joda.time.ReadablePeriod) period38, (long) 1);
        try {
            int[] intArray42 = offsetDateTimeField16.add(readablePartial25, 86400000, intArray40, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 86400000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "14400001" + "'", str21.equals("14400001"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1560629169768L) + "'", long24 == (-1560629169768L));
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(gregorianChronology30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeField32);
        org.junit.Assert.assertNotNull(chronology33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(intArray40);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1, (java.lang.Number) 0, (java.lang.Number) 10.0d);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.String str6 = illegalFieldValueException4.getIllegalStringValue();
        java.lang.String str7 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType4);
        org.joda.time.PeriodType periodType7 = periodType4.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField12 = gregorianChronology11.centuries();
        org.joda.time.DurationField durationField13 = gregorianChronology11.years();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        boolean boolean19 = dateTimeZone16.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology11, dateTimeZone20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        org.joda.time.Chronology chronology27 = zonedChronology21.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.Period period28 = new org.joda.time.Period((-3155759999989L), periodType4, (org.joda.time.Chronology) zonedChronology21);
        java.lang.String str29 = zonedChronology21.toString();
        org.joda.time.DateTimeField dateTimeField30 = zonedChronology21.halfdayOfDay();
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ZonedChronology[GregorianChronology[UTC], +52:00]" + "'", str29.equals("ZonedChronology[GregorianChronology[UTC], +52:00]"));
        org.junit.Assert.assertNotNull(dateTimeField30);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        java.lang.String str26 = unsupportedDurationField25.toString();
        try {
            long long29 = unsupportedDurationField25.getMillis((-100L), (long) 97);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDurationField[hours]" + "'", str26.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((long) 187200000, 187200000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35043840000000000L + "'", long2 == 35043840000000000L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        try {
            long long28 = unsupportedDurationField25.getDifferenceAsLong((long) (byte) -1, 3155759999999L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.Period period2 = new org.joda.time.Period((long) (byte) 100, (-53L));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period5 = period3.normalizedStandard();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((long) '4', (-1L), chronology8);
        int[] intArray10 = period9.getValues();
        org.joda.time.Period period12 = period9.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology16 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone15);
        org.joda.time.DateTimeField dateTimeField17 = gregorianChronology16.monthOfYear();
        org.joda.time.DateTimeField dateTimeField18 = gregorianChronology16.secondOfDay();
        boolean boolean19 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period12, (java.lang.Object) dateTimeField18);
        org.joda.time.Period period20 = period5.minus((org.joda.time.ReadablePeriod) period12);
        org.joda.time.Period period21 = period5.negated();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(gregorianChronology16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeField18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period21);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.DateTimeZone dateTimeZone3 = dateTimeZoneBuilder0.toDateTimeZone("org.joda.time.IllegalFieldValueException: Hours: Value 1 for hi! must be in the range [0,10.0]", true);
        java.io.OutputStream outputStream5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("Coordinated Universal Time", outputStream5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.PeriodType periodType3 = periodType1.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType5 = periodType1.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException9 = new org.joda.time.IllegalFieldValueException(durationFieldType5, (java.lang.Number) 1560629169769L, (java.lang.Number) (-210858379200000L), (java.lang.Number) (-1.0f));
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(durationFieldType5);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 8);
        int int20 = offsetDateTimeField16.getMinimumValue((-210858379200000L));
        long long22 = offsetDateTimeField16.roundHalfEven((long) (-100));
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType27 = periodType26.withYearsRemoved();
        org.joda.time.PeriodType periodType28 = periodType26.withHoursRemoved();
        org.joda.time.PeriodType periodType29 = periodType28.withMillisRemoved();
        org.joda.time.PeriodType periodType30 = periodType28.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
        org.joda.time.DateTimeField dateTimeField35 = gregorianChronology34.yearOfEra();
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology34.secondOfMinute();
        org.joda.time.Period period37 = new org.joda.time.Period((long) 1, periodType28, (org.joda.time.Chronology) gregorianChronology34);
        org.joda.time.DateTimeZone dateTimeZone38 = gregorianChronology34.getZone();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology34.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField41 = new org.joda.time.field.OffsetDateTimeField(dateTimeField39, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial42 = null;
        int[] intArray46 = new int[] { 4, ' ', (byte) 1 };
        int int47 = offsetDateTimeField41.getMinimumValue(readablePartial42, intArray46);
        org.joda.time.ReadablePartial readablePartial48 = null;
        int int49 = offsetDateTimeField41.getMinimumValue(readablePartial48);
        org.joda.time.ReadablePartial readablePartial50 = null;
        int[] intArray53 = new int[] { (short) -1, (-25200000) };
        int int54 = offsetDateTimeField41.getMaximumValue(readablePartial50, intArray53);
        org.joda.time.ReadablePartial readablePartial55 = null;
        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology60 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone59);
        org.joda.time.DateTimeField dateTimeField61 = gregorianChronology60.monthOfYear();
        org.joda.time.DateTimeField dateTimeField62 = gregorianChronology60.secondOfDay();
        org.joda.time.Chronology chronology63 = gregorianChronology60.withUTC();
        org.joda.time.DateTimeField dateTimeField64 = gregorianChronology60.era();
        org.joda.time.Chronology chronology67 = null;
        org.joda.time.Period period68 = new org.joda.time.Period((long) '4', (-1L), chronology67);
        int[] intArray70 = gregorianChronology60.get((org.joda.time.ReadablePeriod) period68, (long) 1);
        int[] intArray72 = offsetDateTimeField41.add(readablePartial55, 0, intArray70, 0);
        try {
            int[] intArray74 = offsetDateTimeField16.addWrapField(readablePartial23, 10800001, intArray70, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10800001");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-100L) + "'", long22 == (-100L));
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType30);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertNotNull(dateTimeField35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1 + "'", int47 == 1);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 86400000 + "'", int54 == 86400000);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(gregorianChronology60);
        org.junit.Assert.assertNotNull(dateTimeField61);
        org.junit.Assert.assertNotNull(dateTimeField62);
        org.junit.Assert.assertNotNull(chronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray72);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(187200000);
        org.joda.time.Period period3 = period1.withMonths(1);
        org.joda.time.PeriodType periodType5 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period6 = new org.joda.time.Period((long) (short) -1, periodType5);
        java.lang.String str7 = periodType5.getName();
        java.lang.String str8 = periodType5.getName();
        org.joda.time.Period period10 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.Period period13 = new org.joda.time.Period(readableInstant11, readableDuration12);
        org.joda.time.Period period15 = period13.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray16 = period13.getFieldTypes();
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period19 = new org.joda.time.Period((long) (short) -1, periodType18);
        org.joda.time.PeriodType periodType20 = periodType18.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType22 = periodType18.getFieldType((int) (short) 0);
        org.joda.time.Period period24 = period13.withFieldAdded(durationFieldType22, 0);
        int int25 = period10.get(durationFieldType22);
        int int26 = periodType5.indexOf(durationFieldType22);
        org.joda.time.IllegalFieldValueException illegalFieldValueException28 = new org.joda.time.IllegalFieldValueException(durationFieldType22, "PT0H");
        int int29 = period3.get(durationFieldType22);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Hours" + "'", str7.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Hours" + "'", str8.equals("Hours"));
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(durationFieldTypeArray16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(durationFieldType22);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.Chronology chronology3 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.era();
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfDay();
        java.lang.String str6 = iSOChronology0.toString();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[GregorianChronology[+52:00]]" + "'", str6.equals("ISOChronology[GregorianChronology[+52:00]]"));
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.Period period4 = new org.joda.time.Period((-28378000), 86400000, (int) ' ', 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period3.plusSeconds(0);
        org.joda.time.Period period9 = period8.toPeriod();
        org.joda.time.Period period11 = period9.minusMonths((int) (byte) 10);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        org.joda.time.PeriodType periodType6 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType7 = periodType6.withMinutesRemoved();
        org.joda.time.DurationFieldType durationFieldType8 = null;
        int int9 = periodType6.indexOf(durationFieldType8);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField14, 0, 97, 520);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for millisOfDay must be in the range [97,520]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        try {
            org.joda.time.Period period1 = org.joda.time.Period.parse("PeriodType[HoursNoHours]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"PeriodType[HoursNoHours]\" is malformed at \"eriodType[HoursNoHours]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField16.getMaximumTextLength(locale23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int[] intArray27 = null;
        java.util.Locale locale29 = null;
        try {
            int[] intArray30 = offsetDateTimeField16.set(readablePartial25, 52, intArray27, "Hours", locale29);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"Hours\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        org.joda.time.Period period6 = org.joda.time.Period.weeks(0);
        boolean boolean7 = fixedDateTimeZone4.equals((java.lang.Object) period6);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology10 = iSOChronology8.withZone(dateTimeZone9);
        org.joda.time.Chronology chronology11 = iSOChronology8.withUTC();
        try {
            org.joda.time.Period period12 = new org.joda.time.Period((java.lang.Object) boolean7, chronology11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Boolean");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(chronology10);
        org.junit.Assert.assertNotNull(chronology11);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.Period period2 = new org.joda.time.Period(187200001L, (long) (byte) 10);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("LenientChronology[ISOChronology[GregorianChronology[+52:00]]]");
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        boolean boolean5 = dateTimeZone2.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        long long8 = dateTimeZone6.convertUTCToLocal((long) (short) 1);
        java.util.TimeZone timeZone9 = dateTimeZone6.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forTimeZone(timeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 187200001L + "'", long8 == 187200001L);
        org.junit.Assert.assertNotNull(timeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(1);
        org.joda.time.Period period8 = period3.withMonths((int) (byte) 0);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PT-0.053S" + "'", str10.equals("PT-0.053S"));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField16.getMaximumTextLength(locale23);
        long long26 = offsetDateTimeField16.roundHalfCeiling((long) 520);
        long long28 = offsetDateTimeField16.roundHalfCeiling(100L);
        int int29 = offsetDateTimeField16.getMinimumValue();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 520L + "'", long26 == 520L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(520, 10800001);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10800521 + "'", int2 == 10800521);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        java.lang.String str5 = dateTimeZone2.getShortName((long) 10);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2, 14400098);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 14400098");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "+52:00" + "'", str5.equals("+52:00"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period6.minusMillis((int) (byte) -1);
        org.joda.time.Days days9 = period6.toStandardDays();
        org.joda.time.Period period11 = period6.multipliedBy((int) (byte) -1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(days9);
        org.junit.Assert.assertNotNull(period11);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        try {
            org.joda.time.Period period4 = new org.joda.time.Period((java.lang.Object) dateTimeField3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ZonedChronology$ZonedDateTimeField");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 52);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period3.plusSeconds(0);
        org.joda.time.Period period9 = period8.toPeriod();
        org.joda.time.Period period11 = period8.plusMillis((int) 'a');
        org.joda.time.Hours hours12 = period8.toStandardHours();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(hours12);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.Period period1 = org.joda.time.Period.weeks((int) '4');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekyear();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.centuryOfEra();
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField9 = iSOChronology8.days();
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology8.millisOfDay();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period((long) '4', (-1L), chronology13);
        int[] intArray15 = period14.getValues();
        org.joda.time.Period period17 = period14.minusDays((int) 'a');
        org.joda.time.Period period19 = period14.plusSeconds(0);
        boolean boolean20 = iSOChronology8.equals((java.lang.Object) period14);
        org.joda.time.DateTimeField dateTimeField21 = iSOChronology8.yearOfEra();
        boolean boolean22 = gregorianChronology3.equals((java.lang.Object) dateTimeField21);
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField21, (int) 'a', 10, 52);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for yearOfEra must be in the range [10,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withHoursRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withMillisRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.yearOfEra();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.secondOfMinute();
        org.joda.time.Period period13 = new org.joda.time.Period((long) 1, periodType4, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology10.getZone();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology10.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) 1);
        int int19 = offsetDateTimeField17.getLeapAmount((long) 8);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField17.getType();
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField21 = new org.joda.time.field.ZeroIsMaxDateTimeField(dateTimeField0, dateTimeFieldType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period3.withYears(0);
        org.joda.time.MutablePeriod mutablePeriod9 = period8.toMutablePeriod();
        org.joda.time.Seconds seconds10 = period8.toStandardSeconds();
        org.joda.time.Period period12 = period8.withDays(86400000);
        org.joda.time.DurationFieldType durationFieldType13 = null;
        int int14 = period8.get(durationFieldType13);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableInstant readableInstant19 = null;
        org.joda.time.PeriodType periodType21 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period22 = new org.joda.time.Period((long) (short) -1, periodType21);
        org.joda.time.Period period23 = new org.joda.time.Period(readableInstant18, readableInstant19, periodType21);
        org.joda.time.PeriodType periodType24 = periodType21.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.DurationField durationField29 = gregorianChronology28.centuries();
        org.joda.time.DurationField durationField30 = gregorianChronology28.years();
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology34 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone33);
        boolean boolean36 = dateTimeZone33.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeUtils.getZone(dateTimeZone33);
        org.joda.time.chrono.ZonedChronology zonedChronology38 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology28, dateTimeZone37);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone43 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        org.joda.time.Chronology chronology44 = zonedChronology38.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone43);
        org.joda.time.Period period45 = new org.joda.time.Period((-3155759999989L), periodType21, (org.joda.time.Chronology) zonedChronology38);
        java.lang.String str46 = zonedChronology38.toString();
        org.joda.time.Period period47 = new org.joda.time.Period((-28799999L), (long) (short) 0, (org.joda.time.Chronology) zonedChronology38);
        try {
            org.joda.time.Period period48 = new org.joda.time.Period((java.lang.Object) int14, (org.joda.time.Chronology) zonedChronology38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(mutablePeriod9);
        org.junit.Assert.assertNotNull(seconds10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(durationField29);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(gregorianChronology34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(zonedChronology38);
        org.junit.Assert.assertNotNull(chronology44);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "ZonedChronology[GregorianChronology[UTC], +52:00]" + "'", str46.equals("ZonedChronology[GregorianChronology[UTC], +52:00]"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.months();
        org.junit.Assert.assertNotNull(periodType0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfDay();
        org.joda.time.Chronology chronology6 = gregorianChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.dayOfWeek();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder2 = dateTimeZoneBuilder0.setStandardOffset((-1));
        java.io.DataOutput dataOutput4 = null;
        try {
            dateTimeZoneBuilder2.writeTo("LenientChronology[ISOChronology[GregorianChronology[+52:00]]]", dataOutput4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 1, 9L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8L) + "'", long2 == (-8L));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        java.lang.String str39 = scaledDurationField33.toString();
        int int41 = scaledDurationField33.getValue((long) 187200000);
        long long43 = scaledDurationField33.getMillis((long) '#');
        int int44 = scaledDurationField33.getScalar();
        int int45 = scaledDurationField33.getScalar();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[hours]" + "'", str39.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 5743365264000000L + "'", long43 == 5743365264000000L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 52 + "'", int44 == 52);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 52 + "'", int45 == 52);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        int int4 = dateTimeZone2.getOffset(readableInstant3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long9 = iSOChronology5.add((long) 97, (long) '#', 14);
        org.joda.time.DateTimeField dateTimeField10 = iSOChronology5.dayOfWeek();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 187200000 + "'", int4 == 187200000);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 587L + "'", long9 == 587L);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) (short) 1, (long) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        java.lang.String str37 = scaledDurationField33.toString();
        java.lang.String str38 = scaledDurationField33.toString();
        long long39 = scaledDurationField33.getUnitMillis();
        int int42 = scaledDurationField33.getValue((long) 10, (long) (-53));
        long long44 = scaledDurationField33.getMillis(0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DurationField[hours]" + "'", str37.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "DurationField[hours]" + "'", str38.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 164096150400000L + "'", long39 == 164096150400000L);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.millisOfDay();
        boolean boolean4 = iSOChronology0.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        try {
            org.joda.time.Period period7 = period5.withWeeks(52);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 8);
        int int20 = offsetDateTimeField16.getMinimumValue((-210858379200000L));
        org.joda.time.ReadablePartial readablePartial21 = null;
        int[] intArray23 = null;
        try {
            int[] intArray25 = offsetDateTimeField16.set(readablePartial21, 86400000, intArray23, (-100));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -100 for millisOfDay must be in the range [1,86400000]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.DateTimeUtils.setCurrentMillisOffset((long) (-100));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getMaximumValue((long) 'a');
        int int20 = offsetDateTimeField16.get((long) (-3600000));
        long long22 = offsetDateTimeField16.roundHalfEven((long) (short) -1);
        java.lang.String str23 = offsetDateTimeField16.toString();
        try {
            long long26 = offsetDateTimeField16.set((-210816043200000L), "PeriodType[HoursNoHours]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PeriodType[HoursNoHours]\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86400000 + "'", int18 == 86400000);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10800001 + "'", int20 == 10800001);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "DateTimeField[millisOfDay]" + "'", str23.equals("DateTimeField[millisOfDay]"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.Period period1 = org.joda.time.Period.millis(520);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period((long) '4', (-1L), chronology4);
        int[] intArray6 = period5.getValues();
        org.joda.time.Period period7 = period5.normalizedStandard();
        org.joda.time.Duration duration8 = period7.toStandardDuration();
        long long9 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        org.joda.time.ReadableDuration readableDuration11 = null;
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.Period period15 = new org.joda.time.Period(readableDuration11, readableInstant12, periodType13);
        org.joda.time.PeriodType periodType16 = period15.getPeriodType();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period((long) 100, periodType16, chronology17);
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant1, (org.joda.time.ReadableDuration) duration8, periodType16);
        long long20 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration8);
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration8);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(duration8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-53L) + "'", long9 == (-53L));
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-53L) + "'", long20 == (-53L));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt((long) 8, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 800 + "'", int2 == 800);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.ReadableInstant readableInstant3 = null;
        int int4 = dateTimeZone2.getOffset(readableInstant3);
        org.joda.time.chrono.ISOChronology iSOChronology5 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone2);
        long long9 = iSOChronology5.add((long) 97, (long) '#', 14);
        java.lang.String str10 = iSOChronology5.toString();
        org.joda.time.DateTimeField dateTimeField11 = iSOChronology5.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 187200000 + "'", int4 == 187200000);
        org.junit.Assert.assertNotNull(iSOChronology5);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 587L + "'", long9 == 587L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ISOChronology[+52:00]" + "'", str10.equals("ISOChronology[+52:00]"));
        org.junit.Assert.assertNotNull(dateTimeField11);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        long long40 = scaledDurationField33.getValueAsLong((long) ' ');
        long long42 = scaledDurationField33.getMillis(10);
        boolean boolean43 = scaledDurationField33.isSupported();
        try {
            long long45 = scaledDurationField33.getMillis(14400098);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 748805096 * 3155695200000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1640961504000000L + "'", long42 == 1640961504000000L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        boolean boolean2 = org.joda.time.field.FieldUtils.equals((java.lang.Object) (-1), (java.lang.Object) 1.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(14, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14 + "'", int2 == 14);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("org.joda.time.IllegalFieldValueException: Hours: Value 1 for hi! must be in the range [0,10.0]", (int) '4');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((-25200000));
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long39 = scaledDurationField33.getValueAsLong((long) ' ', (long) 1);
        long long41 = scaledDurationField33.getValueAsLong(0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((-53L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-53L) + "'", long2 == (-53L));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        java.lang.String str26 = unsupportedDurationField25.toString();
        try {
            long long29 = unsupportedDurationField25.getDifferenceAsLong(10L, (-28800000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDurationField[hours]" + "'", str26.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        boolean boolean4 = dateTimeZone1.isStandardOffset((long) 97);
        long long6 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getOffset(1560629155109L);
        boolean boolean10 = cachedDateTimeZone7.isFixed();
        long long12 = cachedDateTimeZone7.nextTransition((-3600000L));
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology15 = iSOChronology13.withZone(dateTimeZone14);
        boolean boolean17 = dateTimeZone14.isStandardOffset((long) 97);
        long long19 = dateTimeZone14.convertUTCToLocal((long) (byte) 1);
        long long21 = cachedDateTimeZone7.getMillisKeepLocal(dateTimeZone14, (long) 86400000);
        int int23 = cachedDateTimeZone7.getStandardOffset(60L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-3599999L) + "'", long6 == (-3599999L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3600000) + "'", int9 == (-3600000));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-3600000L) + "'", long12 == (-3600000L));
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-3599999L) + "'", long19 == (-3599999L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 86400000L + "'", long21 == 86400000L);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 520 + "'", int23 == 520);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.Period period8 = new org.joda.time.Period(97, (int) (byte) 10, 0, (int) (byte) 10, 0, 4, (int) (byte) 100, 520);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        java.lang.String str39 = scaledDurationField33.toString();
        int int41 = scaledDurationField33.getValue((long) 187200000);
        long long43 = scaledDurationField33.getMillis((long) '#');
        int int44 = scaledDurationField33.getScalar();
        int int47 = scaledDurationField33.getValue(1640961503999947L, 164096150400000L);
        long long50 = scaledDurationField33.getMillis(520, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[hours]" + "'", str39.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 5743365264000000L + "'", long43 == 5743365264000000L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 52 + "'", int44 == 52);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 9 + "'", int47 == 9);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 85329998208000000L + "'", long50 == 85329998208000000L);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("PeriodType[HoursNoHours]", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"PeriodType[HoursNoHours]/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.Period period2 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant3, readableDuration4);
        org.joda.time.Period period7 = period5.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray8 = period5.getFieldTypes();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        org.joda.time.PeriodType periodType12 = periodType10.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType14 = periodType10.getFieldType((int) (short) 0);
        org.joda.time.Period period16 = period5.withFieldAdded(durationFieldType14, 0);
        int int17 = period2.get(durationFieldType14);
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField18 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(period2);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(durationFieldTypeArray8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(durationFieldType14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.PeriodType periodType5 = period4.getPeriodType();
        int int6 = period4.getYears();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.centuryOfEra();
        org.joda.time.DateTimeField dateTimeField4 = iSOChronology0.hourOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(dateTimeField3);
        org.junit.Assert.assertNotNull(dateTimeField4);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        java.lang.String str39 = scaledDurationField33.toString();
        org.joda.time.DurationField durationField40 = scaledDurationField33.getWrappedField();
        int int43 = scaledDurationField33.getValue((-28799999L), (-210865982400000L));
        long long45 = scaledDurationField33.getValueAsLong(0L);
        try {
            long long48 = scaledDurationField33.getMillis(1560629155109L, 85329998208000000L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 8115271606566800");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[hours]" + "'", str39.equals("DurationField[hours]"));
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean11 = dateTimeZone8.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone12);
        try {
            long long19 = zonedChronology13.getDateTimeMillis(587L, (-1), (int) (short) 0, 10800521, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed(10800001L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = offsetDateTimeField16.getMinimumValue(readablePartial23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int[] intArray28 = new int[] { (short) -1, (-25200000) };
        int int29 = offsetDateTimeField16.getMaximumValue(readablePartial25, intArray28);
        org.joda.time.ReadablePartial readablePartial30 = null;
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology35 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone34);
        org.joda.time.DateTimeField dateTimeField36 = gregorianChronology35.monthOfYear();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology35.secondOfDay();
        org.joda.time.Chronology chronology38 = gregorianChronology35.withUTC();
        org.joda.time.DateTimeField dateTimeField39 = gregorianChronology35.era();
        org.joda.time.Chronology chronology42 = null;
        org.joda.time.Period period43 = new org.joda.time.Period((long) '4', (-1L), chronology42);
        int[] intArray45 = gregorianChronology35.get((org.joda.time.ReadablePeriod) period43, (long) 1);
        int[] intArray47 = offsetDateTimeField16.add(readablePartial30, 0, intArray45, 0);
        long long49 = offsetDateTimeField16.roundHalfCeiling(587L);
        java.util.Locale locale51 = null;
        java.lang.String str52 = offsetDateTimeField16.getAsShortText((long) (byte) -1, locale51);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86400000 + "'", int29 == 86400000);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(gregorianChronology35);
        org.junit.Assert.assertNotNull(dateTimeField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(chronology38);
        org.junit.Assert.assertNotNull(dateTimeField39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 587L + "'", long49 == 587L);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "14400000" + "'", str52.equals("14400000"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1, (java.lang.Number) 0, (java.lang.Number) 10.0d);
        illegalFieldValueException4.prependMessage("Hours");
        java.lang.String str7 = illegalFieldValueException4.toString();
        java.lang.Throwable[] throwableArray8 = illegalFieldValueException4.getSuppressed();
        java.lang.Number number9 = illegalFieldValueException4.getIllegalNumberValue();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.joda.time.IllegalFieldValueException: Hours: Value 1 for hi! must be in the range [0,10.0]" + "'", str7.equals("org.joda.time.IllegalFieldValueException: Hours: Value 1 for hi! must be in the range [0,10.0]"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1 + "'", number9.equals(1));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DurationField durationField14 = gregorianChronology9.millis();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        java.lang.String str37 = scaledDurationField33.toString();
        long long40 = scaledDurationField33.getMillis((long) (short) 1, (long) '4');
        int int41 = scaledDurationField33.getScalar();
        long long44 = scaledDurationField33.getMillis(100, 587L);
        long long47 = scaledDurationField33.add(3155759999999L, 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DurationField[hours]" + "'", str37.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 164096150400000L + "'", long40 == 164096150400000L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 52 + "'", int41 == 52);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 16409615040000000L + "'", long44 == 16409615040000000L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 3155759999999L + "'", long47 == 3155759999999L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.ReadablePartial readablePartial0 = null;
        org.joda.time.ReadablePartial readablePartial1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.yearWeekDayTime();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(readablePartial0, readablePartial1, periodType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: ReadablePartial objects must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        java.lang.String str26 = unsupportedDurationField25.toString();
        try {
            int int29 = unsupportedDurationField25.getDifference(0L, 1560629169769L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDurationField[hours]" + "'", str26.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.Period period1 = org.joda.time.Period.millis((int) '4');
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withYearsRemoved();
        org.joda.time.PeriodType periodType2 = periodType0.withHoursRemoved();
        org.joda.time.PeriodType periodType3 = periodType2.withMillisRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMinutesRemoved();
        org.joda.time.PeriodType periodType5 = org.joda.time.DateTimeUtils.getPeriodType(periodType4);
        org.joda.time.PeriodType periodType6 = periodType5.withMillisRemoved();
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber(3155759999999L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2477112L + "'", long1 == 2477112L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.Period period1 = org.joda.time.Period.days(0);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period5 = period3.normalizedStandard();
        org.joda.time.Duration duration6 = period5.toStandardDuration();
        org.joda.time.Period period8 = period5.withWeeks(0);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(durationFieldType27, "PT0H");
        org.joda.time.Period period35 = period5.withFieldAdded(durationFieldType27, (-1));
        try {
            org.joda.time.Period period36 = new org.joda.time.Period((java.lang.Object) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Integer");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(period35);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.Period period1 = org.joda.time.Period.millis(100);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        org.joda.time.DurationFieldType durationFieldType26 = unsupportedDurationField25.getType();
        try {
            long long28 = unsupportedDurationField25.getValueAsLong((long) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertNotNull(durationFieldType26);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) '4', (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1664 + "'", int2 == 1664);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.minuteOfHour();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.hourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.ReadableInterval readableInterval0 = null;
        org.joda.time.ReadableInterval readableInterval1 = org.joda.time.DateTimeUtils.getReadableInterval(readableInterval0);
        org.joda.time.Chronology chronology2 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Chronology chronology3 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.joda.time.Chronology chronology4 = org.joda.time.DateTimeUtils.getIntervalChronology(readableInterval1);
        org.junit.Assert.assertNotNull(readableInterval1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(chronology3);
        org.junit.Assert.assertNotNull(chronology4);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', (-1L), chronology3);
        int[] intArray5 = period4.getValues();
        org.joda.time.Period period6 = period4.normalizedStandard();
        org.joda.time.Duration duration7 = period6.toStandardDuration();
        long long8 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration7);
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType13 = periodType12.withYearsRemoved();
        org.joda.time.Period period14 = new org.joda.time.Period(readableDuration10, readableInstant11, periodType12);
        org.joda.time.PeriodType periodType15 = period14.getPeriodType();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.Period period17 = new org.joda.time.Period((long) 100, periodType15, chronology16);
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7, periodType15);
        org.joda.time.DurationFieldType durationFieldType19 = null;
        int int20 = period18.get(durationFieldType19);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-53L) + "'", long8 == (-53L));
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.Period period1 = org.joda.time.Period.minutes((-3600000));
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType1 = periodType0.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField6 = gregorianChronology5.centuries();
        java.lang.Class<?> wildcardClass7 = durationField6.getClass();
        long long10 = durationField6.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period13 = new org.joda.time.Period((long) (short) -1, periodType12);
        java.lang.String str14 = periodType12.getName();
        java.lang.String str15 = periodType12.getName();
        org.joda.time.Period period17 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant18 = null;
        org.joda.time.ReadableDuration readableDuration19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant18, readableDuration19);
        org.joda.time.Period period22 = period20.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray23 = period20.getFieldTypes();
        org.joda.time.PeriodType periodType25 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period26 = new org.joda.time.Period((long) (short) -1, periodType25);
        org.joda.time.PeriodType periodType27 = periodType25.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType29 = periodType25.getFieldType((int) (short) 0);
        org.joda.time.Period period31 = period20.withFieldAdded(durationFieldType29, 0);
        int int32 = period17.get(durationFieldType29);
        int int33 = periodType12.indexOf(durationFieldType29);
        org.joda.time.field.ScaledDurationField scaledDurationField35 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType29, (int) '4');
        long long37 = scaledDurationField35.getMillis((int) (byte) 0);
        boolean boolean38 = scaledDurationField35.isSupported();
        boolean boolean39 = periodType0.equals((java.lang.Object) scaledDurationField35);
        boolean boolean40 = scaledDurationField35.isSupported();
        long long43 = scaledDurationField35.getMillis((int) (short) 0, 0L);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3155759999999L + "'", long10 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Hours" + "'", str14.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Hours" + "'", str15.equals("Hours"));
        org.junit.Assert.assertNotNull(period17);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(durationFieldTypeArray23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(durationFieldType29);
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 0L + "'", long37 == 0L);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        int int1 = org.joda.time.field.FieldUtils.safeNegate((-100));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.secondOfDay();
        org.joda.time.DurationField durationField6 = gregorianChronology3.millis();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "14400000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType4 = periodType3.withYearsRemoved();
        org.joda.time.Period period5 = new org.joda.time.Period(readableDuration1, readableInstant2, periodType3);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType9 = periodType8.withYearsRemoved();
        org.joda.time.Period period10 = new org.joda.time.Period(readableDuration6, readableInstant7, periodType8);
        org.joda.time.Period period11 = period5.withPeriodType(periodType8);
        org.joda.time.Period period13 = period11.multipliedBy((int) (byte) -1);
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.Duration duration15 = period11.toDurationTo(readableInstant14);
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType18 = periodType17.withYearsRemoved();
        org.joda.time.PeriodType periodType19 = periodType17.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
        org.joda.time.DurationField durationField24 = gregorianChronology23.centuries();
        org.joda.time.DurationField durationField25 = gregorianChronology23.years();
        org.joda.time.DurationField durationField26 = gregorianChronology23.halfdays();
        org.joda.time.Period period27 = new org.joda.time.Period((long) (byte) -1, periodType17, (org.joda.time.Chronology) gregorianChronology23);
        org.joda.time.PeriodType periodType28 = periodType17.withSecondsRemoved();
        org.joda.time.PeriodType periodType29 = periodType17.withDaysRemoved();
        org.joda.time.Period period30 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration15, periodType29);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(duration15);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(durationField24);
        org.junit.Assert.assertNotNull(durationField25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(periodType29);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 52);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getMaximumValue((long) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField16.getAsShortText((-28378000), locale20);
        int int22 = offsetDateTimeField16.getOffset();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86400000 + "'", int18 == 86400000);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-28378000" + "'", str21.equals("-28378000"));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.LocalDateTime localDateTime3 = null;
        boolean boolean4 = dateTimeZone2.isLocalDateTimeGap(localDateTime3);
        java.util.TimeZone timeZone5 = dateTimeZone2.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(timeZone5);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.Period period8 = new org.joda.time.Period((long) '4', (-1L), chronology7);
        int[] intArray9 = period8.getValues();
        org.joda.time.Period period10 = period8.normalizedStandard();
        org.joda.time.Duration duration11 = period10.toStandardDuration();
        org.joda.time.Period period13 = period10.withWeeks(0);
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType15 = periodType14.withYearsRemoved();
        org.joda.time.PeriodType periodType16 = periodType14.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        org.joda.time.DurationField durationField21 = gregorianChronology20.centuries();
        java.lang.Class<?> wildcardClass22 = durationField21.getClass();
        long long25 = durationField21.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType27 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period28 = new org.joda.time.Period((long) (short) -1, periodType27);
        java.lang.String str29 = periodType27.getName();
        java.lang.String str30 = periodType27.getName();
        org.joda.time.Period period32 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant33 = null;
        org.joda.time.ReadableDuration readableDuration34 = null;
        org.joda.time.Period period35 = new org.joda.time.Period(readableInstant33, readableDuration34);
        org.joda.time.Period period37 = period35.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray38 = period35.getFieldTypes();
        org.joda.time.PeriodType periodType40 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period41 = new org.joda.time.Period((long) (short) -1, periodType40);
        org.joda.time.PeriodType periodType42 = periodType40.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType44 = periodType40.getFieldType((int) (short) 0);
        org.joda.time.Period period46 = period35.withFieldAdded(durationFieldType44, 0);
        int int47 = period32.get(durationFieldType44);
        int int48 = periodType27.indexOf(durationFieldType44);
        org.joda.time.field.ScaledDurationField scaledDurationField50 = new org.joda.time.field.ScaledDurationField(durationField21, durationFieldType44, (int) '4');
        int int51 = periodType16.indexOf(durationFieldType44);
        boolean boolean52 = period13.isSupported(durationFieldType44);
        org.joda.time.Period period54 = period3.withFieldAdded(durationFieldType44, (int) (short) 10);
        org.joda.time.PeriodType periodType55 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType56 = periodType55.withYearsRemoved();
        org.joda.time.PeriodType periodType57 = periodType56.withDaysRemoved();
        org.joda.time.Period period58 = period54.normalizedStandard(periodType56);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(duration11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(durationField21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 3155759999999L + "'", long25 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Hours" + "'", str29.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Hours" + "'", str30.equals("Hours"));
        org.junit.Assert.assertNotNull(period32);
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(durationFieldTypeArray38);
        org.junit.Assert.assertNotNull(periodType40);
        org.junit.Assert.assertNotNull(periodType42);
        org.junit.Assert.assertNotNull(durationFieldType44);
        org.junit.Assert.assertNotNull(period46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(period54);
        org.junit.Assert.assertNotNull(periodType55);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertNotNull(periodType57);
        org.junit.Assert.assertNotNull(period58);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        long long40 = scaledDurationField33.getValueAsLong((long) ' ');
        long long42 = scaledDurationField33.getMillis(10);
        boolean boolean43 = scaledDurationField33.isSupported();
        long long46 = scaledDurationField33.add(0L, (-8L));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1640961504000000L + "'", long42 == 1640961504000000L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-1312769203200000L) + "'", long46 == (-1312769203200000L));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period5 = period3.normalizedStandard();
        org.joda.time.Duration duration6 = period5.toStandardDuration();
        long long7 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration6);
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant8);
        org.joda.time.ReadableInstant readableInstant10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration6, readableInstant10);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-53L) + "'", long7 == (-53L));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.format.PeriodFormatter periodFormatter5 = null;
        java.lang.String str6 = period4.toString(periodFormatter5);
        org.joda.time.Period period8 = period4.plusMonths(0);
        org.joda.time.Period period10 = period4.plusWeeks((int) (short) 0);
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.Period period12 = period4.minus(readablePeriod11);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0H" + "'", str6.equals("PT0H"));
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        try {
            long long28 = unsupportedDurationField25.getMillis(15917326588800035L, 3155759999999L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DurationField durationField1 = gregorianChronology0.months();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(durationField1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        java.lang.String str39 = scaledDurationField33.toString();
        org.joda.time.DurationField durationField40 = scaledDurationField33.getWrappedField();
        long long43 = scaledDurationField33.add(0L, (long) (byte) 10);
        long long46 = scaledDurationField33.getMillis((-8L), (long) 97);
        int int49 = scaledDurationField33.getDifference(0L, 0L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[hours]" + "'", str39.equals("DurationField[hours]"));
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1640961504000000L + "'", long43 == 1640961504000000L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + (-1312769203200000L) + "'", long46 == (-1312769203200000L));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(1);
        int int7 = period3.getMinutes();
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Duration duration9 = period3.toDurationTo(readableInstant8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(duration9);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.lang.Object obj0 = null;
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology4 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone3);
        org.joda.time.DurationField durationField5 = gregorianChronology4.halfdays();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology4.millisOfSecond();
        boolean boolean7 = org.joda.time.field.FieldUtils.equals(obj0, (java.lang.Object) dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(gregorianChronology4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 8);
        int int20 = offsetDateTimeField16.getMinimumValue((-210858379200000L));
        try {
            long long23 = offsetDateTimeField16.set((long) 1, "PT0S");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"PT0S\" for millisOfDay is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period6.plusMillis(0);
        int int9 = period8.getDays();
        org.joda.time.Period period11 = period8.minusSeconds((int) '4');
        int int12 = period11.getHours();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-97) + "'", int9 == (-97));
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getMaximumValue((long) 'a');
        int int20 = offsetDateTimeField16.get((long) (-3600000));
        java.util.Locale locale22 = null;
        java.lang.String str23 = offsetDateTimeField16.getAsShortText((int) (byte) 10, locale22);
        long long26 = offsetDateTimeField16.add((long) 97, 0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86400000 + "'", int18 == 86400000);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10800001 + "'", int20 == 10800001);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "10" + "'", str23.equals("10"));
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 97L + "'", long26 == 97L);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        java.lang.String str37 = scaledDurationField33.toString();
        long long40 = scaledDurationField33.getMillis((long) (short) 1, (long) '4');
        long long43 = scaledDurationField33.add((long) 10800001, (int) (short) 0);
        int int44 = scaledDurationField33.getScalar();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DurationField[hours]" + "'", str37.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 164096150400000L + "'", long40 == 164096150400000L);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 10800001L + "'", long43 == 10800001L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 52 + "'", int44 == 52);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        java.lang.String str37 = scaledDurationField33.toString();
        long long40 = scaledDurationField33.getMillis((long) (short) 1, (long) '4');
        long long41 = scaledDurationField33.getUnitMillis();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DurationField[hours]" + "'", str37.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 164096150400000L + "'", long40 == 164096150400000L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 164096150400000L + "'", long41 == 164096150400000L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        long long2 = dateTimeZone0.convertUTCToLocal(0L);
        int int4 = dateTimeZone0.getOffsetFromLocal((long) 35);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3600000L) + "'", long2 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-3600000) + "'", int4 == (-3600000));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.time();
        org.joda.time.PeriodType periodType1 = periodType0.withMinutesRemoved();
        org.joda.time.PeriodType periodType2 = periodType1.withMonthsRemoved();
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType4);
        org.joda.time.Period period7 = period5.minusMinutes((int) (short) 0);
        org.joda.time.Period period9 = period7.minusSeconds((int) (short) 0);
        org.joda.time.Period period11 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant12 = null;
        org.joda.time.ReadableDuration readableDuration13 = null;
        org.joda.time.Period period14 = new org.joda.time.Period(readableInstant12, readableDuration13);
        org.joda.time.Period period16 = period14.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray17 = period14.getFieldTypes();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period20 = new org.joda.time.Period((long) (short) -1, periodType19);
        org.joda.time.PeriodType periodType21 = periodType19.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType23 = periodType19.getFieldType((int) (short) 0);
        org.joda.time.Period period25 = period14.withFieldAdded(durationFieldType23, 0);
        int int26 = period11.get(durationFieldType23);
        boolean boolean27 = period9.isSupported(durationFieldType23);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField28 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType23);
        int int29 = periodType1.indexOf(durationFieldType23);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(durationFieldTypeArray17);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(durationFieldType23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        org.joda.time.DurationFieldType durationFieldType26 = unsupportedDurationField25.getType();
        try {
            int int29 = unsupportedDurationField25.getValue((-210866010778000L), (-210866010778000L));
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertNotNull(durationFieldType26);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period3.plusSeconds(0);
        org.joda.time.Period period9 = period8.toPeriod();
        int int10 = period9.getMinutes();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period7 = period6.normalizedStandard();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) '4', (-1L), chronology10);
        int[] intArray12 = period11.getValues();
        org.joda.time.Period period14 = period11.minusDays((int) 'a');
        org.joda.time.Period period16 = period11.withYears(0);
        org.joda.time.MutablePeriod mutablePeriod17 = period16.toMutablePeriod();
        org.joda.time.Period period18 = period7.plus((org.joda.time.ReadablePeriod) period16);
        org.joda.time.Period period20 = period18.plusHours((int) (short) 100);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.PeriodType periodType2 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) 0, (long) 52, periodType2, chronology3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        java.lang.String str3 = periodType1.getName();
        java.lang.String str4 = periodType1.getName();
        org.joda.time.Period period6 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant7, readableDuration8);
        org.joda.time.Period period11 = period9.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray12 = period9.getFieldTypes();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) -1, periodType14);
        org.joda.time.PeriodType periodType16 = periodType14.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType((int) (short) 0);
        org.joda.time.Period period20 = period9.withFieldAdded(durationFieldType18, 0);
        int int21 = period6.get(durationFieldType18);
        int int22 = periodType1.indexOf(durationFieldType18);
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(durationFieldType18, "PT0H");
        java.lang.Throwable[] throwableArray25 = illegalFieldValueException24.getSuppressed();
        java.lang.Number number26 = illegalFieldValueException24.getUpperBound();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hours" + "'", str3.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Hours" + "'", str4.equals("Hours"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(durationFieldTypeArray12);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertNull(number26);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        java.lang.String str39 = scaledDurationField33.toString();
        org.joda.time.DurationField durationField40 = scaledDurationField33.getWrappedField();
        try {
            long long42 = scaledDurationField33.getMillis((-1312769203200000L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -68263998566400000 * 3155695200000");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[hours]" + "'", str39.equals("DurationField[hours]"));
        org.junit.Assert.assertNotNull(durationField40);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int2 = org.joda.time.field.FieldUtils.safeMultiplyToInt(0L, (-53L));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField16.getMaximumTextLength(locale23);
        int int26 = offsetDateTimeField16.getLeapAmount((-28800000L));
        org.joda.time.ReadablePartial readablePartial27 = null;
        java.util.Locale locale28 = null;
        try {
            java.lang.String str29 = offsetDateTimeField16.getAsShortText(readablePartial27, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        boolean boolean4 = dateTimeZone1.isStandardOffset((long) 97);
        long long6 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getOffset(1560629155109L);
        boolean boolean10 = cachedDateTimeZone7.isFixed();
        long long12 = cachedDateTimeZone7.nextTransition((-3600000L));
        org.joda.time.chrono.ISOChronology iSOChronology13 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology15 = iSOChronology13.withZone(dateTimeZone14);
        boolean boolean17 = dateTimeZone14.isStandardOffset((long) 97);
        long long19 = dateTimeZone14.convertUTCToLocal((long) (byte) 1);
        long long21 = cachedDateTimeZone7.getMillisKeepLocal(dateTimeZone14, (long) 86400000);
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField23 = iSOChronology22.days();
        org.joda.time.DateTimeField dateTimeField24 = iSOChronology22.weekOfWeekyear();
        org.joda.time.DateTimeField dateTimeField25 = iSOChronology22.hourOfHalfday();
        java.lang.String str26 = iSOChronology22.toString();
        try {
            org.joda.time.Period period27 = new org.joda.time.Period((java.lang.Object) long21, (org.joda.time.Chronology) iSOChronology22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: java.lang.Long");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-3599999L) + "'", long6 == (-3599999L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3600000) + "'", int9 == (-3600000));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-3600000L) + "'", long12 == (-3600000L));
        org.junit.Assert.assertNotNull(iSOChronology13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-3599999L) + "'", long19 == (-3599999L));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 86400000L + "'", long21 == 86400000L);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "ISOChronology[GregorianChronology[+52:00]]" + "'", str26.equals("ISOChronology[GregorianChronology[+52:00]]"));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        long long2 = org.joda.time.field.FieldUtils.safeAdd(187200001L, (long) (-28378000));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 158822001L + "'", long2 == 158822001L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getMaximumValue((long) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField16.getAsShortText(1L, locale20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField16.getAsText((-210815856000000L), locale23);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86400000 + "'", int18 == 86400000);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "14400002" + "'", str21.equals("14400002"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "72000001" + "'", str24.equals("72000001"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.util.TimeZone timeZone0 = null;
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forTimeZone(timeZone0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.Period period4 = new org.joda.time.Period(0, (int) (byte) 10, (int) (short) 100, 35);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, periodType6);
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant3, readableInstant4, periodType6);
        org.joda.time.PeriodType periodType9 = periodType6.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        org.joda.time.DurationField durationField14 = gregorianChronology13.centuries();
        org.joda.time.DurationField durationField15 = gregorianChronology13.years();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        boolean boolean21 = dateTimeZone18.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeUtils.getZone(dateTimeZone18);
        org.joda.time.chrono.ZonedChronology zonedChronology23 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology13, dateTimeZone22);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone28 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        org.joda.time.Chronology chronology29 = zonedChronology23.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone28);
        org.joda.time.Period period30 = new org.joda.time.Period((-3155759999989L), periodType6, (org.joda.time.Chronology) zonedChronology23);
        java.lang.String str31 = zonedChronology23.toString();
        org.joda.time.Period period32 = new org.joda.time.Period((-28799999L), (long) (short) 0, (org.joda.time.Chronology) zonedChronology23);
        try {
            long long37 = zonedChronology23.getDateTimeMillis(520, (int) (short) -1, 35, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(durationField15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(zonedChronology23);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ZonedChronology[GregorianChronology[UTC], +52:00]" + "'", str31.equals("ZonedChronology[GregorianChronology[UTC], +52:00]"));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 8);
        int int20 = offsetDateTimeField16.getMinimumValue((-210858379200000L));
        boolean boolean21 = offsetDateTimeField16.isLenient();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        org.joda.time.DurationFieldType durationFieldType26 = unsupportedDurationField25.getType();
        try {
            long long29 = unsupportedDurationField25.add((long) '#', 52);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertNotNull(durationFieldType26);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        java.util.Locale locale23 = null;
        int int24 = offsetDateTimeField16.getMaximumTextLength(locale23);
        long long26 = offsetDateTimeField16.roundHalfCeiling((long) 520);
        long long28 = offsetDateTimeField16.roundHalfCeiling(100L);
        long long31 = offsetDateTimeField16.getDifferenceAsLong(0L, (-3599999L));
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 8 + "'", int24 == 8);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 520L + "'", long26 == 520L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 100L + "'", long28 == 100L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 3599999L + "'", long31 == 3599999L);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.Period period8 = new org.joda.time.Period((-3600000), (int) 'a', (int) (short) -1, 0, (int) (byte) -1, (int) ' ', 4, (int) (byte) 0);
        org.joda.time.format.PeriodFormatter periodFormatter9 = null;
        java.lang.String str10 = period8.toString(periodFormatter9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "P-3600000Y97M-1WT-1H32M4S" + "'", str10.equals("P-3600000Y97M-1WT-1H32M4S"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((-1));
        org.joda.time.Period period6 = period4.minusSeconds((int) '4');
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) -1, periodType8);
        org.joda.time.Period period11 = period9.minusMinutes((int) (short) 0);
        org.joda.time.Period period13 = period11.minusSeconds((int) (short) 0);
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        boolean boolean31 = period13.isSupported(durationFieldType27);
        int int32 = period4.get(durationFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(durationFieldType27, (java.lang.Number) 2440587.500000116d, (java.lang.Number) (-1.0f), (java.lang.Number) 0L);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(1);
        org.joda.time.Period period8 = period6.withMillis(520);
        org.joda.time.Period period10 = period8.minusWeeks((int) (byte) 0);
        org.joda.time.Hours hours11 = period8.toStandardHours();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.Period period15 = new org.joda.time.Period((long) '4', (-1L), chronology14);
        int[] intArray16 = period15.getValues();
        org.joda.time.Chronology chronology19 = null;
        org.joda.time.Period period20 = new org.joda.time.Period((long) '4', (-1L), chronology19);
        int[] intArray21 = period20.getValues();
        org.joda.time.Period period22 = period20.normalizedStandard();
        org.joda.time.Duration duration23 = period22.toStandardDuration();
        org.joda.time.Period period25 = period22.withWeeks(0);
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType27 = periodType26.withYearsRemoved();
        org.joda.time.PeriodType periodType28 = periodType26.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
        org.joda.time.DurationField durationField33 = gregorianChronology32.centuries();
        java.lang.Class<?> wildcardClass34 = durationField33.getClass();
        long long37 = durationField33.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) -1, periodType39);
        java.lang.String str41 = periodType39.getName();
        java.lang.String str42 = periodType39.getName();
        org.joda.time.Period period44 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant45 = null;
        org.joda.time.ReadableDuration readableDuration46 = null;
        org.joda.time.Period period47 = new org.joda.time.Period(readableInstant45, readableDuration46);
        org.joda.time.Period period49 = period47.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray50 = period47.getFieldTypes();
        org.joda.time.PeriodType periodType52 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period53 = new org.joda.time.Period((long) (short) -1, periodType52);
        org.joda.time.PeriodType periodType54 = periodType52.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType56 = periodType52.getFieldType((int) (short) 0);
        org.joda.time.Period period58 = period47.withFieldAdded(durationFieldType56, 0);
        int int59 = period44.get(durationFieldType56);
        int int60 = periodType39.indexOf(durationFieldType56);
        org.joda.time.field.ScaledDurationField scaledDurationField62 = new org.joda.time.field.ScaledDurationField(durationField33, durationFieldType56, (int) '4');
        int int63 = periodType28.indexOf(durationFieldType56);
        boolean boolean64 = period25.isSupported(durationFieldType56);
        org.joda.time.Period period66 = period15.withFieldAdded(durationFieldType56, (int) (short) 10);
        int int67 = period8.get(durationFieldType56);
        org.joda.time.IllegalFieldValueException illegalFieldValueException71 = new org.joda.time.IllegalFieldValueException(durationFieldType56, (java.lang.Number) (short) 0, (java.lang.Number) (-1.0f), (java.lang.Number) (byte) -1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(hours11);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertNotNull(duration23);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(durationField33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 3155759999999L + "'", long37 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "Hours" + "'", str41.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Hours" + "'", str42.equals("Hours"));
        org.junit.Assert.assertNotNull(period44);
        org.junit.Assert.assertNotNull(period49);
        org.junit.Assert.assertNotNull(durationFieldTypeArray50);
        org.junit.Assert.assertNotNull(periodType52);
        org.junit.Assert.assertNotNull(periodType54);
        org.junit.Assert.assertNotNull(durationFieldType56);
        org.junit.Assert.assertNotNull(period58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(period66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        java.lang.String str37 = scaledDurationField33.toString();
        long long40 = scaledDurationField33.getMillis((long) (short) 1, (long) '4');
        long long42 = scaledDurationField33.getValueAsLong((long) 1);
        long long44 = scaledDurationField33.getValueAsLong((long) (-25200000));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "DurationField[hours]" + "'", str37.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 164096150400000L + "'", long40 == 164096150400000L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 0L + "'", long42 == 0L);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        long long5 = dateTimeZone2.convertUTCToLocal((long) (byte) -1);
        long long8 = dateTimeZone2.adjustOffset(100L, false);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        java.util.TimeZone timeZone10 = dateTimeZone9.toTimeZone();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 187199999L + "'", long5 == 187199999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(timeZone10);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withHoursRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withMillisRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.yearOfEra();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.secondOfMinute();
        org.joda.time.Period period13 = new org.joda.time.Period((long) 1, periodType4, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology10.getZone();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology10.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) 1);
        int int19 = offsetDateTimeField17.getLeapAmount((long) 8);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField17.getType();
        java.lang.Number number21 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException24 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, number21, (java.lang.Number) 16409615040000000L, (java.lang.Number) (byte) 100);
        org.joda.time.IllegalFieldValueException illegalFieldValueException27 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, (java.lang.Number) 100.0f, "+52:00");
        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType20, "+52:00");
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        long long35 = scaledDurationField33.getMillis((int) (byte) 0);
        boolean boolean36 = scaledDurationField33.isSupported();
        int int37 = scaledDurationField33.getScalar();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 52 + "'", int37 == 52);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = offsetDateTimeField16.getMinimumValue(readablePartial23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int[] intArray28 = new int[] { (short) -1, (-25200000) };
        int int29 = offsetDateTimeField16.getMaximumValue(readablePartial25, intArray28);
        int int30 = offsetDateTimeField16.getMinimumValue();
        org.joda.time.DurationField durationField31 = offsetDateTimeField16.getRangeDurationField();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86400000 + "'", int29 == 86400000);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(durationField31);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        boolean boolean4 = dateTimeZone1.isStandardOffset((long) 97);
        long long6 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getOffset(1560629155109L);
        boolean boolean10 = cachedDateTimeZone7.isFixed();
        long long12 = cachedDateTimeZone7.nextTransition((-3600000L));
        int int14 = cachedDateTimeZone7.getOffset((long) 35);
        int int16 = cachedDateTimeZone7.getOffset((long) 520);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-3599999L) + "'", long6 == (-3599999L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3600000) + "'", int9 == (-3600000));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-3600000L) + "'", long12 == (-3600000L));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-3600000) + "'", int14 == (-3600000));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-3600000) + "'", int16 == (-3600000));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(1);
        int int7 = period3.getMinutes();
        org.joda.time.Period period8 = period3.normalizedStandard();
        org.joda.time.MutablePeriod mutablePeriod9 = period3.toMutablePeriod();
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType11 = periodType10.withYearsRemoved();
        org.joda.time.PeriodType periodType12 = periodType10.withHoursRemoved();
        org.joda.time.PeriodType periodType13 = periodType12.withMillisRemoved();
        org.joda.time.PeriodType periodType14 = periodType13.withMinutesRemoved();
        org.joda.time.PeriodType periodType15 = org.joda.time.DateTimeUtils.getPeriodType(periodType14);
        boolean boolean16 = mutablePeriod9.equals((java.lang.Object) periodType15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(mutablePeriod9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertNotNull(periodType12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1, (java.lang.Number) 0, (java.lang.Number) 10.0d);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        java.lang.Number number6 = illegalFieldValueException4.getIllegalNumberValue();
        illegalFieldValueException4.prependMessage("GregorianChronology[GregorianChronology[+52:00]]");
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean11 = dateTimeZone8.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone12);
        org.joda.time.DurationField durationField14 = gregorianChronology3.centuries();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(durationField14);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType8 = periodType7.withYearsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableDuration5, readableInstant6, periodType7);
        org.joda.time.Period period10 = period4.withPeriodType(periodType7);
        org.joda.time.Period period12 = period10.plusHours((int) 'a');
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) -1, periodType14);
        org.joda.time.PeriodType periodType16 = periodType14.withMonthsRemoved();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology20 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone19);
        org.joda.time.DateTimeField dateTimeField21 = gregorianChronology20.yearOfEra();
        org.joda.time.DateTimeField dateTimeField22 = gregorianChronology20.secondOfMinute();
        boolean boolean23 = periodType16.equals((java.lang.Object) dateTimeField22);
        org.joda.time.Period period24 = period12.withPeriodType(periodType16);
        org.joda.time.Period period25 = period24.normalizedStandard();
        org.joda.time.DurationFieldType durationFieldType26 = null;
        int int27 = period25.get(durationFieldType26);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(gregorianChronology20);
        org.junit.Assert.assertNotNull(dateTimeField21);
        org.junit.Assert.assertNotNull(dateTimeField22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(period24);
        org.junit.Assert.assertNotNull(period25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("org.joda.time.IllegalFieldValueException: Hours: Value 1 for hi! must be in the range [0,10.0]", (int) '4');
        java.io.DataOutput dataOutput5 = null;
        try {
            dateTimeZoneBuilder0.writeTo("hi!", dataOutput5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withHoursRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withMillisRemoved();
        org.joda.time.PeriodType periodType6 = periodType4.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.yearOfEra();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.secondOfMinute();
        org.joda.time.Period period13 = new org.joda.time.Period((long) 1, periodType4, (org.joda.time.Chronology) gregorianChronology10);
        org.joda.time.DateTimeZone dateTimeZone14 = gregorianChronology10.getZone();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology10.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField17 = new org.joda.time.field.OffsetDateTimeField(dateTimeField15, (int) (byte) 1);
        int int19 = offsetDateTimeField17.getLeapAmount((long) 8);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = offsetDateTimeField17.getType();
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField24 = new org.joda.time.field.OffsetDateTimeField(dateTimeField0, dateTimeFieldType20, (-1008001785), 14400098, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType20);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = gregorianChronology3.getZone();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology8 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone7);
        long long10 = dateTimeZone7.convertUTCToLocal((long) (byte) -1);
        long long13 = dateTimeZone7.adjustOffset(100L, false);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeUtils.getZone(dateTimeZone7);
        boolean boolean16 = dateTimeZone14.isStandardOffset((long) 100);
        long long18 = dateTimeZone4.getMillisKeepLocal(dateTimeZone14, (long) 8);
        boolean boolean20 = dateTimeZone14.isStandardOffset(97L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(gregorianChronology8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 187199999L + "'", long10 == 187199999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 100L + "'", long13 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 8L + "'", long18 == 8L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType4);
        org.joda.time.PeriodType periodType7 = periodType4.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField12 = gregorianChronology11.centuries();
        org.joda.time.DurationField durationField13 = gregorianChronology11.years();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        boolean boolean19 = dateTimeZone16.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology11, dateTimeZone20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        org.joda.time.Chronology chronology27 = zonedChronology21.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.Period period28 = new org.joda.time.Period((-3155759999989L), periodType4, (org.joda.time.Chronology) zonedChronology21);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone33 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        org.joda.time.Period period35 = org.joda.time.Period.weeks(0);
        boolean boolean36 = fixedDateTimeZone33.equals((java.lang.Object) period35);
        int[] intArray38 = zonedChronology21.get((org.joda.time.ReadablePeriod) period35, (long) (short) -1);
        try {
            long long46 = zonedChronology21.getDateTimeMillis(0, 187200000, (-100), (int) (byte) -1, (-53), 0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.clockhourOfDay();
        java.lang.String str7 = gregorianChronology3.toString();
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology3.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "GregorianChronology[+52:00]" + "'", str7.equals("GregorianChronology[+52:00]"));
        org.junit.Assert.assertNotNull(dateTimeField8);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(1);
        int int7 = period3.getMinutes();
        org.joda.time.Period period8 = period3.normalizedStandard();
        org.joda.time.Period period10 = period8.plusSeconds((int) '4');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        long long18 = offsetDateTimeField16.roundHalfEven((long) (-28378000));
        long long20 = offsetDateTimeField16.roundFloor((-210858379200000L));
        int int22 = offsetDateTimeField16.getMaximumValue(1640961504000000L);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-28378000L) + "'", long18 == (-28378000L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210858379200000L) + "'", long20 == (-210858379200000L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 86400000 + "'", int22 == 86400000);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period5 = period3.normalizedStandard();
        org.joda.time.Duration duration6 = period5.toStandardDuration();
        org.joda.time.Period period8 = period5.withWeeks(0);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.IllegalFieldValueException illegalFieldValueException33 = new org.joda.time.IllegalFieldValueException(durationFieldType27, "PT0H");
        org.joda.time.Period period35 = period5.withFieldAdded(durationFieldType27, (-1));
        int int36 = period35.getMinutes();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(duration6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(period35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 8);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField16.getAsShortText(0L, locale20);
        boolean boolean22 = offsetDateTimeField16.isSupported();
        boolean boolean24 = offsetDateTimeField16.isLeap(187200001L);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "14400001" + "'", str21.equals("14400001"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
//        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
//        long long5 = dateTimeZone2.convertUTCToLocal((long) (byte) -1);
//        long long8 = dateTimeZone2.adjustOffset(100L, false);
//        java.lang.String str9 = dateTimeZone2.toString();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.UTC;
//        java.lang.String str12 = dateTimeZone10.getName((long) (byte) 100);
//        long long14 = dateTimeZone2.getMillisKeepLocal(dateTimeZone10, 0L);
//        java.lang.Object obj15 = null;
//        boolean boolean16 = org.joda.time.field.FieldUtils.equals((java.lang.Object) long14, obj15);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(gregorianChronology3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 187199999L + "'", long5 == 187199999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "+52:00" + "'", str9.equals("+52:00"));
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Coordinated Universal Time" + "'", str12.equals("Coordinated Universal Time"));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 187200000L + "'", long14 == 187200000L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        java.lang.String str26 = unsupportedDurationField25.toString();
        try {
            long long29 = unsupportedDurationField25.getValueAsLong((long) '4', (long) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "UnsupportedDurationField[hours]" + "'", str26.equals("UnsupportedDurationField[hours]"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((-1));
        int int5 = period4.getDays();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType3 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period4 = new org.joda.time.Period((long) (short) -1, periodType3);
        org.joda.time.Period period5 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType3);
        org.joda.time.PeriodType periodType6 = periodType3.withSecondsRemoved();
        org.joda.time.PeriodType periodType7 = periodType6.withHoursRemoved();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period((long) '4', (-1L), chronology10);
        int int12 = period11.getMonths();
        org.joda.time.Period period14 = period11.plusDays(1);
        org.joda.time.Period period16 = period14.withMillis(520);
        org.joda.time.Period period18 = period16.minusWeeks((int) (byte) 0);
        org.joda.time.Hours hours19 = period16.toStandardHours();
        org.joda.time.Chronology chronology22 = null;
        org.joda.time.Period period23 = new org.joda.time.Period((long) '4', (-1L), chronology22);
        int[] intArray24 = period23.getValues();
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) '4', (-1L), chronology27);
        int[] intArray29 = period28.getValues();
        org.joda.time.Period period30 = period28.normalizedStandard();
        org.joda.time.Duration duration31 = period30.toStandardDuration();
        org.joda.time.Period period33 = period30.withWeeks(0);
        org.joda.time.PeriodType periodType34 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType35 = periodType34.withYearsRemoved();
        org.joda.time.PeriodType periodType36 = periodType34.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology40 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone39);
        org.joda.time.DurationField durationField41 = gregorianChronology40.centuries();
        java.lang.Class<?> wildcardClass42 = durationField41.getClass();
        long long45 = durationField41.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType47 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period48 = new org.joda.time.Period((long) (short) -1, periodType47);
        java.lang.String str49 = periodType47.getName();
        java.lang.String str50 = periodType47.getName();
        org.joda.time.Period period52 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant53 = null;
        org.joda.time.ReadableDuration readableDuration54 = null;
        org.joda.time.Period period55 = new org.joda.time.Period(readableInstant53, readableDuration54);
        org.joda.time.Period period57 = period55.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray58 = period55.getFieldTypes();
        org.joda.time.PeriodType periodType60 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period61 = new org.joda.time.Period((long) (short) -1, periodType60);
        org.joda.time.PeriodType periodType62 = periodType60.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType64 = periodType60.getFieldType((int) (short) 0);
        org.joda.time.Period period66 = period55.withFieldAdded(durationFieldType64, 0);
        int int67 = period52.get(durationFieldType64);
        int int68 = periodType47.indexOf(durationFieldType64);
        org.joda.time.field.ScaledDurationField scaledDurationField70 = new org.joda.time.field.ScaledDurationField(durationField41, durationFieldType64, (int) '4');
        int int71 = periodType36.indexOf(durationFieldType64);
        boolean boolean72 = period33.isSupported(durationFieldType64);
        org.joda.time.Period period74 = period23.withFieldAdded(durationFieldType64, (int) (short) 10);
        int int75 = period16.get(durationFieldType64);
        int int76 = periodType6.indexOf(durationFieldType64);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(period14);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(hours19);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(duration31);
        org.junit.Assert.assertNotNull(period33);
        org.junit.Assert.assertNotNull(periodType34);
        org.junit.Assert.assertNotNull(periodType35);
        org.junit.Assert.assertNotNull(periodType36);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(gregorianChronology40);
        org.junit.Assert.assertNotNull(durationField41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 3155759999999L + "'", long45 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Hours" + "'", str49.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Hours" + "'", str50.equals("Hours"));
        org.junit.Assert.assertNotNull(period52);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertNotNull(durationFieldTypeArray58);
        org.junit.Assert.assertNotNull(periodType60);
        org.junit.Assert.assertNotNull(periodType62);
        org.junit.Assert.assertNotNull(durationFieldType64);
        org.junit.Assert.assertNotNull(period66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(period74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekyear();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.millisOfSecond();
        int int7 = gregorianChronology3.getMinimumDaysInFirstWeek();
        org.joda.time.DurationField durationField8 = gregorianChronology3.minutes();
        org.joda.time.DurationField durationField9 = gregorianChronology3.halfdays();
        org.joda.time.DurationField durationField10 = gregorianChronology3.weekyears();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(durationField8);
        org.junit.Assert.assertNotNull(durationField9);
        org.junit.Assert.assertNotNull(durationField10);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(1);
        org.joda.time.Period period8 = period6.withMillis(520);
        org.joda.time.Period period10 = period8.minusWeeks((int) (byte) 0);
        org.joda.time.ReadableDuration readableDuration12 = null;
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.PeriodType periodType15 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period16 = new org.joda.time.Period((long) (short) -1, periodType15);
        org.joda.time.Period period17 = new org.joda.time.Period(readableDuration12, readableInstant13, periodType15);
        org.joda.time.Period period18 = new org.joda.time.Period((long) (byte) 10, periodType15);
        org.joda.time.PeriodType periodType19 = periodType15.withYearsRemoved();
        org.joda.time.Period period20 = period10.normalizedStandard(periodType19);
        org.joda.time.Period period22 = period10.minusWeeks(86400000);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        long long5 = dateTimeZone2.convertUTCToLocal((long) (byte) -1);
        long long8 = dateTimeZone2.adjustOffset(100L, false);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeUtils.getZone(dateTimeZone2);
        java.lang.String str10 = dateTimeZone9.getID();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 187199999L + "'", long5 == 187199999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 100L + "'", long8 == 100L);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "+52:00" + "'", str10.equals("+52:00"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        int int4 = org.joda.time.field.FieldUtils.getWrappedValue(35, 52, (int) (byte) 0, 14);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 12 + "'", int4 == 12);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-10) + "'", int1 == (-10));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.PeriodType periodType4 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period5 = new org.joda.time.Period((long) (short) -1, periodType4);
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant1, readableInstant2, periodType4);
        org.joda.time.PeriodType periodType7 = periodType4.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology11 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone10);
        org.joda.time.DurationField durationField12 = gregorianChronology11.centuries();
        org.joda.time.DurationField durationField13 = gregorianChronology11.years();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology17 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone16);
        boolean boolean19 = dateTimeZone16.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeUtils.getZone(dateTimeZone16);
        org.joda.time.chrono.ZonedChronology zonedChronology21 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology11, dateTimeZone20);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone26 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        org.joda.time.Chronology chronology27 = zonedChronology21.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone26);
        org.joda.time.Period period28 = new org.joda.time.Period((-3155759999989L), periodType4, (org.joda.time.Chronology) zonedChronology21);
        java.lang.String str29 = zonedChronology21.toString();
        org.joda.time.DateTimeZone dateTimeZone30 = zonedChronology21.getZone();
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone35 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        int int37 = fixedDateTimeZone35.getOffset((long) 10);
        org.joda.time.Chronology chronology38 = zonedChronology21.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone35);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(gregorianChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(gregorianChronology17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(zonedChronology21);
        org.junit.Assert.assertNotNull(chronology27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "ZonedChronology[GregorianChronology[UTC], +52:00]" + "'", str29.equals("ZonedChronology[GregorianChronology[UTC], +52:00]"));
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-3600000) + "'", int37 == (-3600000));
        org.junit.Assert.assertNotNull(chronology38);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.PeriodType periodType4 = periodType2.withHoursRemoved();
        org.joda.time.PeriodType periodType5 = periodType4.withMillisRemoved();
        org.joda.time.Period period6 = new org.joda.time.Period(readableInstant0, readableInstant1, periodType4);
        org.joda.time.Period period7 = period6.negated();
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(period7);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        int int23 = offsetDateTimeField16.getOffset();
        long long25 = offsetDateTimeField16.roundCeiling((-28800000L));
        org.joda.time.ReadablePartial readablePartial26 = null;
        int int27 = offsetDateTimeField16.getMinimumValue(readablePartial26);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + (-28800000L) + "'", long25 == (-28800000L));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekyear();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField7 = gregorianChronology3.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "DurationField[hours]", "1");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "1", "PT0H");
        org.joda.time.DateTimeZone.setNameProvider((org.joda.time.tz.NameProvider) defaultNameProvider0);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.yearDayTime();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        int int2 = periodType0.indexOf(durationFieldType1);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period6.minusMillis((int) (byte) -1);
        org.joda.time.Period period10 = period6.minusHours(0);
        org.joda.time.Period period12 = period10.plusSeconds((-100));
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-100L), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3500L) + "'", long2 == (-3500L));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(1);
        org.joda.time.Period period8 = period6.withMillis(520);
        org.joda.time.Period period10 = period8.minusWeeks((int) (byte) 0);
        org.joda.time.Period period12 = period10.plusWeeks(1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply((-210858379200000L), (-28378000));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: -210858379200000 * -28378000");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', (-1L), chronology3);
        int[] intArray5 = period4.getValues();
        org.joda.time.Period period6 = period4.normalizedStandard();
        org.joda.time.Duration duration7 = period6.toStandardDuration();
        org.joda.time.Period period9 = period6.withWeeks(0);
        org.joda.time.PeriodType periodType11 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period12 = new org.joda.time.Period((long) (short) -1, periodType11);
        java.lang.String str13 = periodType11.getName();
        java.lang.String str14 = periodType11.getName();
        org.joda.time.Period period16 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.Period period19 = new org.joda.time.Period(readableInstant17, readableDuration18);
        org.joda.time.Period period21 = period19.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray22 = period19.getFieldTypes();
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period25 = new org.joda.time.Period((long) (short) -1, periodType24);
        org.joda.time.PeriodType periodType26 = periodType24.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType28 = periodType24.getFieldType((int) (short) 0);
        org.joda.time.Period period30 = period19.withFieldAdded(durationFieldType28, 0);
        int int31 = period16.get(durationFieldType28);
        int int32 = periodType11.indexOf(durationFieldType28);
        org.joda.time.IllegalFieldValueException illegalFieldValueException34 = new org.joda.time.IllegalFieldValueException(durationFieldType28, "PT0H");
        org.joda.time.Period period36 = period6.withFieldAdded(durationFieldType28, (-1));
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField37 = new org.joda.time.field.DecoratedDurationField(durationField0, durationFieldType28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(periodType11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Hours" + "'", str14.equals("Hours"));
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period21);
        org.junit.Assert.assertNotNull(durationFieldTypeArray22);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(durationFieldType28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(period36);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.minuteOfDay();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.clockhourOfDay();
        try {
            org.joda.time.field.FieldUtils.verifyValueBounds(dateTimeField6, 10800001, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 10800001 for clockhourOfDay must be in the range [35,0]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology10 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone9);
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology10.monthOfYear();
        org.joda.time.DateTimeField dateTimeField12 = gregorianChronology10.secondOfDay();
        boolean boolean13 = org.joda.time.field.FieldUtils.equals((java.lang.Object) period6, (java.lang.Object) dateTimeField12);
        org.joda.time.Minutes minutes14 = period6.toStandardMinutes();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(gregorianChronology10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeField12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(minutes14);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period2.getFieldTypes();
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType7);
        org.joda.time.PeriodType periodType9 = periodType7.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType11 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.Period period13 = period2.withFieldAdded(durationFieldType11, 0);
        org.joda.time.Seconds seconds14 = period2.toStandardSeconds();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(seconds14);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.PeriodType periodType0 = org.joda.time.PeriodType.standard();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        boolean boolean2 = periodType0.isSupported(durationFieldType1);
        org.junit.Assert.assertNotNull(periodType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DateTimeField dateTimeField4 = gregorianChronology3.yearOfEra();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.weekyear();
        org.joda.time.DurationField durationField6 = gregorianChronology3.seconds();
        org.joda.time.DurationField durationField7 = gregorianChronology3.years();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(dateTimeField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int int4 = period3.getMonths();
        org.joda.time.Period period6 = period3.plusDays(8);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType8 = periodType7.withYearsRemoved();
        org.joda.time.PeriodType periodType9 = periodType7.withHoursRemoved();
        org.joda.time.PeriodType periodType10 = periodType9.withMillisRemoved();
        org.joda.time.PeriodType periodType11 = periodType9.withMonthsRemoved();
        try {
            org.joda.time.Period period12 = period6.withPeriodType(periodType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'days'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(periodType11);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        try {
            int int28 = unsupportedDurationField25.getDifference(1560629155109L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.halfdays();
        org.joda.time.DateTimeField dateTimeField5 = gregorianChronology3.millisOfSecond();
        org.joda.time.DateTimeField dateTimeField6 = gregorianChronology3.weekOfWeekyear();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) 100, (long) (short) 10);
        int[] intArray12 = gregorianChronology3.get((org.joda.time.ReadablePeriod) period9, 1560629155109L, (long) 'a');
        org.joda.time.Period period13 = period9.normalizedStandard();
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableInstant readableInstant15 = null;
        org.joda.time.ReadableDuration readableDuration16 = null;
        org.joda.time.ReadableInstant readableInstant17 = null;
        org.joda.time.PeriodType periodType18 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType19 = periodType18.withYearsRemoved();
        org.joda.time.Period period20 = new org.joda.time.Period(readableDuration16, readableInstant17, periodType18);
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant14, readableInstant15, periodType18);
        org.joda.time.Period period22 = period9.minus((org.joda.time.ReadablePeriod) period21);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period22);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.minusWeeks(0);
        org.joda.time.format.PeriodFormatter periodFormatter5 = null;
        java.lang.String str6 = period2.toString(periodFormatter5);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PT0S" + "'", str6.equals("PT0S"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period3.withYears(0);
        org.joda.time.Period period10 = period8.withSeconds((-1));
        org.joda.time.Period period12 = period10.plusSeconds(10);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        long long2 = org.joda.time.field.FieldUtils.safeMultiply((-1L), 800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-800L) + "'", long2 == (-800L));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 8);
        int int20 = offsetDateTimeField16.getMinimumValue((-210858379200000L));
        long long22 = offsetDateTimeField16.roundHalfEven((long) (-100));
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.ReadableInstant readableInstant26 = null;
        org.joda.time.ReadableInstant readableInstant27 = null;
        org.joda.time.PeriodType periodType29 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period30 = new org.joda.time.Period((long) (short) -1, periodType29);
        org.joda.time.Period period31 = new org.joda.time.Period(readableInstant26, readableInstant27, periodType29);
        org.joda.time.PeriodType periodType32 = periodType29.withMillisRemoved();
        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology36 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone35);
        org.joda.time.DurationField durationField37 = gregorianChronology36.centuries();
        org.joda.time.DurationField durationField38 = gregorianChronology36.years();
        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology42 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone41);
        boolean boolean44 = dateTimeZone41.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeUtils.getZone(dateTimeZone41);
        org.joda.time.chrono.ZonedChronology zonedChronology46 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology36, dateTimeZone45);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone51 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        org.joda.time.Chronology chronology52 = zonedChronology46.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone51);
        org.joda.time.Period period53 = new org.joda.time.Period((-3155759999989L), periodType29, (org.joda.time.Chronology) zonedChronology46);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone58 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        org.joda.time.Period period60 = org.joda.time.Period.weeks(0);
        boolean boolean61 = fixedDateTimeZone58.equals((java.lang.Object) period60);
        int[] intArray63 = zonedChronology46.get((org.joda.time.ReadablePeriod) period60, (long) (short) -1);
        try {
            int[] intArray65 = offsetDateTimeField16.addWrapPartial(readablePartial23, (-28378000), intArray63, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -28378000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-100L) + "'", long22 == (-100L));
        org.junit.Assert.assertNotNull(periodType29);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertNotNull(dateTimeZone35);
        org.junit.Assert.assertNotNull(gregorianChronology36);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(durationField38);
        org.junit.Assert.assertNotNull(dateTimeZone41);
        org.junit.Assert.assertNotNull(gregorianChronology42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(zonedChronology46);
        org.junit.Assert.assertNotNull(chronology52);
        org.junit.Assert.assertNotNull(period60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(intArray63);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((-3600000), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Offset is too large");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getMaximumValue((long) 'a');
        int int20 = offsetDateTimeField16.get((long) (-3600000));
        long long22 = offsetDateTimeField16.roundFloor((long) (-1));
        long long24 = offsetDateTimeField16.roundHalfEven(9972000000L);
        long long27 = offsetDateTimeField16.add((long) '4', (long) (-28378000));
        org.joda.time.DurationField durationField28 = offsetDateTimeField16.getDurationField();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86400000 + "'", int18 == 86400000);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10800001 + "'", int20 == 10800001);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9972000000L + "'", long24 == 9972000000L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + (-28377948L) + "'", long27 == (-28377948L));
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField1 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.weekOfWeekyear();
        org.joda.time.ReadableInstant readableInstant3 = null;
        org.joda.time.ReadableInstant readableInstant4 = null;
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period7 = new org.joda.time.Period((long) (short) -1, periodType6);
        org.joda.time.Period period8 = new org.joda.time.Period(readableInstant3, readableInstant4, periodType6);
        org.joda.time.PeriodType periodType9 = periodType6.withYearsRemoved();
        org.joda.time.PeriodType periodType10 = periodType6.withWeeksRemoved();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology14 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13);
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology14.yearOfEra();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology14.weekyear();
        try {
            org.joda.time.Period period17 = new org.joda.time.Period((java.lang.Object) iSOChronology0, periodType10, (org.joda.time.Chronology) gregorianChronology14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No period converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(durationField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(gregorianChronology14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        java.lang.String str3 = periodType1.getName();
        java.lang.String str4 = periodType1.getName();
        org.joda.time.Period period6 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant7, readableDuration8);
        org.joda.time.Period period11 = period9.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray12 = period9.getFieldTypes();
        org.joda.time.PeriodType periodType14 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period15 = new org.joda.time.Period((long) (short) -1, periodType14);
        org.joda.time.PeriodType periodType16 = periodType14.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType18 = periodType14.getFieldType((int) (short) 0);
        org.joda.time.Period period20 = period9.withFieldAdded(durationFieldType18, 0);
        int int21 = period6.get(durationFieldType18);
        int int22 = periodType1.indexOf(durationFieldType18);
        java.lang.String str23 = periodType1.toString();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Hours" + "'", str3.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Hours" + "'", str4.equals("Hours"));
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(durationFieldTypeArray12);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(durationFieldType18);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "PeriodType[Hours]" + "'", str23.equals("PeriodType[Hours]"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        long long18 = offsetDateTimeField16.roundHalfEven((long) (-28378000));
        long long20 = offsetDateTimeField16.roundFloor((-210858379200000L));
        long long22 = offsetDateTimeField16.roundHalfCeiling((long) (short) 1);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-28378000L) + "'", long18 == (-28378000L));
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-210858379200000L) + "'", long20 == (-210858379200000L));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1L + "'", long22 == 1L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DurationField durationField6 = gregorianChronology3.halfdays();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant7, readableInstant8);
        long long12 = gregorianChronology3.add((org.joda.time.ReadablePeriod) period9, (long) 97, 100);
        org.joda.time.DurationField durationField13 = gregorianChronology3.weeks();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology3.monthOfYear();
        org.joda.time.DateTimeField dateTimeField15 = gregorianChronology3.weekyear();
        org.joda.time.DateTimeField dateTimeField16 = gregorianChronology3.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertNotNull(durationField13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeField16);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((-1));
        org.joda.time.Period period6 = period4.minusSeconds((int) '4');
        int int7 = period4.getHours();
        org.joda.time.MutablePeriod mutablePeriod8 = period4.toMutablePeriod();
        org.joda.time.DurationFieldType[] durationFieldTypeArray9 = mutablePeriod8.getFieldTypes();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology13 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone12);
        boolean boolean15 = dateTimeZone12.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeUtils.getZone(dateTimeZone12);
        boolean boolean17 = mutablePeriod8.equals((java.lang.Object) dateTimeZone12);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(mutablePeriod8);
        org.junit.Assert.assertNotNull(durationFieldTypeArray9);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(gregorianChronology13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period6.minusMillis((int) (byte) -1);
        org.joda.time.Period period10 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period11 = period6.plus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period10.plusMillis((int) (byte) 1);
        org.joda.time.Period period15 = period10.plusMillis((int) (byte) 10);
        int int16 = period10.getMinutes();
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType18 = periodType17.withYearsRemoved();
        org.joda.time.PeriodType periodType19 = periodType17.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology23 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone22);
        org.joda.time.DateTimeField dateTimeField24 = gregorianChronology23.yearOfEra();
        org.joda.time.DateTimeField dateTimeField25 = gregorianChronology23.weekyear();
        int int26 = gregorianChronology23.getMinimumDaysInFirstWeek();
        try {
            org.joda.time.Period period27 = new org.joda.time.Period((java.lang.Object) period10, periodType19, (org.joda.time.Chronology) gregorianChronology23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Period does not support field 'seconds'");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(gregorianChronology23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeField25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        java.lang.String str39 = scaledDurationField33.toString();
        int int41 = scaledDurationField33.getValue((long) 187200000);
        long long43 = scaledDurationField33.getMillis((long) '#');
        int int44 = scaledDurationField33.getScalar();
        java.lang.String str45 = scaledDurationField33.toString();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[hours]" + "'", str39.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 5743365264000000L + "'", long43 == 5743365264000000L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 52 + "'", int44 == 52);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "DurationField[hours]" + "'", str45.equals("DurationField[hours]"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.Period period4 = new org.joda.time.Period((long) '4', (-1L), chronology3);
        int[] intArray5 = period4.getValues();
        org.joda.time.Period period6 = period4.normalizedStandard();
        org.joda.time.Duration duration7 = period6.toStandardDuration();
        long long8 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration7);
        org.joda.time.PeriodType periodType9 = null;
        org.joda.time.Period period10 = new org.joda.time.Period(readableInstant0, (org.joda.time.ReadableDuration) duration7, periodType9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.PeriodType periodType12 = org.joda.time.PeriodType.yearWeekDayTime();
        org.joda.time.Period period13 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration7, readableInstant11, periodType12);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(duration7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-53L) + "'", long8 == (-53L));
        org.junit.Assert.assertNotNull(periodType12);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period6.minusMillis((int) (byte) -1);
        org.joda.time.Period period10 = org.joda.time.Period.seconds((int) (byte) 10);
        org.joda.time.Period period11 = period6.plus((org.joda.time.ReadablePeriod) period10);
        org.joda.time.Period period13 = period10.plusMillis((int) (byte) 1);
        int int14 = period13.getYears();
        org.joda.time.Period period16 = period13.plusMinutes((-3600000));
        org.joda.time.Period period18 = period16.plusSeconds((int) 'a');
        org.joda.time.ReadablePeriod readablePeriod19 = null;
        org.joda.time.Period period20 = period16.withFields(readablePeriod19);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period11);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(period16);
        org.junit.Assert.assertNotNull(period18);
        org.junit.Assert.assertNotNull(period20);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        org.joda.time.DurationFieldType durationFieldType26 = unsupportedDurationField25.getType();
        java.lang.String str27 = unsupportedDurationField25.getName();
        try {
            long long30 = unsupportedDurationField25.getMillis((-1), (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertNotNull(durationFieldType26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "hours" + "'", str27.equals("hours"));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = offsetDateTimeField16.getMinimumValue(readablePartial23);
        long long27 = offsetDateTimeField16.add(1640961504000000L, (-53L));
        int int29 = offsetDateTimeField16.get(97L);
        long long31 = offsetDateTimeField16.roundFloor(8L);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1640961503999947L + "'", long27 == 1640961503999947L);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 14400098 + "'", int29 == 14400098);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 8L + "'", long31 == 8L);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
//        org.joda.time.DateTimeField dateTimeField3 = iSOChronology0.yearOfEra();
//        java.lang.String str4 = iSOChronology0.toString();
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(chronology2);
//        org.junit.Assert.assertNotNull(dateTimeField3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ISOChronology[+52:00]" + "'", str4.equals("ISOChronology[+52:00]"));
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "DurationField[hours]", "1");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "1", "PT0H");
        java.util.Locale locale9 = null;
        java.lang.String str12 = defaultNameProvider0.getName(locale9, "-01:00", "PT0H");
        java.util.Locale locale13 = null;
        java.lang.String str16 = defaultNameProvider0.getShortName(locale13, "", "DateTimeField[millisOfDay]");
        java.util.Locale locale17 = null;
        java.lang.String str20 = defaultNameProvider0.getShortName(locale17, "millisOfDay", "52");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(str12);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        long long18 = offsetDateTimeField16.roundHalfEven((long) (-28378000));
        org.joda.time.PeriodType periodType20 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType21 = periodType20.withYearsRemoved();
        org.joda.time.PeriodType periodType22 = periodType20.withHoursRemoved();
        org.joda.time.PeriodType periodType23 = periodType22.withMillisRemoved();
        org.joda.time.PeriodType periodType24 = periodType22.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone27);
        org.joda.time.DateTimeField dateTimeField29 = gregorianChronology28.yearOfEra();
        org.joda.time.DateTimeField dateTimeField30 = gregorianChronology28.secondOfMinute();
        org.joda.time.Period period31 = new org.joda.time.Period((long) 1, periodType22, (org.joda.time.Chronology) gregorianChronology28);
        org.joda.time.DateTimeZone dateTimeZone32 = gregorianChronology28.getZone();
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology28.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField35 = new org.joda.time.field.OffsetDateTimeField(dateTimeField33, (int) (byte) 1);
        int int37 = offsetDateTimeField35.getLeapAmount((long) 8);
        org.joda.time.DateTimeFieldType dateTimeFieldType38 = offsetDateTimeField35.getType();
        java.lang.Number number39 = null;
        org.joda.time.IllegalFieldValueException illegalFieldValueException42 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType38, number39, (java.lang.Number) 16409615040000000L, (java.lang.Number) (byte) 100);
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Wrapped field's minumum value must be zero");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-28378000L) + "'", long18 == (-28378000L));
        org.junit.Assert.assertNotNull(periodType20);
        org.junit.Assert.assertNotNull(periodType21);
        org.junit.Assert.assertNotNull(periodType22);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(gregorianChronology28);
        org.junit.Assert.assertNotNull(dateTimeField29);
        org.junit.Assert.assertNotNull(dateTimeField30);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType38);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period3.withYears(0);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.Period period15 = period13.minusSeconds((int) '4');
        int int16 = period13.getHours();
        org.joda.time.MutablePeriod mutablePeriod17 = period13.toMutablePeriod();
        org.joda.time.DurationFieldType[] durationFieldTypeArray18 = mutablePeriod17.getFieldTypes();
        org.joda.time.PeriodType periodType19 = org.joda.time.PeriodType.forFields(durationFieldTypeArray18);
        org.joda.time.Period period20 = period3.normalizedStandard(periodType19);
        org.joda.time.Minutes minutes21 = period3.toStandardMinutes();
        org.joda.time.Chronology chronology24 = null;
        org.joda.time.Period period25 = new org.joda.time.Period((long) '4', (-1L), chronology24);
        int[] intArray26 = period25.getValues();
        org.joda.time.Period period27 = period25.normalizedStandard();
        org.joda.time.Duration duration28 = period27.toStandardDuration();
        org.joda.time.Period period30 = period27.withWeeks(0);
        org.joda.time.PeriodType periodType32 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period33 = new org.joda.time.Period((long) (short) -1, periodType32);
        java.lang.String str34 = periodType32.getName();
        java.lang.String str35 = periodType32.getName();
        org.joda.time.Period period37 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant38 = null;
        org.joda.time.ReadableDuration readableDuration39 = null;
        org.joda.time.Period period40 = new org.joda.time.Period(readableInstant38, readableDuration39);
        org.joda.time.Period period42 = period40.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray43 = period40.getFieldTypes();
        org.joda.time.PeriodType periodType45 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period46 = new org.joda.time.Period((long) (short) -1, periodType45);
        org.joda.time.PeriodType periodType47 = periodType45.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType49 = periodType45.getFieldType((int) (short) 0);
        org.joda.time.Period period51 = period40.withFieldAdded(durationFieldType49, 0);
        int int52 = period37.get(durationFieldType49);
        int int53 = periodType32.indexOf(durationFieldType49);
        org.joda.time.IllegalFieldValueException illegalFieldValueException55 = new org.joda.time.IllegalFieldValueException(durationFieldType49, "PT0H");
        org.joda.time.Period period57 = period27.withFieldAdded(durationFieldType49, (-1));
        int int58 = period3.get(durationFieldType49);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(mutablePeriod17);
        org.junit.Assert.assertNotNull(durationFieldTypeArray18);
        org.junit.Assert.assertNotNull(periodType19);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(minutes21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(period27);
        org.junit.Assert.assertNotNull(duration28);
        org.junit.Assert.assertNotNull(period30);
        org.junit.Assert.assertNotNull(periodType32);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Hours" + "'", str34.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Hours" + "'", str35.equals("Hours"));
        org.junit.Assert.assertNotNull(period37);
        org.junit.Assert.assertNotNull(period42);
        org.junit.Assert.assertNotNull(durationFieldTypeArray43);
        org.junit.Assert.assertNotNull(periodType45);
        org.junit.Assert.assertNotNull(periodType47);
        org.junit.Assert.assertNotNull(durationFieldType49);
        org.junit.Assert.assertNotNull(period51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(period57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        boolean boolean11 = dateTimeZone8.isStandardOffset((long) (-1));
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeUtils.getZone(dateTimeZone8);
        org.joda.time.chrono.ZonedChronology zonedChronology13 = org.joda.time.chrono.ZonedChronology.getInstance((org.joda.time.Chronology) gregorianChronology3, dateTimeZone12);
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone18 = new org.joda.time.tz.FixedDateTimeZone("GregorianChronology[+52:00]", "PT0H", (-3600000), 520);
        org.joda.time.Chronology chronology19 = zonedChronology13.withZone((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        org.joda.time.DateTimeZone.setDefault((org.joda.time.DateTimeZone) fixedDateTimeZone18);
        int int22 = fixedDateTimeZone18.getOffsetFromLocal((long) (-25200000));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(zonedChronology13);
        org.junit.Assert.assertNotNull(chronology19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-3600000) + "'", int22 == (-3600000));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        boolean boolean4 = dateTimeZone1.isStandardOffset((long) 97);
        long long6 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getOffset(1560629155109L);
        org.joda.time.DateTimeZone dateTimeZone10 = cachedDateTimeZone7.getUncachedZone();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-3599999L) + "'", long6 == (-3599999L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3600000) + "'", int9 == (-3600000));
        org.junit.Assert.assertNotNull(dateTimeZone10);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        java.lang.String str39 = scaledDurationField33.toString();
        org.joda.time.DurationField durationField40 = scaledDurationField33.getWrappedField();
        int int43 = scaledDurationField33.getValue((-28799999L), (-210865982400000L));
        try {
            long long46 = scaledDurationField33.add(0L, (-28800051L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: -149760265200");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[hours]" + "'", str39.equals("DurationField[hours]"));
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 8);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField16.getAsShortText(0L, locale20);
        long long24 = offsetDateTimeField16.getDifferenceAsLong((long) 1, 1560629169769L);
        long long27 = offsetDateTimeField16.add((long) (-1), (int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType28 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField30 = new org.joda.time.field.RemainderDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType28, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "14400001" + "'", str21.equals("14400001"));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + (-1560629169768L) + "'", long24 == (-1560629169768L));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 34L + "'", long27 == 34L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long39 = scaledDurationField33.getValueAsLong((long) ' ', (long) 1);
        long long41 = scaledDurationField33.getMillis((-100));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-16409615040000000L) + "'", long41 == (-16409615040000000L));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getMaximumValue((long) 'a');
        int int20 = offsetDateTimeField16.get((long) (-3600000));
        long long22 = offsetDateTimeField16.roundFloor((long) (-1));
        long long24 = offsetDateTimeField16.roundHalfEven(9972000000L);
        java.util.Locale locale26 = null;
        java.lang.String str27 = offsetDateTimeField16.getAsShortText((-1L), locale26);
        long long29 = offsetDateTimeField16.roundFloor((long) 187200000);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86400000 + "'", int18 == 86400000);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10800001 + "'", int20 == 10800001);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 9972000000L + "'", long24 == 9972000000L);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "14400000" + "'", str27.equals("14400000"));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 187200000L + "'", long29 == 187200000L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.ReadableDuration readableDuration0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.PeriodType periodType2 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType3 = periodType2.withYearsRemoved();
        org.joda.time.Period period4 = new org.joda.time.Period(readableDuration0, readableInstant1, periodType2);
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.ReadableInstant readableInstant6 = null;
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType8 = periodType7.withYearsRemoved();
        org.joda.time.Period period9 = new org.joda.time.Period(readableDuration5, readableInstant6, periodType7);
        org.joda.time.Period period10 = period4.withPeriodType(periodType7);
        org.joda.time.Period period12 = period10.multipliedBy((int) (byte) -1);
        int int13 = period10.getMinutes();
        try {
            org.joda.time.Period period15 = period10.withDays(10800521);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Field is not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(period10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        org.joda.time.ReadablePartial readablePartial17 = null;
        int[] intArray21 = new int[] { 4, ' ', (byte) 1 };
        int int22 = offsetDateTimeField16.getMinimumValue(readablePartial17, intArray21);
        org.joda.time.ReadablePartial readablePartial23 = null;
        int int24 = offsetDateTimeField16.getMinimumValue(readablePartial23);
        org.joda.time.ReadablePartial readablePartial25 = null;
        int[] intArray28 = new int[] { (short) -1, (-25200000) };
        int int29 = offsetDateTimeField16.getMaximumValue(readablePartial25, intArray28);
        long long31 = offsetDateTimeField16.roundFloor(187200000L);
        org.joda.time.ReadablePartial readablePartial32 = null;
        java.util.Locale locale33 = null;
        try {
            java.lang.String str34 = offsetDateTimeField16.getAsText(readablePartial32, locale33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 86400000 + "'", int29 == 86400000);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 187200000L + "'", long31 == 187200000L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("10");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '10' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        org.joda.time.DurationField durationField5 = gregorianChronology3.years();
        org.joda.time.DurationField durationField6 = gregorianChronology3.halfdays();
        org.joda.time.ReadableInstant readableInstant7 = null;
        org.joda.time.ReadableInstant readableInstant8 = null;
        org.joda.time.Period period9 = new org.joda.time.Period(readableInstant7, readableInstant8);
        long long12 = gregorianChronology3.add((org.joda.time.ReadablePeriod) period9, (long) 97, 100);
        int int13 = period9.getMinutes();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(durationField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 97L + "'", long12 == 97L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.Period period1 = org.joda.time.Period.years(12);
        org.junit.Assert.assertNotNull(period1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        boolean boolean4 = dateTimeZone1.isStandardOffset((long) 97);
        long long6 = dateTimeZone1.convertUTCToLocal((long) (byte) 1);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone7 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone1);
        int int9 = cachedDateTimeZone7.getOffset(1560629155109L);
        boolean boolean10 = cachedDateTimeZone7.isFixed();
        long long12 = cachedDateTimeZone7.nextTransition((-3600000L));
        org.joda.time.DateTimeZone dateTimeZone13 = cachedDateTimeZone7.getUncachedZone();
        java.lang.String str15 = cachedDateTimeZone7.getNameKey((long) (short) 10);
        long long17 = cachedDateTimeZone7.nextTransition(0L);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-3599999L) + "'", long6 == (-3599999L));
        org.junit.Assert.assertNotNull(cachedDateTimeZone7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-3600000) + "'", int9 == (-3600000));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-3600000L) + "'", long12 == (-3600000L));
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "PT0H" + "'", str15.equals("PT0H"));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("hours");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"hours/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@3ad6a0e0");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        java.lang.String str39 = scaledDurationField33.toString();
        int int41 = scaledDurationField33.getValue((long) 187200000);
        long long43 = scaledDurationField33.getMillis((long) '#');
        int int44 = scaledDurationField33.getScalar();
        org.joda.time.DurationField durationField45 = scaledDurationField33.getWrappedField();
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[hours]" + "'", str39.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 5743365264000000L + "'", long43 == 5743365264000000L);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 52 + "'", int44 == 52);
        org.junit.Assert.assertNotNull(durationField45);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.Period period3 = new org.joda.time.Period((long) '4', (-1L), chronology2);
        int[] intArray4 = period3.getValues();
        org.joda.time.Period period6 = period3.minusDays((int) 'a');
        org.joda.time.Period period8 = period3.withMillis(10);
        org.joda.time.Period period10 = period8.withWeeks((int) (short) 10);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period10);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        boolean boolean26 = unsupportedDurationField25.isPrecise();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Period period2 = new org.joda.time.Period(readableInstant0, readableDuration1);
        org.joda.time.Period period4 = period2.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray5 = period2.getFieldTypes();
        org.joda.time.PeriodType periodType6 = org.joda.time.PeriodType.forFields(durationFieldTypeArray5);
        org.joda.time.PeriodType periodType7 = periodType6.withHoursRemoved();
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(durationFieldTypeArray5);
        org.junit.Assert.assertNotNull(periodType6);
        org.junit.Assert.assertNotNull(periodType7);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.Chronology chronology2 = iSOChronology0.withZone(dateTimeZone1);
        org.joda.time.chrono.ISOChronology iSOChronology3 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone1);
        org.joda.time.ReadablePartial readablePartial4 = null;
        try {
            long long6 = iSOChronology3.set(readablePartial4, (long) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(chronology2);
        org.junit.Assert.assertNotNull(iSOChronology3);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withMillisRemoved();
        try {
            org.joda.time.Period period3 = new org.joda.time.Period(85329998208000000L, periodType1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 23702777280");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        long long11 = durationField4.subtract(0L, (long) 8);
        try {
            long long14 = durationField4.subtract((long) 52, (-28800051L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Value cannot fit in an int: 2880005100");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-25245561600000L) + "'", long11 == (-25245561600000L));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getMaximumValue((long) 'a');
        int int20 = offsetDateTimeField16.get((long) (-3600000));
        long long22 = offsetDateTimeField16.roundFloor((long) (-1));
        org.joda.time.ReadablePartial readablePartial23 = null;
        org.joda.time.Chronology chronology27 = null;
        org.joda.time.Period period28 = new org.joda.time.Period((long) '4', (-1L), chronology27);
        int[] intArray29 = period28.getValues();
        try {
            int[] intArray31 = offsetDateTimeField16.set(readablePartial23, (int) (byte) 1, intArray29, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86400000 + "'", int18 == 86400000);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10800001 + "'", int20 == 10800001);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-1L) + "'", long22 == (-1L));
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        java.lang.String str39 = scaledDurationField33.toString();
        long long42 = scaledDurationField33.add((-1L), (long) '#');
        long long45 = scaledDurationField33.add((-16409615040000000L), (int) ' ');
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[hours]" + "'", str39.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 5743365263999999L + "'", long42 == 5743365263999999L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-11158538227200000L) + "'", long45 == (-11158538227200000L));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.ReadableInstant readableInstant0 = null;
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.ReadableInstant readableInstant2 = null;
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.Period period6 = new org.joda.time.Period((long) '4', (-1L), chronology5);
        int[] intArray7 = period6.getValues();
        org.joda.time.Period period8 = period6.normalizedStandard();
        org.joda.time.Duration duration9 = period8.toStandardDuration();
        long long10 = org.joda.time.DateTimeUtils.getDurationMillis((org.joda.time.ReadableDuration) duration9);
        org.joda.time.ReadableInstant readableInstant11 = null;
        org.joda.time.Period period12 = new org.joda.time.Period((org.joda.time.ReadableDuration) duration9, readableInstant11);
        org.joda.time.ReadableInstant readableInstant13 = null;
        org.joda.time.ReadableInstant readableInstant14 = null;
        org.joda.time.ReadableDuration readableDuration15 = null;
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.PeriodType periodType17 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType18 = periodType17.withYearsRemoved();
        org.joda.time.Period period19 = new org.joda.time.Period(readableDuration15, readableInstant16, periodType17);
        org.joda.time.Period period20 = new org.joda.time.Period(readableInstant13, readableInstant14, periodType17);
        org.joda.time.Period period21 = new org.joda.time.Period(readableInstant2, (org.joda.time.ReadableDuration) duration9, periodType17);
        org.joda.time.Period period22 = new org.joda.time.Period(readableInstant0, readableDuration1, periodType17);
        org.joda.time.PeriodType periodType23 = periodType17.withMonthsRemoved();
        org.joda.time.PeriodType periodType24 = periodType23.withMinutesRemoved();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(duration9);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-53L) + "'", long10 == (-53L));
        org.junit.Assert.assertNotNull(periodType17);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType24);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("hi!", (java.lang.Number) 1, (java.lang.Number) 0, (java.lang.Number) 10.0d);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        boolean boolean6 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        org.joda.time.PeriodType periodType8 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period9 = new org.joda.time.Period((long) (short) -1, periodType8);
        org.joda.time.PeriodType periodType10 = periodType8.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType12 = periodType8.getFieldType((int) (short) 0);
        org.joda.time.IllegalFieldValueException illegalFieldValueException16 = new org.joda.time.IllegalFieldValueException(durationFieldType12, (java.lang.Number) 10.0f, (java.lang.Number) 9L, (java.lang.Number) (byte) -1);
        java.lang.String str17 = illegalFieldValueException16.getFieldName();
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalFieldValueException16);
        java.lang.Number number19 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "1" + "'", str5.equals("1"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(periodType8);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertNotNull(durationFieldType12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "hours" + "'", str17.equals("hours"));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0 + "'", number19.equals(0));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder0 = new org.joda.time.tz.DateTimeZoneBuilder();
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder3 = dateTimeZoneBuilder0.setFixedSavings("org.joda.time.IllegalFieldValueException: Hours: Value 1 for hi! must be in the range [0,10.0]", (int) '4');
        org.joda.time.tz.DateTimeZoneBuilder dateTimeZoneBuilder5 = dateTimeZoneBuilder0.setStandardOffset((int) '#');
        org.joda.time.DateTimeZone dateTimeZone8 = dateTimeZoneBuilder5.toDateTimeZone("Hours", true);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder3);
        org.junit.Assert.assertNotNull(dateTimeZoneBuilder5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.halfdays();
        long long7 = durationField4.subtract(164096150400000L, 100);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 164091830400000L + "'", long7 == 164091830400000L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology3 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone2);
        org.joda.time.DurationField durationField4 = gregorianChronology3.centuries();
        java.lang.Class<?> wildcardClass5 = durationField4.getClass();
        long long8 = durationField4.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType10 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period11 = new org.joda.time.Period((long) (short) -1, periodType10);
        java.lang.String str12 = periodType10.getName();
        java.lang.String str13 = periodType10.getName();
        org.joda.time.Period period15 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant16 = null;
        org.joda.time.ReadableDuration readableDuration17 = null;
        org.joda.time.Period period18 = new org.joda.time.Period(readableInstant16, readableDuration17);
        org.joda.time.Period period20 = period18.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray21 = period18.getFieldTypes();
        org.joda.time.PeriodType periodType23 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period24 = new org.joda.time.Period((long) (short) -1, periodType23);
        org.joda.time.PeriodType periodType25 = periodType23.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType27 = periodType23.getFieldType((int) (short) 0);
        org.joda.time.Period period29 = period18.withFieldAdded(durationFieldType27, 0);
        int int30 = period15.get(durationFieldType27);
        int int31 = periodType10.indexOf(durationFieldType27);
        org.joda.time.field.ScaledDurationField scaledDurationField33 = new org.joda.time.field.ScaledDurationField(durationField4, durationFieldType27, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField35 = iSOChronology34.hours();
        int int36 = scaledDurationField33.compareTo(durationField35);
        long long38 = scaledDurationField33.getValueAsLong((long) '#');
        java.lang.String str39 = scaledDurationField33.toString();
        org.joda.time.DurationField durationField40 = scaledDurationField33.getWrappedField();
        long long43 = scaledDurationField33.add(0L, (long) (byte) 10);
        long long45 = scaledDurationField33.getValueAsLong((-210816043200000L));
        org.joda.time.DateTimeZone dateTimeZone48 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology49 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone48);
        org.joda.time.DurationField durationField50 = gregorianChronology49.centuries();
        java.lang.Class<?> wildcardClass51 = durationField50.getClass();
        long long54 = durationField50.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType56 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period57 = new org.joda.time.Period((long) (short) -1, periodType56);
        java.lang.String str58 = periodType56.getName();
        java.lang.String str59 = periodType56.getName();
        org.joda.time.Period period61 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant62 = null;
        org.joda.time.ReadableDuration readableDuration63 = null;
        org.joda.time.Period period64 = new org.joda.time.Period(readableInstant62, readableDuration63);
        org.joda.time.Period period66 = period64.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray67 = period64.getFieldTypes();
        org.joda.time.PeriodType periodType69 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period70 = new org.joda.time.Period((long) (short) -1, periodType69);
        org.joda.time.PeriodType periodType71 = periodType69.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType73 = periodType69.getFieldType((int) (short) 0);
        org.joda.time.Period period75 = period64.withFieldAdded(durationFieldType73, 0);
        int int76 = period61.get(durationFieldType73);
        int int77 = periodType56.indexOf(durationFieldType73);
        org.joda.time.field.ScaledDurationField scaledDurationField79 = new org.joda.time.field.ScaledDurationField(durationField50, durationFieldType73, (int) '4');
        org.joda.time.chrono.ISOChronology iSOChronology80 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DurationField durationField81 = iSOChronology80.hours();
        int int82 = scaledDurationField79.compareTo(durationField81);
        java.lang.String str83 = scaledDurationField79.toString();
        long long86 = scaledDurationField79.getMillis((long) (short) 1, (long) '4');
        int int87 = scaledDurationField33.compareTo((org.joda.time.DurationField) scaledDurationField79);
        int int90 = scaledDurationField79.getValue(0L, (-3500L));
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(gregorianChronology3);
        org.junit.Assert.assertNotNull(durationField4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 3155759999999L + "'", long8 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Hours" + "'", str12.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Hours" + "'", str13.equals("Hours"));
        org.junit.Assert.assertNotNull(period15);
        org.junit.Assert.assertNotNull(period20);
        org.junit.Assert.assertNotNull(durationFieldTypeArray21);
        org.junit.Assert.assertNotNull(periodType23);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(durationFieldType27);
        org.junit.Assert.assertNotNull(period29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(iSOChronology34);
        org.junit.Assert.assertNotNull(durationField35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DurationField[hours]" + "'", str39.equals("DurationField[hours]"));
        org.junit.Assert.assertNotNull(durationField40);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1640961504000000L + "'", long43 == 1640961504000000L);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + (-1L) + "'", long45 == (-1L));
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(gregorianChronology49);
        org.junit.Assert.assertNotNull(durationField50);
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 3155759999999L + "'", long54 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "Hours" + "'", str58.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Hours" + "'", str59.equals("Hours"));
        org.junit.Assert.assertNotNull(period61);
        org.junit.Assert.assertNotNull(period66);
        org.junit.Assert.assertNotNull(durationFieldTypeArray67);
        org.junit.Assert.assertNotNull(periodType69);
        org.junit.Assert.assertNotNull(periodType71);
        org.junit.Assert.assertNotNull(durationFieldType73);
        org.junit.Assert.assertNotNull(period75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(iSOChronology80);
        org.junit.Assert.assertNotNull(durationField81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1 + "'", int82 == 1);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "DurationField[hours]" + "'", str83.equals("DurationField[hours]"));
        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 164096150400000L + "'", long86 == 164096150400000L);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getLeapAmount((long) 8);
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField16.getAsShortText(0L, locale20);
        java.util.Locale locale23 = null;
        java.lang.String str24 = offsetDateTimeField16.getAsShortText((long) 0, locale23);
        boolean boolean25 = offsetDateTimeField16.isSupported();
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "14400001" + "'", str21.equals("14400001"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "14400001" + "'", str24.equals("14400001"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.joda.time.Period period1 = org.joda.time.Period.seconds((int) ' ');
        org.joda.time.Period period3 = period1.withMonths((-1));
        org.joda.time.Period period5 = period3.plusMillis(0);
        org.joda.time.PeriodType periodType7 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period8 = new org.joda.time.Period((long) (short) -1, periodType7);
        org.joda.time.PeriodType periodType9 = periodType7.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType11 = periodType7.getFieldType((int) (short) 0);
        org.joda.time.field.PreciseDurationField preciseDurationField13 = new org.joda.time.field.PreciseDurationField(durationFieldType11, (long) (byte) -1);
        org.joda.time.Period period15 = period5.withFieldAdded(durationFieldType11, 8);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(period5);
        org.junit.Assert.assertNotNull(periodType7);
        org.junit.Assert.assertNotNull(periodType9);
        org.junit.Assert.assertNotNull(durationFieldType11);
        org.junit.Assert.assertNotNull(period15);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.chrono.GregorianChronology gregorianChronology0 = org.joda.time.chrono.GregorianChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = gregorianChronology0.clockhourOfDay();
        org.joda.time.DurationField durationField2 = gregorianChronology0.millis();
        org.junit.Assert.assertNotNull(gregorianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(durationField2);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period3 = period2.normalizedStandard();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology7 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField8 = gregorianChronology7.yearOfEra();
        boolean boolean9 = period2.equals((java.lang.Object) gregorianChronology7);
        try {
            long long14 = gregorianChronology7.getDateTimeMillis(100, (-53), 14400098, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(gregorianChronology7);
        org.junit.Assert.assertNotNull(dateTimeField8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period2 = new org.joda.time.Period((long) (short) -1, periodType1);
        org.joda.time.Period period4 = period2.minusMinutes((int) (short) 0);
        org.joda.time.Period period6 = period4.minusSeconds((int) (short) 0);
        org.joda.time.Period period8 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant9 = null;
        org.joda.time.ReadableDuration readableDuration10 = null;
        org.joda.time.Period period11 = new org.joda.time.Period(readableInstant9, readableDuration10);
        org.joda.time.Period period13 = period11.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray14 = period11.getFieldTypes();
        org.joda.time.PeriodType periodType16 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period17 = new org.joda.time.Period((long) (short) -1, periodType16);
        org.joda.time.PeriodType periodType18 = periodType16.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType20 = periodType16.getFieldType((int) (short) 0);
        org.joda.time.Period period22 = period11.withFieldAdded(durationFieldType20, 0);
        int int23 = period8.get(durationFieldType20);
        boolean boolean24 = period6.isSupported(durationFieldType20);
        org.joda.time.field.UnsupportedDurationField unsupportedDurationField25 = org.joda.time.field.UnsupportedDurationField.getInstance(durationFieldType20);
        long long26 = unsupportedDurationField25.getUnitMillis();
        try {
            int int28 = unsupportedDurationField25.getValue(0L);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: hours field is unsupported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(period4);
        org.junit.Assert.assertNotNull(period6);
        org.junit.Assert.assertNotNull(period8);
        org.junit.Assert.assertNotNull(period13);
        org.junit.Assert.assertNotNull(durationFieldTypeArray14);
        org.junit.Assert.assertNotNull(periodType16);
        org.junit.Assert.assertNotNull(periodType18);
        org.junit.Assert.assertNotNull(durationFieldType20);
        org.junit.Assert.assertNotNull(period22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(unsupportedDurationField25);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.joda.time.Period period1 = org.joda.time.Period.minutes(187200000);
        org.joda.time.Period period3 = period1.withWeeks(10800001);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.Period period7 = new org.joda.time.Period((long) '4', (-1L), chronology6);
        int[] intArray8 = period7.getValues();
        org.joda.time.Period period9 = period7.normalizedStandard();
        org.joda.time.Duration duration10 = period9.toStandardDuration();
        org.joda.time.Period period12 = period9.withWeeks(0);
        org.joda.time.PeriodType periodType13 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType14 = periodType13.withYearsRemoved();
        org.joda.time.PeriodType periodType15 = periodType13.withHoursRemoved();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology19 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField20 = gregorianChronology19.centuries();
        java.lang.Class<?> wildcardClass21 = durationField20.getClass();
        long long24 = durationField20.subtract((long) (short) -1, (int) (byte) -1);
        org.joda.time.PeriodType periodType26 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period27 = new org.joda.time.Period((long) (short) -1, periodType26);
        java.lang.String str28 = periodType26.getName();
        java.lang.String str29 = periodType26.getName();
        org.joda.time.Period period31 = org.joda.time.Period.millis((int) (byte) 100);
        org.joda.time.ReadableInstant readableInstant32 = null;
        org.joda.time.ReadableDuration readableDuration33 = null;
        org.joda.time.Period period34 = new org.joda.time.Period(readableInstant32, readableDuration33);
        org.joda.time.Period period36 = period34.plusWeeks((-1));
        org.joda.time.DurationFieldType[] durationFieldTypeArray37 = period34.getFieldTypes();
        org.joda.time.PeriodType periodType39 = org.joda.time.PeriodType.hours();
        org.joda.time.Period period40 = new org.joda.time.Period((long) (short) -1, periodType39);
        org.joda.time.PeriodType periodType41 = periodType39.withMonthsRemoved();
        org.joda.time.DurationFieldType durationFieldType43 = periodType39.getFieldType((int) (short) 0);
        org.joda.time.Period period45 = period34.withFieldAdded(durationFieldType43, 0);
        int int46 = period31.get(durationFieldType43);
        int int47 = periodType26.indexOf(durationFieldType43);
        org.joda.time.field.ScaledDurationField scaledDurationField49 = new org.joda.time.field.ScaledDurationField(durationField20, durationFieldType43, (int) '4');
        int int50 = periodType15.indexOf(durationFieldType43);
        boolean boolean51 = period12.isSupported(durationFieldType43);
        int int52 = period1.indexOf(durationFieldType43);
        org.junit.Assert.assertNotNull(period1);
        org.junit.Assert.assertNotNull(period3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(period9);
        org.junit.Assert.assertNotNull(duration10);
        org.junit.Assert.assertNotNull(period12);
        org.junit.Assert.assertNotNull(periodType13);
        org.junit.Assert.assertNotNull(periodType14);
        org.junit.Assert.assertNotNull(periodType15);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(gregorianChronology19);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3155759999999L + "'", long24 == 3155759999999L);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Hours" + "'", str28.equals("Hours"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Hours" + "'", str29.equals("Hours"));
        org.junit.Assert.assertNotNull(period31);
        org.junit.Assert.assertNotNull(period36);
        org.junit.Assert.assertNotNull(durationFieldTypeArray37);
        org.junit.Assert.assertNotNull(periodType39);
        org.junit.Assert.assertNotNull(periodType41);
        org.junit.Assert.assertNotNull(durationFieldType43);
        org.junit.Assert.assertNotNull(period45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.PeriodType periodType1 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType2 = periodType1.withYearsRemoved();
        org.joda.time.PeriodType periodType3 = periodType1.withHoursRemoved();
        org.joda.time.PeriodType periodType4 = periodType3.withMillisRemoved();
        org.joda.time.PeriodType periodType5 = periodType3.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology9 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone8);
        org.joda.time.DateTimeField dateTimeField10 = gregorianChronology9.yearOfEra();
        org.joda.time.DateTimeField dateTimeField11 = gregorianChronology9.secondOfMinute();
        org.joda.time.Period period12 = new org.joda.time.Period((long) 1, periodType3, (org.joda.time.Chronology) gregorianChronology9);
        org.joda.time.DateTimeZone dateTimeZone13 = gregorianChronology9.getZone();
        org.joda.time.DateTimeField dateTimeField14 = gregorianChronology9.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField16 = new org.joda.time.field.OffsetDateTimeField(dateTimeField14, (int) (byte) 1);
        int int18 = offsetDateTimeField16.getMaximumValue((long) 'a');
        java.util.Locale locale20 = null;
        java.lang.String str21 = offsetDateTimeField16.getAsShortText(1L, locale20);
        java.lang.String str22 = offsetDateTimeField16.toString();
        org.joda.time.PeriodType periodType24 = org.joda.time.PeriodType.hours();
        org.joda.time.PeriodType periodType25 = periodType24.withYearsRemoved();
        org.joda.time.PeriodType periodType26 = periodType24.withHoursRemoved();
        org.joda.time.PeriodType periodType27 = periodType26.withMillisRemoved();
        org.joda.time.PeriodType periodType28 = periodType26.withYearsRemoved();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.forOffsetHoursMinutes((int) '4', 0);
        org.joda.time.chrono.GregorianChronology gregorianChronology32 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone31);
        org.joda.time.DateTimeField dateTimeField33 = gregorianChronology32.yearOfEra();
        org.joda.time.DateTimeField dateTimeField34 = gregorianChronology32.secondOfMinute();
        org.joda.time.Period period35 = new org.joda.time.Period((long) 1, periodType26, (org.joda.time.Chronology) gregorianChronology32);
        org.joda.time.DateTimeZone dateTimeZone36 = gregorianChronology32.getZone();
        org.joda.time.DateTimeField dateTimeField37 = gregorianChronology32.millisOfDay();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField39 = new org.joda.time.field.OffsetDateTimeField(dateTimeField37, (int) (byte) 1);
        int int41 = offsetDateTimeField39.getLeapAmount((long) 8);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = offsetDateTimeField39.getType();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField16, dateTimeFieldType42, 10, (int) (short) 1, (int) (short) 10);
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType42, (java.lang.Number) 9L, (java.lang.Number) (-28377948L), (java.lang.Number) (-1312769203200000L));
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
        org.junit.Assert.assertNotNull(periodType5);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(gregorianChronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
        org.junit.Assert.assertNotNull(dateTimeField11);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 86400000 + "'", int18 == 86400000);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "14400002" + "'", str21.equals("14400002"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "DateTimeField[millisOfDay]" + "'", str22.equals("DateTimeField[millisOfDay]"));
        org.junit.Assert.assertNotNull(periodType24);
        org.junit.Assert.assertNotNull(periodType25);
        org.junit.Assert.assertNotNull(periodType26);
        org.junit.Assert.assertNotNull(periodType27);
        org.junit.Assert.assertNotNull(periodType28);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(gregorianChronology32);
        org.junit.Assert.assertNotNull(dateTimeField33);
        org.junit.Assert.assertNotNull(dateTimeField34);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dateTimeFieldType42);
    }
}

