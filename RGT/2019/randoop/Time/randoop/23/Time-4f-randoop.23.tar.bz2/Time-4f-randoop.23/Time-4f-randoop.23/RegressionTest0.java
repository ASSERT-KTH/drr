import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DurationField durationField1 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType2 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField4 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, durationField1, dateTimeFieldType2, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, 0L, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.ReadableDateTime readableDateTime1 = null;
        org.joda.time.ReadableDateTime readableDateTime2 = null;
        try {
            org.joda.time.chrono.LimitChronology limitChronology3 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, readableDateTime1, readableDateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(1, (int) (short) 10, (int) (short) -1, (int) 'a', (int) (short) 10, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 97 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int1 = org.joda.time.field.FieldUtils.safeNegate(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 100, (java.lang.Number) 100, (java.lang.Number) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.joda.time.DateTimeField dateTimeField0 = null;
        try {
            org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField1 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalTime localTime5 = null;
        try {
            org.joda.time.LocalDateTime localDateTime6 = localDate2.toLocalDateTime(localTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.DateTime dateTime8 = new org.joda.time.DateTime((int) (short) 1, (int) '#', (int) ' ', (int) (short) -1, 2000, 0, (int) '4', dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField2 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField0, dateTimeFieldType1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.io.Writer writer1 = null;
        try {
            dateTimeFormatter0.printTo(writer1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        try {
            org.joda.time.DateTime dateTime8 = dateTime1.withMonthOfYear((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.DateTimeField dateTimeField2 = null;
        try {
            org.joda.time.field.SkipDateTimeField skipDateTimeField3 = new org.joda.time.field.SkipDateTimeField(chronology1, dateTimeField2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.DateTime.Property property3 = dateTime1.weekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime5.getZone();
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime5.toYearMonthDay();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 10, chronology9);
        boolean boolean11 = yearMonthDay7.isBefore((org.joda.time.ReadablePartial) localDate10);
        try {
            int int12 = property3.compareTo((org.joda.time.ReadablePartial) yearMonthDay7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'weekOfWeekyear' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, (long) 0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        java.lang.Appendable appendable1 = null;
        org.joda.time.ReadablePartial readablePartial2 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, readablePartial2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The partial must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        try {
            org.joda.time.DateTime dateTime4 = dateTimeFormatter0.parseDateTime("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"hi!\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeParser2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getMonthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.Chronology chronology3 = dateTimeFormatter0.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNull(chronology3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(2000, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 2000");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.Chronology chronology3 = null;
        org.joda.time.LocalDate localDate4 = new org.joda.time.LocalDate((long) (short) 10, chronology3);
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = localDate4.toDateTimeAtMidnight(dateTimeZone5);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadablePartial) localDate4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        boolean boolean7 = dateTime1.isEqualNow();
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        long long9 = property8.remainder();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 58L + "'", long9 == 58L);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate.Property property8 = localDate6.dayOfYear();
        org.joda.time.LocalDate localDate9 = property8.roundHalfFloorCopy();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            org.joda.time.LocalDate.Property property11 = localDate9.property(dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate.Property property5 = localDate2.year();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) localDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No instant converter found for type: org.joda.time.LocalDate");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        try {
            org.joda.time.Instant instant1 = org.joda.time.Instant.parse("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalTime localTime5 = null;
        try {
            org.joda.time.LocalDateTime localDateTime6 = localDate4.toLocalDateTime(localTime5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 9, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-91L) + "'", long2 == (-91L));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Interval interval6 = localDate2.toInterval(dateTimeZone5);
        org.joda.time.LocalDate.Property property7 = localDate2.weekyear();
        org.joda.time.DateMidnight dateMidnight8 = localDate2.toDateMidnight();
        try {
            java.lang.String str10 = localDate2.toString("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateMidnight8);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        org.joda.time.DateTimeFieldType dateTimeFieldType5 = null;
        try {
            org.joda.time.LocalDate localDate7 = localDate2.withField(dateTimeFieldType5, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test038");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 10, chronology14);
//        org.joda.time.LocalDate localDate17 = localDate15.plusWeeks(0);
//        org.joda.time.LocalDate.Property property18 = localDate15.year();
//        org.joda.time.DateTime dateTime19 = localDate15.toDateTimeAtMidnight();
//        int[] intArray21 = new int[] { 2000 };
//        try {
//            gJChronology11.validate((org.joda.time.ReadablePartial) localDate15, intArray21);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 166 + "'", int9 == 166);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(localDate17);
//        org.junit.Assert.assertNotNull(property18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(intArray21);
//    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        try {
            org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: name can't be empty");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = dateTime6.toString("hi!", locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: i");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        java.lang.Appendable appendable2 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 10, chronology4);
        org.joda.time.LocalDate localDate7 = localDate5.plusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Interval interval9 = localDate5.toInterval(dateTimeZone8);
        org.joda.time.LocalDate.Property property10 = localDate5.weekyear();
        org.joda.time.DateMidnight dateMidnight11 = localDate5.toDateMidnight();
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadablePartial) localDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateMidnight11);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 10, chronology2);
        org.joda.time.LocalDate localDate5 = localDate3.plusWeeks(0);
        org.joda.time.LocalDate.Property property6 = localDate3.year();
        org.joda.time.DateTime dateTime7 = localDate3.toDateTimeAtMidnight();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTime dateTime14 = dateTime9.withFields((org.joda.time.ReadablePartial) yearMonthDay13);
        try {
            org.joda.time.chrono.LimitChronology limitChronology15 = org.joda.time.chrono.LimitChronology.getInstance(chronology0, (org.joda.time.ReadableDateTime) dateTime7, (org.joda.time.ReadableDateTime) dateTime14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Must supply a chronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate5);
        org.junit.Assert.assertNotNull(property6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(dateTime14);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.joda.time.DateTimeUtils.toJulianDay((long) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2440587.500000081d + "'", double1 == 2440587.500000081d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 9");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        boolean boolean7 = dateTime1.isEqualNow();
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTimeField dateTimeField9 = property8.getField();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeField9);
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        boolean boolean7 = dateTime1.isEqualNow();
//        org.joda.time.DateTime dateTime8 = dateTime1.withEarlierOffsetAtOverlap();
//        java.lang.String str9 = dateTime1.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2019-06-15T16:08:12.898-07:00" + "'", str9.equals("2019-06-15T16:08:12.898-07:00"));
//    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test048");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        boolean boolean7 = dateTime1.isEqualNow();
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 10, chronology10);
//        org.joda.time.DateTimeFieldType dateTimeFieldType12 = null;
//        int int13 = localDate11.indexOf(dateTimeFieldType12);
//        try {
//            int int14 = property8.compareTo((org.joda.time.ReadablePartial) localDate11);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'secondOfDay' is not supported");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
//    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType14 = null;
//        try {
//            org.joda.time.field.OffsetDateTimeField offsetDateTimeField18 = new org.joda.time.field.OffsetDateTimeField(dateTimeField13, dateTimeFieldType14, (int) (byte) 10, (-1), 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 166 + "'", int9 == 166);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        org.joda.time.DateTime dateTime8 = dateTime6.withDayOfYear((int) '#');
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            int int10 = dateTime8.get(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        try {
            org.joda.time.LocalDate localDate8 = localDate2.withDayOfWeek(100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "hi!", "2019-06-15T16:08:12.898-07:00");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        int int2 = dateTime1.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
//        try {
//            org.joda.time.DateTime dateTime9 = property7.setCopy("2019-06-15T16:08:12.898-07:00");
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T16:08:12.898-07:00\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 166 + "'", int2 == 166);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        int int0 = org.joda.time.chrono.CopticChronology.AM;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        java.lang.Number number2 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) (short) 100, number2, (java.lang.Number) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getDayOfYear();
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField26 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
//        int int29 = skipDateTimeField28.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
//        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
//        org.joda.time.Chronology chronology35 = null;
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
//        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
//        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
//        org.joda.time.DurationField durationField42 = null;
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField45 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField28, durationField42, dateTimeFieldType43, (int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 166 + "'", int9 == 166);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(yearMonthDay17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 166 + "'", int23 == 166);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-25200000) + "'", int24 == (-25200000));
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(yearMonthDay33);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
//    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        boolean boolean7 = dateTime1.isEqualNow();
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        try {
//            org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((java.lang.Object) property8);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.DateTime$Property");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(property8);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.field.PreciseDurationField preciseDurationField2 = new org.joda.time.field.PreciseDurationField(durationFieldType0, (long) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((int) (byte) 1, 166, (int) 'a', (int) '4', 0, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 52 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = null;
        try {
            int int9 = yearMonthDay3.get(dateTimeFieldType8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test062");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getDayOfYear();
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField26 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
//        org.joda.time.YearMonthDay yearMonthDay32 = dateTime30.toYearMonthDay();
//        org.joda.time.chrono.ISOChronology iSOChronology34 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        long long38 = iSOChronology34.add(readablePeriod35, (long) 58089, 6);
//        org.joda.time.DateTimeField dateTimeField39 = iSOChronology34.secondOfMinute();
//        org.joda.time.Chronology chronology41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (short) 10, chronology41);
//        org.joda.time.LocalDate localDate44 = localDate42.plusWeeks(0);
//        org.joda.time.LocalDate localDate46 = localDate44.withDayOfYear((int) (byte) 100);
//        int[] intArray48 = iSOChronology34.get((org.joda.time.ReadablePartial) localDate44, 0L);
//        java.util.Locale locale50 = null;
//        try {
//            int[] intArray51 = skipDateTimeField28.set((org.joda.time.ReadablePartial) yearMonthDay32, 8, intArray48, "2019-06-15T16:08:12.898-07:00", locale50);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"2019-06-15T16:08:12.898-07:00\" for dayOfMonth is not supported");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 166 + "'", int9 == 166);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(yearMonthDay17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 166 + "'", int23 == 166);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-25200000) + "'", int24 == (-25200000));
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(yearMonthDay32);
//        org.junit.Assert.assertNotNull(iSOChronology34);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 58089L + "'", long38 == 58089L);
//        org.junit.Assert.assertNotNull(dateTimeField39);
//        org.junit.Assert.assertNotNull(localDate44);
//        org.junit.Assert.assertNotNull(localDate46);
//        org.junit.Assert.assertNotNull(intArray48);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendUnpaddedInteger(stringBuffer0, 58092);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test064");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        int int4 = dateTime1.getWeekOfWeekyear();
//        org.joda.time.DateTime dateTime6 = dateTime1.withMillisOfSecond(0);
//        org.joda.time.DateTime.Property property7 = dateTime6.weekOfWeekyear();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 58095 + "'", int2 == 58095);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 24 + "'", int4 == 24);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(property7);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone0);
        boolean boolean4 = dateTimeZone0.isStandardOffset((long) (-1));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test066");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        boolean boolean7 = dateTime1.isEqualNow();
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
//        try {
//            java.lang.String str11 = dateTime9.toString("2019-06-15T16:08:12.898-07:00");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime9);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test068");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getDayOfYear();
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField26 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
//        org.joda.time.YearMonthDay yearMonthDay32 = dateTime30.toYearMonthDay();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) (short) 10, chronology34);
//        boolean boolean36 = yearMonthDay32.isBefore((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.LocalDate.Property property37 = localDate35.dayOfYear();
//        org.joda.time.LocalDate localDate38 = property37.roundHalfFloorCopy();
//        java.util.Date date39 = localDate38.toDate();
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate38, 58092, locale41);
//        int int43 = localDate38.getYear();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 166 + "'", int9 == 166);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-25200000) + "'", int10 == (-25200000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(yearMonthDay17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 166 + "'", int23 == 166);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-25200000) + "'", int24 == (-25200000));
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(yearMonthDay32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "58092" + "'", str42.equals("58092"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1969 + "'", int43 == 1969);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate.Property property5 = localDate2.year();
        java.util.Locale locale7 = null;
        try {
            org.joda.time.LocalDate localDate8 = property5.setCopy("", locale7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for year is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 0L, (java.lang.Number) 10L, (java.lang.Number) 19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test071");
//        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
//        org.joda.time.Instant instant2 = instant0.plus((long) '4');
//        long long3 = instant0.getMillis();
//        boolean boolean5 = instant0.isEqual((long) 15);
//        org.junit.Assert.assertNotNull(instant0);
//        org.junit.Assert.assertNotNull(instant2);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560640097302L + "'", long3 == 1560640097302L);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Interval interval6 = localDate2.toInterval(dateTimeZone5);
        org.joda.time.Chronology chronology7 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval6);
        org.joda.time.ReadableInterval readableInterval8 = org.joda.time.DateTimeUtils.getReadableInterval((org.joda.time.ReadableInterval) interval6);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(chronology7);
        org.junit.Assert.assertNotNull(readableInterval8);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test073");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
//        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
//        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
//        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone14);
//        boolean boolean17 = dateTime11.isEqualNow();
//        org.joda.time.DateTime dateTime18 = dateTime11.withEarlierOffsetAtOverlap();
//        int int19 = property9.getDifference((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.Instant instant20 = dateTime18.toInstant();
//        boolean boolean22 = instant20.isBefore((long) 1);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-49) + "'", int19 == (-49));
//        org.junit.Assert.assertNotNull(instant20);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeParser dateTimeParser1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser1);
        java.lang.Appendable appendable3 = null;
        try {
            dateTimeFormatter2.printTo(appendable3, (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.joda.time.DateTimeUtils.setCurrentMillisFixed((long) 100);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        int int1 = org.joda.time.field.FieldUtils.safeToInt(0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.plus(readableDuration1);
        org.joda.time.Instant instant3 = instant2.toInstant();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.joda.time.DateTimeField dateTimeField0 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType1 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField3 = new org.joda.time.field.DividedDateTimeField(dateTimeField0, dateTimeFieldType1, (-49));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("DateTimeField[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"DateTimeField[dayOfMonth]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        try {
            org.joda.time.LocalDateTime localDateTime2 = dateTimeFormatter0.parseLocalDateTime("58087");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"58087\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 28800001L, (java.lang.Number) 57600, (java.lang.Number) 960);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        org.joda.time.DurationField durationField6 = iSOChronology0.days();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.secondOfDay();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(166, 100, 7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.LocalTime localTime1 = null;
        try {
            org.joda.time.LocalDateTime localDateTime2 = localDate0.toLocalDateTime(localTime1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The time must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((int) (short) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        java.util.Locale locale10 = null;
        int int11 = property9.getMaximumTextLength(locale10);
        org.joda.time.DurationField durationField12 = property9.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
        org.junit.Assert.assertNull(durationField12);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField1 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(0, 0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        long long5 = iSOChronology0.getDateTimeMillis(0, (int) (short) 10, 8, 7);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        try {
            long long11 = iSOChronology0.getDateTimeMillis(18, 10, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62142940799993L) + "'", long5 == (-62142940799993L));
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate.Property property8 = localDate6.dayOfYear();
        org.joda.time.LocalDate localDate9 = property8.roundHalfFloorCopy();
        java.lang.String str10 = property8.getAsString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "365" + "'", str10.equals("365"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
        int int13 = gJChronology11.getMinimumDaysInFirstWeek();
        int int14 = gJChronology11.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate.Property property5 = localDate2.year();
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property7 = localDate2.dayOfMonth();
        try {
            org.joda.time.LocalDate localDate9 = localDate2.withDayOfYear(58089);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58089 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withFields((org.joda.time.ReadablePartial) yearMonthDay5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = null;
        try {
            org.joda.time.DateTime.Property property10 = dateTime8.property(dateTimeFieldType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        try {
            int int4 = localDate2.getValue(58087);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 58087");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 0, 58097);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.lang.Appendable appendable2 = null;
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 10, chronology4);
        org.joda.time.LocalDate localDate7 = localDate5.plusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone8 = null;
        org.joda.time.Interval interval9 = localDate5.toInterval(dateTimeZone8);
        org.joda.time.LocalDate.Property property10 = localDate5.weekyear();
        org.joda.time.DateMidnight dateMidnight11 = localDate5.toDateMidnight();
        try {
            dateTimeFormatter0.printTo(appendable2, (org.joda.time.ReadablePartial) localDate5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(interval9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateMidnight11);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        int int4 = dateTime1.getWeekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
        org.joda.time.YearMonthDay yearMonthDay8 = dateTime6.toYearMonthDay();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 10, chronology10);
        boolean boolean12 = yearMonthDay8.isBefore((org.joda.time.ReadablePartial) localDate11);
        org.joda.time.DateMidnight dateMidnight13 = localDate11.toDateMidnight();
        boolean boolean14 = dateTime1.isEqual((org.joda.time.ReadableInstant) dateMidnight13);
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = null;
        boolean boolean16 = dateTime1.isSupported(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(yearMonthDay8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dateMidnight13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        long long13 = dateTimeZone4.adjustOffset(28800001L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.Instant instant15 = org.joda.time.Instant.now();
        org.joda.time.Instant instant17 = instant15.plus((long) '4');
        try {
            org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) instant15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800001L + "'", long13 == 28800001L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(instant15);
        org.junit.Assert.assertNotNull(instant17);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        try {
            org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, 0L, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(166, (int) (byte) 10, (int) '#', 58097, 15, dateTimeZone5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58097 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone5);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("2019-06-15T16:08:12.898-07:00");
        int int2 = dateTime1.getYearOfCentury();
        boolean boolean4 = dateTime1.isAfter((-57600000L));
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.lang.StringBuffer stringBuffer0 = null;
        try {
            org.joda.time.format.FormatUtils.appendPaddedInteger(stringBuffer0, (long) 166, 17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        try {
            org.joda.time.LocalDate localDate11 = localDate6.withYearOfCentury(960);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.DurationField durationField23 = gJChronology11.months();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        try {
            int[] intArray3 = iSOChronology0.get(readablePeriod1, (-54000000L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("2019-06-15T16:08:12.898-07:00");
        int int2 = dateTime1.getYearOfCentury();
        org.joda.time.Instant instant3 = dateTime1.toInstant();
        org.joda.time.TimeOfDay timeOfDay4 = dateTime1.toTimeOfDay();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(timeOfDay4);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.joda.time.Chronology chronology6 = null;
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(0, (int) (short) 1, (int) (short) -1, 58095, 0, 960, chronology6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58095 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now(dateTimeZone45);
        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
        org.joda.time.YearMonthDay yearMonthDay48 = dateTime46.toYearMonthDay();
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 10, chronology50);
        boolean boolean52 = yearMonthDay48.isBefore((org.joda.time.ReadablePartial) localDate51);
        org.joda.time.LocalDate.Property property53 = localDate51.dayOfYear();
        org.joda.time.LocalDate localDate54 = property53.roundHalfFloorCopy();
        java.util.Date date55 = localDate54.toDate();
        org.joda.time.LocalDate localDate56 = org.joda.time.LocalDate.fromDateFields(date55);
        java.util.Locale locale57 = null;
        java.lang.String str58 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate56, locale57);
        boolean boolean59 = skipDateTimeField28.isSupported();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(yearMonthDay48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "31" + "'", str58.equals("31"));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        org.joda.time.DateTimeZone dateTimeZone2 = dateTimeFormatter1.getZone();
        try {
            org.joda.time.Instant instant3 = org.joda.time.Instant.parse("58092", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"58092\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertNull(dateTimeZone2);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTime.Property property9 = dateTime1.year();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime1.toYearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
        try {
            org.joda.time.Instant instant2 = org.joda.time.Instant.parse("ISOChronology[America/Los_Angeles]", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withFields((org.joda.time.ReadablePartial) yearMonthDay5);
        org.joda.time.DateTime.Property property7 = dateTime1.secondOfDay();
        org.joda.time.Interval interval8 = property7.toInterval();
        int int9 = property7.get();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(interval8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600 + "'", int9 == 57600);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate.Property property8 = localDate6.dayOfYear();
        java.lang.String str9 = property8.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Property[dayOfYear]" + "'", str9.equals("Property[dayOfYear]"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime30.toYearMonthDay();
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) (short) 10, chronology34);
        boolean boolean36 = yearMonthDay32.isBefore((org.joda.time.ReadablePartial) localDate35);
        org.joda.time.LocalDate.Property property37 = localDate35.dayOfYear();
        org.joda.time.LocalDate localDate38 = property37.roundHalfFloorCopy();
        java.util.Date date39 = localDate38.toDate();
        java.util.Locale locale41 = null;
        java.lang.String str42 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate38, 58092, locale41);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.String str44 = localDate38.toString(dateTimeFormatter43);
        java.lang.StringBuffer stringBuffer45 = null;
        try {
            dateTimeFormatter43.printTo(stringBuffer45, (long) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "58092" + "'", str42.equals("58092"));
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1969-12-31T��:��:��.000" + "'", str44.equals("1969-12-31T��:��:��.000"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.Instant instant23 = gJChronology11.getGregorianCutover();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(instant23);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        boolean boolean1 = instant0.isEqualNow();
        java.lang.String str2 = instant0.toString();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "1970-01-01T00:00:00.100Z" + "'", str2.equals("1970-01-01T00:00:00.100Z"));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
        try {
            org.joda.time.field.OffsetDateTimeField offsetDateTimeField46 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) skipDateTimeField28, dateTimeFieldType42, 13, (int) (short) 1, 19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        long long5 = iSOChronology0.getDateTimeMillis(0, (int) (short) 10, 8, 7);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.clockhourOfHalfday();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.monthOfYear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + (-62142940799993L) + "'", long5 == (-62142940799993L));
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.ReadWritableInstant readWritableInstant1 = null;
        try {
            int int4 = dateTimeFormatter0.parseInto(readWritableInstant1, "1970-01-01T00:00:00.100Z", 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Instant must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writePaddedInteger(writer0, 58093, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonth();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfCentury();
        boolean boolean8 = property7.isLeap();
        java.util.Locale locale9 = null;
        java.lang.String str10 = property7.getAsShortText(locale9);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "69" + "'", str10.equals("69"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((int) (short) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.joda.time.DateMidnight dateMidnight10 = dateTime8.toDateMidnight();
        org.joda.time.DateTime dateTime12 = dateTime8.withDayOfYear(31);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.util.Map<java.lang.String, org.joda.time.DateTimeZone> strMap0 = org.joda.time.DateTimeUtils.getDefaultTimeZoneNames();
        org.junit.Assert.assertNotNull(strMap0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.joda.time.ReadableDuration readableDuration0 = null;
        long long1 = org.joda.time.DateTimeUtils.getDurationMillis(readableDuration0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int2 = org.joda.time.field.FieldUtils.safeAdd((-1), 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 14 + "'", int2 == 14);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.Chronology chronology12 = gJChronology11.withUTC();
        org.joda.time.DurationField durationField13 = gJChronology11.halfdays();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(chronology12);
        org.junit.Assert.assertNotNull(durationField13);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(58085);
        try {
            org.joda.time.chrono.JulianChronology julianChronology3 = org.joda.time.chrono.JulianChronology.getInstance(dateTimeZone1, 18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 18");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology1.add(readablePeriod2, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology1.secondOfMinute();
        org.joda.time.DurationField durationField7 = iSOChronology1.days();
        long long10 = durationField7.subtract((long) 2000, (long) 58089);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        try {
            org.joda.time.field.RemainderDateTimeField remainderDateTimeField12 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, durationField7, dateTimeFieldType11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 58089L + "'", long5 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(durationField7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-5018890020000L) + "'", long10 == (-5018890020000L));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.util.Set<java.lang.String> strSet0 = org.joda.time.DateTimeZone.getAvailableIDs();
        org.junit.Assert.assertNotNull(strSet0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withFields((org.joda.time.ReadablePartial) yearMonthDay5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime10 = dateTime6.minusDays(58087);
        try {
            java.lang.String str12 = dateTime10.toString("DateTimeField[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: t");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime30.toYearMonthDay();
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) (short) 10, chronology34);
        boolean boolean36 = yearMonthDay32.isBefore((org.joda.time.ReadablePartial) localDate35);
        org.joda.time.LocalDate.Property property37 = localDate35.dayOfYear();
        org.joda.time.LocalDate localDate38 = property37.roundHalfFloorCopy();
        java.util.Date date39 = localDate38.toDate();
        java.util.Locale locale41 = null;
        java.lang.String str42 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate38, 58092, locale41);
        try {
            long long45 = skipDateTimeField28.set((long) 17, "");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "58092" + "'", str42.equals("58092"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate4.withCenturyOfEra((int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 10, chronology12);
        boolean boolean14 = yearMonthDay10.isBefore((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 10, chronology16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        int int19 = localDate17.indexOf(dateTimeFieldType18);
        boolean boolean20 = yearMonthDay10.isAfter((org.joda.time.ReadablePartial) localDate17);
        boolean boolean21 = localDate6.isAfter((org.joda.time.ReadablePartial) yearMonthDay10);
        int int22 = localDate6.getDayOfMonth();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("69");
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        int int5 = dateTime4.getMillisOfDay();
        java.util.Date date6 = dateTime4.toDate();
        org.joda.time.LocalDate localDate7 = org.joda.time.LocalDate.fromDateFields(date6);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(localDate7);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimePrinter dateTimePrinter1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = org.joda.time.format.ISODateTimeFormat.hour();
        int int3 = dateTimeFormatter2.getDefaultYear();
        org.joda.time.format.DateTimeParser dateTimeParser4 = dateTimeFormatter2.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter1, dateTimeParser4);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser4);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2000 + "'", int3 == 2000);
        org.junit.Assert.assertNotNull(dateTimeParser4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        int int2 = dateTimeZone0.getOffsetFromLocal(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28800000) + "'", int2 == (-28800000));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate.Property property8 = localDate6.dayOfYear();
        org.joda.time.LocalDate localDate9 = property8.roundHalfFloorCopy();
        org.joda.time.LocalDate localDate11 = localDate9.minusMonths((int) '#');
        org.joda.time.ReadablePartial readablePartial12 = null;
        try {
            boolean boolean13 = localDate9.isBefore(readablePartial12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Partial cannot be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(58087, 166);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 58087");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime1.withMillisOfSecond((int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "DateTimeField[dayOfMonth]", "31");
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        java.lang.String str29 = skipDateTimeField28.toString();
        boolean boolean30 = skipDateTimeField28.isSupported();
        long long32 = skipDateTimeField28.roundHalfFloor((long) 100);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str29.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 28800000L + "'", long32 == 28800000L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider("58087");
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"58087/ZoneInfoMap\" ClassLoader: sun.misc.Launcher$AppClassLoader@60dbf04d");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        int int4 = dateTime1.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMillisOfSecond(0);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.DateTime dateTime9 = dateTime1.withFieldAdded(durationFieldType7, (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.joda.time.tz.NameProvider nameProvider0 = org.joda.time.DateTimeZone.getNameProvider();
        org.joda.time.DateTimeZone.setNameProvider(nameProvider0);
        org.junit.Assert.assertNotNull(nameProvider0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate4.withCenturyOfEra((int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 10, chronology12);
        boolean boolean14 = yearMonthDay10.isBefore((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 10, chronology16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        int int19 = localDate17.indexOf(dateTimeFieldType18);
        boolean boolean20 = yearMonthDay10.isAfter((org.joda.time.ReadablePartial) localDate17);
        boolean boolean21 = localDate6.isAfter((org.joda.time.ReadablePartial) yearMonthDay10);
        org.joda.time.LocalDate localDate23 = localDate6.withDayOfYear((int) (short) 100);
        try {
            int int25 = localDate6.getValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 32");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(localDate23);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withFields((org.joda.time.ReadablePartial) yearMonthDay5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) (byte) 1);
        java.util.GregorianCalendar gregorianCalendar9 = dateTime8.toGregorianCalendar();
        org.joda.time.DateTimeFieldType dateTimeFieldType10 = null;
        try {
            int int11 = dateTime8.get(dateTimeFieldType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The DateTimeFieldType must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(gregorianCalendar9);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        java.lang.String str7 = dateTime6.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str7.equals("1969-12-31T16:00:00.100-08:00"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime7 = dateTime1.minusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.monthOfYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter9 = org.joda.time.format.ISODateTimeFormat.weekDate();
        boolean boolean10 = property8.equals((java.lang.Object) dateTimeFormatter9);
        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod12 = null;
        long long15 = iSOChronology11.add(readablePeriod12, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology11.secondOfMinute();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 10, chronology18);
        org.joda.time.LocalDate localDate21 = localDate19.plusWeeks(0);
        org.joda.time.LocalDate localDate23 = localDate21.withDayOfYear((int) (byte) 100);
        int[] intArray25 = iSOChronology11.get((org.joda.time.ReadablePartial) localDate21, 0L);
        org.joda.time.DateTimeField dateTimeField26 = iSOChronology11.millisOfDay();
        boolean boolean27 = property8.equals((java.lang.Object) dateTimeField26);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeFormatter9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(iSOChronology11);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 58089L + "'", long15 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(localDate21);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(dateTimeField26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTime();
        java.io.Writer writer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        int int4 = dateTime3.getSecondOfDay();
        org.joda.time.DateTime dateTime6 = dateTime3.withYear((int) (short) 1);
        try {
            dateTimeFormatter0.printTo(writer1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600 + "'", int4 == 57600);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        int int11 = dateTime10.getDayOfYear();
        int int12 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime10);
        org.joda.time.chrono.GJChronology gJChronology13 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone6);
        org.joda.time.DurationField durationField14 = gJChronology13.millis();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology13.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        int int18 = dateTime17.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = dateTime17.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime17.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime23 = dateTime22.toDateTimeISO();
        boolean boolean24 = gJChronology13.equals((java.lang.Object) dateTime22);
        try {
            org.joda.time.Partial partial25 = new org.joda.time.Partial(dateTimeFieldType0, 0, (org.joda.time.Chronology) gJChronology13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The field type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 365 + "'", int11 == 365);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology13);
        org.junit.Assert.assertNotNull(durationField14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 365 + "'", int18 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime1.plusMonths((int) (byte) -1);
        org.joda.time.DateTime dateTime10 = dateTime1.withYear(6);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.DateTime.Property property3 = dateTime1.weekOfWeekyear();
        org.joda.time.Interval interval4 = property3.toInterval();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(interval4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 10, chronology9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        int int12 = localDate10.indexOf(dateTimeFieldType11);
        boolean boolean13 = yearMonthDay3.isAfter((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.LocalDate.Property property14 = localDate10.weekyear();
        org.joda.time.LocalDate localDate15 = property14.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate15);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        boolean boolean6 = dateTime2.isEqual(58089L);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.joda.time.Instant instant1 = new org.joda.time.Instant((long) (byte) 100);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        long long1 = org.joda.time.DateTimeUtils.fromJulianDay(10.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-210865896000000L) + "'", long1 == (-210865896000000L));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate4.withDayOfYear((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        long long13 = dateTimeZone9.convertLocalToUTC((long) (byte) 1, false, 100L);
        org.joda.time.Interval interval14 = localDate4.toInterval(dateTimeZone9);
        org.joda.time.Chronology chronology15 = org.joda.time.DateTimeUtils.getIntervalChronology((org.joda.time.ReadableInterval) interval14);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800001L + "'", long13 == 28800001L);
        org.junit.Assert.assertNotNull(interval14);
        org.junit.Assert.assertNotNull(chronology15);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (-25200000), 8);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 10, chronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = localDate7.toDateTimeAtMidnight(dateTimeZone8);
        org.joda.time.LocalDate localDate13 = localDate7.minusYears(58087);
        int[] intArray14 = localDate13.getValues();
        boolean boolean15 = copticChronology0.equals((java.lang.Object) intArray14);
        org.joda.time.DurationField durationField16 = copticChronology0.millis();
        org.joda.time.Chronology chronology17 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-25200000L) + "'", long4 == (-25200000L));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicOrdinalDateTime();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, (long) 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.withMillis(58L);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        long long2 = org.joda.time.field.FieldUtils.safeAdd((long) 10, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.ReadableDuration readableDuration1 = null;
        org.joda.time.Instant instant2 = instant0.minus(readableDuration1);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTime4.getZone();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 10, chronology8);
        boolean boolean10 = yearMonthDay6.isBefore((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateMidnight dateMidnight11 = localDate9.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        long long16 = iSOChronology12.add(readablePeriod13, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.secondOfMinute();
        org.joda.time.DateTime dateTime18 = dateMidnight11.toDateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology12);
        try {
            org.joda.time.LocalDate localDate21 = localDate19.withDayOfWeek((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 58089L + "'", long16 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        int int6 = dateTime1.getMillisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("2019-06-15T16:08:12.898-07:00");
        int int2 = dateTime1.getYearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.minus(readablePeriod3);
        int int5 = dateTime4.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 20 + "'", int5 == 20);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate.Property property5 = localDate2.year();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray6 = localDate2.getFieldTypes();
        try {
            org.joda.time.LocalDate localDate8 = localDate2.withEra(18);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 18 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray6);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (short) 10, chronology30);
        org.joda.time.LocalDate localDate33 = localDate31.plusWeeks(0);
        org.joda.time.LocalDate localDate35 = localDate31.plusWeeks(58097);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate35, (int) '#', locale37);
        org.joda.time.DurationField durationField39 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField28, durationField39, dateTimeFieldType40);
        long long43 = skipDateTimeField28.roundHalfCeiling((long) 19);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "35" + "'", str38.equals("35"));
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 28800000L + "'", long43 == 28800000L);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        int int4 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.minus(readableDuration5);
        boolean boolean8 = org.joda.time.field.FieldUtils.equals((java.lang.Object) dateTime1, (java.lang.Object) 8);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
        org.joda.time.DateTime dateTime12 = dateTime8.minusMinutes(18);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now(dateTimeZone46);
        org.joda.time.DateTime dateTime48 = dateTime43.withZoneRetainFields(dateTimeZone46);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now(dateTimeZone49);
        int int51 = dateTime50.getDayOfYear();
        int int52 = dateTimeZone46.getOffset((org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField54 = gJChronology53.millis();
        org.joda.time.DateTimeField dateTimeField55 = gJChronology53.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime57 = org.joda.time.DateTime.now(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = dateTime57.getZone();
        org.joda.time.YearMonthDay yearMonthDay59 = dateTime57.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime61 = org.joda.time.DateTime.now(dateTimeZone60);
        org.joda.time.DateTime dateTime62 = dateTime57.withZoneRetainFields(dateTimeZone60);
        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now(dateTimeZone63);
        int int65 = dateTime64.getDayOfYear();
        int int66 = dateTimeZone60.getOffset((org.joda.time.ReadableInstant) dateTime64);
        org.joda.time.chrono.GJChronology gJChronology67 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone60);
        org.joda.time.DurationField durationField68 = gJChronology67.millis();
        org.joda.time.DateTimeField dateTimeField69 = gJChronology67.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField70 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology53, dateTimeField69);
        int int71 = skipDateTimeField70.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime73 = org.joda.time.DateTime.now(dateTimeZone72);
        org.joda.time.DateTimeZone dateTimeZone74 = dateTime73.getZone();
        org.joda.time.YearMonthDay yearMonthDay75 = dateTime73.toYearMonthDay();
        org.joda.time.Chronology chronology77 = null;
        org.joda.time.LocalDate localDate78 = new org.joda.time.LocalDate((long) (short) 10, chronology77);
        boolean boolean79 = yearMonthDay75.isBefore((org.joda.time.ReadablePartial) localDate78);
        org.joda.time.LocalDate.Property property80 = localDate78.dayOfYear();
        java.util.Locale locale82 = null;
        java.lang.String str83 = skipDateTimeField70.getAsText((org.joda.time.ReadablePartial) localDate78, 58087, locale82);
        java.util.Locale locale84 = null;
        java.lang.String str85 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate78, locale84);
        long long87 = skipDateTimeField28.roundHalfEven((long) 58093);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(yearMonthDay45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 365 + "'", int51 == 365);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-28800000) + "'", int52 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(yearMonthDay59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 365 + "'", int65 == 365);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-28800000) + "'", int66 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 31 + "'", int71 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone72);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(dateTimeZone74);
        org.junit.Assert.assertNotNull(yearMonthDay75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(property80);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "58087" + "'", str83.equals("58087"));
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "31" + "'", str85.equals("31"));
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 28800000L + "'", long87 == 28800000L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate.Property property8 = localDate6.dayOfYear();
        org.joda.time.LocalDate localDate9 = property8.roundHalfFloorCopy();
        org.joda.time.DurationField durationField10 = property8.getLeapDurationField();
        org.joda.time.LocalDate localDate12 = property8.addWrapFieldToCopy(8);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertNotNull(localDate12);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        int int4 = dateTime1.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMillisOfSecond(0);
        org.joda.time.ReadableInstant readableInstant7 = null;
        boolean boolean8 = dateTime6.isAfter(readableInstant7);
        org.joda.time.DateTime.Property property9 = dateTime6.minuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(property9);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
//        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
//        org.joda.time.Chronology chronology7 = null;
//        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 10, chronology7);
//        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks(0);
//        org.joda.time.LocalDate localDate12 = localDate10.withDayOfYear((int) (byte) 100);
//        int[] intArray14 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate10, 0L);
//        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.millisOfDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTimeZone dateTimeZone19 = dateTime18.getZone();
//        org.joda.time.YearMonthDay yearMonthDay20 = dateTime18.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = dateTime18.withZoneRetainFields(dateTimeZone21);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
//        int int26 = dateTime25.getDayOfYear();
//        int int27 = dateTimeZone21.getOffset((org.joda.time.ReadableInstant) dateTime25);
//        org.joda.time.chrono.GJChronology gJChronology28 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone21);
//        long long30 = dateTimeZone16.getMillisKeepLocal(dateTimeZone21, (long) 10);
//        java.util.Locale locale32 = null;
//        java.lang.String str33 = dateTimeZone21.getShortName((long) '4', locale32);
//        try {
//            org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((java.lang.Object) iSOChronology0, dateTimeZone21);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.ISOChronology");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(localDate10);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(yearMonthDay20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 365 + "'", int26 == 365);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-28800000) + "'", int27 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology28);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 10L + "'", long30 == 10L);
//        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "PST" + "'", str33.equals("PST"));
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = copticChronology0.minuteOfDay();
        try {
            long long6 = copticChronology0.getDateTimeMillis((-1), 0, 13, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,13]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        int int4 = dateTime1.getWeekOfWeekyear();
        org.joda.time.ReadableDuration readableDuration5 = null;
        org.joda.time.DateTime dateTime6 = dateTime1.minus(readableDuration5);
        org.joda.time.DateTime dateTime8 = dateTime1.withMinuteOfHour(12);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate2.plusWeeks(58097);
        try {
            org.joda.time.LocalDate localDate8 = localDate2.withCenturyOfEra((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for centuryOfEra must be in the range [0,2922789]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        int int2 = julianChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-25200000));
        java.io.Writer writer4 = null;
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 10, chronology6);
        org.joda.time.LocalDate localDate9 = localDate7.plusWeeks(0);
        org.joda.time.LocalDate.Property property10 = localDate7.year();
        try {
            dateTimeFormatter0.printTo(writer4, (org.joda.time.ReadablePartial) localDate7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNotNull(property10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(58093, (int) (short) 0, 9, 0, (int) '#', 1969, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for secondOfMinute must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfCentury();
        org.joda.time.DateTimeField dateTimeField2 = iSOChronology0.secondOfMinute();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        java.lang.String str1 = julianChronology0.toString();
        try {
            long long6 = julianChronology0.getDateTimeMillis(58093, 960, (int) (byte) 1, (-49));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -49 for millisOfDay must be in the range [0,86399999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str1.equals("JulianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(6, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withZoneUTC();
        try {
            org.joda.time.DateTime dateTime5 = dateTimeFormatter3.parseDateTime("31");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Cannot parse \"31\": Value 31 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecond();
        try {
            org.joda.time.LocalDate localDate2 = org.joda.time.LocalDate.parse("", dateTimeFormatter1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        org.joda.time.ReadableInstant readableInstant7 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology9 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone3, readableInstant7, 58093);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 58093");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime2.withZoneRetainFields(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTime9.getDayOfYear();
        int int11 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 9, (org.joda.time.Chronology) gJChronology12);
        org.joda.time.ReadablePeriod readablePeriod14 = null;
        org.joda.time.DateTime dateTime15 = dateTime13.plus(readablePeriod14);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(yearMonthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone14);
        boolean boolean17 = dateTime11.isEqualNow();
        org.joda.time.DateTime dateTime18 = dateTime11.withEarlierOffsetAtOverlap();
        int int19 = property9.getDifference((org.joda.time.ReadableInstant) dateTime18);
        int int20 = dateTime18.getSecondOfDay();
        org.joda.time.DateTime dateTime22 = dateTime18.withWeekOfWeekyear(10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 57600 + "'", int20 == 57600);
        org.junit.Assert.assertNotNull(dateTime22);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone14);
        boolean boolean17 = dateTime11.isEqualNow();
        org.joda.time.DateTime dateTime18 = dateTime11.withEarlierOffsetAtOverlap();
        int int19 = property9.getDifference((org.joda.time.ReadableInstant) dateTime18);
        int int20 = property9.getMinimumValue();
        try {
            org.joda.time.LocalDate localDate22 = property9.setCopy("1969-12-31T16:00:00.100-08:00");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1969-12-31T16:00:00.100-08:00\" for yearOfCentury is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        java.lang.Appendable appendable1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        int int4 = dateTime3.getSecondOfDay();
        int int5 = dateTime3.getSecondOfMinute();
        int int6 = dateTime3.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime8 = dateTime3.withMillisOfSecond(0);
        try {
            dateTimeFormatter0.printTo(appendable1, (org.joda.time.ReadableInstant) dateTime3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 57600 + "'", int4 == 57600);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTime dateTime9 = property8.roundHalfEvenCopy();
        int int10 = property8.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 86399 + "'", int10 == 86399);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        org.joda.time.LocalDate.Property property10 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property10.roundFloorCopy();
        int int12 = localDate11.getCenturyOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 19 + "'", int12 == 19);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        org.joda.time.DateTime dateTime8 = dateTime6.withDayOfYear((int) '#');
        org.joda.time.DateTime.Property property9 = dateTime6.dayOfWeek();
        org.joda.time.DateTime dateTime11 = dateTime6.minus(464793L);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.joda.time.chrono.ISOChronology iSOChronology6 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((java.lang.Object) (-1L), (org.joda.time.Chronology) iSOChronology6);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime10.getZone();
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime10.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime10.withZoneRetainFields(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        int int18 = dateTime17.getDayOfYear();
        int int19 = dateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.DateTime dateTime20 = localDate7.toDateTime(localTime8, dateTimeZone13);
        try {
            org.joda.time.DateTime dateTime21 = new org.joda.time.DateTime(0, 7, 58093, 1969, 18, dateTimeZone13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1969 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology6);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 365 + "'", int18 == 365);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime20);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test199");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        java.lang.String str4 = dateTimeZone2.getShortName((long) 10);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
//        java.lang.String str6 = dateTimeZone2.toString();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "America/Los_Angeles" + "'", str6.equals("America/Los_Angeles"));
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "58087");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        int int44 = skipDateTimeField28.getDifference((long) (short) 100, (long) (short) -1);
        int int46 = skipDateTimeField28.getMinimumValue(1L);
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate49 = new org.joda.time.LocalDate((java.lang.Object) (-1L), (org.joda.time.Chronology) iSOChronology48);
        org.joda.time.LocalTime localTime50 = null;
        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now(dateTimeZone51);
        org.joda.time.DateTimeZone dateTimeZone53 = dateTime52.getZone();
        org.joda.time.YearMonthDay yearMonthDay54 = dateTime52.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime56 = org.joda.time.DateTime.now(dateTimeZone55);
        org.joda.time.DateTime dateTime57 = dateTime52.withZoneRetainFields(dateTimeZone55);
        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime59 = org.joda.time.DateTime.now(dateTimeZone58);
        int int60 = dateTime59.getDayOfYear();
        int int61 = dateTimeZone55.getOffset((org.joda.time.ReadableInstant) dateTime59);
        org.joda.time.DateTime dateTime62 = localDate49.toDateTime(localTime50, dateTimeZone55);
        java.util.Locale locale64 = null;
        java.lang.String str65 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate49, 57600, locale64);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertNotNull(dateTimeZone51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertNotNull(dateTimeZone53);
        org.junit.Assert.assertNotNull(yearMonthDay54);
        org.junit.Assert.assertNotNull(dateTimeZone55);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 365 + "'", int60 == 365);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-28800000) + "'", int61 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "57600" + "'", str65.equals("57600"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 10, chronology7);
        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks(0);
        org.joda.time.LocalDate localDate12 = localDate10.withDayOfYear((int) (byte) 100);
        int[] intArray14 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate10, 0L);
        org.joda.time.DurationField durationField15 = iSOChronology0.days();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(durationField15);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
        java.security.PermissionCollection permissionCollection2 = jodaTimePermission1.newPermissionCollection();
        org.junit.Assert.assertNotNull(permissionCollection2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        boolean boolean2 = dateTimeZone0.isStandardOffset((-91L));
        java.lang.String str3 = dateTimeZone0.getID();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "America/Los_Angeles" + "'", str3.equals("America/Los_Angeles"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        long long13 = dateTimeZone4.adjustOffset(28800001L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        int int16 = cachedDateTimeZone14.getStandardOffset(0L);
        boolean boolean17 = cachedDateTimeZone14.isFixed();
        long long19 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        int int21 = cachedDateTimeZone14.getStandardOffset((long) (byte) 1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800001L + "'", long13 == 28800001L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9972000000L + "'", long19 == 9972000000L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTime();
        try {
            org.joda.time.LocalDate localDate2 = dateTimeFormatter0.parseLocalDate("69");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"69\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        try {
            long long18 = gJChronology11.getDateTimeMillis(58095, 17, 1, 8);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 17 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withFields((org.joda.time.ReadablePartial) yearMonthDay5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime10 = dateTime6.minusDays(58087);
        org.joda.time.DateTime dateTime12 = dateTime10.minusYears(58085);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinuteSecondMillis();
        try {
            org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("ISOChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"ISOChronology[America/Los_Angeles]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTime4.getZone();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 10, chronology8);
        boolean boolean10 = yearMonthDay6.isBefore((org.joda.time.ReadablePartial) localDate9);
        org.joda.time.DateMidnight dateMidnight11 = localDate9.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology12 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        long long16 = iSOChronology12.add(readablePeriod13, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology12.secondOfMinute();
        org.joda.time.DateTime dateTime18 = dateMidnight11.toDateTime((org.joda.time.Chronology) iSOChronology12);
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology12);
        try {
            org.joda.time.LocalDate localDate21 = localDate19.withMonthOfYear(13);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 13 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateMidnight11);
        org.junit.Assert.assertNotNull(iSOChronology12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 58089L + "'", long16 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTime18);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(31, 14, 1, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -1 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        int int4 = localDate2.indexOf(dateTimeFieldType3);
        int int5 = localDate2.getDayOfYear();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 10, chronology9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        int int12 = localDate10.indexOf(dateTimeFieldType11);
        boolean boolean13 = yearMonthDay3.isAfter((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.LocalDate.Property property14 = localDate10.weekyear();
        int int15 = localDate10.getDayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 365 + "'", int15 == 365);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime1.minus(readableDuration8);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
        java.lang.String str11 = property10.toString();
        org.joda.time.DateTime dateTime12 = property10.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Property[dayOfMonth]" + "'", str11.equals("Property[dayOfMonth]"));
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.plus((long) '4');
        long long3 = instant0.getMillis();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant0.minus(readableDuration4);
        org.joda.time.ReadableDuration readableDuration6 = null;
        org.joda.time.Instant instant7 = instant5.minus(readableDuration6);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertNotNull(instant7);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.joda.time.DateTime dateTime1 = new org.joda.time.DateTime(1L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime1.plusMonths((int) (byte) -1);
        try {
            org.joda.time.DateTime dateTime10 = dateTime1.withHourOfDay((-49));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -49 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicDate();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        boolean boolean1 = instant0.isEqualNow();
        org.joda.time.Instant instant3 = instant0.withMillis((long) (byte) 1);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(instant3);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((int) (short) -1);
        int int9 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        int int12 = dateTime11.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime11.toDateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime8.toDateTime(dateTimeZone13);
        java.lang.String str17 = dateTimeZone13.getID();
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone18 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 365 + "'", int12 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "America/Los_Angeles" + "'", str17.equals("America/Los_Angeles"));
        org.junit.Assert.assertNotNull(cachedDateTimeZone18);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        org.joda.time.LocalDate.Property property10 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property10.roundFloorCopy();
        try {
            org.joda.time.LocalDate localDate13 = localDate11.withYearOfCentury(2000);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for yearOfCentury must be in the range [0,99]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.joda.time.DateTimeFieldType dateTimeFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType0, (java.lang.Number) 10, (java.lang.Number) (-62142940799993L), (java.lang.Number) (-18063L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((int) (short) -1);
        int int9 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        int int12 = dateTime11.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime11.toDateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime8.toDateTime(dateTimeZone13);
        org.joda.time.DateTime.Property property17 = dateTime8.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 365 + "'", int12 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        org.joda.time.DateTimeFieldType dateTimeFieldType42 = null;
        try {
            org.joda.time.field.ZeroIsMaxDateTimeField zeroIsMaxDateTimeField43 = new org.joda.time.field.ZeroIsMaxDateTimeField((org.joda.time.DateTimeField) skipDateTimeField28, dateTimeFieldType42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime30.toYearMonthDay();
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) (short) 10, chronology34);
        boolean boolean36 = yearMonthDay32.isBefore((org.joda.time.ReadablePartial) localDate35);
        org.joda.time.LocalDate.Property property37 = localDate35.dayOfYear();
        org.joda.time.LocalDate localDate38 = property37.roundHalfFloorCopy();
        java.util.Date date39 = localDate38.toDate();
        java.util.Locale locale41 = null;
        java.lang.String str42 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate38, 58092, locale41);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter43 = org.joda.time.format.ISODateTimeFormat.dateTime();
        java.lang.String str44 = localDate38.toString(dateTimeFormatter43);
        try {
            org.joda.time.LocalDateTime localDateTime46 = dateTimeFormatter43.parseLocalDateTime("");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "58092" + "'", str42.equals("58092"));
        org.junit.Assert.assertNotNull(dateTimeFormatter43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "1969-12-31T��:��:��.000" + "'", str44.equals("1969-12-31T��:��:��.000"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        long long13 = iSOChronology9.add(readablePeriod10, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology9.secondOfMinute();
        org.joda.time.DateTime dateTime15 = dateMidnight8.toDateTime((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology9.millisOfDay();
        org.joda.time.DurationField durationField17 = iSOChronology9.weekyears();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 58089L + "'", long13 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(durationField17);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
        org.joda.time.YearMonthDay yearMonthDay32 = dateTime30.toYearMonthDay();
        org.joda.time.Chronology chronology34 = null;
        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) (short) 10, chronology34);
        boolean boolean36 = yearMonthDay32.isBefore((org.joda.time.ReadablePartial) localDate35);
        org.joda.time.LocalDate.Property property37 = localDate35.dayOfYear();
        org.joda.time.LocalDate localDate38 = property37.roundHalfFloorCopy();
        java.util.Date date39 = localDate38.toDate();
        java.util.Locale locale41 = null;
        java.lang.String str42 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate38, 58092, locale41);
        java.lang.String str43 = skipDateTimeField28.getName();
        org.joda.time.DurationField durationField44 = skipDateTimeField28.getRangeDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(yearMonthDay32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(property37);
        org.junit.Assert.assertNotNull(localDate38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "58092" + "'", str42.equals("58092"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "dayOfMonth" + "'", str43.equals("dayOfMonth"));
        org.junit.Assert.assertNotNull(durationField44);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone14);
        boolean boolean17 = dateTime11.isEqualNow();
        org.joda.time.DateTime dateTime18 = dateTime11.withEarlierOffsetAtOverlap();
        int int19 = property9.getDifference((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DurationField durationField20 = property9.getDurationField();
        long long23 = durationField20.subtract(0L, (long) (byte) 0);
        long long26 = durationField20.subtract((long) 86399, (long) (-28800000));
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(durationField20);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 908840217600086399L + "'", long26 == 908840217600086399L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstance();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstance();
        org.junit.Assert.assertNotNull(buddhistChronology0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        java.lang.String str29 = skipDateTimeField28.toString();
        long long31 = skipDateTimeField28.roundHalfCeiling((long) (-28800000));
        java.util.Locale locale32 = null;
        int int33 = skipDateTimeField28.getMaximumTextLength(locale32);
        int int35 = skipDateTimeField28.getMinimumValue(58089L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str29.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-57600000L) + "'", long31 == (-57600000L));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.Chronology chronology1 = partial0.getChronology();
        try {
            java.lang.String str3 = partial0.toString("1969-12-31T��:��:��.000");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: T");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
        java.lang.String str2 = jodaTimePermission1.getName();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "31" + "'", str2.equals("31"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("69", "69", 14, 58097);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) '#');
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "69" + "'", str6.equals("69"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate.Property property8 = localDate6.dayOfYear();
        try {
            org.joda.time.LocalDate localDate10 = property8.setCopy("");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"\" for dayOfYear is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.Chronology chronology4 = buddhistChronology3.withUTC();
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology3.millisOfSecond();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(chronology4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.joda.time.Instant instant0 = new org.joda.time.Instant();
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        try {
            org.joda.time.LocalDate localDate9 = localDate6.withDayOfYear(58097);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58097 for dayOfYear must be in the range [1,365]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 10, chronology7);
        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks(0);
        org.joda.time.LocalDate localDate12 = localDate10.withDayOfYear((int) (byte) 100);
        int[] intArray14 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate10, 0L);
        org.joda.time.Chronology chronology15 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        int int18 = delegatedDateTimeField17.getMinimumValue();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        java.lang.String str4 = dateTimeZone2.getShortName((long) 10);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        int int8 = dateTime7.getDayOfYear();
//        try {
//            org.joda.time.chrono.GJChronology gJChronology10 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2, (org.joda.time.ReadableInstant) dateTime7, 58097);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 58097");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "PST" + "'", str4.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime1.minus(readableDuration8);
        org.joda.time.DateTime dateTime11 = dateTime1.withCenturyOfEra((int) (byte) 1);
        org.joda.time.DateTime dateTime13 = dateTime11.plusDays(7);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (-25200000), 8);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.centuryOfEra();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-25200000L) + "'", long4 == (-25200000L));
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (long) 365);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.yearMonthDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfCentury();
        boolean boolean8 = property7.isLeap();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 10, chronology10);
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone12);
        org.joda.time.DateTime dateTime15 = localDate11.toDateTimeAtMidnight(dateTimeZone12);
        org.joda.time.DateTime dateTime17 = dateTime15.withDayOfYear((int) '#');
        int int18 = property7.compareTo((org.joda.time.ReadableInstant) dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (-25200000), 8);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 10, chronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = localDate7.toDateTimeAtMidnight(dateTimeZone8);
        org.joda.time.LocalDate localDate13 = localDate7.minusYears(58087);
        int[] intArray14 = localDate13.getValues();
        boolean boolean15 = copticChronology0.equals((java.lang.Object) intArray14);
        org.joda.time.Chronology chronology16 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-25200000L) + "'", long4 == (-25200000L));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(chronology16);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        java.util.Locale locale30 = null;
        int int31 = skipDateTimeField28.getMaximumTextLength(locale30);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        java.lang.StringBuffer stringBuffer1 = null;
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        int int4 = dateTime3.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime3.toDateTime(dateTimeZone5);
        org.joda.time.DateTime dateTime8 = dateTime3.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime10 = dateTime3.plusMonths((int) (byte) -1);
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (org.joda.time.ReadableInstant) dateTime10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 365 + "'", int4 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate.Property property5 = localDate2.year();
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight();
        int int7 = dateTime6.getEra();
        org.joda.time.DateTime dateTime9 = dateTime6.minusMonths(0);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 10, chronology10);
        org.joda.time.LocalDate localDate13 = localDate11.plusWeeks(0);
        org.joda.time.LocalDate localDate15 = localDate13.withCenturyOfEra((int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime17.toYearMonthDay();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 10, chronology21);
        boolean boolean23 = yearMonthDay19.isBefore((org.joda.time.ReadablePartial) localDate22);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 10, chronology25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        int int28 = localDate26.indexOf(dateTimeFieldType27);
        boolean boolean29 = yearMonthDay19.isAfter((org.joda.time.ReadablePartial) localDate26);
        boolean boolean30 = localDate15.isAfter((org.joda.time.ReadablePartial) yearMonthDay19);
        org.joda.time.DateTimeFieldType dateTimeFieldType31 = null;
        boolean boolean32 = yearMonthDay19.isSupported(dateTimeFieldType31);
        org.joda.time.DateTimeZone dateTimeZone33 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime34 = org.joda.time.DateTime.now(dateTimeZone33);
        int int35 = dateTime34.getSecondOfDay();
        int int36 = dateTime34.getSecondOfMinute();
        int int37 = dateTime34.getWeekOfWeekyear();
        org.joda.time.DateTimeZone dateTimeZone38 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime39 = org.joda.time.DateTime.now(dateTimeZone38);
        org.joda.time.DateTimeZone dateTimeZone40 = dateTime39.getZone();
        org.joda.time.YearMonthDay yearMonthDay41 = dateTime39.toYearMonthDay();
        org.joda.time.Chronology chronology43 = null;
        org.joda.time.LocalDate localDate44 = new org.joda.time.LocalDate((long) (short) 10, chronology43);
        boolean boolean45 = yearMonthDay41.isBefore((org.joda.time.ReadablePartial) localDate44);
        org.joda.time.DateMidnight dateMidnight46 = localDate44.toDateMidnight();
        boolean boolean47 = dateTime34.isEqual((org.joda.time.ReadableInstant) dateMidnight46);
        org.joda.time.DateTime dateTime48 = yearMonthDay19.toDateTime((org.joda.time.ReadableInstant) dateTime34);
        boolean boolean49 = dateTime1.isAfter((org.joda.time.ReadableInstant) dateTime34);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(dateTimeZone33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 57600 + "'", int35 == 57600);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(dateTimeZone38);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTimeZone40);
        org.junit.Assert.assertNotNull(yearMonthDay41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dateMidnight46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTimeISO();
        org.joda.time.Chronology chronology8 = org.joda.time.DateTimeUtils.getInstantChronology((org.joda.time.ReadableInstant) dateTime7);
        try {
            org.joda.time.DateTime dateTime10 = dateTime7.withDayOfWeek(86399);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 86399 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(chronology8);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
        java.lang.String str2 = illegalInstantException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.joda.time.IllegalInstantException: " + "'", str2.equals("org.joda.time.IllegalInstantException: "));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        org.joda.time.DateTimeField dateTimeField2 = julianChronology0.dayOfMonth();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now(dateTimeZone45);
        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
        org.joda.time.YearMonthDay yearMonthDay48 = dateTime46.toYearMonthDay();
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 10, chronology50);
        boolean boolean52 = yearMonthDay48.isBefore((org.joda.time.ReadablePartial) localDate51);
        int[] intArray58 = new int[] { 58093, 58089, 1969, 0, (short) 0 };
        int int59 = skipDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) localDate51, intArray58);
        try {
            long long62 = skipDateTimeField28.set((long) (byte) -1, 58093);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58093 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(yearMonthDay48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone14);
        boolean boolean17 = dateTime11.isEqualNow();
        org.joda.time.DateTime dateTime18 = dateTime11.withEarlierOffsetAtOverlap();
        int int19 = property9.getDifference((org.joda.time.ReadableInstant) dateTime18);
        int int20 = property9.getMinimumValue();
        org.joda.time.LocalDate localDate21 = property9.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(localDate21);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now(dateTimeZone45);
        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
        org.joda.time.YearMonthDay yearMonthDay48 = dateTime46.toYearMonthDay();
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 10, chronology50);
        boolean boolean52 = yearMonthDay48.isBefore((org.joda.time.ReadablePartial) localDate51);
        org.joda.time.LocalDate.Property property53 = localDate51.dayOfYear();
        org.joda.time.LocalDate localDate54 = property53.roundHalfFloorCopy();
        java.util.Date date55 = localDate54.toDate();
        org.joda.time.LocalDate localDate56 = org.joda.time.LocalDate.fromDateFields(date55);
        java.util.Locale locale57 = null;
        java.lang.String str58 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate56, locale57);
        int int59 = skipDateTimeField28.getMaximumValue();
        long long61 = skipDateTimeField28.roundHalfCeiling(58L);
        org.joda.time.Chronology chronology63 = null;
        org.joda.time.LocalDate localDate64 = new org.joda.time.LocalDate((long) (short) 10, chronology63);
        org.joda.time.LocalDate localDate66 = localDate64.plusWeeks(0);
        org.joda.time.LocalDate localDate68 = localDate64.plusWeeks(58097);
        int int69 = skipDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) localDate68);
        try {
            org.joda.time.LocalDate localDate71 = localDate68.withEra(7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 7 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(yearMonthDay48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "31" + "'", str58.equals("31"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 31 + "'", int59 == 31);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 28800000L + "'", long61 == 28800000L);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("2019-06-15T16:08:12.898-07:00");
        int int2 = dateTime1.getYearOfCentury();
        boolean boolean4 = dateTime1.isAfter((-57600000L));
        org.joda.time.DateTime dateTime6 = dateTime1.plusWeeks(6);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
        long long26 = durationField23.subtract(28800035L, (long) 365);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 6900035L + "'", long26 == 6900035L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        try {
            org.joda.time.LocalDate localDate4 = localDate2.withMonthOfYear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        long long13 = dateTimeZone4.adjustOffset(28800001L, true);
        long long17 = dateTimeZone4.convertLocalToUTC(100L, false, (long) (short) 1);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone20 = dateTime19.getZone();
        org.joda.time.YearMonthDay yearMonthDay21 = dateTime19.toYearMonthDay();
        org.joda.time.Chronology chronology23 = null;
        org.joda.time.LocalDate localDate24 = new org.joda.time.LocalDate((long) (short) 10, chronology23);
        boolean boolean25 = yearMonthDay21.isBefore((org.joda.time.ReadablePartial) localDate24);
        org.joda.time.LocalDate.Property property26 = localDate24.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(dateTimeZone27);
        org.joda.time.DateTimeZone dateTimeZone29 = dateTime28.getZone();
        org.joda.time.YearMonthDay yearMonthDay30 = dateTime28.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(dateTimeZone31);
        org.joda.time.DateTime dateTime33 = dateTime28.withZoneRetainFields(dateTimeZone31);
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone34);
        int int36 = dateTime35.getDayOfYear();
        int int37 = dateTimeZone31.getOffset((org.joda.time.ReadableInstant) dateTime35);
        boolean boolean39 = dateTime35.isEqual((long) (short) 10);
        int int40 = property26.compareTo((org.joda.time.ReadableInstant) dateTime35);
        try {
            org.joda.time.chrono.GJChronology gJChronology42 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4, (org.joda.time.ReadableInstant) dateTime35, 58087);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 58087");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800001L + "'", long13 == 28800001L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 28800100L + "'", long17 == 28800100L);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(yearMonthDay21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(property26);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTimeZone29);
        org.junit.Assert.assertNotNull(yearMonthDay30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 365 + "'", int36 == 365);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-28800000) + "'", int37 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withFields((org.joda.time.ReadablePartial) yearMonthDay5);
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.DateTime dateTime9 = dateTime1.withFieldAdded(durationFieldType7, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        try {
            org.joda.time.LocalTime localTime2 = dateTimeFormatter0.parseLocalTime("Property[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[dayOfMonth]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate4.withDayOfYear((int) (byte) 100);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        long long13 = dateTimeZone9.convertLocalToUTC((long) (byte) 1, false, 100L);
        org.joda.time.Interval interval14 = localDate4.toInterval(dateTimeZone9);
        try {
            org.joda.time.LocalDate localDate16 = localDate4.withEra(4);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 4 for era must be in the range [0,1]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800001L + "'", long13 == 28800001L);
        org.junit.Assert.assertNotNull(interval14);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDate();
        java.lang.Appendable appendable1 = null;
        try {
            dateTimeFormatter0.printTo(appendable1, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.io.File file0 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider1 = new org.joda.time.tz.ZoneInfoProvider(file0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No file directory provided");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime2.withZoneRetainFields(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTime9.getDayOfYear();
        int int11 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 9, (org.joda.time.Chronology) gJChronology12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        long long27 = dateTimeZone18.adjustOffset(28800001L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone28 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        org.joda.time.Chronology chronology29 = gJChronology12.withZone(dateTimeZone18);
        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        try {
            long long38 = gJChronology30.getDateTimeMillis((-49), (-25200000), 6, 7, 0, 0, 7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(yearMonthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800001L + "'", long27 == 28800001L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(gJChronology30);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.year();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone14);
        boolean boolean17 = dateTime11.isEqualNow();
        org.joda.time.DateTime dateTime18 = dateTime11.withEarlierOffsetAtOverlap();
        int int19 = property9.getDifference((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.DateTime dateTime21 = dateTime18.withYearOfCentury((int) (short) 10);
        org.joda.time.DateTime dateTime23 = dateTime18.minusYears((int) (byte) 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        org.joda.time.LocalDate.Property property10 = localDate6.centuryOfEra();
        int int11 = property10.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2922789 + "'", int11 == 2922789);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate2.plusWeeks(58097);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        int int17 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime15);
        boolean boolean18 = localDate2.equals((java.lang.Object) int17);
        org.joda.time.LocalDate localDate20 = localDate2.withCenturyOfEra(365);
        org.joda.time.LocalDate localDate22 = localDate20.withEra(0);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract(464793L, (-54000000L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 54464793L + "'", long2 == 54464793L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(19, 31);
        boolean boolean4 = dateTimeZone2.isStandardOffset(28800001L);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        int int9 = property8.getLeapAmount();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTime.Property property7 = dateTime1.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply((int) ' ', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3200 + "'", int2 == 3200);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (short) 10, chronology30);
        org.joda.time.LocalDate localDate33 = localDate31.plusWeeks(0);
        org.joda.time.LocalDate localDate35 = localDate31.plusWeeks(58097);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate35, (int) '#', locale37);
        long long41 = skipDateTimeField28.set((long) ' ', 31);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "35" + "'", str38.equals("35"));
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 32L + "'", long41 == 32L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), (org.joda.time.Chronology) iSOChronology1);
        long long6 = iSOChronology1.add((long) 'a', (long) 58087, 8);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 10, chronology8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone10);
        org.joda.time.DateTime dateTime13 = localDate9.toDateTimeAtMidnight(dateTimeZone10);
        org.joda.time.LocalTime localTime14 = null;
        org.joda.time.chrono.CopticChronology copticChronology15 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod16 = null;
        long long19 = copticChronology15.add(readablePeriod16, (long) (-25200000), 8);
        org.joda.time.DateTimeField dateTimeField20 = copticChronology15.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone21 = copticChronology15.getZone();
        org.joda.time.DateTime dateTime22 = localDate9.toDateTime(localTime14, dateTimeZone21);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate(dateTimeZone21);
        org.joda.time.Chronology chronology24 = iSOChronology1.withZone(dateTimeZone21);
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 464793L + "'", long6 == 464793L);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(copticChronology15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-25200000L) + "'", long19 == (-25200000L));
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(chronology24);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(100);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.DateTime.Property property3 = dateTime1.weekOfWeekyear();
        org.joda.time.ReadablePeriod readablePeriod4 = null;
        org.joda.time.DateTime dateTime5 = dateTime1.plus(readablePeriod4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.joda.time.Chronology chronology0 = null;
        org.joda.time.Chronology chronology1 = org.joda.time.DateTimeUtils.getChronology(chronology0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime3.withZoneRetainFields(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        int int11 = dateTime10.getDayOfYear();
        int int12 = dateTimeZone6.getOffset((org.joda.time.ReadableInstant) dateTime10);
        long long15 = dateTimeZone6.adjustOffset(28800001L, true);
        long long19 = dateTimeZone6.convertLocalToUTC(100L, false, (long) (short) 1);
        try {
            org.joda.time.LocalDate localDate20 = new org.joda.time.LocalDate((java.lang.Object) chronology1, dateTimeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: No partial converter found for type: org.joda.time.chrono.ISOChronology");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 365 + "'", int11 == 365);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-28800000) + "'", int12 == (-28800000));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 28800001L + "'", long15 == 28800001L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 28800100L + "'", long19 == 28800100L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15T16:08:12.898-07:00", (java.lang.Number) 9972000000L, (java.lang.Number) 1.0d, (java.lang.Number) 2000);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.joda.time.DateTimeFieldType dateTimeFieldType6 = illegalFieldValueException4.getDateTimeFieldType();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0d + "'", number5.equals(1.0d));
        org.junit.Assert.assertNull(dateTimeFieldType6);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, 0L, (-49));
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.weekyear();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeZone dateTimeZone1 = julianChronology0.getZone();
        try {
            long long9 = julianChronology0.getDateTimeMillis((-28800000), 1, (-11), (int) ' ', 15, (int) (byte) 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 32 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        boolean boolean2 = dateTimeFormatter0.isOffsetParsed();
        java.io.Writer writer3 = null;
        try {
            dateTimeFormatter0.printTo(writer3, (-62142940799993L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localDateOptionalTimeParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forOffsetHoursMinutes(86399, (-28800000));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Hours out of range: 86399");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 31, 24);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        int int7 = fixedDateTimeZone4.getOffset((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate2.plusWeeks(58097);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 10, chronology12);
        boolean boolean14 = yearMonthDay10.isBefore((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 10, chronology16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        int int19 = localDate17.indexOf(dateTimeFieldType18);
        boolean boolean20 = yearMonthDay10.isAfter((org.joda.time.ReadablePartial) localDate17);
        org.joda.time.LocalDate.Property property21 = localDate17.monthOfYear();
        org.joda.time.LocalDate localDate22 = localDate2.withFields((org.joda.time.ReadablePartial) localDate17);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(property21);
        org.junit.Assert.assertNotNull(localDate22);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 31, 24);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        int int7 = fixedDateTimeZone4.getOffset((long) 3200);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 31 + "'", int7 == 31);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        try {
            long long20 = gJChronology11.getDateTimeMillis(166, 2, 960, 365, 0, 166, 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (-25200000), 8);
        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.yearOfCentury();
        org.joda.time.Chronology chronology6 = copticChronology0.withUTC();
        int int7 = copticChronology0.getMinimumDaysInFirstWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-25200000L) + "'", long4 == (-25200000L));
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(chronology6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withFields((org.joda.time.ReadablePartial) yearMonthDay5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) (byte) 1);
        int int9 = dateTime8.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57660 + "'", int9 == 57660);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime7 = dateTime1.minusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.monthOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = null;
        org.joda.time.MutableDateTime mutableDateTime10 = dateTime1.toMutableDateTime(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(mutableDateTime10);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
        try {
            long long62 = remainderDateTimeField38.set((long) 13, "DateTimeField[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"DateTimeField[dayOfMonth]\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(yearMonthDay45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateMidnight50);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((int) (short) -1);
        int int9 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        int int12 = dateTime11.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime11.toDateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime8.toDateTime(dateTimeZone13);
        org.joda.time.DateMidnight dateMidnight17 = dateTime8.toDateMidnight();
        boolean boolean19 = dateMidnight17.isEqual(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 365 + "'", int12 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        org.joda.time.LocalDate localDate43 = localDate36.withYearOfCentury(0);
        org.joda.time.LocalDate localDate45 = localDate43.withDayOfYear(17);
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now(dateTimeZone46);
        org.joda.time.DateTimeZone dateTimeZone48 = dateTime47.getZone();
        org.joda.time.YearMonthDay yearMonthDay49 = dateTime47.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now(dateTimeZone50);
        org.joda.time.DateTime dateTime52 = dateTime47.withZoneRetainFields(dateTimeZone50);
        boolean boolean53 = dateTime47.isEqualNow();
        org.joda.time.DateTime.Property property54 = dateTime47.secondOfDay();
        org.joda.time.DateTime dateTime56 = dateTime47.plusYears(0);
        org.joda.time.DateTimeZone dateTimeZone57 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime58 = org.joda.time.DateTime.now(dateTimeZone57);
        org.joda.time.DateTimeZone dateTimeZone59 = dateTime58.getZone();
        org.joda.time.YearMonthDay yearMonthDay60 = dateTime58.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime62 = org.joda.time.DateTime.now(dateTimeZone61);
        org.joda.time.DateTime dateTime63 = dateTime58.withZoneRetainFields(dateTimeZone61);
        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime65 = org.joda.time.DateTime.now(dateTimeZone64);
        int int66 = dateTime65.getDayOfYear();
        int int67 = dateTimeZone61.getOffset((org.joda.time.ReadableInstant) dateTime65);
        long long70 = dateTimeZone61.adjustOffset(28800001L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone71 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone61);
        org.joda.time.DateTime dateTime72 = dateTime47.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone71);
        org.joda.time.DateMidnight dateMidnight73 = localDate43.toDateMidnight((org.joda.time.DateTimeZone) cachedDateTimeZone71);
        java.lang.String str74 = localDate43.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertNotNull(localDate45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTimeZone48);
        org.junit.Assert.assertNotNull(yearMonthDay49);
        org.junit.Assert.assertNotNull(dateTimeZone50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(dateTime52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(property54);
        org.junit.Assert.assertNotNull(dateTime56);
        org.junit.Assert.assertNotNull(dateTimeZone57);
        org.junit.Assert.assertNotNull(dateTime58);
        org.junit.Assert.assertNotNull(dateTimeZone59);
        org.junit.Assert.assertNotNull(yearMonthDay60);
        org.junit.Assert.assertNotNull(dateTimeZone61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTime63);
        org.junit.Assert.assertNotNull(dateTimeZone64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 365 + "'", int66 == 365);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-28800000) + "'", int67 == (-28800000));
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 28800001L + "'", long70 == 28800001L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone71);
        org.junit.Assert.assertNotNull(dateTime72);
        org.junit.Assert.assertNotNull(dateMidnight73);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "1900-12-31" + "'", str74.equals("1900-12-31"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
        java.lang.String str39 = remainderDateTimeField38.toString();
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (short) 10, chronology41);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = null;
        int int44 = localDate42.indexOf(dateTimeFieldType43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField38.getAsShortText((org.joda.time.ReadablePartial) localDate42, locale45);
        long long49 = remainderDateTimeField38.add((long) (short) 1, 58092);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str39.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "31" + "'", str46.equals("31"));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1833206515200001L + "'", long49 == 1833206515200001L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTime.Property property7 = dateTime1.centuryOfEra();
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        try {
            java.lang.String str9 = dateTime1.toString("JulianChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: J");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime9.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone12);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        int int17 = dateTime16.getDayOfYear();
        int int18 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime16);
        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
        long long21 = dateTimeZone7.getMillisKeepLocal(dateTimeZone12, (long) 10);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone22 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone7);
        try {
            org.joda.time.DateTime dateTime23 = new org.joda.time.DateTime(24, 12, 58097, 0, 58092, 960, 20, dateTimeZone7);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58092 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(yearMonthDay11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 365 + "'", int17 == 365);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 10L + "'", long21 == 10L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone22);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, 0L, (-49));
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekyear();
        org.joda.time.DateTimeField dateTimeField7 = iSOChronology0.clockhourOfHalfday();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeField7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        int int2 = org.joda.time.field.FieldUtils.safeMultiply(58087, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1858784 + "'", int2 == 1858784);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        try {
            org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime(20, 58092, 3200, 166, (-1));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 166 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
//        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
//        java.lang.String str39 = remainderDateTimeField38.toString();
//        org.joda.time.Chronology chronology41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (short) 10, chronology41);
//        int int43 = localDate42.getCenturyOfEra();
//        org.joda.time.LocalDate localDate45 = localDate42.minusMonths(0);
//        org.joda.time.chrono.CopticChronology copticChronology46 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod47 = null;
//        long long50 = copticChronology46.add(readablePeriod47, (long) (-25200000), 8);
//        org.joda.time.Chronology chronology52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate((long) (short) 10, chronology52);
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now(dateTimeZone54);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone54);
//        org.joda.time.DateTime dateTime57 = localDate53.toDateTimeAtMidnight(dateTimeZone54);
//        org.joda.time.LocalDate localDate59 = localDate53.minusYears(58087);
//        int[] intArray60 = localDate59.getValues();
//        boolean boolean61 = copticChronology46.equals((java.lang.Object) intArray60);
//        int int62 = remainderDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) localDate42, intArray60);
//        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTimeZone dateTimeZone64 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime65 = org.joda.time.DateTime.now(dateTimeZone64);
//        org.joda.time.DateTimeZone dateTimeZone66 = dateTime65.getZone();
//        org.joda.time.YearMonthDay yearMonthDay67 = dateTime65.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now(dateTimeZone68);
//        org.joda.time.DateTime dateTime70 = dateTime65.withZoneRetainFields(dateTimeZone68);
//        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime72 = org.joda.time.DateTime.now(dateTimeZone71);
//        int int73 = dateTime72.getDayOfYear();
//        int int74 = dateTimeZone68.getOffset((org.joda.time.ReadableInstant) dateTime72);
//        org.joda.time.chrono.GJChronology gJChronology75 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone68);
//        long long77 = dateTimeZone63.getMillisKeepLocal(dateTimeZone68, (long) 10);
//        java.util.Locale locale79 = null;
//        java.lang.String str80 = dateTimeZone68.getShortName((long) '4', locale79);
//        org.joda.time.DateTime dateTime81 = localDate42.toDateTimeAtStartOfDay(dateTimeZone68);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str39.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 19 + "'", int43 == 19);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(copticChronology46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-25200000L) + "'", long50 == (-25200000L));
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(localDate59);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone63);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertNotNull(dateTimeZone66);
//        org.junit.Assert.assertNotNull(yearMonthDay67);
//        org.junit.Assert.assertNotNull(dateTimeZone68);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(dateTime70);
//        org.junit.Assert.assertNotNull(dateTimeZone71);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 365 + "'", int73 == 365);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-28800000) + "'", int74 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology75);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 10L + "'", long77 == 10L);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "PST" + "'", str80.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime81);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hourMinute();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException("1969-12-31T16:00:00.100-08:00", "PST");
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        int int5 = dateTime4.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        long long14 = iSOChronology10.add(readablePeriod11, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology10.secondOfMinute();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 10, chronology17);
        org.joda.time.LocalDate localDate20 = localDate18.plusWeeks(0);
        org.joda.time.LocalDate localDate22 = localDate20.withDayOfYear((int) (byte) 100);
        int[] intArray24 = iSOChronology10.get((org.joda.time.ReadablePartial) localDate20, 0L);
        org.joda.time.Chronology chronology25 = iSOChronology10.withUTC();
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime9.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        int int29 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime26, "DateTimeField[dayOfMonth]", (int) (short) 10);
        try {
            long long31 = dateTimeFormatter0.parseMillis("69");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Cannot parse \"69\": Value 69 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 58089L + "'", long14 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-11) + "'", int29 == (-11));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.Partial partial3 = partial0.withFieldAdded(durationFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate2.plusWeeks(58097);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 10, chronology12);
        boolean boolean14 = yearMonthDay10.isBefore((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.LocalDate.Property property15 = localDate13.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
        org.joda.time.YearMonthDay yearMonthDay19 = dateTime17.toYearMonthDay();
        org.joda.time.Chronology chronology21 = null;
        org.joda.time.LocalDate localDate22 = new org.joda.time.LocalDate((long) (short) 10, chronology21);
        boolean boolean23 = yearMonthDay19.isBefore((org.joda.time.ReadablePartial) localDate22);
        org.joda.time.Chronology chronology25 = null;
        org.joda.time.LocalDate localDate26 = new org.joda.time.LocalDate((long) (short) 10, chronology25);
        org.joda.time.DateTimeFieldType dateTimeFieldType27 = null;
        int int28 = localDate26.indexOf(dateTimeFieldType27);
        boolean boolean29 = yearMonthDay19.isAfter((org.joda.time.ReadablePartial) localDate26);
        int int30 = localDate13.compareTo((org.joda.time.ReadablePartial) yearMonthDay19);
        org.joda.time.LocalDate localDate31 = localDate6.withFields((org.joda.time.ReadablePartial) yearMonthDay19);
        int int32 = localDate6.getYear();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(yearMonthDay19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(localDate31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3083 + "'", int32 == 3083);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        java.lang.String str29 = skipDateTimeField28.toString();
        boolean boolean30 = skipDateTimeField28.isSupported();
        int int31 = skipDateTimeField28.getMinimumValue();
        int int33 = skipDateTimeField28.getLeapAmount((long) 7);
        int int34 = skipDateTimeField28.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str29.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 31 + "'", int34 == 31);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate4.withCenturyOfEra((int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime9 = dateTimeFormatter7.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.LocalDate.Property property16 = localDate4.property(dateTimeFieldType15);
        int int17 = localDate4.getYear();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1969 + "'", int17 == 1969);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone dateTimeZone5 = dateTime4.getZone();
        org.joda.time.YearMonthDay yearMonthDay6 = dateTime4.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTime dateTime9 = dateTime4.withZoneRetainFields(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        int int12 = dateTime11.getDayOfYear();
        int int13 = dateTimeZone7.getOffset((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.chrono.GJChronology gJChronology14 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone7);
        long long16 = dateTimeZone2.getMillisKeepLocal(dateTimeZone7, (long) 10);
        org.joda.time.Chronology chronology17 = buddhistChronology0.withZone(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(yearMonthDay6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 365 + "'", int12 == 365);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-28800000) + "'", int13 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology14);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 10L + "'", long16 == 10L);
        org.junit.Assert.assertNotNull(chronology17);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        org.joda.time.DurationField durationField6 = iSOChronology0.days();
        long long9 = durationField6.subtract(6900035L, (-28800000));
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2488320003300035L + "'", long9 == 2488320003300035L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.joda.time.DateTime dateTime0 = org.joda.time.DateTime.now();
        org.junit.Assert.assertNotNull(dateTime0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTimeISO();
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 10, chronology9);
        org.joda.time.LocalDate localDate12 = localDate10.plusWeeks(0);
        org.joda.time.LocalDate localDate14 = localDate10.plusWeeks(58097);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone17 = dateTime16.getZone();
        org.joda.time.YearMonthDay yearMonthDay18 = dateTime16.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = dateTime16.withZoneRetainFields(dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
        int int24 = dateTime23.getDayOfYear();
        int int25 = dateTimeZone19.getOffset((org.joda.time.ReadableInstant) dateTime23);
        boolean boolean26 = localDate10.equals((java.lang.Object) int25);
        org.joda.time.LocalDate localDate28 = localDate10.withCenturyOfEra(365);
        org.joda.time.DateTime dateTime29 = dateTime7.withFields((org.joda.time.ReadablePartial) localDate28);
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (short) 10, chronology31);
        org.joda.time.LocalDate localDate34 = localDate32.plusWeeks(0);
        org.joda.time.LocalDate localDate36 = localDate34.withDayOfYear((int) (byte) 100);
        java.util.Date date37 = localDate36.toDate();
        org.joda.time.DateTime dateTime38 = dateTime7.withFields((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.Instant instant39 = new org.joda.time.Instant((java.lang.Object) dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(localDate14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(yearMonthDay18);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 365 + "'", int24 == 365);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-28800000) + "'", int25 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(localDate28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(dateTime38);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (-25200000), 8);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 10, chronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = localDate7.toDateTimeAtMidnight(dateTimeZone8);
        org.joda.time.LocalDate localDate13 = localDate7.minusYears(58087);
        int[] intArray14 = localDate13.getValues();
        boolean boolean15 = copticChronology0.equals((java.lang.Object) intArray14);
        org.joda.time.DurationField durationField16 = copticChronology0.millis();
        org.joda.time.DateTimeField dateTimeField17 = copticChronology0.dayOfWeek();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-25200000L) + "'", long4 == (-25200000L));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(58085);
        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
        java.lang.String str3 = gregorianChronology2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gregorianChronology2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "GregorianChronology[+00:00:58.085]" + "'", str3.equals("GregorianChronology[+00:00:58.085]"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        java.lang.String str8 = property7.getAsShortText();
        org.joda.time.DurationField durationField9 = property7.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31" + "'", str8.equals("31"));
        org.junit.Assert.assertNotNull(durationField9);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfMonth();
        try {
            org.joda.time.DateTime dateTime9 = dateTime4.withYearOfEra((-2));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -2 for yearOfEra must be in the range [1,292278993]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.plus((long) '4');
        long long3 = instant0.getMillis();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant0.minus(readableDuration4);
        org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime((java.lang.Object) readableDuration4);
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(instant5);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("");
        boolean boolean2 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException1);
        java.lang.Throwable[] throwableArray3 = illegalInstantException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now(dateTimeZone45);
        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
        org.joda.time.YearMonthDay yearMonthDay48 = dateTime46.toYearMonthDay();
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 10, chronology50);
        boolean boolean52 = yearMonthDay48.isBefore((org.joda.time.ReadablePartial) localDate51);
        int[] intArray58 = new int[] { 58093, 58089, 1969, 0, (short) 0 };
        int int59 = skipDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) localDate51, intArray58);
        int int61 = skipDateTimeField28.getMaximumValue((long) 24);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(yearMonthDay48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 31 + "'", int61 == 31);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime7 = dateTime6.toDateTimeISO();
        org.joda.time.DateTime dateTime9 = dateTime6.plusHours(3200);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial2 = partial0.minus(readablePeriod1);
        org.joda.time.Chronology chronology4 = null;
        org.joda.time.LocalDate localDate5 = new org.joda.time.LocalDate((long) (short) 10, chronology4);
        org.joda.time.LocalDate localDate7 = localDate5.plusWeeks(0);
        org.joda.time.LocalDate.Property property8 = localDate5.year();
        org.joda.time.DateTime dateTime9 = localDate5.toDateTimeAtMidnight();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter10 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime12 = dateTimeFormatter10.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime14 = dateTime12.plus(readablePeriod13);
        org.joda.time.DateTime dateTime16 = dateTime14.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property17 = dateTime14.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = property17.getFieldType();
        int int19 = localDate5.get(dateTimeFieldType18);
        try {
            org.joda.time.Partial partial21 = partial0.withField(dateTimeFieldType18, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'dayOfMonth' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(partial2);
        org.junit.Assert.assertNotNull(localDate7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeFormatter10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 31 + "'", int19 == 31);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("2019-06-15T16:08:12.898-07:00");
        int int2 = dateTime1.getYearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.minus(readablePeriod3);
        int int5 = dateTime1.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 58092898 + "'", int5 == 58092898);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.joda.time.LocalDate localDate0 = new org.joda.time.LocalDate();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate((long) (short) 10, chronology2);
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone4);
        org.joda.time.DateTime dateTime7 = localDate3.toDateTimeAtMidnight(dateTimeZone4);
        org.joda.time.LocalTime localTime8 = null;
        org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        long long13 = copticChronology9.add(readablePeriod10, (long) (-25200000), 8);
        org.joda.time.DateTimeField dateTimeField14 = copticChronology9.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone15 = copticChronology9.getZone();
        org.joda.time.DateTime dateTime16 = localDate3.toDateTime(localTime8, dateTimeZone15);
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate(dateTimeZone15);
        org.joda.time.DateMidnight dateMidnight18 = localDate0.toDateMidnight(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(copticChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-25200000L) + "'", long13 == (-25200000L));
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateMidnight18);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        long long13 = iSOChronology9.add(readablePeriod10, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology9.secondOfMinute();
        org.joda.time.DateTime dateTime15 = dateMidnight8.toDateTime((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology9.yearOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 58089L + "'", long13 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.joda.time.Instant instant0 = org.joda.time.Instant.now();
        org.joda.time.Instant instant2 = instant0.plus((long) '4');
        long long3 = instant0.getMillis();
        org.joda.time.ReadableDuration readableDuration4 = null;
        org.joda.time.Instant instant5 = instant0.minus(readableDuration4);
        long long6 = instant5.getMillis();
        org.junit.Assert.assertNotNull(instant0);
        org.junit.Assert.assertNotNull(instant2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
        org.junit.Assert.assertNotNull(instant5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 100L + "'", long6 == 100L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        try {
            long long32 = skipDateTimeField28.set(1833206515200001L, "1900-12-31");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"1900-12-31\" for dayOfMonth is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        java.lang.String str29 = skipDateTimeField28.toString();
        boolean boolean30 = skipDateTimeField28.isSupported();
        int int31 = skipDateTimeField28.getMinimumValue();
        int int33 = skipDateTimeField28.getLeapAmount((long) 7);
        long long36 = skipDateTimeField28.getDifferenceAsLong((long) (byte) 100, 1560640094305L);
        org.joda.time.ReadablePartial readablePartial37 = null;
        int int38 = skipDateTimeField28.getMinimumValue(readablePartial37);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str29.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + (-18063L) + "'", long36 == (-18063L));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        java.util.Locale locale30 = null;
        java.lang.String str31 = skipDateTimeField28.getAsText(58087, locale30);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "58087" + "'", str31.equals("58087"));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 10, chronology9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        int int12 = localDate10.indexOf(dateTimeFieldType11);
        boolean boolean13 = yearMonthDay3.isAfter((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.LocalDate.Property property14 = localDate10.weekyear();
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 10, chronology16);
        org.joda.time.LocalDate localDate19 = localDate17.plusWeeks(0);
        org.joda.time.LocalDate.Property property20 = localDate17.year();
        org.joda.time.DateTime dateTime21 = localDate17.toDateTimeAtMidnight();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter22 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime24 = dateTimeFormatter22.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod25 = null;
        org.joda.time.DateTime dateTime26 = dateTime24.plus(readablePeriod25);
        org.joda.time.DateTime dateTime28 = dateTime26.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property29 = dateTime26.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType30 = property29.getFieldType();
        int int31 = localDate17.get(dateTimeFieldType30);
        try {
            org.joda.time.LocalDate localDate33 = localDate10.withField(dateTimeFieldType30, 58092898);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58092898 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(localDate19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeFormatter22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(property29);
        org.junit.Assert.assertNotNull(dateTimeFieldType30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 31 + "'", int31 == 31);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        long long1 = org.joda.time.DateTimeUtils.toJulianDayNumber((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2440587L + "'", long1 == 2440587L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.DateTime dateTime9 = property7.withMinimumValue();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone15 = dateTime14.getZone();
        org.joda.time.YearMonthDay yearMonthDay16 = dateTime14.toYearMonthDay();
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 10, chronology18);
        boolean boolean20 = yearMonthDay16.isBefore((org.joda.time.ReadablePartial) localDate19);
        org.joda.time.DateMidnight dateMidnight21 = localDate19.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology22 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod23 = null;
        long long26 = iSOChronology22.add(readablePeriod23, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField27 = iSOChronology22.secondOfMinute();
        org.joda.time.DateTime dateTime28 = dateMidnight21.toDateTime((org.joda.time.Chronology) iSOChronology22);
        org.joda.time.LocalDate localDate29 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology22);
        boolean boolean30 = dateTime9.equals((java.lang.Object) 19);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(yearMonthDay16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dateMidnight21);
        org.junit.Assert.assertNotNull(iSOChronology22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 58089L + "'", long26 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTime.Property property7 = dateTime1.centuryOfEra();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime9.toYearMonthDay();
        boolean boolean12 = dateTime1.isAfter((org.joda.time.ReadableInstant) dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(yearMonthDay11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((int) (short) -1);
        int int9 = dateTime8.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        int int12 = dateTime11.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime11.toDateTime(dateTimeZone13);
        org.joda.time.DateTime dateTime16 = dateTime8.toDateTime(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        int int19 = dateTime18.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = dateTime18.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime24 = dateTime18.minusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property25 = dateTime18.monthOfYear();
        int int26 = dateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime18);
        try {
            org.joda.time.chrono.GregorianChronology gregorianChronology28 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone13, 58097);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 58097");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 365 + "'", int12 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 365 + "'", int19 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(property25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-28800000) + "'", int26 == (-28800000));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology3);
        org.joda.time.DateTimeField dateTimeField5 = buddhistChronology3.minuteOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTimeField5);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        long long13 = dateTimeZone4.adjustOffset(28800001L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        int int16 = cachedDateTimeZone14.getStandardOffset(0L);
        boolean boolean17 = cachedDateTimeZone14.isFixed();
        int int19 = cachedDateTimeZone14.getStandardOffset(100L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800001L + "'", long13 == 28800001L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.joda.time.DurationField durationField0 = null;
        org.joda.time.DurationFieldType durationFieldType1 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField3 = new org.joda.time.field.ScaledDurationField(durationField0, durationFieldType1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        try {
            long long2 = org.joda.time.field.FieldUtils.safeMultiply(1833206515200001L, 58097);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: Multiplication overflows a long: 1833206515200001 * 58097");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTime dateTime9 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime11 = dateTime1.minusWeeks((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(58085);
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(gJChronology2);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField28, dateTimeFieldType45);
        java.util.Locale locale48 = null;
        java.lang.String str49 = skipDateTimeField28.getAsShortText((-25200000L), locale48);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "31" + "'", str49.equals("31"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        int int14 = gJChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField15 = gJChronology11.yearOfCentury();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dateTimeField15);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.joda.time.tz.DefaultNameProvider defaultNameProvider0 = new org.joda.time.tz.DefaultNameProvider();
        java.util.Locale locale1 = null;
        java.lang.String str4 = defaultNameProvider0.getShortName(locale1, "69", "ISOChronology[America/Los_Angeles]");
        java.util.Locale locale5 = null;
        java.lang.String str8 = defaultNameProvider0.getShortName(locale5, "31", "(\"org.joda.time.JodaTimePermission\" \"31\")");
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str8);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, 0L, (-49));
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        int int17 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField19 = gJChronology18.millis();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime22.toDateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime22.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime28 = dateTime27.toDateTimeISO();
        boolean boolean29 = gJChronology18.equals((java.lang.Object) dateTime27);
        org.joda.time.DurationField durationField30 = gJChronology18.minutes();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology18.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime34 = dateTimeFormatter32.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.plus(readablePeriod35);
        org.joda.time.DateTime dateTime38 = dateTime36.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property39 = dateTime36.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField45 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType40, 9);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType40, (-21), 58085, 3083);
        try {
            long long52 = offsetDateTimeField49.add((long) ' ', (long) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1950 for dayOfMonth must be in the range [58085,3083]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property7.setCopy(0);
        org.joda.time.DateTime dateTime10 = property7.roundCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.LocalDate localDate4 = org.joda.time.LocalDate.now((org.joda.time.Chronology) buddhistChronology3);
        java.lang.String str5 = buddhistChronology3.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "BuddhistChronology[America/Los_Angeles]" + "'", str5.equals("BuddhistChronology[America/Los_Angeles]"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        org.joda.time.DateTime dateTime9 = property7.addToCopy(100L);
        int int10 = property7.get();
        org.joda.time.DateTime dateTime11 = property7.roundHalfCeilingCopy();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 31 + "'", int10 == 31);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate.Property property5 = localDate2.year();
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property7 = localDate2.dayOfMonth();
        org.joda.time.LocalDate localDate9 = localDate2.withWeekyear(57660);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        long long13 = dateTimeZone4.adjustOffset(28800001L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        int int16 = cachedDateTimeZone14.getOffset(28800100L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800001L + "'", long13 == 28800001L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        int int5 = dateTime2.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            org.joda.time.LocalDate localDate3 = new org.joda.time.LocalDate(17, 31, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateParser();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("org.joda.time.IllegalInstantException: ");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"org.joda.time.IllegalInstantExce...\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        org.joda.time.DurationField durationField6 = iSOChronology0.days();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField8 = new org.joda.time.field.DecoratedDurationField(durationField6, durationFieldType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
        java.util.Locale locale61 = null;
        java.lang.String str62 = remainderDateTimeField38.getAsShortText(28800035L, locale61);
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = null;
        try {
            org.joda.time.field.DividedDateTimeField dividedDateTimeField64 = new org.joda.time.field.DividedDateTimeField(remainderDateTimeField38, dateTimeFieldType63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(yearMonthDay45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateMidnight50);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "8" + "'", str62.equals("8"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField6 = iSOChronology0.minutes();
        long long9 = durationField6.subtract((long) 8, (long) (byte) 10);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-599992L) + "'", long9 == (-599992L));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        try {
            org.joda.time.DateTime dateTime6 = new org.joda.time.DateTime(57660, 31, 7, (-25200000), (-28800000), 58092898);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25200000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.Chronology chronology2 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withChronology(chronology2);
        java.lang.String str5 = dateTimeFormatter0.print((long) '#');
        java.lang.StringBuffer stringBuffer6 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime9 = dateTimeFormatter7.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        try {
            dateTimeFormatter0.printTo(stringBuffer6, (org.joda.time.ReadableInstant) dateTime9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "16" + "'", str5.equals("16"));
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.joda.time.tz.Provider provider0 = org.joda.time.DateTimeZone.getProvider();
        org.junit.Assert.assertNotNull(provider0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone14);
        boolean boolean17 = dateTime11.isEqualNow();
        org.joda.time.DateTime dateTime18 = dateTime11.withEarlierOffsetAtOverlap();
        int int19 = property9.getDifference((org.joda.time.ReadableInstant) dateTime18);
        int int20 = dateTime18.getSecondOfDay();
        org.joda.time.MutableDateTime mutableDateTime21 = dateTime18.toMutableDateTimeISO();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 57600 + "'", int20 == 57600);
        org.junit.Assert.assertNotNull(mutableDateTime21);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        java.lang.String str29 = skipDateTimeField28.toString();
        boolean boolean30 = skipDateTimeField28.isSupported();
        int int31 = skipDateTimeField28.getMinimumValue();
        int int33 = skipDateTimeField28.getLeapAmount((long) 7);
        long long35 = skipDateTimeField28.roundFloor(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str29.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + (-57600000L) + "'", long35 == (-57600000L));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.millisOfSecond();
        try {
            long long7 = iSOChronology0.getDateTimeMillis((long) (byte) 1, 14, 2000, 58092898, (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2000 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
        java.lang.String str39 = remainderDateTimeField38.toString();
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (short) 10, chronology41);
        org.joda.time.LocalDate localDate44 = localDate42.plusWeeks(0);
        org.joda.time.LocalDate.Property property45 = localDate42.year();
        org.joda.time.LocalDate localDate46 = property45.roundFloorCopy();
        int int47 = remainderDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) localDate46);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str39.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertNotNull(localDate44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(localDate46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.Chronology chronology1 = partial0.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Partial partial3 = partial0.withChronologyRetainFields((org.joda.time.Chronology) copticChronology2);
        java.lang.String str4 = partial3.toStringList();
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(partial3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[]" + "'", str4.equals("[]"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
        java.util.Locale locale61 = null;
        java.lang.String str62 = remainderDateTimeField38.getAsShortText(28800035L, locale61);
        java.util.Locale locale64 = null;
        java.lang.String str65 = remainderDateTimeField38.getAsShortText((int) (byte) 10, locale64);
        long long67 = remainderDateTimeField38.roundHalfCeiling((long) (-2));
        org.joda.time.DurationField durationField68 = remainderDateTimeField38.getDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(yearMonthDay45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateMidnight50);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "8" + "'", str62.equals("8"));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10" + "'", str65.equals("10"));
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 28800000L + "'", long67 == 28800000L);
        org.junit.Assert.assertNotNull(durationField68);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        org.joda.time.LocalDate localDate8 = localDate2.minusYears(58087);
        org.joda.time.LocalDate localDate10 = localDate2.withYearOfCentury(12);
        org.joda.time.LocalDate.Property property11 = localDate10.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(property11);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField6 = iSOChronology0.minutes();
        org.joda.time.DurationFieldType durationFieldType7 = null;
        try {
            org.joda.time.field.ScaledDurationField scaledDurationField9 = new org.joda.time.field.ScaledDurationField(durationField6, durationFieldType7, 58085);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(durationField6);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
        java.util.Locale locale61 = null;
        java.lang.String str62 = remainderDateTimeField38.getAsShortText(28800035L, locale61);
        java.util.Locale locale64 = null;
        java.lang.String str65 = remainderDateTimeField38.getAsShortText((int) (byte) 10, locale64);
        java.lang.String str66 = remainderDateTimeField38.toString();
        boolean boolean67 = remainderDateTimeField38.isLenient();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(yearMonthDay45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateMidnight50);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "8" + "'", str62.equals("8"));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10" + "'", str65.equals("10"));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str66.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        int int3 = dateTime2.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime2.toDateTime(dateTimeZone4);
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) 14, dateTimeZone4);
        try {
            org.joda.time.chrono.CopticChronology copticChronology9 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone4, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 52");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 365 + "'", int3 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.Chronology chronology31 = null;
        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (short) 10, chronology31);
        org.joda.time.LocalDate localDate34 = localDate32.plusWeeks(0);
        org.joda.time.LocalDate.Property property35 = localDate32.year();
        org.joda.time.LocalDate localDate36 = property35.roundFloorCopy();
        int[] intArray37 = null;
        int int38 = skipDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) localDate36, intArray37);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(localDate34);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(localDate36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.Chronology chronology9 = null;
        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 10, chronology9);
        org.joda.time.DateTimeFieldType dateTimeFieldType11 = null;
        int int12 = localDate10.indexOf(dateTimeFieldType11);
        boolean boolean13 = yearMonthDay3.isAfter((org.joda.time.ReadablePartial) localDate10);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
        int int30 = dateTime29.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(dateTimeZone31);
        org.joda.time.DateTime dateTime33 = dateTime29.toDateTime(dateTimeZone31);
        org.joda.time.DateTime dateTime34 = dateTime29.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime35 = dateTime34.toDateTimeISO();
        boolean boolean36 = gJChronology25.equals((java.lang.Object) dateTime34);
        org.joda.time.DurationField durationField37 = gJChronology25.minutes();
        org.joda.time.DateTimeField dateTimeField38 = gJChronology25.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter39 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime41 = dateTimeFormatter39.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod42 = null;
        org.joda.time.DateTime dateTime43 = dateTime41.plus(readablePeriod42);
        org.joda.time.DateTime dateTime45 = dateTime43.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property46 = dateTime43.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType47 = property46.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException50 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType47, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField52 = new org.joda.time.field.RemainderDateTimeField(dateTimeField38, dateTimeFieldType47, 9);
        java.lang.String str53 = remainderDateTimeField52.toString();
        org.joda.time.Chronology chronology55 = null;
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate((long) (short) 10, chronology55);
        int int57 = localDate56.getCenturyOfEra();
        org.joda.time.LocalDate localDate59 = localDate56.minusMonths(0);
        org.joda.time.chrono.CopticChronology copticChronology60 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod61 = null;
        long long64 = copticChronology60.add(readablePeriod61, (long) (-25200000), 8);
        org.joda.time.Chronology chronology66 = null;
        org.joda.time.LocalDate localDate67 = new org.joda.time.LocalDate((long) (short) 10, chronology66);
        org.joda.time.DateTimeZone dateTimeZone68 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime69 = org.joda.time.DateTime.now(dateTimeZone68);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone68);
        org.joda.time.DateTime dateTime71 = localDate67.toDateTimeAtMidnight(dateTimeZone68);
        org.joda.time.LocalDate localDate73 = localDate67.minusYears(58087);
        int[] intArray74 = localDate73.getValues();
        boolean boolean75 = copticChronology60.equals((java.lang.Object) intArray74);
        int int76 = remainderDateTimeField52.getMinimumValue((org.joda.time.ReadablePartial) localDate56, intArray74);
        org.joda.time.Chronology chronology78 = null;
        org.joda.time.LocalDate localDate79 = new org.joda.time.LocalDate((long) (short) 10, chronology78);
        org.joda.time.LocalDate localDate81 = localDate79.plusWeeks(0);
        org.joda.time.LocalDate.Property property82 = localDate79.year();
        org.joda.time.DateTime dateTime83 = localDate79.toDateTimeAtMidnight();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter84 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime86 = dateTimeFormatter84.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod87 = null;
        org.joda.time.DateTime dateTime88 = dateTime86.plus(readablePeriod87);
        org.joda.time.DateTime dateTime90 = dateTime88.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property91 = dateTime88.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType92 = property91.getFieldType();
        int int93 = localDate79.get(dateTimeFieldType92);
        boolean boolean94 = localDate56.isSupported(dateTimeFieldType92);
        org.joda.time.LocalDate.Property property95 = localDate10.property(dateTimeFieldType92);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 365 + "'", int30 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(durationField37);
        org.junit.Assert.assertNotNull(dateTimeField38);
        org.junit.Assert.assertNotNull(dateTimeFormatter39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertNotNull(property46);
        org.junit.Assert.assertNotNull(dateTimeFieldType47);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str53.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 19 + "'", int57 == 19);
        org.junit.Assert.assertNotNull(localDate59);
        org.junit.Assert.assertNotNull(copticChronology60);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + (-25200000L) + "'", long64 == (-25200000L));
        org.junit.Assert.assertNotNull(dateTimeZone68);
        org.junit.Assert.assertNotNull(dateTime69);
        org.junit.Assert.assertNotNull(dateTime71);
        org.junit.Assert.assertNotNull(localDate73);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(localDate81);
        org.junit.Assert.assertNotNull(property82);
        org.junit.Assert.assertNotNull(dateTime83);
        org.junit.Assert.assertNotNull(dateTimeFormatter84);
        org.junit.Assert.assertNotNull(dateTime86);
        org.junit.Assert.assertNotNull(dateTime88);
        org.junit.Assert.assertNotNull(dateTime90);
        org.junit.Assert.assertNotNull(property91);
        org.junit.Assert.assertNotNull(dateTimeFieldType92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 31 + "'", int93 == 31);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertNotNull(property95);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial2 = partial0.minus(readablePeriod1);
        java.util.Locale locale4 = null;
        try {
            java.lang.String str5 = partial2.toString("PST", locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: P");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(partial2);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
        org.joda.time.DateTimeFieldType dateTimeFieldType45 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField46 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField28, dateTimeFieldType45);
        java.lang.String str48 = delegatedDateTimeField46.getAsShortText((long) (byte) -1);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "31" + "'", str48.equals("31"));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        int int4 = dateTime1.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime6 = dateTime1.withMillisOfSecond(0);
        int int7 = dateTime6.getHourOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime10 = dateTime1.withCenturyOfEra(14);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime2.withZoneRetainFields(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTime9.getDayOfYear();
        int int11 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 9, (org.joda.time.Chronology) gJChronology12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        long long27 = dateTimeZone18.adjustOffset(28800001L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone28 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        org.joda.time.Chronology chronology29 = gJChronology12.withZone(dateTimeZone18);
        long long31 = dateTimeZone18.convertUTCToLocal((long) 12);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(yearMonthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800001L + "'", long27 == 28800001L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-28799988L) + "'", long31 == (-28799988L));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTime();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime7 = dateTime1.minusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.monthOfYear();
        org.joda.time.DateTime dateTime9 = property8.getDateTime();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
        java.lang.String str45 = skipDateTimeField28.getName();
        java.lang.String str46 = skipDateTimeField28.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfMonth" + "'", str45.equals("dayOfMonth"));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str46.equals("DateTimeField[dayOfMonth]"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime7 = dateTime1.minusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.monthOfYear();
        org.joda.time.DateTime dateTime10 = dateTime1.plusMillis(19);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-25200000));
        java.lang.String str5 = dateTimeFormatter0.print((long) (-25200000));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "09" + "'", str5.equals("09"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.clockhourOfDay();
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.yearOfEra();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(dateTimeField6);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (-25200000), 8);
        org.joda.time.DateTime dateTime5 = new org.joda.time.DateTime((java.lang.Object) long4);
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-25200000L) + "'", long4 == (-25200000L));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate4.withCenturyOfEra((int) (short) 0);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.joda.time.Chronology chronology12 = null;
        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 10, chronology12);
        boolean boolean14 = yearMonthDay10.isBefore((org.joda.time.ReadablePartial) localDate13);
        org.joda.time.Chronology chronology16 = null;
        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 10, chronology16);
        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
        int int19 = localDate17.indexOf(dateTimeFieldType18);
        boolean boolean20 = yearMonthDay10.isAfter((org.joda.time.ReadablePartial) localDate17);
        boolean boolean21 = localDate6.isAfter((org.joda.time.ReadablePartial) yearMonthDay10);
        org.joda.time.LocalDate localDate23 = localDate6.withDayOfYear((int) (short) 100);
        int int24 = localDate23.getDayOfMonth();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(localDate23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecond();
        java.lang.StringBuffer stringBuffer1 = null;
        try {
            dateTimeFormatter0.printTo(stringBuffer1, (long) (-25200000));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        long long13 = dateTimeZone4.adjustOffset(28800001L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        org.joda.time.chrono.ISOChronology iSOChronology15 = org.joda.time.chrono.ISOChronology.getInstance(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800001L + "'", long13 == 28800001L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertNotNull(iSOChronology15);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.getActions();
        java.lang.String str4 = jodaTimePermission1.toString();
        java.lang.String str5 = jodaTimePermission1.toString();
        java.lang.String str6 = jodaTimePermission1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"31\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"31\")"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"31\")" + "'", str5.equals("(\"org.joda.time.JodaTimePermission\" \"31\")"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"31\")" + "'", str6.equals("(\"org.joda.time.JodaTimePermission\" \"31\")"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate.Property property8 = localDate6.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime10.getZone();
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime10.toYearMonthDay();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 10, chronology14);
        boolean boolean16 = yearMonthDay12.isBefore((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 10, chronology18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        int int21 = localDate19.indexOf(dateTimeFieldType20);
        boolean boolean22 = yearMonthDay12.isAfter((org.joda.time.ReadablePartial) localDate19);
        int int23 = localDate6.compareTo((org.joda.time.ReadablePartial) yearMonthDay12);
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.UTC;
        java.util.TimeZone timeZone25 = dateTimeZone24.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.forTimeZone(timeZone25);
        org.joda.time.DateMidnight dateMidnight27 = localDate6.toDateMidnight(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateMidnight27);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate2.plusWeeks(58097);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 10, chronology8);
        int int10 = localDate9.getCenturyOfEra();
        org.joda.time.LocalDate localDate12 = localDate9.minusMonths(0);
        org.joda.time.LocalDate.Property property13 = localDate12.weekyear();
        boolean boolean14 = localDate2.isEqual((org.joda.time.ReadablePartial) localDate12);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(property13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime.Property property7 = dateTime6.dayOfMonth();
        java.util.Locale locale8 = null;
        java.util.Calendar calendar9 = dateTime6.toCalendar(locale8);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        int int19 = dateTime18.getDayOfYear();
        int int20 = dateTimeZone14.getOffset((org.joda.time.ReadableInstant) dateTime18);
        org.joda.time.chrono.GJChronology gJChronology21 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone14);
        org.joda.time.DurationField durationField22 = gJChronology21.millis();
        org.joda.time.DateTimeField dateTimeField23 = gJChronology21.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
        org.joda.time.YearMonthDay yearMonthDay27 = dateTime25.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
        org.joda.time.DateTime dateTime30 = dateTime25.withZoneRetainFields(dateTimeZone28);
        org.joda.time.DateTimeZone dateTimeZone31 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime32 = org.joda.time.DateTime.now(dateTimeZone31);
        int int33 = dateTime32.getDayOfYear();
        int int34 = dateTimeZone28.getOffset((org.joda.time.ReadableInstant) dateTime32);
        org.joda.time.chrono.GJChronology gJChronology35 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone28);
        org.joda.time.DurationField durationField36 = gJChronology35.millis();
        org.joda.time.DateTimeField dateTimeField37 = gJChronology35.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField38 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology21, dateTimeField37);
        org.joda.time.DateTime dateTime39 = dateTime6.toDateTime((org.joda.time.Chronology) gJChronology21);
        org.joda.time.DateTime dateTime41 = dateTime39.plusYears((int) (byte) 1);
        org.joda.time.DateTime dateTime43 = dateTime39.minusHours(58087);
        int int44 = dateTime39.getYearOfEra();
        try {
            org.joda.time.DateTime dateTime46 = dateTime39.withWeekOfWeekyear((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for weekOfWeekyear must be in the range [1,53]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(calendar9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 365 + "'", int19 == 365);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-28800000) + "'", int20 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology21);
        org.junit.Assert.assertNotNull(durationField22);
        org.junit.Assert.assertNotNull(dateTimeField23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(yearMonthDay27);
        org.junit.Assert.assertNotNull(dateTimeZone28);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(dateTimeZone31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 365 + "'", int33 == 365);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-28800000) + "'", int34 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology35);
        org.junit.Assert.assertNotNull(durationField36);
        org.junit.Assert.assertNotNull(dateTimeField37);
        org.junit.Assert.assertNotNull(dateTime39);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1969 + "'", int44 == 1969);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, 0L, (-49));
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        int int17 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField19 = gJChronology18.millis();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime22.toDateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime22.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime28 = dateTime27.toDateTimeISO();
        boolean boolean29 = gJChronology18.equals((java.lang.Object) dateTime27);
        org.joda.time.DurationField durationField30 = gJChronology18.minutes();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology18.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime34 = dateTimeFormatter32.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.plus(readablePeriod35);
        org.joda.time.DateTime dateTime38 = dateTime36.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property39 = dateTime36.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField45 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType40, 9);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType40, (-21), 58085, 3083);
        int int50 = offsetDateTimeField49.getOffset();
        long long52 = offsetDateTimeField49.roundHalfFloor((long) 2922789);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-21) + "'", int50 == (-21));
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + (-230400000L) + "'", long52 == (-230400000L));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime1.minus(readableDuration8);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
        org.joda.time.DateTime dateTime11 = property10.roundFloorCopy();
        org.joda.time.DateTime dateTime13 = dateTime11.minusMonths(166);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone14);
        boolean boolean17 = dateTime11.isEqualNow();
        org.joda.time.DateTime dateTime18 = dateTime11.withEarlierOffsetAtOverlap();
        int int19 = property9.getDifference((org.joda.time.ReadableInstant) dateTime18);
        int int20 = property9.getLeapAmount();
        java.util.Locale locale21 = null;
        int int22 = property9.getMaximumTextLength(locale21);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2 + "'", int22 == 2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        java.lang.String str6 = iSOChronology0.toString();
        org.joda.time.DurationField durationField7 = iSOChronology0.years();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str6.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(durationField7);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        org.joda.time.ReadableInstant readableInstant1 = null;
        org.joda.time.chrono.GJChronology gJChronology2 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, readableInstant1);
        org.joda.time.DateTimeZone dateTimeZone3 = gJChronology2.getZone();
        org.junit.Assert.assertNotNull(gJChronology2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now(dateTimeZone45);
        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
        org.joda.time.YearMonthDay yearMonthDay48 = dateTime46.toYearMonthDay();
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 10, chronology50);
        boolean boolean52 = yearMonthDay48.isBefore((org.joda.time.ReadablePartial) localDate51);
        org.joda.time.LocalDate.Property property53 = localDate51.dayOfYear();
        org.joda.time.LocalDate localDate54 = property53.roundHalfFloorCopy();
        java.util.Date date55 = localDate54.toDate();
        org.joda.time.LocalDate localDate56 = org.joda.time.LocalDate.fromDateFields(date55);
        java.util.Locale locale57 = null;
        java.lang.String str58 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate56, locale57);
        int int59 = skipDateTimeField28.getMaximumValue();
        long long61 = skipDateTimeField28.roundHalfCeiling(58L);
        org.joda.time.Chronology chronology63 = null;
        org.joda.time.LocalDate localDate64 = new org.joda.time.LocalDate((long) (short) 10, chronology63);
        org.joda.time.LocalDate localDate66 = localDate64.plusWeeks(0);
        org.joda.time.LocalDate localDate68 = localDate64.plusWeeks(58097);
        int int69 = skipDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) localDate68);
        java.util.Locale locale71 = null;
        try {
            java.lang.String str72 = localDate68.toString("America/Los_Angeles", locale71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Illegal pattern component: A");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(yearMonthDay48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "31" + "'", str58.equals("31"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 31 + "'", int59 == 31);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 28800000L + "'", long61 == 28800000L);
        org.junit.Assert.assertNotNull(localDate66);
        org.junit.Assert.assertNotNull(localDate68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime2.withZoneRetainFields(dateTimeZone5);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        int int10 = dateTime9.getDayOfYear();
        int int11 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime9);
        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
        org.joda.time.DateTime dateTime13 = new org.joda.time.DateTime((long) 9, (org.joda.time.Chronology) gJChronology12);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        long long27 = dateTimeZone18.adjustOffset(28800001L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone28 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone18);
        org.joda.time.Chronology chronology29 = gJChronology12.withZone(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone34);
        org.joda.time.DateTime dateTime36 = dateTime31.withZoneRetainFields(dateTimeZone34);
        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now(dateTimeZone37);
        int int39 = dateTime38.getDayOfYear();
        int int40 = dateTimeZone34.getOffset((org.joda.time.ReadableInstant) dateTime38);
        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34);
        org.joda.time.DurationField durationField42 = gJChronology41.millis();
        org.joda.time.DateTimeField dateTimeField43 = gJChronology41.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone44 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime45 = org.joda.time.DateTime.now(dateTimeZone44);
        int int46 = dateTime45.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone47 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime48 = org.joda.time.DateTime.now(dateTimeZone47);
        org.joda.time.DateTime dateTime49 = dateTime45.toDateTime(dateTimeZone47);
        org.joda.time.DateTime dateTime50 = dateTime45.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime51 = dateTime50.toDateTimeISO();
        boolean boolean52 = gJChronology41.equals((java.lang.Object) dateTime50);
        org.joda.time.DurationField durationField53 = gJChronology41.minutes();
        org.joda.time.DateTimeField dateTimeField54 = gJChronology41.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter55 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime57 = dateTimeFormatter55.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod58 = null;
        org.joda.time.DateTime dateTime59 = dateTime57.plus(readablePeriod58);
        org.joda.time.DateTime dateTime61 = dateTime59.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property62 = dateTime59.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType63 = property62.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException66 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType63, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField68 = new org.joda.time.field.RemainderDateTimeField(dateTimeField54, dateTimeFieldType63, 9);
        org.joda.time.field.SkipDateTimeField skipDateTimeField69 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology12, (org.joda.time.DateTimeField) remainderDateTimeField68);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(yearMonthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology12);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 28800001L + "'", long27 == 28800001L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone28);
        org.junit.Assert.assertNotNull(chronology29);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertNotNull(dateTimeZone34);
        org.junit.Assert.assertNotNull(dateTime35);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTimeZone37);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 365 + "'", int39 == 365);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-28800000) + "'", int40 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology41);
        org.junit.Assert.assertNotNull(durationField42);
        org.junit.Assert.assertNotNull(dateTimeField43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(dateTime45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 365 + "'", int46 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTime49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(durationField53);
        org.junit.Assert.assertNotNull(dateTimeField54);
        org.junit.Assert.assertNotNull(dateTimeFormatter55);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTime59);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(property62);
        org.junit.Assert.assertNotNull(dateTimeFieldType63);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        org.joda.time.Chronology chronology30 = null;
        org.joda.time.LocalDate localDate31 = new org.joda.time.LocalDate((long) (short) 10, chronology30);
        org.joda.time.LocalDate localDate33 = localDate31.plusWeeks(0);
        org.joda.time.LocalDate localDate35 = localDate31.plusWeeks(58097);
        java.util.Locale locale37 = null;
        java.lang.String str38 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate35, (int) '#', locale37);
        org.joda.time.DurationField durationField39 = null;
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = null;
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField41 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField28, durationField39, dateTimeFieldType40);
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField42 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) delegatedDateTimeField41);
        java.util.Locale locale44 = null;
        java.lang.String str45 = delegatedDateTimeField42.getAsShortText(20, locale44);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertNotNull(localDate33);
        org.junit.Assert.assertNotNull(localDate35);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "35" + "'", str38.equals("35"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "20" + "'", str45.equals("20"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate.Property property8 = localDate6.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime10.getZone();
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime10.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime10.withZoneRetainFields(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        int int18 = dateTime17.getDayOfYear();
        int int19 = dateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime17);
        boolean boolean21 = dateTime17.isEqual((long) (short) 10);
        int int22 = property8.compareTo((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.LocalDate localDate23 = property8.roundHalfFloorCopy();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 365 + "'", int18 == 365);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(localDate23);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        long long27 = gJChronology11.add(readablePeriod24, (long) (short) 1, (int) '#');
        org.joda.time.DurationField durationField28 = gJChronology11.centuries();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1L + "'", long27 == 1L);
        org.junit.Assert.assertNotNull(durationField28);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateTimeFieldType dateTimeFieldType9 = yearMonthDay3.getFieldType((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateTimeFieldType9);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withDefaultYear(0);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        int int5 = dateTime4.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        long long14 = iSOChronology10.add(readablePeriod11, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology10.secondOfMinute();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 10, chronology17);
        org.joda.time.LocalDate localDate20 = localDate18.plusWeeks(0);
        org.joda.time.LocalDate localDate22 = localDate20.withDayOfYear((int) (byte) 100);
        int[] intArray24 = iSOChronology10.get((org.joda.time.ReadablePartial) localDate20, 0L);
        org.joda.time.Chronology chronology25 = iSOChronology10.withUTC();
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime9.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        int int29 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime26, "DateTimeField[dayOfMonth]", (int) (short) 10);
        try {
            org.joda.time.MutableDateTime mutableDateTime31 = dateTimeFormatter0.parseMutableDateTime("Property[dayOfMonth]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[dayOfMonth]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 58089L + "'", long14 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-11) + "'", int29 == (-11));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        int int12 = gJChronology11.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfWeek();
        try {
            long long18 = gJChronology11.getDateTimeMillis(17, 58092, (int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58092 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dateTimeField13);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getSecondOfDay();
        int int3 = dateTime1.getSecondOfMinute();
        org.joda.time.DateTime dateTime4 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime5 = dateTime1.withEarlierOffsetAtOverlap();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now(dateTimeZone45);
        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
        org.joda.time.YearMonthDay yearMonthDay48 = dateTime46.toYearMonthDay();
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 10, chronology50);
        boolean boolean52 = yearMonthDay48.isBefore((org.joda.time.ReadablePartial) localDate51);
        org.joda.time.LocalDate.Property property53 = localDate51.dayOfYear();
        org.joda.time.LocalDate localDate54 = property53.roundHalfFloorCopy();
        java.util.Date date55 = localDate54.toDate();
        org.joda.time.LocalDate localDate56 = org.joda.time.LocalDate.fromDateFields(date55);
        java.util.Locale locale57 = null;
        java.lang.String str58 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate56, locale57);
        int int59 = skipDateTimeField28.getMaximumValue();
        long long61 = skipDateTimeField28.roundHalfCeiling(58L);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter62 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime64 = dateTimeFormatter62.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod65 = null;
        org.joda.time.DateTime dateTime66 = dateTime64.plus(readablePeriod65);
        org.joda.time.DateTime dateTime68 = dateTime66.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property69 = dateTime66.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType70 = property69.getFieldType();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField71 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField28, dateTimeFieldType70);
        org.joda.time.Chronology chronology73 = null;
        org.joda.time.LocalDate localDate74 = new org.joda.time.LocalDate((long) (short) 10, chronology73);
        org.joda.time.LocalDate localDate76 = localDate74.plusWeeks(0);
        org.joda.time.LocalDate localDate78 = localDate76.withDayOfYear((int) (byte) 100);
        java.util.Date date79 = localDate78.toDate();
        org.joda.time.LocalDate.Property property80 = localDate78.monthOfYear();
        java.util.Date date81 = localDate78.toDate();
        int[] intArray83 = null;
        try {
            int[] intArray85 = delegatedDateTimeField71.addWrapField((org.joda.time.ReadablePartial) localDate78, 365, intArray83, 2000);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(yearMonthDay48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "31" + "'", str58.equals("31"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 31 + "'", int59 == 31);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 28800000L + "'", long61 == 28800000L);
        org.junit.Assert.assertNotNull(dateTimeFormatter62);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertNotNull(dateTime66);
        org.junit.Assert.assertNotNull(dateTime68);
        org.junit.Assert.assertNotNull(property69);
        org.junit.Assert.assertNotNull(dateTimeFieldType70);
        org.junit.Assert.assertNotNull(localDate76);
        org.junit.Assert.assertNotNull(localDate78);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(property80);
        org.junit.Assert.assertNotNull(date81);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        int int44 = skipDateTimeField28.getDifference((long) (short) 100, (long) (short) -1);
        org.joda.time.Chronology chronology46 = null;
        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (short) 10, chronology46);
        org.joda.time.LocalDate localDate49 = localDate47.plusWeeks(0);
        org.joda.time.LocalDate.Property property50 = localDate47.year();
        org.joda.time.DateTime dateTime51 = localDate47.toDateTimeAtMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology53 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod54 = null;
        long long57 = iSOChronology53.add(readablePeriod54, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField58 = iSOChronology53.secondOfMinute();
        org.joda.time.Chronology chronology60 = null;
        org.joda.time.LocalDate localDate61 = new org.joda.time.LocalDate((long) (short) 10, chronology60);
        org.joda.time.LocalDate localDate63 = localDate61.plusWeeks(0);
        org.joda.time.LocalDate localDate65 = localDate63.withDayOfYear((int) (byte) 100);
        int[] intArray67 = iSOChronology53.get((org.joda.time.ReadablePartial) localDate63, 0L);
        try {
            int[] intArray69 = skipDateTimeField28.addWrapField((org.joda.time.ReadablePartial) localDate47, 6, intArray67, 58093);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(localDate49);
        org.junit.Assert.assertNotNull(property50);
        org.junit.Assert.assertNotNull(dateTime51);
        org.junit.Assert.assertNotNull(iSOChronology53);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 58089L + "'", long57 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField58);
        org.junit.Assert.assertNotNull(localDate63);
        org.junit.Assert.assertNotNull(localDate65);
        org.junit.Assert.assertNotNull(intArray67);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
        java.util.Locale locale61 = null;
        java.lang.String str62 = remainderDateTimeField38.getAsShortText(28800035L, locale61);
        java.util.Locale locale64 = null;
        java.lang.String str65 = remainderDateTimeField38.getAsShortText((int) (byte) 10, locale64);
        java.lang.String str66 = remainderDateTimeField38.toString();
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField38, 2922789);
        long long70 = offsetDateTimeField68.roundHalfEven((long) 58095);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(yearMonthDay45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateMidnight50);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "8" + "'", str62.equals("8"));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10" + "'", str65.equals("10"));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str66.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 28800000L + "'", long70 == 28800000L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime1.withEarlierOffsetAtOverlap();
        int int9 = dateTime1.getMillisOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 57600100 + "'", int9 == 57600100);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime7 = dateTime1.minusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property8 = dateTime1.monthOfYear();
        int int9 = property8.getMaximumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate4.withCenturyOfEra((int) (short) 0);
        int int7 = localDate6.getDayOfWeek();
        org.joda.time.LocalDate.Property property8 = localDate6.era();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2 + "'", int7 == 2);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.joda.time.PeriodType periodType0 = null;
        org.joda.time.PeriodType periodType1 = org.joda.time.DateTimeUtils.getPeriodType(periodType0);
        org.joda.time.PeriodType periodType2 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType3 = org.joda.time.DateTimeUtils.getPeriodType(periodType1);
        org.joda.time.PeriodType periodType4 = org.joda.time.DateTimeUtils.getPeriodType(periodType3);
        org.junit.Assert.assertNotNull(periodType1);
        org.junit.Assert.assertNotNull(periodType2);
        org.junit.Assert.assertNotNull(periodType3);
        org.junit.Assert.assertNotNull(periodType4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate2.plusWeeks(58097);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        int int17 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime15);
        boolean boolean18 = localDate2.equals((java.lang.Object) int17);
        int int19 = localDate2.getWeekOfWeekyear();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondFraction();
        org.joda.time.DateTimeZone dateTimeZone1 = dateTimeFormatter0.getZone();
        java.lang.Appendable appendable2 = null;
        try {
            dateTimeFormatter0.printTo(appendable2, 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(dateTimeZone1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeElementParser();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.lang.String str3 = jodaTimePermission1.getActions();
        java.lang.String str4 = jodaTimePermission1.toString();
        org.joda.time.JodaTimePermission jodaTimePermission6 = new org.joda.time.JodaTimePermission("31");
        java.lang.String str7 = jodaTimePermission6.getActions();
        java.security.PermissionCollection permissionCollection8 = jodaTimePermission6.newPermissionCollection();
        java.lang.String str9 = jodaTimePermission6.getName();
        boolean boolean10 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "(\"org.joda.time.JodaTimePermission\" \"31\")" + "'", str4.equals("(\"org.joda.time.JodaTimePermission\" \"31\")"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "31" + "'", str9.equals("31"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue(20, 58095, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 10, chronology7);
        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks(0);
        org.joda.time.LocalDate localDate12 = localDate10.withDayOfYear((int) (byte) 100);
        int[] intArray14 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate10, 0L);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.millisOfDay();
        java.lang.String str16 = iSOChronology0.toString();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        int int19 = dateTime18.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
        org.joda.time.DateTime dateTime22 = dateTime18.toDateTime(dateTimeZone20);
        org.joda.time.DateTime dateTime23 = dateTime18.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime25 = dateTime23.minusMinutes((int) (short) -1);
        int int26 = dateTime25.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(dateTimeZone27);
        int int29 = dateTime28.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTime dateTime32 = dateTime28.toDateTime(dateTimeZone30);
        org.joda.time.DateTime dateTime33 = dateTime25.toDateTime(dateTimeZone30);
        int int34 = dateTime25.getSecondOfMinute();
        org.joda.time.DateTime.Property property35 = dateTime25.secondOfDay();
        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now(dateTimeZone36);
        int int38 = dateTime37.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone39 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime40 = org.joda.time.DateTime.now(dateTimeZone39);
        org.joda.time.DateTime dateTime41 = dateTime37.toDateTime(dateTimeZone39);
        org.joda.time.DateTime dateTime42 = dateTime37.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime44 = dateTime42.minusMinutes((int) (short) -1);
        org.joda.time.DateTime.Property property45 = dateTime44.centuryOfEra();
        org.joda.time.DateMidnight dateMidnight46 = dateTime44.toDateMidnight();
        org.joda.time.DateTime.Property property47 = dateTime44.weekOfWeekyear();
        int int48 = dateTime44.getSecondOfMinute();
        try {
            org.joda.time.chrono.LimitChronology limitChronology49 = org.joda.time.chrono.LimitChronology.getInstance((org.joda.time.Chronology) iSOChronology0, (org.joda.time.ReadableDateTime) dateTime25, (org.joda.time.ReadableDateTime) dateTime44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The lower limit must be come before than the upper limit");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "ISOChronology[America/Los_Angeles]" + "'", str16.equals("ISOChronology[America/Los_Angeles]"));
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 365 + "'", int19 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 365 + "'", int29 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertNotNull(dateTime33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(property35);
        org.junit.Assert.assertNotNull(dateTimeZone36);
        org.junit.Assert.assertNotNull(dateTime37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 365 + "'", int38 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone39);
        org.junit.Assert.assertNotNull(dateTime40);
        org.junit.Assert.assertNotNull(dateTime41);
        org.junit.Assert.assertNotNull(dateTime42);
        org.junit.Assert.assertNotNull(dateTime44);
        org.junit.Assert.assertNotNull(property45);
        org.junit.Assert.assertNotNull(dateMidnight46);
        org.junit.Assert.assertNotNull(property47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Interval interval6 = localDate2.toInterval(dateTimeZone5);
        org.joda.time.LocalDate.Property property7 = localDate2.weekyear();
        try {
            org.joda.time.LocalDate localDate9 = localDate2.withDayOfMonth(3083);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3083 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(property7);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        long long2 = org.joda.time.field.FieldUtils.safeSubtract((long) 58085, (long) 20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 58065L + "'", long2 == 58065L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate.Property property8 = localDate6.dayOfYear();
        org.joda.time.LocalDate localDate9 = property8.roundHalfFloorCopy();
        org.joda.time.DurationField durationField10 = property8.getLeapDurationField();
        org.joda.time.LocalDate localDate11 = property8.withMinimumValue();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate9);
        org.junit.Assert.assertNull(durationField10);
        org.junit.Assert.assertNotNull(localDate11);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate.Property property8 = localDate6.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime10.getZone();
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime10.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
        org.joda.time.DateTime dateTime15 = dateTime10.withZoneRetainFields(dateTimeZone13);
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        int int18 = dateTime17.getDayOfYear();
        int int19 = dateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime17);
        boolean boolean21 = dateTime17.isEqual((long) (short) 10);
        int int22 = property8.compareTo((org.joda.time.ReadableInstant) dateTime17);
        org.joda.time.LocalDate localDate23 = new org.joda.time.LocalDate((java.lang.Object) dateTime17);
        org.joda.time.ReadablePeriod readablePeriod24 = null;
        org.joda.time.DateTime dateTime26 = dateTime17.withPeriodAdded(readablePeriod24, 3200);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 365 + "'", int18 == 365);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, 0L, (-49));
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        int int17 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField19 = gJChronology18.millis();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime22.toDateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime22.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime28 = dateTime27.toDateTimeISO();
        boolean boolean29 = gJChronology18.equals((java.lang.Object) dateTime27);
        org.joda.time.DurationField durationField30 = gJChronology18.minutes();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology18.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime34 = dateTimeFormatter32.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.plus(readablePeriod35);
        org.joda.time.DateTime dateTime38 = dateTime36.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property39 = dateTime36.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField45 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType40, 9);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType40, (-21), 58085, 3083);
        int int51 = offsetDateTimeField49.get((long) 58093);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1949 + "'", int51 == 1949);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.days();
        org.joda.time.DurationFieldType durationFieldType13 = null;
        try {
            org.joda.time.field.DecoratedDurationField decoratedDurationField14 = new org.joda.time.field.DecoratedDurationField(durationField12, durationFieldType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTime dateTime9 = dateTime1.withEarlierOffsetAtOverlap();
        boolean boolean11 = dateTime9.isEqual(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate4.withDayOfYear((int) (byte) 100);
        java.util.Date date7 = localDate6.toDate();
        org.joda.time.LocalDate.Property property8 = localDate6.monthOfYear();
        java.util.Date date9 = localDate6.toDate();
        try {
            org.joda.time.LocalDate localDate11 = localDate6.withMonthOfYear(58092898);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58092898 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (-25200000), 8);
        org.joda.time.Chronology chronology5 = copticChronology0.withUTC();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-25200000L) + "'", long4 == (-25200000L));
        org.junit.Assert.assertNotNull(chronology5);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15T16:08:12.898-07:00", (java.lang.Number) 9972000000L, (java.lang.Number) 1.0d, (java.lang.Number) 2000);
        java.lang.Number number5 = illegalFieldValueException4.getLowerBound();
        org.joda.time.IllegalInstantException illegalInstantException7 = new org.joda.time.IllegalInstantException("");
        boolean boolean8 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException7);
        illegalFieldValueException4.addSuppressed((java.lang.Throwable) illegalInstantException7);
        java.lang.String str10 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0d + "'", number5.equals(1.0d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9972000000" + "'", str10.equals("9972000000"));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 10, chronology7);
        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks(0);
        org.joda.time.LocalDate localDate12 = localDate10.withDayOfYear((int) (byte) 100);
        int[] intArray14 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate10, 0L);
        org.joda.time.Chronology chronology15 = iSOChronology0.withUTC();
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology0.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField17 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField16);
        int int19 = delegatedDateTimeField17.get((long) 'a');
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(chronology15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 365 + "'", int19 == 365);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        org.joda.time.LocalDate.Property property10 = localDate6.centuryOfEra();
        org.joda.time.LocalDate localDate11 = property10.roundFloorCopy();
        int int12 = property10.getMinimumValueOverall();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.DateTime dateTime24 = dateTime20.plusSeconds(18);
        org.joda.time.ReadableDuration readableDuration25 = null;
        org.joda.time.DateTime dateTime26 = dateTime24.minus(readableDuration25);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertNotNull(dateTime26);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
        java.lang.String str39 = remainderDateTimeField38.toString();
        org.joda.time.Chronology chronology41 = null;
        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (short) 10, chronology41);
        org.joda.time.DateTimeFieldType dateTimeFieldType43 = null;
        int int44 = localDate42.indexOf(dateTimeFieldType43);
        java.util.Locale locale45 = null;
        java.lang.String str46 = remainderDateTimeField38.getAsShortText((org.joda.time.ReadablePartial) localDate42, locale45);
        org.joda.time.ReadablePartial readablePartial47 = null;
        java.util.Locale locale49 = null;
        java.lang.String str50 = remainderDateTimeField38.getAsShortText(readablePartial47, 960, locale49);
        java.lang.String str52 = remainderDateTimeField38.getAsText(9972000000L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str39.equals("DateTimeField[dayOfMonth]"));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "31" + "'", str46.equals("31"));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "960" + "'", str50.equals("960"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "8" + "'", str52.equals("8"));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.LocalDate.Property property8 = localDate6.dayOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.DateTimeZone dateTimeZone11 = dateTime10.getZone();
        org.joda.time.YearMonthDay yearMonthDay12 = dateTime10.toYearMonthDay();
        org.joda.time.Chronology chronology14 = null;
        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 10, chronology14);
        boolean boolean16 = yearMonthDay12.isBefore((org.joda.time.ReadablePartial) localDate15);
        org.joda.time.Chronology chronology18 = null;
        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 10, chronology18);
        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
        int int21 = localDate19.indexOf(dateTimeFieldType20);
        boolean boolean22 = yearMonthDay12.isAfter((org.joda.time.ReadablePartial) localDate19);
        int int23 = localDate6.compareTo((org.joda.time.ReadablePartial) yearMonthDay12);
        org.joda.time.LocalDate localDate25 = localDate6.minusDays(86399);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(yearMonthDay12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(localDate25);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("69", "69", 14, 58097);
        java.lang.String str6 = fixedDateTimeZone4.getNameKey((long) 57600);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "69" + "'", str6.equals("69"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (short) 100);
        org.joda.time.LocalTime localTime7 = dateTime4.toLocalTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(localTime7);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.Chronology chronology1 = partial0.getChronology();
        org.joda.time.DurationFieldType durationFieldType2 = null;
        try {
            org.joda.time.Partial partial4 = partial0.withFieldAdded(durationFieldType2, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate.Property property5 = localDate2.year();
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property7 = localDate2.dayOfMonth();
        org.joda.time.LocalDate localDate9 = property7.setCopy(6);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate9);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial2 = partial0.minus(readablePeriod1);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = partial0.getFormatter();
        org.junit.Assert.assertNotNull(partial2);
        org.junit.Assert.assertNull(dateTimeFormatter3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now(dateTimeZone45);
        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
        org.joda.time.YearMonthDay yearMonthDay48 = dateTime46.toYearMonthDay();
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 10, chronology50);
        boolean boolean52 = yearMonthDay48.isBefore((org.joda.time.ReadablePartial) localDate51);
        org.joda.time.LocalDate.Property property53 = localDate51.dayOfYear();
        org.joda.time.LocalDate localDate54 = property53.roundHalfFloorCopy();
        java.util.Date date55 = localDate54.toDate();
        org.joda.time.LocalDate localDate56 = org.joda.time.LocalDate.fromDateFields(date55);
        java.util.Locale locale57 = null;
        java.lang.String str58 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate56, locale57);
        org.joda.time.Chronology chronology60 = null;
        org.joda.time.LocalDate localDate61 = new org.joda.time.LocalDate((long) (short) 10, chronology60);
        org.joda.time.LocalDate localDate63 = localDate61.plusWeeks(0);
        org.joda.time.LocalDate.Property property64 = localDate61.year();
        org.joda.time.DateTime dateTime65 = localDate61.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property66 = localDate61.dayOfMonth();
        org.joda.time.LocalDate localDate67 = property66.getLocalDate();
        int int68 = localDate67.getYearOfCentury();
        org.joda.time.LocalDate localDate69 = localDate56.withFields((org.joda.time.ReadablePartial) localDate67);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(yearMonthDay48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "31" + "'", str58.equals("31"));
        org.junit.Assert.assertNotNull(localDate63);
        org.junit.Assert.assertNotNull(property64);
        org.junit.Assert.assertNotNull(dateTime65);
        org.junit.Assert.assertNotNull(property66);
        org.junit.Assert.assertNotNull(localDate67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 69 + "'", int68 == 69);
        org.junit.Assert.assertNotNull(localDate69);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime1.plusYears(0);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = dateTime12.getZone();
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime12.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = dateTime12.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        int int20 = dateTime19.getDayOfYear();
        int int21 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime19);
        long long24 = dateTimeZone15.adjustOffset(28800001L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.DateTime dateTime26 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone25);
        org.joda.time.DateTime dateTime27 = dateTime1.toDateTime();
        org.joda.time.ReadableDuration readableDuration28 = null;
        org.joda.time.DateTime dateTime29 = dateTime1.minus(readableDuration28);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 365 + "'", int20 == 365);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800001L + "'", long24 == 28800001L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime1.plus((long) 166);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.forOffsetMillis(58085);
        org.joda.time.chrono.GregorianChronology gregorianChronology5 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        int int8 = dateTime7.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.minusMinutes((int) (short) -1);
        int int15 = dateTime14.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        int int18 = dateTime17.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = dateTime17.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime14.toDateTime(dateTimeZone19);
        int int23 = dateTime14.getSecondOfMinute();
        org.joda.time.DateTime.Property property24 = dateTime14.secondOfDay();
        boolean boolean25 = gregorianChronology5.equals((java.lang.Object) property24);
        int int26 = gregorianChronology5.getMinimumDaysInFirstWeek();
        org.joda.time.DateTimeZone dateTimeZone27 = gregorianChronology5.getZone();
        try {
            org.joda.time.LocalDate localDate28 = new org.joda.time.LocalDate(0, 100, 17, (org.joda.time.Chronology) gregorianChronology5);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(gregorianChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 365 + "'", int18 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(property24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dateTimeZone27);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
        org.joda.time.DateTime dateTime10 = dateTime1.plusYears(0);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone13 = dateTime12.getZone();
        org.joda.time.YearMonthDay yearMonthDay14 = dateTime12.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.DateTime dateTime17 = dateTime12.withZoneRetainFields(dateTimeZone15);
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        int int20 = dateTime19.getDayOfYear();
        int int21 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime19);
        long long24 = dateTimeZone15.adjustOffset(28800001L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
        org.joda.time.DateTime dateTime26 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone25);
        org.joda.time.DateTime dateTime28 = dateTime1.minusMonths(19);
        try {
            org.joda.time.DateTime dateTime30 = dateTime28.withWeekOfWeekyear(3200);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3200 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTimeZone13);
        org.junit.Assert.assertNotNull(yearMonthDay14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 365 + "'", int20 == 365);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800001L + "'", long24 == 28800001L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime28);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.ReadableInstant readableInstant3 = null;
        boolean boolean4 = dateTime1.isEqual(readableInstant3);
        org.joda.time.DateTime dateTime6 = dateTime1.plusSeconds(24);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(dateTime6);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.joda.time.DateTimeZone dateTimeZone0 = null;
        try {
            org.joda.time.chrono.GJChronology gJChronology3 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone0, 9972000000L, 14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: 14");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology9 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        long long13 = iSOChronology9.add(readablePeriod10, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField14 = iSOChronology9.secondOfMinute();
        org.joda.time.DateTime dateTime15 = dateMidnight8.toDateTime((org.joda.time.Chronology) iSOChronology9);
        org.joda.time.DateTimeField dateTimeField16 = iSOChronology9.millisOfDay();
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology9.monthOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(iSOChronology9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 58089L + "'", long13 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate4.withCenturyOfEra((int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime9 = dateTimeFormatter7.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.LocalDate.Property property16 = localDate4.property(dateTimeFieldType15);
        org.joda.time.LocalDate localDate17 = property16.withMaximumValue();
        org.joda.time.LocalDate.Property property18 = localDate17.era();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(property18);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        long long13 = dateTimeZone4.adjustOffset(28800001L, true);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone14 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone4);
        int int16 = cachedDateTimeZone14.getStandardOffset(0L);
        boolean boolean17 = cachedDateTimeZone14.isFixed();
        long long19 = cachedDateTimeZone14.nextTransition((long) (short) 0);
        boolean boolean20 = cachedDateTimeZone14.isFixed();
        long long22 = cachedDateTimeZone14.nextTransition(0L);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 28800001L + "'", long13 == 28800001L);
        org.junit.Assert.assertNotNull(cachedDateTimeZone14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9972000000L + "'", long19 == 9972000000L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 9972000000L + "'", long22 == 9972000000L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstanceUTC();
        org.joda.time.DateTimeField dateTimeField1 = julianChronology0.minuteOfHour();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate.Property property5 = localDate2.year();
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight();
        org.joda.time.LocalDate.Property property7 = localDate2.dayOfMonth();
        org.joda.time.LocalDate localDate8 = property7.getLocalDate();
        java.util.Locale locale9 = null;
        int int10 = property7.getMaximumTextLength(locale9);
        java.lang.String str11 = property7.getName();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(localDate8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "dayOfMonth" + "'", str11.equals("dayOfMonth"));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.timeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now(dateTimeZone46);
        org.joda.time.DateTime dateTime48 = dateTime43.withZoneRetainFields(dateTimeZone46);
        org.joda.time.DateTimeZone dateTimeZone49 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime50 = org.joda.time.DateTime.now(dateTimeZone49);
        int int51 = dateTime50.getDayOfYear();
        int int52 = dateTimeZone46.getOffset((org.joda.time.ReadableInstant) dateTime50);
        org.joda.time.chrono.GJChronology gJChronology53 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone46);
        org.joda.time.DurationField durationField54 = gJChronology53.millis();
        org.joda.time.DateTimeField dateTimeField55 = gJChronology53.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone56 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime57 = org.joda.time.DateTime.now(dateTimeZone56);
        org.joda.time.DateTimeZone dateTimeZone58 = dateTime57.getZone();
        org.joda.time.YearMonthDay yearMonthDay59 = dateTime57.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone60 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime61 = org.joda.time.DateTime.now(dateTimeZone60);
        org.joda.time.DateTime dateTime62 = dateTime57.withZoneRetainFields(dateTimeZone60);
        org.joda.time.DateTimeZone dateTimeZone63 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime64 = org.joda.time.DateTime.now(dateTimeZone63);
        int int65 = dateTime64.getDayOfYear();
        int int66 = dateTimeZone60.getOffset((org.joda.time.ReadableInstant) dateTime64);
        org.joda.time.chrono.GJChronology gJChronology67 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone60);
        org.joda.time.DurationField durationField68 = gJChronology67.millis();
        org.joda.time.DateTimeField dateTimeField69 = gJChronology67.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField70 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology53, dateTimeField69);
        int int71 = skipDateTimeField70.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone72 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime73 = org.joda.time.DateTime.now(dateTimeZone72);
        org.joda.time.DateTimeZone dateTimeZone74 = dateTime73.getZone();
        org.joda.time.YearMonthDay yearMonthDay75 = dateTime73.toYearMonthDay();
        org.joda.time.Chronology chronology77 = null;
        org.joda.time.LocalDate localDate78 = new org.joda.time.LocalDate((long) (short) 10, chronology77);
        boolean boolean79 = yearMonthDay75.isBefore((org.joda.time.ReadablePartial) localDate78);
        org.joda.time.LocalDate.Property property80 = localDate78.dayOfYear();
        java.util.Locale locale82 = null;
        java.lang.String str83 = skipDateTimeField70.getAsText((org.joda.time.ReadablePartial) localDate78, 58087, locale82);
        java.util.Locale locale84 = null;
        java.lang.String str85 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate78, locale84);
        try {
            long long88 = skipDateTimeField28.set(28800000L, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(yearMonthDay45);
        org.junit.Assert.assertNotNull(dateTimeZone46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(dateTime48);
        org.junit.Assert.assertNotNull(dateTimeZone49);
        org.junit.Assert.assertNotNull(dateTime50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 365 + "'", int51 == 365);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-28800000) + "'", int52 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology53);
        org.junit.Assert.assertNotNull(durationField54);
        org.junit.Assert.assertNotNull(dateTimeField55);
        org.junit.Assert.assertNotNull(dateTimeZone56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertNotNull(dateTimeZone58);
        org.junit.Assert.assertNotNull(yearMonthDay59);
        org.junit.Assert.assertNotNull(dateTimeZone60);
        org.junit.Assert.assertNotNull(dateTime61);
        org.junit.Assert.assertNotNull(dateTime62);
        org.junit.Assert.assertNotNull(dateTimeZone63);
        org.junit.Assert.assertNotNull(dateTime64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 365 + "'", int65 == 365);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-28800000) + "'", int66 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology67);
        org.junit.Assert.assertNotNull(durationField68);
        org.junit.Assert.assertNotNull(dateTimeField69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 31 + "'", int71 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone72);
        org.junit.Assert.assertNotNull(dateTime73);
        org.junit.Assert.assertNotNull(dateTimeZone74);
        org.junit.Assert.assertNotNull(yearMonthDay75);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(property80);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "58087" + "'", str83.equals("58087"));
        org.junit.Assert.assertTrue("'" + str85 + "' != '" + "31" + "'", str85.equals("31"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod28 = null;
        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
        org.joda.time.Chronology chronology47 = null;
        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod52 = null;
        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
        java.util.Locale locale61 = null;
        java.lang.String str62 = remainderDateTimeField38.getAsShortText(28800035L, locale61);
        int int64 = remainderDateTimeField38.getLeapAmount(0L);
        org.joda.time.DurationField durationField65 = remainderDateTimeField38.getLeapDurationField();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone17);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(durationField23);
        org.junit.Assert.assertNotNull(dateTimeField24);
        org.junit.Assert.assertNotNull(dateTimeFormatter25);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime29);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(property32);
        org.junit.Assert.assertNotNull(dateTimeFieldType33);
        org.junit.Assert.assertNotNull(dateTimeZone42);
        org.junit.Assert.assertNotNull(dateTime43);
        org.junit.Assert.assertNotNull(dateTimeZone44);
        org.junit.Assert.assertNotNull(yearMonthDay45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(dateMidnight50);
        org.junit.Assert.assertNotNull(iSOChronology51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField56);
        org.junit.Assert.assertNotNull(dateTime57);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "8" + "'", str62.equals("8"));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNull(durationField65);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeek();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimeParser dateTimeParser2 = dateTimeFormatter0.getParser();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        int int5 = dateTime4.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone6);
        org.joda.time.DateTime dateTime9 = dateTime4.withEarlierOffsetAtOverlap();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        long long14 = iSOChronology10.add(readablePeriod11, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology10.secondOfMinute();
        org.joda.time.Chronology chronology17 = null;
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) (short) 10, chronology17);
        org.joda.time.LocalDate localDate20 = localDate18.plusWeeks(0);
        org.joda.time.LocalDate localDate22 = localDate20.withDayOfYear((int) (byte) 100);
        int[] intArray24 = iSOChronology10.get((org.joda.time.ReadablePartial) localDate20, 0L);
        org.joda.time.Chronology chronology25 = iSOChronology10.withUTC();
        org.joda.time.MutableDateTime mutableDateTime26 = dateTime9.toMutableDateTime((org.joda.time.Chronology) iSOChronology10);
        int int29 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime26, "JulianChronology[America/Los_Angeles]", 20);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter31 = dateTimeFormatter0.withPivotYear(14);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeParser2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 58089L + "'", long14 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(localDate22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(chronology25);
        org.junit.Assert.assertNotNull(mutableDateTime26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-21) + "'", int29 == (-21));
        org.junit.Assert.assertNotNull(dateTimeFormatter31);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 10, chronology6);
        boolean boolean8 = yearMonthDay4.isBefore((org.joda.time.ReadablePartial) localDate7);
        org.joda.time.DateMidnight dateMidnight9 = localDate7.toDateMidnight();
        org.joda.time.chrono.ISOChronology iSOChronology10 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        long long14 = iSOChronology10.add(readablePeriod11, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology10.secondOfMinute();
        org.joda.time.DateTime dateTime16 = dateMidnight9.toDateTime((org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeField dateTimeField17 = iSOChronology10.millisOfDay();
        org.joda.time.LocalDate localDate18 = new org.joda.time.LocalDate((long) 58095, (org.joda.time.Chronology) iSOChronology10);
        org.joda.time.DateTimeZone dateTimeZone19 = iSOChronology10.getZone();
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(yearMonthDay4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(dateMidnight9);
        org.junit.Assert.assertNotNull(iSOChronology10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 58089L + "'", long14 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertNotNull(dateTimeZone19);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDate();
        org.joda.time.Chronology chronology1 = dateTimeFormatter0.getChronolgy();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter5 = dateTimeFormatter0.withChronology((org.joda.time.Chronology) gJChronology4);
        int int6 = dateTimeFormatter5.getDefaultYear();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(chronology1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(gJChronology4);
        org.junit.Assert.assertNotNull(dateTimeFormatter5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2000 + "'", int6 == 2000);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
        int int2 = dateTimeFormatter1.getDefaultYear();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser3);
        org.joda.time.Chronology chronology5 = dateTimeFormatter4.getChronology();
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNull(chronology5);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((int) (short) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        int int10 = dateTime8.getDayOfYear();
        try {
            org.joda.time.DateTime dateTime12 = dateTime8.withDayOfWeek(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfWeek must be in the range [1,7]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfCentury();
        org.joda.time.ReadablePeriod readablePeriod2 = null;
        long long5 = iSOChronology0.add(readablePeriod2, 0L, (-49));
        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekyear();
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone11);
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        int int16 = dateTime15.getDayOfYear();
        int int17 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime15);
        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
        org.joda.time.DurationField durationField19 = gJChronology18.millis();
        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
        org.joda.time.DateTime dateTime26 = dateTime22.toDateTime(dateTimeZone24);
        org.joda.time.DateTime dateTime27 = dateTime22.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime28 = dateTime27.toDateTimeISO();
        boolean boolean29 = gJChronology18.equals((java.lang.Object) dateTime27);
        org.joda.time.DurationField durationField30 = gJChronology18.minutes();
        org.joda.time.DateTimeField dateTimeField31 = gJChronology18.year();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime34 = dateTimeFormatter32.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod35 = null;
        org.joda.time.DateTime dateTime36 = dateTime34.plus(readablePeriod35);
        org.joda.time.DateTime dateTime38 = dateTime36.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property39 = dateTime36.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 13, "58092");
        org.joda.time.field.RemainderDateTimeField remainderDateTimeField45 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType40, 9);
        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType40, (-21), 58085, 3083);
        int int50 = offsetDateTimeField49.getOffset();
        try {
            long long53 = offsetDateTimeField49.add((-18063L), (long) (-25200000));
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -25198051 for dayOfMonth must be in the range [58085,3083]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertNotNull(dateTimeField1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(dateTimeField6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(yearMonthDay10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology18);
        org.junit.Assert.assertNotNull(durationField19);
        org.junit.Assert.assertNotNull(dateTimeField20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(dateTime25);
        org.junit.Assert.assertNotNull(dateTime26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(durationField30);
        org.junit.Assert.assertNotNull(dateTimeField31);
        org.junit.Assert.assertNotNull(dateTimeFormatter32);
        org.junit.Assert.assertNotNull(dateTime34);
        org.junit.Assert.assertNotNull(dateTime36);
        org.junit.Assert.assertNotNull(dateTime38);
        org.junit.Assert.assertNotNull(property39);
        org.junit.Assert.assertNotNull(dateTimeFieldType40);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-21) + "'", int50 == (-21));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        int int3 = dateTime1.getMinuteOfHour();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate.Property property5 = localDate2.year();
        org.joda.time.LocalDate localDate6 = property5.withMinimumValue();
        int int7 = localDate6.getDayOfWeek();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
        org.joda.time.YearMonthDay yearMonthDay11 = dateTime9.toYearMonthDay();
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 10, chronology13);
        boolean boolean15 = yearMonthDay11.isBefore((org.joda.time.ReadablePartial) localDate14);
        org.joda.time.DateMidnight dateMidnight16 = localDate14.toDateMidnight();
        org.joda.time.LocalDate.Property property17 = localDate14.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        int int20 = dateTime19.getSecondOfDay();
        int int21 = dateTime19.getSecondOfMinute();
        int int22 = dateTime19.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime23 = localDate14.toDateTime((org.joda.time.ReadableInstant) dateTime19);
        boolean boolean24 = localDate6.isAfter((org.joda.time.ReadablePartial) localDate14);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(yearMonthDay11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateMidnight16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 57600 + "'", int20 == 57600);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.util.Locale locale0 = null;
        try {
            java.text.DateFormatSymbols dateFormatSymbols1 = org.joda.time.DateTimeUtils.getDateFormatSymbols(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        int int7 = localDate2.getYearOfEra();
        org.joda.time.LocalDate.Property property8 = localDate2.centuryOfEra();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.ReadableDuration readableDuration8 = null;
        org.joda.time.DateTime dateTime9 = dateTime1.minus(readableDuration8);
        org.joda.time.DateTime.Property property10 = dateTime9.dayOfMonth();
        org.joda.time.DateTime.Property property11 = dateTime9.centuryOfEra();
        org.joda.time.DateTime dateTime12 = property11.roundHalfEvenCopy();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(property10);
        org.junit.Assert.assertNotNull(property11);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        org.joda.time.LocalTime localTime7 = null;
        org.joda.time.chrono.CopticChronology copticChronology8 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod9 = null;
        long long12 = copticChronology8.add(readablePeriod9, (long) (-25200000), 8);
        org.joda.time.DateTimeField dateTimeField13 = copticChronology8.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone14 = copticChronology8.getZone();
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime(localTime7, dateTimeZone14);
        org.joda.time.LocalDate localDate17 = localDate2.withEra(0);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(copticChronology8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + (-25200000L) + "'", long12 == (-25200000L));
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(localDate17);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
        int int9 = dateTime8.getDayOfYear();
        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
        org.joda.time.DurationField durationField12 = gJChronology11.millis();
        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
        int int23 = dateTime22.getDayOfYear();
        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
        org.joda.time.DurationField durationField26 = gJChronology25.millis();
        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
        int int29 = skipDateTimeField28.getMaximumValue();
        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
        org.joda.time.Chronology chronology35 = null;
        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
        java.util.Locale locale40 = null;
        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
        java.util.Locale locale43 = null;
        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now(dateTimeZone45);
        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
        org.joda.time.YearMonthDay yearMonthDay48 = dateTime46.toYearMonthDay();
        org.joda.time.Chronology chronology50 = null;
        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 10, chronology50);
        boolean boolean52 = yearMonthDay48.isBefore((org.joda.time.ReadablePartial) localDate51);
        org.joda.time.LocalDate.Property property53 = localDate51.dayOfYear();
        org.joda.time.LocalDate localDate54 = property53.roundHalfFloorCopy();
        java.util.Date date55 = localDate54.toDate();
        org.joda.time.LocalDate localDate56 = org.joda.time.LocalDate.fromDateFields(date55);
        java.util.Locale locale57 = null;
        java.lang.String str58 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate56, locale57);
        int int59 = skipDateTimeField28.getMaximumValue();
        long long61 = skipDateTimeField28.roundHalfCeiling(58L);
        boolean boolean62 = skipDateTimeField28.isSupported();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTimeZone7);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology11);
        org.junit.Assert.assertNotNull(durationField12);
        org.junit.Assert.assertNotNull(dateTimeField13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(yearMonthDay17);
        org.junit.Assert.assertNotNull(dateTimeZone18);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTimeZone21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
        org.junit.Assert.assertNotNull(gJChronology25);
        org.junit.Assert.assertNotNull(durationField26);
        org.junit.Assert.assertNotNull(dateTimeField27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
        org.junit.Assert.assertNotNull(dateTimeZone30);
        org.junit.Assert.assertNotNull(dateTime31);
        org.junit.Assert.assertNotNull(dateTimeZone32);
        org.junit.Assert.assertNotNull(yearMonthDay33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(property38);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
        org.junit.Assert.assertNotNull(dateTimeZone45);
        org.junit.Assert.assertNotNull(dateTime46);
        org.junit.Assert.assertNotNull(dateTimeZone47);
        org.junit.Assert.assertNotNull(yearMonthDay48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(property53);
        org.junit.Assert.assertNotNull(localDate54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(localDate56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "31" + "'", str58.equals("31"));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 31 + "'", int59 == 31);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 28800000L + "'", long61 == 28800000L);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((java.lang.Object) (-1L), (org.joda.time.Chronology) iSOChronology1);
        org.joda.time.LocalTime localTime3 = null;
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = dateTime5.getZone();
        org.joda.time.YearMonthDay yearMonthDay7 = dateTime5.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.DateTime dateTime10 = dateTime5.withZoneRetainFields(dateTimeZone8);
        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
        int int13 = dateTime12.getDayOfYear();
        int int14 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime12);
        org.joda.time.DateTime dateTime15 = localDate2.toDateTime(localTime3, dateTimeZone8);
        long long16 = dateTime15.getMillis();
        org.junit.Assert.assertNotNull(iSOChronology1);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(yearMonthDay7);
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTimeZone11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 365 + "'", int13 == 365);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 100L + "'", long16 == 100L);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.joda.time.Instant instant1 = org.joda.time.Instant.parse("1970-01-01T00:00:00.100Z");
        org.junit.Assert.assertNotNull(instant1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.joda.time.format.DateTimePrinter dateTimePrinter0 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
        int int2 = dateTimeFormatter1.getDefaultYear();
        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter1.getParser();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter4 = new org.joda.time.format.DateTimeFormatter(dateTimePrinter0, dateTimeParser3);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter6 = dateTimeFormatter4.withPivotYear((java.lang.Integer) 9);
        try {
            long long8 = dateTimeFormatter6.parseMillis("58087");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"58087\" is malformed at \"087\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
        org.junit.Assert.assertNotNull(dateTimeParser3);
        org.junit.Assert.assertNotNull(dateTimeFormatter6);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withFields((org.joda.time.ReadablePartial) yearMonthDay5);
        int int7 = dateTime6.getYear();
        try {
            org.joda.time.DateTime dateTime9 = dateTime6.withWeekOfWeekyear(0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for weekOfWeekyear must be in the range [1,52]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.joda.time.chrono.GJChronology gJChronology0 = org.joda.time.chrono.GJChronology.getInstanceUTC();
        org.junit.Assert.assertNotNull(gJChronology0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((int) (short) -1);
        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
        org.joda.time.DateMidnight dateMidnight10 = dateTime8.toDateMidnight();
        boolean boolean11 = dateTime8.isBeforeNow();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateMidnight10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        org.joda.time.chrono.BuddhistChronology buddhistChronology1 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone0);
        org.joda.time.DateTimeField dateTimeField2 = buddhistChronology1.yearOfEra();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        try {
            int[] intArray5 = buddhistChronology1.get(readablePeriod3, (long) 58085);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(buddhistChronology1);
        org.junit.Assert.assertNotNull(dateTimeField2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        int int7 = localDate2.getYearOfEra();
        org.joda.time.LocalDate.Property property8 = localDate2.weekOfWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1969 + "'", int7 == 1969);
        org.junit.Assert.assertNotNull(property8);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinuteSecondMillis();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = dateTimeFormatter0.withZoneUTC();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter1);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.io.Writer writer0 = null;
        try {
            org.joda.time.format.FormatUtils.writeUnpaddedInteger(writer0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.localTimeParser();
        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
        org.joda.time.DateTime dateTime7 = dateTime2.withZoneRetainFields(dateTimeZone5);
        boolean boolean8 = dateTime2.isEqualNow();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime2.minus(readableDuration9);
        boolean boolean11 = dateTime2.isEqualNow();
        try {
            java.lang.String str12 = dateTimeFormatter0.print((org.joda.time.ReadableInstant) dateTime2);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeZone1);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(yearMonthDay4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        int int12 = dateTime11.getSecondOfDay();
        int int13 = dateTime11.getSecondOfMinute();
        int int14 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime15 = localDate6.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.parse("2019-06-15T16:08:12.898-07:00");
        int int18 = dateTime17.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
        org.joda.time.DateTime dateTime20 = localDate6.toDateTimeAtMidnight(dateTimeZone19);
        try {
            org.joda.time.DateTime dateTime24 = dateTime20.withDate(86399, (int) (byte) 100, 6);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 100 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600 + "'", int12 == 57600);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) 10.0f, (java.lang.Number) 0, (java.lang.Number) 16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 31, 24);
        boolean boolean5 = fixedDateTimeZone4.isFixed();
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
        int int8 = dateTime7.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
        org.joda.time.DateTime dateTime11 = dateTime7.toDateTime(dateTimeZone9);
        org.joda.time.DateTime dateTime12 = dateTime7.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime14 = dateTime12.minusMinutes((int) (short) -1);
        int int15 = dateTime14.getSecondOfMinute();
        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
        int int18 = dateTime17.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
        org.joda.time.DateTime dateTime21 = dateTime17.toDateTime(dateTimeZone19);
        org.joda.time.DateTime dateTime22 = dateTime14.toDateTime(dateTimeZone19);
        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone23);
        int int25 = dateTime24.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = dateTime24.toDateTime(dateTimeZone26);
        org.joda.time.DateTime dateTime30 = dateTime24.minusMonths((int) (short) 1);
        org.joda.time.DateTime.Property property31 = dateTime24.monthOfYear();
        int int32 = dateTimeZone19.getOffset((org.joda.time.ReadableInstant) dateTime24);
        int int33 = dateTime24.getDayOfYear();
        boolean boolean34 = fixedDateTimeZone4.equals((java.lang.Object) int33);
        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone35 = org.joda.time.tz.CachedDateTimeZone.forZone((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 365 + "'", int8 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone9);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dateTimeZone16);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 365 + "'", int18 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTime22);
        org.junit.Assert.assertNotNull(dateTimeZone23);
        org.junit.Assert.assertNotNull(dateTime24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 365 + "'", int25 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertNotNull(dateTime30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-28800000) + "'", int32 == (-28800000));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 365 + "'", int33 == 365);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(cachedDateTimeZone35);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        try {
            org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forID("8");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The datetime zone id '8' is not recognised");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate.Property property5 = localDate2.year();
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight();
        int int7 = dateTime6.getEra();
        org.joda.time.DateTime.Property property8 = dateTime6.dayOfYear();
        org.joda.time.Chronology chronology10 = null;
        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 10, chronology10);
        org.joda.time.LocalDate localDate13 = localDate11.plusWeeks(0);
        org.joda.time.LocalDate localDate15 = localDate13.withDayOfYear((int) (byte) 100);
        java.util.Date date16 = localDate15.toDate();
        org.joda.time.LocalDate localDate17 = org.joda.time.LocalDate.fromDateFields(date16);
        int int18 = property8.compareTo((org.joda.time.ReadablePartial) localDate17);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(property8);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(localDate15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        int int12 = dateTime11.getSecondOfDay();
        int int13 = dateTime11.getSecondOfMinute();
        int int14 = dateTime11.getWeekOfWeekyear();
        org.joda.time.DateTime dateTime15 = localDate6.toDateTime((org.joda.time.ReadableInstant) dateTime11);
        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.parse("2019-06-15T16:08:12.898-07:00");
        int int18 = dateTime17.getYearOfCentury();
        org.joda.time.DateTimeZone dateTimeZone19 = dateTime17.getZone();
        org.joda.time.DateTime dateTime20 = localDate6.toDateTimeAtMidnight(dateTimeZone19);
        org.joda.time.DateTime dateTime23 = dateTime20.withDurationAdded((long) 6, (int) (short) 10);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertNotNull(property9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 57600 + "'", int12 == 57600);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 19 + "'", int18 == 19);
        org.junit.Assert.assertNotNull(dateTimeZone19);
        org.junit.Assert.assertNotNull(dateTime20);
        org.junit.Assert.assertNotNull(dateTime23);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate2.plusWeeks(58097);
        org.joda.time.Interval interval7 = localDate6.toInterval();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(interval7);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        boolean boolean7 = dateTime1.isEqualNow();
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime1.plusYears(0);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime12.getZone();
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime12.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime12.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        int int20 = dateTime19.getDayOfYear();
//        int int21 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime19);
//        long long24 = dateTimeZone15.adjustOffset(28800001L, true);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime26 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone25);
//        java.lang.String str28 = cachedDateTimeZone25.getShortName(28800000L);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 365 + "'", int20 == 365);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800001L + "'", long24 == 28800001L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "PST" + "'", str28.equals("PST"));
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicTTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.lang.ClassLoader classLoader1 = null;
        try {
            org.joda.time.tz.ZoneInfoProvider zoneInfoProvider2 = new org.joda.time.tz.ZoneInfoProvider("1969-12-31T00:00:00.000-08:00", classLoader1);
            org.junit.Assert.fail("Expected exception of type java.io.IOException; message: Resource not found: \"1969-12-31T00:00:00.000-08:00/ZoneInfoMap\" ClassLoader: system");
        } catch (java.io.IOException e) {
        }
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.joda.time.chrono.JulianChronology julianChronology0 = org.joda.time.chrono.JulianChronology.getInstance();
        long long4 = julianChronology0.add((long) 100, (long) 0, 10);
        java.lang.String str5 = julianChronology0.toString();
        org.junit.Assert.assertNotNull(julianChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 100L + "'", long4 == 100L);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "JulianChronology[America/Los_Angeles]" + "'", str5.equals("JulianChronology[America/Los_Angeles]"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1858784, 0, 14, 13, 960, 12, 2);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 960 for minuteOfHour must be in the range [0,59]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        int int2 = dateTime1.getDayOfYear();
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.DateTime dateTime8 = dateTime1.minusMonths((int) (byte) 100);
        java.lang.String str9 = dateTime1.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "1969-12-31T16:00:00.100-08:00" + "'", str9.equals("1969-12-31T16:00:00.100-08:00"));
    }
}

