import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("69", "69", 14, 58097);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 58092);
        int int8 = fixedDateTimeZone4.getOffset((long) 15);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 14 + "'", int6 == 14);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 14 + "'", int8 == 14);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
//        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
//        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
//        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone14);
//        boolean boolean17 = dateTime11.isEqualNow();
//        org.joda.time.DateTime dateTime18 = dateTime11.withEarlierOffsetAtOverlap();
//        int int19 = property9.getDifference((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.Instant instant20 = dateTime18.toInstant();
//        org.joda.time.Instant instant23 = instant20.withDurationAdded((long) 14, 166);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(instant20);
//        org.junit.Assert.assertNotNull(instant23);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-25200000), 15, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.joda.time.field.DividedDateTimeField dividedDateTimeField0 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology1 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField2 = iSOChronology1.yearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod3 = null;
//        long long6 = iSOChronology1.add(readablePeriod3, 0L, (-49));
//        org.joda.time.DateTimeField dateTimeField7 = iSOChronology1.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone10 = dateTime9.getZone();
//        org.joda.time.YearMonthDay yearMonthDay11 = dateTime9.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
//        org.joda.time.DateTime dateTime14 = dateTime9.withZoneRetainFields(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        int int17 = dateTime16.getDayOfYear();
//        int int18 = dateTimeZone12.getOffset((org.joda.time.ReadableInstant) dateTime16);
//        org.joda.time.chrono.GJChronology gJChronology19 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone12);
//        org.joda.time.DurationField durationField20 = gJChronology19.millis();
//        org.joda.time.DateTimeField dateTimeField21 = gJChronology19.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
//        int int24 = dateTime23.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = dateTime23.toDateTime(dateTimeZone25);
//        org.joda.time.DateTime dateTime28 = dateTime23.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime29 = dateTime28.toDateTimeISO();
//        boolean boolean30 = gJChronology19.equals((java.lang.Object) dateTime28);
//        org.joda.time.DurationField durationField31 = gJChronology19.minutes();
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology19.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter33 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime35 = dateTimeFormatter33.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod36 = null;
//        org.joda.time.DateTime dateTime37 = dateTime35.plus(readablePeriod36);
//        org.joda.time.DateTime dateTime39 = dateTime37.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property40 = dateTime37.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType41 = property40.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException44 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType41, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField46 = new org.joda.time.field.RemainderDateTimeField(dateTimeField32, dateTimeFieldType41, 9);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField50 = new org.joda.time.field.OffsetDateTimeField(dateTimeField7, dateTimeFieldType41, (-21), 58085, 3083);
//        try {
//            org.joda.time.field.RemainderDateTimeField remainderDateTimeField51 = new org.joda.time.field.RemainderDateTimeField(dividedDateTimeField0, dateTimeFieldType41);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(iSOChronology1);
//        org.junit.Assert.assertNotNull(dateTimeField2);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(yearMonthDay11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 365 + "'", int17 == 365);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-28800000) + "'", int18 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology19);
//        org.junit.Assert.assertNotNull(durationField20);
//        org.junit.Assert.assertNotNull(dateTimeField21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 365 + "'", int24 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertNotNull(dateTimeFormatter33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTime39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTimeFieldType41);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.chrono.BuddhistChronology buddhistChronology3 = org.joda.time.chrono.BuddhistChronology.getInstance(dateTimeZone2);
        org.joda.time.chrono.GJChronology gJChronology4 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(buddhistChronology3);
        org.junit.Assert.assertNotNull(gJChronology4);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
        boolean boolean7 = dateTime1.isEqualNow();
        org.joda.time.DateTime dateTime8 = dateTime1.withEarlierOffsetAtOverlap();
        org.joda.time.ReadableDuration readableDuration9 = null;
        org.joda.time.DateTime dateTime10 = dateTime8.minus(readableDuration9);
        org.joda.time.DateMidnight dateMidnight11 = dateTime10.toDateMidnight();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateMidnight11);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.joda.time.Chronology chronology1 = null;
//        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
//        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
//        org.joda.time.LocalDate localDate6 = localDate4.withCenturyOfEra((int) (short) 0);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
//        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
//        org.joda.time.Chronology chronology12 = null;
//        org.joda.time.LocalDate localDate13 = new org.joda.time.LocalDate((long) (short) 10, chronology12);
//        boolean boolean14 = yearMonthDay10.isBefore((org.joda.time.ReadablePartial) localDate13);
//        org.joda.time.Chronology chronology16 = null;
//        org.joda.time.LocalDate localDate17 = new org.joda.time.LocalDate((long) (short) 10, chronology16);
//        org.joda.time.DateTimeFieldType dateTimeFieldType18 = null;
//        int int19 = localDate17.indexOf(dateTimeFieldType18);
//        boolean boolean20 = yearMonthDay10.isAfter((org.joda.time.ReadablePartial) localDate17);
//        boolean boolean21 = localDate6.isAfter((org.joda.time.ReadablePartial) yearMonthDay10);
//        org.joda.time.LocalDate localDate23 = localDate6.withDayOfYear((int) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone26 = dateTime25.getZone();
//        org.joda.time.YearMonthDay yearMonthDay27 = dateTime25.toYearMonthDay();
//        org.joda.time.Chronology chronology29 = null;
//        org.joda.time.LocalDate localDate30 = new org.joda.time.LocalDate((long) (short) 10, chronology29);
//        boolean boolean31 = yearMonthDay27.isBefore((org.joda.time.ReadablePartial) localDate30);
//        org.joda.time.DateMidnight dateMidnight32 = localDate30.toDateMidnight();
//        org.joda.time.LocalDate.Property property33 = localDate30.yearOfCentury();
//        org.joda.time.LocalDate.Property property34 = localDate30.centuryOfEra();
//        org.joda.time.Chronology chronology36 = null;
//        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) (short) 10, chronology36);
//        org.joda.time.LocalDate localDate39 = localDate37.plusWeeks(0);
//        org.joda.time.LocalDate.Property property40 = localDate37.year();
//        org.joda.time.DateTime dateTime41 = localDate37.toDateTimeAtMidnight();
//        boolean boolean42 = localDate30.isBefore((org.joda.time.ReadablePartial) localDate37);
//        boolean boolean43 = localDate23.isBefore((org.joda.time.ReadablePartial) localDate30);
//        org.junit.Assert.assertNotNull(localDate4);
//        org.junit.Assert.assertNotNull(localDate6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(yearMonthDay10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(yearMonthDay27);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNotNull(dateMidnight32);
//        org.junit.Assert.assertNotNull(property33);
//        org.junit.Assert.assertNotNull(property34);
//        org.junit.Assert.assertNotNull(localDate39);
//        org.junit.Assert.assertNotNull(property40);
//        org.junit.Assert.assertNotNull(dateTime41);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property7 = dateTime4.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = property7.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException12 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType8, (java.lang.Number) 58L, (java.lang.Number) 54464793L, (java.lang.Number) (-18063L));
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        int int2 = dateTime1.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime7 = dateTime6.toDateTimeISO();
//        org.joda.time.Chronology chronology9 = null;
//        org.joda.time.LocalDate localDate10 = new org.joda.time.LocalDate((long) (short) 10, chronology9);
//        org.joda.time.LocalDate localDate12 = localDate10.plusWeeks(0);
//        org.joda.time.LocalDate localDate14 = localDate10.plusWeeks(58097);
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone17 = dateTime16.getZone();
//        org.joda.time.YearMonthDay yearMonthDay18 = dateTime16.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
//        org.joda.time.DateTime dateTime21 = dateTime16.withZoneRetainFields(dateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
//        int int24 = dateTime23.getDayOfYear();
//        int int25 = dateTimeZone19.getOffset((org.joda.time.ReadableInstant) dateTime23);
//        boolean boolean26 = localDate10.equals((java.lang.Object) int25);
//        org.joda.time.LocalDate localDate28 = localDate10.withCenturyOfEra(365);
//        org.joda.time.DateTime dateTime29 = dateTime7.withFields((org.joda.time.ReadablePartial) localDate28);
//        org.joda.time.Chronology chronology31 = null;
//        org.joda.time.LocalDate localDate32 = new org.joda.time.LocalDate((long) (short) 10, chronology31);
//        org.joda.time.LocalDate localDate34 = localDate32.plusWeeks(0);
//        org.joda.time.LocalDate localDate36 = localDate34.withDayOfYear((int) (byte) 100);
//        java.util.Date date37 = localDate36.toDate();
//        org.joda.time.DateTime dateTime38 = dateTime7.withFields((org.joda.time.ReadablePartial) localDate36);
//        try {
//            org.joda.time.DateTime dateTime40 = dateTime38.withMonthOfYear(69);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 69 for monthOfYear must be in the range [1,12]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(localDate12);
//        org.junit.Assert.assertNotNull(localDate14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(yearMonthDay18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 365 + "'", int24 == 365);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-28800000) + "'", int25 == (-28800000));
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(localDate28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(localDate34);
//        org.junit.Assert.assertNotNull(localDate36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(dateTime38);
//    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.UTC;
//        java.util.TimeZone timeZone13 = dateTimeZone12.toTimeZone();
//        org.joda.time.Chronology chronology14 = gJChronology11.withZone(dateTimeZone12);
//        org.joda.time.DateTimeField dateTimeField15 = gJChronology11.monthOfYear();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(timeZone13);
//        org.junit.Assert.assertNotNull(chronology14);
//        org.junit.Assert.assertNotNull(dateTimeField15);
//    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        long long4 = copticChronology0.add(readablePeriod1, (long) (-25200000), 8);
//        org.joda.time.Chronology chronology6 = null;
//        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 10, chronology6);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
//        org.joda.time.DateTime dateTime11 = localDate7.toDateTimeAtMidnight(dateTimeZone8);
//        org.joda.time.LocalDate localDate13 = localDate7.minusYears(58087);
//        int[] intArray14 = localDate13.getValues();
//        boolean boolean15 = copticChronology0.equals((java.lang.Object) intArray14);
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone18 = dateTime17.getZone();
//        org.joda.time.YearMonthDay yearMonthDay19 = dateTime17.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
//        org.joda.time.DateTime dateTime22 = dateTime17.withZoneRetainFields(dateTimeZone20);
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone23);
//        int int25 = dateTime24.getDayOfYear();
//        int int26 = dateTimeZone20.getOffset((org.joda.time.ReadableInstant) dateTime24);
//        org.joda.time.chrono.GJChronology gJChronology27 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone20);
//        org.joda.time.DurationField durationField28 = gJChronology27.millis();
//        org.joda.time.DateTimeField dateTimeField29 = gJChronology27.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
//        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone34 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime35 = org.joda.time.DateTime.now(dateTimeZone34);
//        org.joda.time.DateTime dateTime36 = dateTime31.withZoneRetainFields(dateTimeZone34);
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now(dateTimeZone37);
//        int int39 = dateTime38.getDayOfYear();
//        int int40 = dateTimeZone34.getOffset((org.joda.time.ReadableInstant) dateTime38);
//        org.joda.time.chrono.GJChronology gJChronology41 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone34);
//        org.joda.time.DurationField durationField42 = gJChronology41.millis();
//        org.joda.time.DateTimeField dateTimeField43 = gJChronology41.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField44 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology27, dateTimeField43);
//        int int45 = skipDateTimeField44.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone46 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime47 = org.joda.time.DateTime.now(dateTimeZone46);
//        org.joda.time.DateTimeZone dateTimeZone48 = dateTime47.getZone();
//        org.joda.time.YearMonthDay yearMonthDay49 = dateTime47.toYearMonthDay();
//        org.joda.time.Chronology chronology51 = null;
//        org.joda.time.LocalDate localDate52 = new org.joda.time.LocalDate((long) (short) 10, chronology51);
//        boolean boolean53 = yearMonthDay49.isBefore((org.joda.time.ReadablePartial) localDate52);
//        org.joda.time.LocalDate.Property property54 = localDate52.dayOfYear();
//        java.util.Locale locale56 = null;
//        java.lang.String str57 = skipDateTimeField44.getAsText((org.joda.time.ReadablePartial) localDate52, 58087, locale56);
//        org.joda.time.LocalDate localDate59 = localDate52.withYearOfCentury(0);
//        org.joda.time.LocalDate localDate61 = localDate59.withDayOfYear(17);
//        org.joda.time.DateTimeZone dateTimeZone62 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime63 = org.joda.time.DateTime.now(dateTimeZone62);
//        org.joda.time.DateTimeZone dateTimeZone64 = dateTime63.getZone();
//        org.joda.time.YearMonthDay yearMonthDay65 = dateTime63.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone66 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime67 = org.joda.time.DateTime.now(dateTimeZone66);
//        org.joda.time.DateTime dateTime68 = dateTime63.withZoneRetainFields(dateTimeZone66);
//        boolean boolean69 = dateTime63.isEqualNow();
//        org.joda.time.DateTime.Property property70 = dateTime63.secondOfDay();
//        org.joda.time.DateTime dateTime72 = dateTime63.plusYears(0);
//        org.joda.time.DateTimeZone dateTimeZone73 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime74 = org.joda.time.DateTime.now(dateTimeZone73);
//        org.joda.time.DateTimeZone dateTimeZone75 = dateTime74.getZone();
//        org.joda.time.YearMonthDay yearMonthDay76 = dateTime74.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone77 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime78 = org.joda.time.DateTime.now(dateTimeZone77);
//        org.joda.time.DateTime dateTime79 = dateTime74.withZoneRetainFields(dateTimeZone77);
//        org.joda.time.DateTimeZone dateTimeZone80 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime81 = org.joda.time.DateTime.now(dateTimeZone80);
//        int int82 = dateTime81.getDayOfYear();
//        int int83 = dateTimeZone77.getOffset((org.joda.time.ReadableInstant) dateTime81);
//        long long86 = dateTimeZone77.adjustOffset(28800001L, true);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone87 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone77);
//        org.joda.time.DateTime dateTime88 = dateTime63.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone87);
//        org.joda.time.DateMidnight dateMidnight89 = localDate59.toDateMidnight((org.joda.time.DateTimeZone) cachedDateTimeZone87);
//        org.joda.time.Chronology chronology90 = copticChronology0.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone87);
//        try {
//            long long98 = copticChronology0.getDateTimeMillis(0, 2000, 15, (-11), 15, (int) (byte) -1, 57660);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -11 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-25200000L) + "'", long4 == (-25200000L));
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(yearMonthDay19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 365 + "'", int25 == 365);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-28800000) + "'", int26 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology27);
//        org.junit.Assert.assertNotNull(durationField28);
//        org.junit.Assert.assertNotNull(dateTimeField29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(yearMonthDay33);
//        org.junit.Assert.assertNotNull(dateTimeZone34);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 365 + "'", int39 == 365);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-28800000) + "'", int40 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology41);
//        org.junit.Assert.assertNotNull(durationField42);
//        org.junit.Assert.assertNotNull(dateTimeField43);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 31 + "'", int45 == 31);
//        org.junit.Assert.assertNotNull(dateTimeZone46);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(dateTimeZone48);
//        org.junit.Assert.assertNotNull(yearMonthDay49);
//        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
//        org.junit.Assert.assertNotNull(property54);
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "58087" + "'", str57.equals("58087"));
//        org.junit.Assert.assertNotNull(localDate59);
//        org.junit.Assert.assertNotNull(localDate61);
//        org.junit.Assert.assertNotNull(dateTimeZone62);
//        org.junit.Assert.assertNotNull(dateTime63);
//        org.junit.Assert.assertNotNull(dateTimeZone64);
//        org.junit.Assert.assertNotNull(yearMonthDay65);
//        org.junit.Assert.assertNotNull(dateTimeZone66);
//        org.junit.Assert.assertNotNull(dateTime67);
//        org.junit.Assert.assertNotNull(dateTime68);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
//        org.junit.Assert.assertNotNull(property70);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertNotNull(dateTime74);
//        org.junit.Assert.assertNotNull(dateTimeZone75);
//        org.junit.Assert.assertNotNull(yearMonthDay76);
//        org.junit.Assert.assertNotNull(dateTimeZone77);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(dateTime79);
//        org.junit.Assert.assertNotNull(dateTimeZone80);
//        org.junit.Assert.assertNotNull(dateTime81);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 365 + "'", int82 == 365);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-28800000) + "'", int83 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long86 + "' != '" + 28800001L + "'", long86 == 28800001L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone87);
//        org.junit.Assert.assertNotNull(dateTime88);
//        org.junit.Assert.assertNotNull(dateMidnight89);
//        org.junit.Assert.assertNotNull(chronology90);
//    }

//    @Test
//    public void test012() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test012");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(58085);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        int int5 = dateTime4.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime4.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime11 = dateTime9.minusMinutes((int) (short) -1);
//        int int12 = dateTime11.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        int int15 = dateTime14.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime14.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime11.toDateTime(dateTimeZone16);
//        int int20 = dateTime11.getSecondOfMinute();
//        org.joda.time.DateTime.Property property21 = dateTime11.secondOfDay();
//        boolean boolean22 = gregorianChronology2.equals((java.lang.Object) property21);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.hour();
//        int int24 = dateTimeFormatter23.getDefaultYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter23.withPivotYear((java.lang.Integer) (-25200000));
//        boolean boolean27 = gregorianChronology2.equals((java.lang.Object) dateTimeFormatter26);
//        long long32 = gregorianChronology2.getDateTimeMillis(1, 2, 8, 58087);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 365 + "'", int15 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2000 + "'", int24 == 2000);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-62132313599998L) + "'", long32 == (-62132313599998L));
//    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test013");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime4 = dateTime1.withEarlierOffsetAtOverlap();
//        org.joda.time.MutableDateTime mutableDateTime5 = dateTime1.toMutableDateTime();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(mutableDateTime5);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.DateTimeField dateTimeField1 = iSOChronology0.yearOfCentury();
//        org.joda.time.ReadablePeriod readablePeriod2 = null;
//        long long5 = iSOChronology0.add(readablePeriod2, 0L, (-49));
//        org.joda.time.DateTimeField dateTimeField6 = iSOChronology0.weekyear();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
//        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        int int17 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
//        org.joda.time.DurationField durationField19 = gJChronology18.millis();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime22.toDateTime(dateTimeZone24);
//        org.joda.time.DateTime dateTime27 = dateTime22.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime28 = dateTime27.toDateTimeISO();
//        boolean boolean29 = gJChronology18.equals((java.lang.Object) dateTime27);
//        org.joda.time.DurationField durationField30 = gJChronology18.minutes();
//        org.joda.time.DateTimeField dateTimeField31 = gJChronology18.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter32 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime34 = dateTimeFormatter32.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod35 = null;
//        org.joda.time.DateTime dateTime36 = dateTime34.plus(readablePeriod35);
//        org.joda.time.DateTime dateTime38 = dateTime36.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property39 = dateTime36.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType40 = property39.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException43 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType40, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField45 = new org.joda.time.field.RemainderDateTimeField(dateTimeField31, dateTimeFieldType40, 9);
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField49 = new org.joda.time.field.OffsetDateTimeField(dateTimeField6, dateTimeFieldType40, (-21), 58085, 3083);
//        int int50 = offsetDateTimeField49.getOffset();
//        long long52 = offsetDateTimeField49.remainder((-91L));
//        org.junit.Assert.assertNotNull(iSOChronology0);
//        org.junit.Assert.assertNotNull(dateTimeField1);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertNotNull(dateTimeField6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(yearMonthDay10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertNotNull(dateTimeField31);
//        org.junit.Assert.assertNotNull(dateTimeFormatter32);
//        org.junit.Assert.assertNotNull(dateTime34);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(property39);
//        org.junit.Assert.assertNotNull(dateTimeFieldType40);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-21) + "'", int50 == (-21));
//        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 230399909L + "'", long52 == 230399909L);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        long long4 = copticChronology0.add(readablePeriod1, (long) (-25200000), 8);
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone6 = copticChronology0.getZone();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTimeZone dateTimeZone9 = dateTime8.getZone();
//        org.joda.time.YearMonthDay yearMonthDay10 = dateTime8.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.DateTime dateTime13 = dateTime8.withZoneRetainFields(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        int int17 = dateTimeZone11.getOffset((org.joda.time.ReadableInstant) dateTime15);
//        org.joda.time.chrono.GJChronology gJChronology18 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone11);
//        org.joda.time.DurationField durationField19 = gJChronology18.millis();
//        org.joda.time.DateTimeField dateTimeField20 = gJChronology18.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        org.joda.time.DateTimeZone dateTimeZone23 = dateTime22.getZone();
//        org.joda.time.YearMonthDay yearMonthDay24 = dateTime22.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now(dateTimeZone25);
//        org.joda.time.DateTime dateTime27 = dateTime22.withZoneRetainFields(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone28 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime29 = org.joda.time.DateTime.now(dateTimeZone28);
//        int int30 = dateTime29.getDayOfYear();
//        int int31 = dateTimeZone25.getOffset((org.joda.time.ReadableInstant) dateTime29);
//        org.joda.time.chrono.GJChronology gJChronology32 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone25);
//        org.joda.time.DurationField durationField33 = gJChronology32.millis();
//        org.joda.time.DateTimeField dateTimeField34 = gJChronology32.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField35 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology18, dateTimeField34);
//        int int36 = skipDateTimeField35.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone37 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime38 = org.joda.time.DateTime.now(dateTimeZone37);
//        org.joda.time.DateTimeZone dateTimeZone39 = dateTime38.getZone();
//        org.joda.time.YearMonthDay yearMonthDay40 = dateTime38.toYearMonthDay();
//        org.joda.time.Chronology chronology42 = null;
//        org.joda.time.LocalDate localDate43 = new org.joda.time.LocalDate((long) (short) 10, chronology42);
//        boolean boolean44 = yearMonthDay40.isBefore((org.joda.time.ReadablePartial) localDate43);
//        org.joda.time.LocalDate.Property property45 = localDate43.dayOfYear();
//        java.util.Locale locale47 = null;
//        java.lang.String str48 = skipDateTimeField35.getAsText((org.joda.time.ReadablePartial) localDate43, 58087, locale47);
//        org.joda.time.LocalDate localDate50 = localDate43.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone53 = dateTime52.getZone();
//        org.joda.time.YearMonthDay yearMonthDay54 = dateTime52.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime56 = org.joda.time.DateTime.now(dateTimeZone55);
//        org.joda.time.DateTime dateTime57 = dateTime52.withZoneRetainFields(dateTimeZone55);
//        java.util.Locale locale59 = null;
//        java.lang.String str60 = dateTimeZone55.getShortName((long) 7, locale59);
//        org.joda.time.DateTime dateTime61 = localDate50.toDateTimeAtMidnight(dateTimeZone55);
//        org.joda.time.Chronology chronology62 = copticChronology0.withZone(dateTimeZone55);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-25200000L) + "'", long4 == (-25200000L));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(yearMonthDay10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-28800000) + "'", int17 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology18);
//        org.junit.Assert.assertNotNull(durationField19);
//        org.junit.Assert.assertNotNull(dateTimeField20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(yearMonthDay24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 365 + "'", int30 == 365);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-28800000) + "'", int31 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology32);
//        org.junit.Assert.assertNotNull(durationField33);
//        org.junit.Assert.assertNotNull(dateTimeField34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 31 + "'", int36 == 31);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertNotNull(dateTimeZone39);
//        org.junit.Assert.assertNotNull(yearMonthDay40);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
//        org.junit.Assert.assertNotNull(property45);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "58087" + "'", str48.equals("58087"));
//        org.junit.Assert.assertNotNull(localDate50);
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(yearMonthDay54);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "PST" + "'", str60.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(chronology62);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        boolean boolean1 = dateTimeFormatter0.isPrinter();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(58085);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        int int5 = dateTime4.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime4.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime11 = dateTime9.minusMinutes((int) (short) -1);
//        int int12 = dateTime11.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        int int15 = dateTime14.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime14.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime11.toDateTime(dateTimeZone16);
//        int int20 = dateTime11.getSecondOfMinute();
//        org.joda.time.DateTime.Property property21 = dateTime11.secondOfDay();
//        boolean boolean22 = gregorianChronology2.equals((java.lang.Object) property21);
//        org.joda.time.Instant instant23 = org.joda.time.Instant.now();
//        boolean boolean24 = gregorianChronology2.equals((java.lang.Object) instant23);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 365 + "'", int15 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(instant23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.basicWeekDateTimeNoMillis();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateHourMinute();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter1 = org.joda.time.format.ISODateTimeFormat.hour();
//        int int2 = dateTimeFormatter1.getDefaultYear();
//        org.joda.time.format.DateTimeParser dateTimeParser3 = dateTimeFormatter1.getParser();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        int int6 = dateTime5.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        org.joda.time.DateTime dateTime9 = dateTime5.toDateTime(dateTimeZone7);
//        org.joda.time.DateTime dateTime10 = dateTime5.withEarlierOffsetAtOverlap();
//        org.joda.time.chrono.ISOChronology iSOChronology11 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod12 = null;
//        long long15 = iSOChronology11.add(readablePeriod12, (long) 58089, 6);
//        org.joda.time.DateTimeField dateTimeField16 = iSOChronology11.secondOfMinute();
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 10, chronology18);
//        org.joda.time.LocalDate localDate21 = localDate19.plusWeeks(0);
//        org.joda.time.LocalDate localDate23 = localDate21.withDayOfYear((int) (byte) 100);
//        int[] intArray25 = iSOChronology11.get((org.joda.time.ReadablePartial) localDate21, 0L);
//        org.joda.time.Chronology chronology26 = iSOChronology11.withUTC();
//        org.joda.time.MutableDateTime mutableDateTime27 = dateTime10.toMutableDateTime((org.joda.time.Chronology) iSOChronology11);
//        int int30 = dateTimeFormatter1.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime27, "JulianChronology[America/Los_Angeles]", 20);
//        int int33 = dateTimeFormatter0.parseInto((org.joda.time.ReadWritableInstant) mutableDateTime27, "", 1);
//        org.joda.time.Chronology chronology35 = null;
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
//        org.joda.time.LocalDate localDate38 = localDate36.plusWeeks(0);
//        org.joda.time.LocalDate localDate40 = localDate38.withCenturyOfEra((int) (short) 0);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter41 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime43 = dateTimeFormatter41.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod44 = null;
//        org.joda.time.DateTime dateTime45 = dateTime43.plus(readablePeriod44);
//        org.joda.time.DateTime dateTime47 = dateTime45.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property48 = dateTime45.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType49 = property48.getFieldType();
//        org.joda.time.LocalDate.Property property50 = localDate38.property(dateTimeFieldType49);
//        java.lang.String str51 = dateTimeFormatter0.print((org.joda.time.ReadablePartial) localDate38);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeFormatter1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2000 + "'", int2 == 2000);
//        org.junit.Assert.assertNotNull(dateTimeParser3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 365 + "'", int6 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(iSOChronology11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 58089L + "'", long15 == 58089L);
//        org.junit.Assert.assertNotNull(dateTimeField16);
//        org.junit.Assert.assertNotNull(localDate21);
//        org.junit.Assert.assertNotNull(localDate23);
//        org.junit.Assert.assertNotNull(intArray25);
//        org.junit.Assert.assertNotNull(chronology26);
//        org.junit.Assert.assertNotNull(mutableDateTime27);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-21) + "'", int30 == (-21));
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-2) + "'", int33 == (-2));
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(localDate40);
//        org.junit.Assert.assertNotNull(dateTimeFormatter41);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTime45);
//        org.junit.Assert.assertNotNull(dateTime47);
//        org.junit.Assert.assertNotNull(property48);
//        org.junit.Assert.assertNotNull(dateTimeFieldType49);
//        org.junit.Assert.assertNotNull(property50);
//        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "1969-12-31T��:��" + "'", str51.equals("1969-12-31T��:��"));
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.Interval interval5 = localDate4.toInterval();
        org.joda.time.DateTimeField[] dateTimeFieldArray6 = localDate4.getFields();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(interval5);
        org.junit.Assert.assertNotNull(dateTimeFieldArray6);
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test021");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        org.joda.time.Chronology chronology1 = partial0.getChronology();
//        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.Partial partial3 = partial0.withChronologyRetainFields((org.joda.time.Chronology) copticChronology2);
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone6 = dateTime5.getZone();
//        org.joda.time.YearMonthDay yearMonthDay7 = dateTime5.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        org.joda.time.DateTime dateTime10 = dateTime5.withZoneRetainFields(dateTimeZone8);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        int int13 = dateTime12.getDayOfYear();
//        int int14 = dateTimeZone8.getOffset((org.joda.time.ReadableInstant) dateTime12);
//        org.joda.time.chrono.GJChronology gJChronology15 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone8);
//        org.joda.time.DurationField durationField16 = gJChronology15.millis();
//        org.joda.time.DateTimeField dateTimeField17 = gJChronology15.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        int int20 = dateTime19.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        org.joda.time.DateTime dateTime23 = dateTime19.toDateTime(dateTimeZone21);
//        org.joda.time.DateTime dateTime24 = dateTime19.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime25 = dateTime24.toDateTimeISO();
//        boolean boolean26 = gJChronology15.equals((java.lang.Object) dateTime24);
//        org.joda.time.DurationField durationField27 = gJChronology15.minutes();
//        org.joda.time.DateTimeField dateTimeField28 = gJChronology15.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter29 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime31 = dateTimeFormatter29.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod32 = null;
//        org.joda.time.DateTime dateTime33 = dateTime31.plus(readablePeriod32);
//        org.joda.time.DateTime dateTime35 = dateTime33.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property36 = dateTime33.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType37 = property36.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException40 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType37, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField42 = new org.joda.time.field.RemainderDateTimeField(dateTimeField28, dateTimeFieldType37, 9);
//        java.lang.String str43 = remainderDateTimeField42.toString();
//        org.joda.time.Chronology chronology45 = null;
//        org.joda.time.LocalDate localDate46 = new org.joda.time.LocalDate((long) (short) 10, chronology45);
//        int int47 = localDate46.getCenturyOfEra();
//        org.joda.time.LocalDate localDate49 = localDate46.minusMonths(0);
//        org.joda.time.chrono.CopticChronology copticChronology50 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod51 = null;
//        long long54 = copticChronology50.add(readablePeriod51, (long) (-25200000), 8);
//        org.joda.time.Chronology chronology56 = null;
//        org.joda.time.LocalDate localDate57 = new org.joda.time.LocalDate((long) (short) 10, chronology56);
//        org.joda.time.DateTimeZone dateTimeZone58 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime59 = org.joda.time.DateTime.now(dateTimeZone58);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone58);
//        org.joda.time.DateTime dateTime61 = localDate57.toDateTimeAtMidnight(dateTimeZone58);
//        org.joda.time.LocalDate localDate63 = localDate57.minusYears(58087);
//        int[] intArray64 = localDate63.getValues();
//        boolean boolean65 = copticChronology50.equals((java.lang.Object) intArray64);
//        int int66 = remainderDateTimeField42.getMinimumValue((org.joda.time.ReadablePartial) localDate46, intArray64);
//        org.joda.time.Chronology chronology68 = null;
//        org.joda.time.LocalDate localDate69 = new org.joda.time.LocalDate((long) (short) 10, chronology68);
//        org.joda.time.LocalDate localDate71 = localDate69.plusWeeks(0);
//        org.joda.time.LocalDate.Property property72 = localDate69.year();
//        org.joda.time.DateTime dateTime73 = localDate69.toDateTimeAtMidnight();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter74 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime76 = dateTimeFormatter74.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod77 = null;
//        org.joda.time.DateTime dateTime78 = dateTime76.plus(readablePeriod77);
//        org.joda.time.DateTime dateTime80 = dateTime78.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property81 = dateTime78.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType82 = property81.getFieldType();
//        int int83 = localDate69.get(dateTimeFieldType82);
//        boolean boolean84 = localDate46.isSupported(dateTimeFieldType82);
//        try {
//            org.joda.time.Partial partial86 = partial3.with(dateTimeFieldType82, 3200);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3200 for dayOfMonth must not be larger than 30");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(chronology1);
//        org.junit.Assert.assertNotNull(copticChronology2);
//        org.junit.Assert.assertNotNull(partial3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(yearMonthDay7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 365 + "'", int13 == 365);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-28800000) + "'", int14 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology15);
//        org.junit.Assert.assertNotNull(durationField16);
//        org.junit.Assert.assertNotNull(dateTimeField17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 365 + "'", int20 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//        org.junit.Assert.assertNotNull(durationField27);
//        org.junit.Assert.assertNotNull(dateTimeField28);
//        org.junit.Assert.assertNotNull(dateTimeFormatter29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(dateTimeFieldType37);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str43.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 19 + "'", int47 == 19);
//        org.junit.Assert.assertNotNull(localDate49);
//        org.junit.Assert.assertNotNull(copticChronology50);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + (-25200000L) + "'", long54 == (-25200000L));
//        org.junit.Assert.assertNotNull(dateTimeZone58);
//        org.junit.Assert.assertNotNull(dateTime59);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertNotNull(localDate63);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
//        org.junit.Assert.assertNotNull(localDate71);
//        org.junit.Assert.assertNotNull(property72);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(dateTimeFormatter74);
//        org.junit.Assert.assertNotNull(dateTime76);
//        org.junit.Assert.assertNotNull(dateTime78);
//        org.junit.Assert.assertNotNull(dateTime80);
//        org.junit.Assert.assertNotNull(property81);
//        org.junit.Assert.assertNotNull(dateTimeFieldType82);
//        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 31 + "'", int83 == 31);
//        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
//    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        int int2 = dateTime1.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((int) (short) -1);
//        org.joda.time.DateTime.Property property9 = dateTime8.centuryOfEra();
//        org.joda.time.DateTime dateTime11 = property9.addToCopy((int) (byte) 0);
//        int int12 = property9.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("1969-12-31T00:00:00.000-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T00:00:00.000-08:00\" is malformed at \"-12-31T00:00:00.000-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.Chronology chronology1 = partial0.getChronology();
        org.joda.time.chrono.CopticChronology copticChronology2 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.Partial partial3 = partial0.withChronologyRetainFields((org.joda.time.Chronology) copticChronology2);
        try {
            org.joda.time.DateTimeFieldType dateTimeFieldType5 = partial0.getFieldType((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(copticChronology2);
        org.junit.Assert.assertNotNull(partial3);
    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test025");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
//        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime2.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        int int10 = dateTime9.getDayOfYear();
//        int int11 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
//        long long14 = dateTimeZone0.getMillisKeepLocal(dateTimeZone5, (long) 10);
//        java.util.Locale locale16 = null;
//        java.lang.String str17 = dateTimeZone5.getShortName((long) '4', locale16);
//        int int19 = dateTimeZone5.getOffsetFromLocal(0L);
//        try {
//            org.joda.time.chrono.CopticChronology copticChronology21 = org.joda.time.chrono.CopticChronology.getInstance(dateTimeZone5, (-25200000));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid min days in first week: -25200000");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(yearMonthDay4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 10L + "'", long14 == 10L);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PST" + "'", str17.equals("PST"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-28800000) + "'", int19 == (-28800000));
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate.Property property5 = localDate2.year();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray6 = localDate2.getFieldTypes();
        org.joda.time.chrono.CopticChronology copticChronology7 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod8 = null;
        long long11 = copticChronology7.add(readablePeriod8, (long) (-25200000), 8);
        org.joda.time.Chronology chronology13 = null;
        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 10, chronology13);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone15);
        org.joda.time.DateTime dateTime18 = localDate14.toDateTimeAtMidnight(dateTimeZone15);
        org.joda.time.LocalDate localDate20 = localDate14.minusYears(58087);
        int[] intArray21 = localDate20.getValues();
        boolean boolean22 = copticChronology7.equals((java.lang.Object) intArray21);
        org.joda.time.Partial partial23 = new org.joda.time.Partial(dateTimeFieldTypeArray6, intArray21);
        org.joda.time.DurationFieldType durationFieldType24 = null;
        try {
            org.joda.time.Partial partial26 = partial23.withFieldAdded(durationFieldType24, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray6);
        org.junit.Assert.assertNotNull(copticChronology7);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + (-25200000L) + "'", long11 == (-25200000L));
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(dateTime18);
        org.junit.Assert.assertNotNull(localDate20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
//        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
//        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
//        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
//        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
//        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
//        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = remainderDateTimeField38.getAsShortText(28800035L, locale61);
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = remainderDateTimeField38.getAsShortText((int) (byte) 10, locale64);
//        long long67 = remainderDateTimeField38.roundHalfCeiling((long) (-2));
//        boolean boolean68 = remainderDateTimeField38.isLenient();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(dateMidnight50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "8" + "'", str62.equals("8"));
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10" + "'", str65.equals("10"));
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 28800000L + "'", long67 == 28800000L);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15T16:08:12.898-07:00", (java.lang.Number) 9972000000L, (java.lang.Number) 1.0d, (java.lang.Number) 2000);
        boolean boolean5 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalFieldValueException4);
        java.lang.Number number6 = illegalFieldValueException4.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        long long4 = copticChronology0.add(readablePeriod1, (long) (-25200000), 8);
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone7 = dateTime6.getZone();
//        org.joda.time.YearMonthDay yearMonthDay8 = dateTime6.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
//        org.joda.time.DateTime dateTime11 = dateTime6.withZoneRetainFields(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
//        int int14 = dateTime13.getDayOfYear();
//        int int15 = dateTimeZone9.getOffset((org.joda.time.ReadableInstant) dateTime13);
//        org.joda.time.chrono.GJChronology gJChronology16 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone9);
//        org.joda.time.DurationField durationField17 = gJChronology16.millis();
//        org.joda.time.DateTimeField dateTimeField18 = gJChronology16.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
//        org.joda.time.DateTimeZone dateTimeZone21 = dateTime20.getZone();
//        org.joda.time.YearMonthDay yearMonthDay22 = dateTime20.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone23 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime24 = org.joda.time.DateTime.now(dateTimeZone23);
//        org.joda.time.DateTime dateTime25 = dateTime20.withZoneRetainFields(dateTimeZone23);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone26);
//        int int28 = dateTime27.getDayOfYear();
//        int int29 = dateTimeZone23.getOffset((org.joda.time.ReadableInstant) dateTime27);
//        org.joda.time.chrono.GJChronology gJChronology30 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone23);
//        org.joda.time.DurationField durationField31 = gJChronology30.millis();
//        org.joda.time.DateTimeField dateTimeField32 = gJChronology30.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField33 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology16, dateTimeField32);
//        int int34 = skipDateTimeField33.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone35 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime36 = org.joda.time.DateTime.now(dateTimeZone35);
//        org.joda.time.DateTimeZone dateTimeZone37 = dateTime36.getZone();
//        org.joda.time.YearMonthDay yearMonthDay38 = dateTime36.toYearMonthDay();
//        org.joda.time.Chronology chronology40 = null;
//        org.joda.time.LocalDate localDate41 = new org.joda.time.LocalDate((long) (short) 10, chronology40);
//        boolean boolean42 = yearMonthDay38.isBefore((org.joda.time.ReadablePartial) localDate41);
//        org.joda.time.LocalDate.Property property43 = localDate41.dayOfYear();
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = skipDateTimeField33.getAsText((org.joda.time.ReadablePartial) localDate41, 58087, locale45);
//        java.util.Locale locale48 = null;
//        java.lang.String str49 = skipDateTimeField33.getAsShortText((long) 6, locale48);
//        org.joda.time.DateTimeZone dateTimeZone50 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime51 = org.joda.time.DateTime.now(dateTimeZone50);
//        org.joda.time.DateTimeZone dateTimeZone52 = dateTime51.getZone();
//        org.joda.time.YearMonthDay yearMonthDay53 = dateTime51.toYearMonthDay();
//        org.joda.time.Chronology chronology55 = null;
//        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate((long) (short) 10, chronology55);
//        boolean boolean57 = yearMonthDay53.isBefore((org.joda.time.ReadablePartial) localDate56);
//        org.joda.time.LocalDate.Property property58 = localDate56.dayOfYear();
//        org.joda.time.LocalDate localDate59 = property58.roundHalfFloorCopy();
//        java.util.Date date60 = localDate59.toDate();
//        org.joda.time.LocalDate localDate61 = org.joda.time.LocalDate.fromDateFields(date60);
//        java.util.Locale locale62 = null;
//        java.lang.String str63 = skipDateTimeField33.getAsShortText((org.joda.time.ReadablePartial) localDate61, locale62);
//        int int64 = skipDateTimeField33.getMaximumValue();
//        long long66 = skipDateTimeField33.roundHalfCeiling(58L);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter67 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime69 = dateTimeFormatter67.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod70 = null;
//        org.joda.time.DateTime dateTime71 = dateTime69.plus(readablePeriod70);
//        org.joda.time.DateTime dateTime73 = dateTime71.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property74 = dateTime71.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType75 = property74.getFieldType();
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField76 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) skipDateTimeField33, dateTimeFieldType75);
//        org.joda.time.field.SkipDateTimeField skipDateTimeField77 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) copticChronology0, (org.joda.time.DateTimeField) delegatedDateTimeField76);
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-25200000L) + "'", long4 == (-25200000L));
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(yearMonthDay8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 365 + "'", int14 == 365);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-28800000) + "'", int15 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology16);
//        org.junit.Assert.assertNotNull(durationField17);
//        org.junit.Assert.assertNotNull(dateTimeField18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(yearMonthDay22);
//        org.junit.Assert.assertNotNull(dateTimeZone23);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 365 + "'", int28 == 365);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-28800000) + "'", int29 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology30);
//        org.junit.Assert.assertNotNull(durationField31);
//        org.junit.Assert.assertNotNull(dateTimeField32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 31 + "'", int34 == 31);
//        org.junit.Assert.assertNotNull(dateTimeZone35);
//        org.junit.Assert.assertNotNull(dateTime36);
//        org.junit.Assert.assertNotNull(dateTimeZone37);
//        org.junit.Assert.assertNotNull(yearMonthDay38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(property43);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "58087" + "'", str46.equals("58087"));
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "31" + "'", str49.equals("31"));
//        org.junit.Assert.assertNotNull(dateTimeZone50);
//        org.junit.Assert.assertNotNull(dateTime51);
//        org.junit.Assert.assertNotNull(dateTimeZone52);
//        org.junit.Assert.assertNotNull(yearMonthDay53);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertNotNull(property58);
//        org.junit.Assert.assertNotNull(localDate59);
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(localDate61);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "31" + "'", str63.equals("31"));
//        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 31 + "'", int64 == 31);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 28800000L + "'", long66 == 28800000L);
//        org.junit.Assert.assertNotNull(dateTimeFormatter67);
//        org.junit.Assert.assertNotNull(dateTime69);
//        org.junit.Assert.assertNotNull(dateTime71);
//        org.junit.Assert.assertNotNull(dateTime73);
//        org.junit.Assert.assertNotNull(property74);
//        org.junit.Assert.assertNotNull(dateTimeFieldType75);
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        boolean boolean7 = dateTime1.isEqualNow();
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime1.plusYears(0);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime12.getZone();
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime12.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime12.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        int int20 = dateTime19.getDayOfYear();
//        int int21 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime19);
//        long long24 = dateTimeZone15.adjustOffset(28800001L, true);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime26 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone25);
//        org.joda.time.ReadableDuration readableDuration27 = null;
//        org.joda.time.DateTime dateTime28 = dateTime26.plus(readableDuration27);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 365 + "'", int20 == 365);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800001L + "'", long24 == 28800001L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTime28);
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        int int4 = dateTime1.getCenturyOfEra();
//        int int5 = dateTime1.getSecondOfMinute();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        org.joda.time.DateTime dateTime7 = dateTime6.withTimeAtStartOfDay();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        try {
            org.joda.time.DateTime dateTime7 = new org.joda.time.DateTime(1, 58092, (int) (short) 10, (-28800000), 14, 58085, 17);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value -28800000 for hourOfDay must be in the range [0,23]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate2.plusWeeks(58097);
        org.joda.time.DateTimeFieldType dateTimeFieldType8 = localDate2.getFieldType(0);
        try {
            org.joda.time.LocalDate localDate10 = localDate2.withMonthOfYear(365);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 365 for monthOfYear must be in the range [1,12]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeFieldType8);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
//        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
//        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
//        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
//        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
//        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
//        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = remainderDateTimeField38.getAsShortText(28800035L, locale61);
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = remainderDateTimeField38.getAsShortText((int) (byte) 10, locale64);
//        java.lang.String str66 = remainderDateTimeField38.toString();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField38, 2922789);
//        long long70 = offsetDateTimeField68.roundCeiling(908840217600086399L);
//        org.joda.time.DateTimeFieldType dateTimeFieldType71 = null;
//        try {
//            org.joda.time.field.DividedDateTimeField dividedDateTimeField73 = new org.joda.time.field.DividedDateTimeField((org.joda.time.DateTimeField) offsetDateTimeField68, dateTimeFieldType71, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The type must not be null");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(dateMidnight50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "8" + "'", str62.equals("8"));
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10" + "'", str65.equals("10"));
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str66.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 908840217628800000L + "'", long70 == 908840217628800000L);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 10, chronology7);
        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks(0);
        org.joda.time.LocalDate localDate12 = localDate10.withDayOfYear((int) (byte) 100);
        int[] intArray14 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate10, 0L);
        org.joda.time.DateTimeField dateTimeField15 = iSOChronology0.millisOfDay();
        org.joda.time.DurationField durationField16 = iSOChronology0.eras();
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeField15);
        org.junit.Assert.assertNotNull(durationField16);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        int int2 = dateTime1.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((int) (short) -1);
//        int int9 = dateTime8.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        int int12 = dateTime11.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        org.joda.time.DateTime dateTime15 = dateTime11.toDateTime(dateTimeZone13);
//        org.joda.time.DateTime dateTime16 = dateTime8.toDateTime(dateTimeZone13);
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        int int19 = dateTime18.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
//        org.joda.time.DateTime dateTime22 = dateTime18.toDateTime(dateTimeZone20);
//        org.joda.time.DateTime dateTime24 = dateTime18.minusMonths((int) (short) 1);
//        org.joda.time.DateTime.Property property25 = dateTime18.monthOfYear();
//        int int26 = dateTimeZone13.getOffset((org.joda.time.ReadableInstant) dateTime18);
//        long long30 = dateTimeZone13.convertLocalToUTC((long) '#', false, 464793L);
//        long long33 = dateTimeZone13.adjustOffset((long) 57660, true);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 365 + "'", int12 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 365 + "'", int19 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(dateTime24);
//        org.junit.Assert.assertNotNull(property25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-28800000) + "'", int26 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 28800035L + "'", long30 == 28800035L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 57660L + "'", long33 == 57660L);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.io.InputStream inputStream0 = null;
        try {
            org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.tz.DateTimeZoneBuilder.readFrom(inputStream0, "BuddhistChronology[America/Los_Angeles]");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withFields((org.joda.time.ReadablePartial) yearMonthDay5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillis((long) (short) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.minusMonths(57660);
        try {
            org.joda.time.DateTime dateTime14 = dateTime10.withMillisOfSecond(3083);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 3083 for millisOfSecond must be in the range [0,999]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate.Property property3 = localDate2.era();
        try {
            org.joda.time.LocalDate localDate5 = property3.setCopy("365");
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value \"365\" for era is not supported");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(property3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate4.withDayOfYear((int) (byte) 100);
        org.joda.time.Chronology chronology8 = null;
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((long) (short) 10, chronology8);
        org.joda.time.LocalDate localDate11 = localDate9.plusWeeks(0);
        org.joda.time.LocalDate localDate13 = localDate11.withDayOfYear((int) (byte) 100);
        java.util.Date date14 = localDate13.toDate();
        int int15 = localDate4.compareTo((org.joda.time.ReadablePartial) localDate13);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(localDate11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
//        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
//        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
//        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
//        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
//        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
//        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = remainderDateTimeField38.getAsShortText(28800035L, locale61);
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = remainderDateTimeField38.getAsShortText((int) (byte) 10, locale64);
//        java.lang.String str66 = remainderDateTimeField38.toString();
//        java.util.Locale locale68 = null;
//        java.lang.String str69 = remainderDateTimeField38.getAsText((int) ' ', locale68);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(dateMidnight50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "8" + "'", str62.equals("8"));
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10" + "'", str65.equals("10"));
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str66.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "32" + "'", str69.equals("32"));
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.joda.time.chrono.ISOChronology iSOChronology0 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = iSOChronology0.add(readablePeriod1, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField5 = iSOChronology0.secondOfMinute();
        org.joda.time.Chronology chronology7 = null;
        org.joda.time.LocalDate localDate8 = new org.joda.time.LocalDate((long) (short) 10, chronology7);
        org.joda.time.LocalDate localDate10 = localDate8.plusWeeks(0);
        org.joda.time.LocalDate localDate12 = localDate10.withDayOfYear((int) (byte) 100);
        int[] intArray14 = iSOChronology0.get((org.joda.time.ReadablePartial) localDate10, 0L);
        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime16 = localDate10.toDateTimeAtStartOfDay(dateTimeZone15);
        org.joda.time.LocalDate.Property property17 = localDate10.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType19 = localDate10.getFieldType((int) (short) 0);
        org.junit.Assert.assertNotNull(iSOChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 58089L + "'", long4 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField5);
        org.junit.Assert.assertNotNull(localDate10);
        org.junit.Assert.assertNotNull(localDate12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(dateTimeZone15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertNotNull(property17);
        org.junit.Assert.assertNotNull(dateTimeFieldType19);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.joda.time.DateTimeUtils.MillisProvider millisProvider0 = null;
        try {
            org.joda.time.DateTimeUtils.setCurrentMillisProvider(millisProvider0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The MillisProvider must not be null");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int int2 = org.joda.time.field.FieldUtils.safeAdd(57600100, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600120 + "'", int2 == 57600120);
    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
//        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
//        java.lang.String str39 = remainderDateTimeField38.toString();
//        org.joda.time.Chronology chronology41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (short) 10, chronology41);
//        org.joda.time.DateTimeFieldType dateTimeFieldType43 = null;
//        int int44 = localDate42.indexOf(dateTimeFieldType43);
//        java.util.Locale locale45 = null;
//        java.lang.String str46 = remainderDateTimeField38.getAsShortText((org.joda.time.ReadablePartial) localDate42, locale45);
//        org.joda.time.ReadablePartial readablePartial47 = null;
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = remainderDateTimeField38.getAsShortText(readablePartial47, 960, locale49);
//        int int52 = remainderDateTimeField38.get((long) 57600100);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str39.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "31" + "'", str46.equals("31"));
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "960" + "'", str50.equals("960"));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 8 + "'", int52 == 8);
//    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
//        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
//        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
//        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
//        int int10 = localDate6.getMonthOfYear();
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime12.getZone();
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime12.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime12.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        int int20 = dateTime19.getDayOfYear();
//        int int21 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime19);
//        org.joda.time.chrono.GJChronology gJChronology22 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone15);
//        org.joda.time.DurationField durationField23 = gJChronology22.millis();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology22.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone25 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime26 = org.joda.time.DateTime.now(dateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
//        org.joda.time.YearMonthDay yearMonthDay28 = dateTime26.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.DateTime dateTime31 = dateTime26.withZoneRetainFields(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone32 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime33 = org.joda.time.DateTime.now(dateTimeZone32);
//        int int34 = dateTime33.getDayOfYear();
//        int int35 = dateTimeZone29.getOffset((org.joda.time.ReadableInstant) dateTime33);
//        org.joda.time.chrono.GJChronology gJChronology36 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone29);
//        org.joda.time.DurationField durationField37 = gJChronology36.millis();
//        org.joda.time.DateTimeField dateTimeField38 = gJChronology36.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField39 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology22, dateTimeField38);
//        int int40 = skipDateTimeField39.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone41 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime42 = org.joda.time.DateTime.now(dateTimeZone41);
//        org.joda.time.DateTimeZone dateTimeZone43 = dateTime42.getZone();
//        org.joda.time.YearMonthDay yearMonthDay44 = dateTime42.toYearMonthDay();
//        org.joda.time.Chronology chronology46 = null;
//        org.joda.time.LocalDate localDate47 = new org.joda.time.LocalDate((long) (short) 10, chronology46);
//        boolean boolean48 = yearMonthDay44.isBefore((org.joda.time.ReadablePartial) localDate47);
//        org.joda.time.LocalDate.Property property49 = localDate47.dayOfYear();
//        java.util.Locale locale51 = null;
//        java.lang.String str52 = skipDateTimeField39.getAsText((org.joda.time.ReadablePartial) localDate47, 58087, locale51);
//        org.joda.time.LocalDate localDate54 = localDate47.withYearOfCentury(0);
//        org.joda.time.DateTimeZone dateTimeZone55 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime56 = org.joda.time.DateTime.now(dateTimeZone55);
//        org.joda.time.DateTimeZone dateTimeZone57 = dateTime56.getZone();
//        org.joda.time.YearMonthDay yearMonthDay58 = dateTime56.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone59 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime60 = org.joda.time.DateTime.now(dateTimeZone59);
//        org.joda.time.DateTime dateTime61 = dateTime56.withZoneRetainFields(dateTimeZone59);
//        java.util.Locale locale63 = null;
//        java.lang.String str64 = dateTimeZone59.getShortName((long) 7, locale63);
//        org.joda.time.DateTime dateTime65 = localDate54.toDateTimeAtMidnight(dateTimeZone59);
//        int int66 = localDate6.compareTo((org.joda.time.ReadablePartial) localDate54);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 12 + "'", int10 == 12);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 365 + "'", int20 == 365);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology22);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(yearMonthDay28);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(dateTime33);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 365 + "'", int34 == 365);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-28800000) + "'", int35 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology36);
//        org.junit.Assert.assertNotNull(durationField37);
//        org.junit.Assert.assertNotNull(dateTimeField38);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 31 + "'", int40 == 31);
//        org.junit.Assert.assertNotNull(dateTimeZone41);
//        org.junit.Assert.assertNotNull(dateTime42);
//        org.junit.Assert.assertNotNull(dateTimeZone43);
//        org.junit.Assert.assertNotNull(yearMonthDay44);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertNotNull(property49);
//        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "58087" + "'", str52.equals("58087"));
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(dateTimeZone55);
//        org.junit.Assert.assertNotNull(dateTime56);
//        org.junit.Assert.assertNotNull(dateTimeZone57);
//        org.junit.Assert.assertNotNull(yearMonthDay58);
//        org.junit.Assert.assertNotNull(dateTimeZone59);
//        org.junit.Assert.assertNotNull(dateTime60);
//        org.junit.Assert.assertNotNull(dateTime61);
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "PST" + "'", str64.equals("PST"));
//        org.junit.Assert.assertNotNull(dateTime65);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate4.withCenturyOfEra((int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime9 = dateTimeFormatter7.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.LocalDate.Property property16 = localDate4.property(dateTimeFieldType15);
        org.joda.time.IllegalFieldValueException illegalFieldValueException18 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType15, "GregorianChronology[+00:00:58.085]");
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(property16);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test049");
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.ordinalDateTimeNoMillis();
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
//        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime2.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        int int10 = dateTime9.getDayOfYear();
//        int int11 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
//        org.joda.time.Chronology chronology13 = gJChronology12.withUTC();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getDayOfYear();
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.Chronology chronology25 = gJChronology12.withZone(dateTimeZone18);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter0.withZone(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter0);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(yearMonthDay4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertNotNull(chronology13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(yearMonthDay17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertNotNull(chronology25);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTime();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test051");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
//        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
//        org.joda.time.DateMidnight dateMidnight8 = localDate6.toDateMidnight();
//        org.joda.time.LocalDate.Property property9 = localDate6.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
//        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone14);
//        boolean boolean17 = dateTime11.isEqualNow();
//        org.joda.time.DateTime dateTime18 = dateTime11.withEarlierOffsetAtOverlap();
//        int int19 = property9.getDifference((org.joda.time.ReadableInstant) dateTime18);
//        org.joda.time.Instant instant20 = dateTime18.toInstant();
//        org.joda.time.Instant instant22 = instant20.withMillis((long) 12);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(dateMidnight8);
//        org.junit.Assert.assertNotNull(property9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(yearMonthDay13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(instant20);
//        org.junit.Assert.assertNotNull(instant22);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        int int1 = org.joda.time.field.FieldUtils.safeToInt((long) 1858784);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1858784 + "'", int1 == 1858784);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getDayOfYear();
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField26 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
//        java.lang.String str29 = skipDateTimeField28.toString();
//        org.joda.time.DurationField durationField30 = skipDateTimeField28.getDurationField();
//        long long33 = skipDateTimeField28.add(1833206515200001L, (long) 15);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(yearMonthDay17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str29.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertNotNull(durationField30);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1833207811200001L + "'", long33 == 1833207811200001L);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        org.joda.time.Partial partial2 = partial0.minus(readablePeriod1);
        org.joda.time.DateTimeFieldType dateTimeFieldType3 = null;
        try {
            org.joda.time.Partial partial5 = partial0.withField(dateTimeFieldType3, (-49));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Field 'null' is not supported");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(partial2);
    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
//        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
//        org.joda.time.Instant instant25 = gJChronology11.getGregorianCutover();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(instant25);
//    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        try {
            int int3 = org.joda.time.field.FieldUtils.getWrappedValue((-49), 3200, 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: MIN > MAX");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.hour();
        int int1 = dateTimeFormatter0.getDefaultYear();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter3 = dateTimeFormatter0.withPivotYear((java.lang.Integer) (-25200000));
        java.lang.StringBuffer stringBuffer4 = null;
        try {
            dateTimeFormatter3.printTo(stringBuffer4, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2000 + "'", int1 == 2000);
        org.junit.Assert.assertNotNull(dateTimeFormatter3);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
//        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
//        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
//        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
//        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
//        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
//        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
//        long long62 = remainderDateTimeField38.add(0L, 1858784);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) remainderDateTimeField38, 58095, 20, 365);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58095 for dayOfMonth must be in the range [20,365]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(dateMidnight50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 58657557456000000L + "'", long62 == 58657557456000000L);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getDayOfYear();
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField26 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
//        int int29 = skipDateTimeField28.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
//        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
//        org.joda.time.Chronology chronology35 = null;
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
//        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
//        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now(dateTimeZone45);
//        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime46.toYearMonthDay();
//        org.joda.time.Chronology chronology50 = null;
//        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 10, chronology50);
//        boolean boolean52 = yearMonthDay48.isBefore((org.joda.time.ReadablePartial) localDate51);
//        int[] intArray58 = new int[] { 58093, 58089, 1969, 0, (short) 0 };
//        int int59 = skipDateTimeField28.getMinimumValue((org.joda.time.ReadablePartial) localDate51, intArray58);
//        org.joda.time.DateTimeZone dateTimeZone61 = org.joda.time.DateTimeZone.forOffsetMillis(58085);
//        org.joda.time.chrono.GregorianChronology gregorianChronology62 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone61);
//        org.joda.time.DateTime dateTime63 = localDate51.toDateTimeAtStartOfDay(dateTimeZone61);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(yearMonthDay17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(yearMonthDay33);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(intArray58);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
//        org.junit.Assert.assertNotNull(dateTimeZone61);
//        org.junit.Assert.assertNotNull(gregorianChronology62);
//        org.junit.Assert.assertNotNull(dateTime63);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 31, 24);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        boolean boolean8 = dateTimeZone6.isStandardOffset((-91L));
        org.joda.time.Chronology chronology9 = buddhistChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTimeField dateTimeField10 = buddhistChronology5.clockhourOfDay();
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeField10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("1900-12-31", "(\"org.joda.time.JodaTimePermission\" \"31\")", 57660, 31);
        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.junit.Assert.assertNotNull(dateTime5);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test062");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        int int2 = dateTime1.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime8 = dateTime6.minusMinutes((int) (short) -1);
//        org.joda.time.DateTime dateTime10 = dateTime8.plusWeeks(12);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.date();
        java.lang.Integer int1 = dateTimeFormatter0.getPivotYear();
        try {
            org.joda.time.DateTime dateTime3 = dateTimeFormatter0.parseDateTime("Property[dayOfYear]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"Property[dayOfYear]\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNull(int1);
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getDayOfYear();
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField26 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
//        java.lang.String str29 = skipDateTimeField28.toString();
//        org.joda.time.ReadablePartial readablePartial30 = null;
//        org.joda.time.chrono.ISOChronology iSOChronology33 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
//        org.joda.time.LocalDate localDate34 = new org.joda.time.LocalDate((java.lang.Object) (-1L), (org.joda.time.Chronology) iSOChronology33);
//        org.joda.time.DateTime dateTime35 = localDate34.toDateTimeAtCurrentTime();
//        int[] intArray36 = localDate34.getValues();
//        try {
//            int[] intArray38 = skipDateTimeField28.set(readablePartial30, 1969, intArray36, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(yearMonthDay17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str29.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertNotNull(iSOChronology33);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(intArray36);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("", "", 31, 24);
        org.joda.time.chrono.BuddhistChronology buddhistChronology5 = org.joda.time.chrono.BuddhistChronology.getInstance((org.joda.time.DateTimeZone) fixedDateTimeZone4);
        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
        boolean boolean8 = dateTimeZone6.isStandardOffset((-91L));
        org.joda.time.Chronology chronology9 = buddhistChronology5.withZone(dateTimeZone6);
        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
        org.joda.time.DateTimeZone dateTimeZone12 = dateTime11.getZone();
        org.joda.time.YearMonthDay yearMonthDay13 = dateTime11.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
        org.joda.time.DateTime dateTime16 = dateTime11.withZoneRetainFields(dateTimeZone14);
        boolean boolean17 = dateTime11.isEqualNow();
        org.joda.time.ReadableDuration readableDuration18 = null;
        org.joda.time.DateTime dateTime19 = dateTime11.minus(readableDuration18);
        org.joda.time.DateTime.Property property20 = dateTime19.dayOfMonth();
        org.joda.time.DateTime dateTime21 = property20.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone22 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime23 = org.joda.time.DateTime.now(dateTimeZone22);
        org.joda.time.DateTimeZone dateTimeZone24 = dateTime23.getZone();
        org.joda.time.YearMonthDay yearMonthDay25 = dateTime23.toYearMonthDay();
        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone26);
        org.joda.time.DateTime dateTime28 = dateTime23.withZoneRetainFields(dateTimeZone26);
        boolean boolean29 = dateTime23.isEqualNow();
        org.joda.time.DateTime.Property property30 = dateTime23.secondOfDay();
        org.joda.time.DateTime.Property property31 = dateTime23.year();
        org.joda.time.DateTime dateTime32 = property31.roundHalfEvenCopy();
        java.util.Locale locale33 = null;
        int int34 = property31.getMaximumTextLength(locale33);
        org.joda.time.Chronology chronology36 = null;
        org.joda.time.LocalDate localDate37 = new org.joda.time.LocalDate((long) (short) 10, chronology36);
        org.joda.time.LocalDate localDate39 = localDate37.plusWeeks(0);
        org.joda.time.LocalDate.Property property40 = localDate37.year();
        org.joda.time.DateTimeFieldType[] dateTimeFieldTypeArray41 = localDate37.getFieldTypes();
        org.joda.time.LocalDate localDate43 = localDate37.plusMonths(58087);
        int int44 = property31.compareTo((org.joda.time.ReadablePartial) localDate43);
        org.joda.time.DateMidnight dateMidnight45 = localDate43.toDateMidnight();
        org.joda.time.chrono.LimitChronology limitChronology46 = org.joda.time.chrono.LimitChronology.getInstance(chronology9, (org.joda.time.ReadableDateTime) dateTime21, (org.joda.time.ReadableDateTime) dateMidnight45);
        org.joda.time.DateTime dateTime47 = limitChronology46.getLowerLimit();
        org.joda.time.chrono.ISOChronology iSOChronology48 = org.joda.time.chrono.ISOChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod49 = null;
        long long52 = iSOChronology48.add(readablePeriod49, (long) 58089, 6);
        org.joda.time.DateTimeField dateTimeField53 = iSOChronology48.secondOfMinute();
        org.joda.time.Chronology chronology55 = null;
        org.joda.time.LocalDate localDate56 = new org.joda.time.LocalDate((long) (short) 10, chronology55);
        org.joda.time.LocalDate localDate58 = localDate56.plusWeeks(0);
        org.joda.time.LocalDate localDate60 = localDate58.withDayOfYear((int) (byte) 100);
        int[] intArray62 = iSOChronology48.get((org.joda.time.ReadablePartial) localDate58, 0L);
        org.joda.time.Chronology chronology63 = iSOChronology48.withUTC();
        org.joda.time.DateTimeField dateTimeField64 = iSOChronology48.dayOfYear();
        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField65 = new org.joda.time.field.DelegatedDateTimeField(dateTimeField64);
        boolean boolean66 = limitChronology46.equals((java.lang.Object) dateTimeField64);
        org.junit.Assert.assertNotNull(buddhistChronology5);
        org.junit.Assert.assertNotNull(dateTimeZone6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(chronology9);
        org.junit.Assert.assertNotNull(dateTimeZone10);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTimeZone12);
        org.junit.Assert.assertNotNull(yearMonthDay13);
        org.junit.Assert.assertNotNull(dateTimeZone14);
        org.junit.Assert.assertNotNull(dateTime15);
        org.junit.Assert.assertNotNull(dateTime16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dateTime19);
        org.junit.Assert.assertNotNull(property20);
        org.junit.Assert.assertNotNull(dateTime21);
        org.junit.Assert.assertNotNull(dateTimeZone22);
        org.junit.Assert.assertNotNull(dateTime23);
        org.junit.Assert.assertNotNull(dateTimeZone24);
        org.junit.Assert.assertNotNull(yearMonthDay25);
        org.junit.Assert.assertNotNull(dateTimeZone26);
        org.junit.Assert.assertNotNull(dateTime27);
        org.junit.Assert.assertNotNull(dateTime28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(property30);
        org.junit.Assert.assertNotNull(property31);
        org.junit.Assert.assertNotNull(dateTime32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 9 + "'", int34 == 9);
        org.junit.Assert.assertNotNull(localDate39);
        org.junit.Assert.assertNotNull(property40);
        org.junit.Assert.assertNotNull(dateTimeFieldTypeArray41);
        org.junit.Assert.assertNotNull(localDate43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertNotNull(dateMidnight45);
        org.junit.Assert.assertNotNull(limitChronology46);
        org.junit.Assert.assertNotNull(dateTime47);
        org.junit.Assert.assertNotNull(iSOChronology48);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 58089L + "'", long52 == 58089L);
        org.junit.Assert.assertNotNull(dateTimeField53);
        org.junit.Assert.assertNotNull(localDate58);
        org.junit.Assert.assertNotNull(localDate60);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(chronology63);
        org.junit.Assert.assertNotNull(dateTimeField64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekDateTime();
        boolean boolean1 = dateTimeFormatter0.isOffsetParsed();
        try {
            org.joda.time.LocalDate localDate3 = dateTimeFormatter0.parseLocalDate("10");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"10\" is too short");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
//        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
//        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
//        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
//        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
//        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
//        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = remainderDateTimeField38.getAsShortText(28800035L, locale61);
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = remainderDateTimeField38.getAsShortText((int) (byte) 10, locale64);
//        java.lang.String str66 = remainderDateTimeField38.toString();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField38, 2922789);
//        try {
//            org.joda.time.field.FieldUtils.verifyValueBounds((org.joda.time.DateTimeField) offsetDateTimeField68, 1949, (-21), 0);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 1949 for dayOfMonth must be in the range [-21,0]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(dateMidnight50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "8" + "'", str62.equals("8"));
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10" + "'", str65.equals("10"));
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str66.equals("DateTimeField[dayOfMonth]"));
//    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        boolean boolean7 = dateTime1.isEqualNow();
//        org.joda.time.DateTime.Property property8 = dateTime1.secondOfDay();
//        org.joda.time.DateTime dateTime10 = dateTime1.plusYears(0);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime12 = org.joda.time.DateTime.now(dateTimeZone11);
//        org.joda.time.DateTimeZone dateTimeZone13 = dateTime12.getZone();
//        org.joda.time.YearMonthDay yearMonthDay14 = dateTime12.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone15 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime16 = org.joda.time.DateTime.now(dateTimeZone15);
//        org.joda.time.DateTime dateTime17 = dateTime12.withZoneRetainFields(dateTimeZone15);
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        int int20 = dateTime19.getDayOfYear();
//        int int21 = dateTimeZone15.getOffset((org.joda.time.ReadableInstant) dateTime19);
//        long long24 = dateTimeZone15.adjustOffset(28800001L, true);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone25 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone15);
//        org.joda.time.DateTime dateTime26 = dateTime1.withZoneRetainFields((org.joda.time.DateTimeZone) cachedDateTimeZone25);
//        org.joda.time.DateTimeZone dateTimeZone27 = dateTime26.getZone();
//        boolean boolean28 = dateTime26.isEqualNow();
//        org.joda.time.DateTime dateTime30 = dateTime26.minusHours(4);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(yearMonthDay14);
//        org.junit.Assert.assertNotNull(dateTimeZone15);
//        org.junit.Assert.assertNotNull(dateTime16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 365 + "'", int20 == 365);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-28800000) + "'", int21 == (-28800000));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 28800001L + "'", long24 == 28800001L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(dateTime30);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate localDate6 = localDate4.withCenturyOfEra((int) (short) 0);
        org.joda.time.format.DateTimeFormatter dateTimeFormatter7 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime9 = dateTimeFormatter7.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod10 = null;
        org.joda.time.DateTime dateTime11 = dateTime9.plus(readablePeriod10);
        org.joda.time.DateTime dateTime13 = dateTime11.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property14 = dateTime11.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType15 = property14.getFieldType();
        org.joda.time.LocalDate.Property property16 = localDate4.property(dateTimeFieldType15);
        org.joda.time.LocalDate localDate17 = property16.withMaximumValue();
        org.joda.time.LocalDate localDate18 = property16.withMinimumValue();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(localDate6);
        org.junit.Assert.assertNotNull(dateTimeFormatter7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(dateTime13);
        org.junit.Assert.assertNotNull(property14);
        org.junit.Assert.assertNotNull(dateTimeFieldType15);
        org.junit.Assert.assertNotNull(property16);
        org.junit.Assert.assertNotNull(localDate17);
        org.junit.Assert.assertNotNull(localDate18);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.tTimeNoMillis();
        try {
            org.joda.time.MutableDateTime mutableDateTime2 = dateTimeFormatter0.parseMutableDateTime("1969-12-31T16:00:00.100-08:00");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid format: \"1969-12-31T16:00:00.100-08:00\"");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.joda.time.IllegalInstantException illegalInstantException2 = new org.joda.time.IllegalInstantException((long) (-28800000), "BuddhistChronology[America/Los_Angeles]");
        boolean boolean3 = org.joda.time.IllegalInstantException.isIllegalInstant((java.lang.Throwable) illegalInstantException2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getDayOfYear();
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField26 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
//        int int29 = skipDateTimeField28.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
//        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
//        org.joda.time.Chronology chronology35 = null;
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
//        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
//        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now(dateTimeZone45);
//        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime46.toYearMonthDay();
//        org.joda.time.Chronology chronology50 = null;
//        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 10, chronology50);
//        boolean boolean52 = yearMonthDay48.isBefore((org.joda.time.ReadablePartial) localDate51);
//        org.joda.time.LocalDate.Property property53 = localDate51.dayOfYear();
//        org.joda.time.LocalDate localDate54 = property53.roundHalfFloorCopy();
//        java.util.Date date55 = localDate54.toDate();
//        org.joda.time.LocalDate localDate56 = org.joda.time.LocalDate.fromDateFields(date55);
//        java.util.Locale locale57 = null;
//        java.lang.String str58 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate56, locale57);
//        int int59 = skipDateTimeField28.getMaximumValue();
//        boolean boolean60 = skipDateTimeField28.isLenient();
//        java.util.Locale locale61 = null;
//        int int62 = skipDateTimeField28.getMaximumShortTextLength(locale61);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(yearMonthDay17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(yearMonthDay33);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(localDate56);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "31" + "'", str58.equals("31"));
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 31 + "'", int59 == 31);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 2 + "'", int62 == 2);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.joda.time.IllegalInstantException illegalInstantException1 = new org.joda.time.IllegalInstantException("1900-12-31");
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.dateTimeParser();
        try {
            java.lang.String str2 = dateTimeFormatter0.print((long) 6);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: Printing not supported");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        int int2 = dateTime1.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        org.joda.time.DateTime dateTime5 = dateTime1.toDateTime(dateTimeZone3);
//        org.joda.time.DateTime dateTime6 = dateTime1.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime8 = dateTime1.plusMonths((int) (byte) -1);
//        org.joda.time.Chronology chronology10 = null;
//        org.joda.time.LocalDate localDate11 = new org.joda.time.LocalDate((long) (short) 10, chronology10);
//        org.joda.time.LocalDate localDate13 = localDate11.plusWeeks(0);
//        org.joda.time.LocalDate.Property property14 = localDate11.year();
//        org.joda.time.DateTime dateTime15 = localDate11.toDateTimeAtMidnight();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter16 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime18 = dateTimeFormatter16.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod19 = null;
//        org.joda.time.DateTime dateTime20 = dateTime18.plus(readablePeriod19);
//        org.joda.time.DateTime dateTime22 = dateTime20.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property23 = dateTime20.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType24 = property23.getFieldType();
//        int int25 = localDate11.get(dateTimeFieldType24);
//        org.joda.time.DateTime.Property property26 = dateTime8.property(dateTimeFieldType24);
//        java.lang.Number number27 = null;
//        org.joda.time.IllegalFieldValueException illegalFieldValueException29 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType24, number27, "");
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 365 + "'", int2 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(localDate13);
//        org.junit.Assert.assertNotNull(property14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeFormatter16);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertNotNull(property23);
//        org.junit.Assert.assertNotNull(dateTimeFieldType24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 31 + "'", int25 == 31);
//        org.junit.Assert.assertNotNull(property26);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("31");
        java.lang.String str2 = jodaTimePermission1.getActions();
        java.security.PermissionCollection permissionCollection3 = jodaTimePermission1.newPermissionCollection();
        org.joda.time.JodaTimePermission jodaTimePermission5 = new org.joda.time.JodaTimePermission("31");
        java.lang.String str6 = jodaTimePermission5.getActions();
        java.security.PermissionCollection permissionCollection7 = jodaTimePermission5.newPermissionCollection();
        java.lang.String str8 = jodaTimePermission5.getName();
        boolean boolean9 = jodaTimePermission1.implies((java.security.Permission) jodaTimePermission5);
        boolean boolean11 = jodaTimePermission1.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertNotNull(permissionCollection7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "31" + "'", str8.equals("31"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        org.joda.time.DateTime dateTime8 = dateTime6.withDayOfYear((int) '#');
        org.joda.time.YearMonthDay yearMonthDay9 = dateTime6.toYearMonthDay();
        int int10 = dateTime6.getMinuteOfHour();
        int int11 = dateTime6.getWeekyear();
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(yearMonthDay9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1970 + "'", int11 == 1970);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.forOffsetMillis(58085);
//        org.joda.time.chrono.GregorianChronology gregorianChronology2 = org.joda.time.chrono.GregorianChronology.getInstance(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        int int5 = dateTime4.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime4.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime11 = dateTime9.minusMinutes((int) (short) -1);
//        int int12 = dateTime11.getSecondOfMinute();
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        int int15 = dateTime14.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime14.toDateTime(dateTimeZone16);
//        org.joda.time.DateTime dateTime19 = dateTime11.toDateTime(dateTimeZone16);
//        int int20 = dateTime11.getSecondOfMinute();
//        org.joda.time.DateTime.Property property21 = dateTime11.secondOfDay();
//        boolean boolean22 = gregorianChronology2.equals((java.lang.Object) property21);
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter23 = org.joda.time.format.ISODateTimeFormat.hour();
//        int int24 = dateTimeFormatter23.getDefaultYear();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter26 = dateTimeFormatter23.withPivotYear((java.lang.Integer) (-25200000));
//        boolean boolean27 = gregorianChronology2.equals((java.lang.Object) dateTimeFormatter26);
//        try {
//            long long35 = gregorianChronology2.getDateTimeMillis(86399, 57600100, (-11), 58085, (int) (byte) 1, (int) ' ', 58092898);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58085 for hourOfDay must be in the range [0,23]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(gregorianChronology2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 365 + "'", int15 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
//        org.junit.Assert.assertNotNull(property21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(dateTimeFormatter23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2000 + "'", int24 == 2000);
//        org.junit.Assert.assertNotNull(dateTimeFormatter26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withFields((org.joda.time.ReadablePartial) yearMonthDay5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillis((long) (short) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.plusYears(3083);
        org.joda.time.ReadablePeriod readablePeriod13 = null;
        org.joda.time.DateTime dateTime15 = dateTime12.withPeriodAdded(readablePeriod13, 960);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime15);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.DateTimeZone dateTimeZone5 = null;
        org.joda.time.Interval interval6 = localDate2.toInterval(dateTimeZone5);
        org.joda.time.LocalDate.Property property7 = localDate2.weekyear();
        org.joda.time.DateMidnight dateMidnight8 = localDate2.toDateMidnight();
        int int9 = dateMidnight8.getMonthOfYear();
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(interval6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateMidnight8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 12 + "'", int9 == 12);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException2 = new org.joda.time.IllegalFieldValueException(durationFieldType0, "9972000000");
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        long long4 = copticChronology0.add(readablePeriod1, (long) (-25200000), 8);
//        org.joda.time.DateTimeField dateTimeField5 = copticChronology0.yearOfCentury();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        org.joda.time.DateTimeZone dateTimeZone8 = dateTime7.getZone();
//        org.joda.time.YearMonthDay yearMonthDay9 = dateTime7.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone10 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime11 = org.joda.time.DateTime.now(dateTimeZone10);
//        org.joda.time.DateTime dateTime12 = dateTime7.withZoneRetainFields(dateTimeZone10);
//        org.joda.time.DateTimeZone dateTimeZone13 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime14 = org.joda.time.DateTime.now(dateTimeZone13);
//        int int15 = dateTime14.getDayOfYear();
//        int int16 = dateTimeZone10.getOffset((org.joda.time.ReadableInstant) dateTime14);
//        org.joda.time.chrono.GJChronology gJChronology17 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone10);
//        org.joda.time.DurationField durationField18 = gJChronology17.millis();
//        org.joda.time.DateTimeField dateTimeField19 = gJChronology17.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone20 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime21 = org.joda.time.DateTime.now(dateTimeZone20);
//        org.joda.time.DateTimeZone dateTimeZone22 = dateTime21.getZone();
//        org.joda.time.YearMonthDay yearMonthDay23 = dateTime21.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone24 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime25 = org.joda.time.DateTime.now(dateTimeZone24);
//        org.joda.time.DateTime dateTime26 = dateTime21.withZoneRetainFields(dateTimeZone24);
//        org.joda.time.DateTimeZone dateTimeZone27 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime28 = org.joda.time.DateTime.now(dateTimeZone27);
//        int int29 = dateTime28.getDayOfYear();
//        int int30 = dateTimeZone24.getOffset((org.joda.time.ReadableInstant) dateTime28);
//        org.joda.time.chrono.GJChronology gJChronology31 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone24);
//        org.joda.time.DurationField durationField32 = gJChronology31.millis();
//        org.joda.time.DateTimeField dateTimeField33 = gJChronology31.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField34 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology17, dateTimeField33);
//        int int35 = skipDateTimeField34.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone36 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime37 = org.joda.time.DateTime.now(dateTimeZone36);
//        org.joda.time.DateTimeZone dateTimeZone38 = dateTime37.getZone();
//        org.joda.time.YearMonthDay yearMonthDay39 = dateTime37.toYearMonthDay();
//        org.joda.time.Chronology chronology41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (short) 10, chronology41);
//        boolean boolean43 = yearMonthDay39.isBefore((org.joda.time.ReadablePartial) localDate42);
//        org.joda.time.LocalDate.Property property44 = localDate42.dayOfYear();
//        java.util.Locale locale46 = null;
//        java.lang.String str47 = skipDateTimeField34.getAsText((org.joda.time.ReadablePartial) localDate42, 58087, locale46);
//        java.util.Locale locale49 = null;
//        java.lang.String str50 = skipDateTimeField34.getAsShortText((long) 6, locale49);
//        org.joda.time.DateTimeZone dateTimeZone51 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime52 = org.joda.time.DateTime.now(dateTimeZone51);
//        org.joda.time.DateTimeZone dateTimeZone53 = dateTime52.getZone();
//        org.joda.time.YearMonthDay yearMonthDay54 = dateTime52.toYearMonthDay();
//        org.joda.time.Chronology chronology56 = null;
//        org.joda.time.LocalDate localDate57 = new org.joda.time.LocalDate((long) (short) 10, chronology56);
//        boolean boolean58 = yearMonthDay54.isBefore((org.joda.time.ReadablePartial) localDate57);
//        int[] intArray64 = new int[] { 58093, 58089, 1969, 0, (short) 0 };
//        int int65 = skipDateTimeField34.getMinimumValue((org.joda.time.ReadablePartial) localDate57, intArray64);
//        try {
//            long long67 = copticChronology0.set((org.joda.time.ReadablePartial) localDate57, (long) 58095);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 31 for dayOfMonth must be in the range [1,30]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(copticChronology0);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-25200000L) + "'", long4 == (-25200000L));
//        org.junit.Assert.assertNotNull(dateTimeField5);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(yearMonthDay9);
//        org.junit.Assert.assertNotNull(dateTimeZone10);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(dateTime12);
//        org.junit.Assert.assertNotNull(dateTimeZone13);
//        org.junit.Assert.assertNotNull(dateTime14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 365 + "'", int15 == 365);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-28800000) + "'", int16 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology17);
//        org.junit.Assert.assertNotNull(durationField18);
//        org.junit.Assert.assertNotNull(dateTimeField19);
//        org.junit.Assert.assertNotNull(dateTimeZone20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTimeZone22);
//        org.junit.Assert.assertNotNull(yearMonthDay23);
//        org.junit.Assert.assertNotNull(dateTimeZone24);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(dateTime26);
//        org.junit.Assert.assertNotNull(dateTimeZone27);
//        org.junit.Assert.assertNotNull(dateTime28);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 365 + "'", int29 == 365);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-28800000) + "'", int30 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology31);
//        org.junit.Assert.assertNotNull(durationField32);
//        org.junit.Assert.assertNotNull(dateTimeField33);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 31 + "'", int35 == 31);
//        org.junit.Assert.assertNotNull(dateTimeZone36);
//        org.junit.Assert.assertNotNull(dateTime37);
//        org.junit.Assert.assertNotNull(dateTimeZone38);
//        org.junit.Assert.assertNotNull(yearMonthDay39);
//        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
//        org.junit.Assert.assertNotNull(property44);
//        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "58087" + "'", str47.equals("58087"));
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "31" + "'", str50.equals("31"));
//        org.junit.Assert.assertNotNull(dateTimeZone51);
//        org.junit.Assert.assertNotNull(dateTime52);
//        org.junit.Assert.assertNotNull(dateTimeZone53);
//        org.junit.Assert.assertNotNull(yearMonthDay54);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(intArray64);
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1 + "'", int65 == 1);
//    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
//        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
//        java.lang.String str39 = remainderDateTimeField38.toString();
//        org.joda.time.Chronology chronology41 = null;
//        org.joda.time.LocalDate localDate42 = new org.joda.time.LocalDate((long) (short) 10, chronology41);
//        int int43 = localDate42.getCenturyOfEra();
//        org.joda.time.LocalDate localDate45 = localDate42.minusMonths(0);
//        org.joda.time.chrono.CopticChronology copticChronology46 = org.joda.time.chrono.CopticChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod47 = null;
//        long long50 = copticChronology46.add(readablePeriod47, (long) (-25200000), 8);
//        org.joda.time.Chronology chronology52 = null;
//        org.joda.time.LocalDate localDate53 = new org.joda.time.LocalDate((long) (short) 10, chronology52);
//        org.joda.time.DateTimeZone dateTimeZone54 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime55 = org.joda.time.DateTime.now(dateTimeZone54);
//        org.joda.time.DateTimeZone.setDefault(dateTimeZone54);
//        org.joda.time.DateTime dateTime57 = localDate53.toDateTimeAtMidnight(dateTimeZone54);
//        org.joda.time.LocalDate localDate59 = localDate53.minusYears(58087);
//        int[] intArray60 = localDate59.getValues();
//        boolean boolean61 = copticChronology46.equals((java.lang.Object) intArray60);
//        int int62 = remainderDateTimeField38.getMinimumValue((org.joda.time.ReadablePartial) localDate42, intArray60);
//        int int63 = localDate42.getYearOfCentury();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str39.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 19 + "'", int43 == 19);
//        org.junit.Assert.assertNotNull(localDate45);
//        org.junit.Assert.assertNotNull(copticChronology46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + (-25200000L) + "'", long50 == (-25200000L));
//        org.junit.Assert.assertNotNull(dateTimeZone54);
//        org.junit.Assert.assertNotNull(dateTime55);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertNotNull(localDate59);
//        org.junit.Assert.assertNotNull(intArray60);
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 69 + "'", int63 == 69);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.joda.time.chrono.BuddhistChronology buddhistChronology0 = org.joda.time.chrono.BuddhistChronology.getInstanceUTC();
        org.joda.time.Chronology chronology1 = buddhistChronology0.withUTC();
        org.joda.time.DurationField durationField2 = buddhistChronology0.weekyears();
        org.junit.Assert.assertNotNull(buddhistChronology0);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNotNull(durationField2);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
//        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
//        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
//        org.joda.time.DateTime dateTime6 = dateTime1.withFields((org.joda.time.ReadablePartial) yearMonthDay5);
//        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) (byte) 1);
//        org.joda.time.DateTime dateTime10 = dateTime8.withMillis((long) (short) 100);
//        org.joda.time.DateTimeZone dateTimeZone11 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTimeZone dateTimeZone12 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime13 = org.joda.time.DateTime.now(dateTimeZone12);
//        org.joda.time.DateTimeZone dateTimeZone14 = dateTime13.getZone();
//        org.joda.time.YearMonthDay yearMonthDay15 = dateTime13.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone16 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime17 = org.joda.time.DateTime.now(dateTimeZone16);
//        org.joda.time.DateTime dateTime18 = dateTime13.withZoneRetainFields(dateTimeZone16);
//        org.joda.time.DateTimeZone dateTimeZone19 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime20 = org.joda.time.DateTime.now(dateTimeZone19);
//        int int21 = dateTime20.getDayOfYear();
//        int int22 = dateTimeZone16.getOffset((org.joda.time.ReadableInstant) dateTime20);
//        org.joda.time.chrono.GJChronology gJChronology23 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone16);
//        long long25 = dateTimeZone11.getMillisKeepLocal(dateTimeZone16, (long) 10);
//        org.joda.time.tz.CachedDateTimeZone cachedDateTimeZone26 = org.joda.time.tz.CachedDateTimeZone.forZone(dateTimeZone11);
//        org.joda.time.DateTime dateTime27 = dateTime8.withZone((org.joda.time.DateTimeZone) cachedDateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(dateTime3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(yearMonthDay5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(dateTimeZone12);
//        org.junit.Assert.assertNotNull(dateTime13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(yearMonthDay15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(dateTime17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeZone19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 365 + "'", int21 == 365);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-28800000) + "'", int22 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 10L + "'", long25 == 10L);
//        org.junit.Assert.assertNotNull(cachedDateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.joda.time.JodaTimePermission jodaTimePermission1 = new org.joda.time.JodaTimePermission("58087");
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test087");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
//        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
//        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
//        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
//        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
//        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
//        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = remainderDateTimeField38.getAsShortText(28800035L, locale61);
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = remainderDateTimeField38.getAsShortText((int) (byte) 10, locale64);
//        java.lang.String str66 = remainderDateTimeField38.toString();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField38, 2922789);
//        long long70 = offsetDateTimeField68.roundCeiling(908840217600086399L);
//        try {
//            long long73 = offsetDateTimeField68.set((long) 57600120, 2);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 2 for dayOfMonth must be in the range [2922789,2922797]");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(dateMidnight50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "8" + "'", str62.equals("8"));
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10" + "'", str65.equals("10"));
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str66.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 908840217628800000L + "'", long70 == 908840217628800000L);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
        org.joda.time.Chronology chronology5 = null;
        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
        try {
            org.joda.time.DateTimeField dateTimeField9 = yearMonthDay3.getField(57660);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Invalid index: 57660");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(yearMonthDay3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate.Property property3 = localDate2.era();
        org.joda.time.LocalDate localDate4 = property3.roundFloorCopy();
        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.UTC;
        java.util.TimeZone timeZone6 = dateTimeZone5.toTimeZone();
        org.joda.time.DateTime dateTime7 = localDate4.toDateTimeAtStartOfDay(dateTimeZone5);
        org.junit.Assert.assertNotNull(property3);
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(dateTimeZone5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNotNull(dateTime7);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
        org.joda.time.ReadableDuration readableDuration3 = null;
        org.joda.time.DateTime dateTime4 = dateTime1.plus(readableDuration3);
        org.joda.time.DateTime.Property property5 = dateTime4.dayOfYear();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(property5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.LocalDate localDate4 = localDate2.plusWeeks(0);
        org.joda.time.LocalDate.Property property5 = localDate2.year();
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight();
        java.lang.String str7 = dateTime6.toString();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter8 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime10 = dateTimeFormatter8.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod11 = null;
        org.joda.time.DateTime dateTime12 = dateTime10.plus(readablePeriod11);
        org.joda.time.DateTime dateTime14 = dateTime12.minusMillis((int) (short) 100);
        org.joda.time.DateTime.Property property15 = dateTime12.dayOfMonth();
        org.joda.time.DateTimeFieldType dateTimeFieldType16 = property15.getFieldType();
        org.joda.time.IllegalFieldValueException illegalFieldValueException19 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType16, (java.lang.Number) 13, "58092");
        try {
            org.joda.time.DateTime dateTime21 = dateTime6.withField(dateTimeFieldType16, 0);
            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 0 for dayOfMonth must be in the range [1,31]");
        } catch (org.joda.time.IllegalFieldValueException e) {
        }
        org.junit.Assert.assertNotNull(localDate4);
        org.junit.Assert.assertNotNull(property5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1969-12-31T00:00:00.000-08:00" + "'", str7.equals("1969-12-31T00:00:00.000-08:00"));
        org.junit.Assert.assertNotNull(dateTimeFormatter8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
        org.junit.Assert.assertNotNull(dateTime14);
        org.junit.Assert.assertNotNull(property15);
        org.junit.Assert.assertNotNull(dateTimeFieldType16);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.parse("2019-06-15T16:08:12.898-07:00");
        int int2 = dateTime1.getYearOfCentury();
        org.joda.time.Instant instant3 = dateTime1.toInstant();
        org.joda.time.MutableDateTime mutableDateTime4 = instant3.toMutableDateTime();
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19 + "'", int2 == 19);
        org.junit.Assert.assertNotNull(instant3);
        org.junit.Assert.assertNotNull(mutableDateTime4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.UTC;
        java.util.TimeZone timeZone1 = dateTimeZone0.toTimeZone();
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.forTimeZone(timeZone1);
        java.lang.String str3 = dateTimeZone2.toString();
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "UTC" + "'", str3.equals("UTC"));
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
//        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
//        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
//        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
//        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
//        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
//        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = remainderDateTimeField38.getAsShortText(28800035L, locale61);
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = remainderDateTimeField38.getAsShortText((int) (byte) 10, locale64);
//        java.lang.String str66 = remainderDateTimeField38.toString();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField38, 2922789);
//        org.joda.time.field.DelegatedDateTimeField delegatedDateTimeField69 = new org.joda.time.field.DelegatedDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField38);
//        int int70 = remainderDateTimeField38.getMinimumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(dateMidnight50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "8" + "'", str62.equals("8"));
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10" + "'", str65.equals("10"));
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str66.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
//    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        int int2 = dateTime1.getSecondOfDay();
//        int int3 = dateTime1.getSecondOfMinute();
//        org.joda.time.DateTime dateTime4 = dateTime1.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime6 = dateTime1.plus((-62142940799993L));
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 57600 + "'", int2 == 57600);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertNotNull(dateTime6);
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
        org.joda.time.DateTimeZone dateTimeZone2 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime3 = org.joda.time.DateTime.now(dateTimeZone2);
        org.joda.time.DateTimeZone dateTimeZone4 = dateTime3.getZone();
        org.joda.time.YearMonthDay yearMonthDay5 = dateTime3.toYearMonthDay();
        org.joda.time.DateTime dateTime6 = dateTime1.withFields((org.joda.time.ReadablePartial) yearMonthDay5);
        org.joda.time.DateTime dateTime8 = dateTime6.withMinuteOfHour((int) (byte) 1);
        org.joda.time.DateTime dateTime10 = dateTime8.withMillis((long) (short) 100);
        org.joda.time.DateTime dateTime12 = dateTime10.minusDays(0);
        org.junit.Assert.assertNotNull(dateTimeZone0);
        org.junit.Assert.assertNotNull(dateTime1);
        org.junit.Assert.assertNotNull(dateTimeZone2);
        org.junit.Assert.assertNotNull(dateTime3);
        org.junit.Assert.assertNotNull(dateTimeZone4);
        org.junit.Assert.assertNotNull(yearMonthDay5);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(dateTime8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertNotNull(dateTime12);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.joda.time.Partial partial0 = new org.joda.time.Partial();
        org.joda.time.Chronology chronology1 = partial0.getChronology();
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = partial0.getFormatter();
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.Partial partial4 = partial0.plus(readablePeriod3);
        org.junit.Assert.assertNotNull(chronology1);
        org.junit.Assert.assertNull(dateTimeFormatter2);
        org.junit.Assert.assertNotNull(partial4);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException("2019-06-15T16:08:12.898-07:00", (java.lang.Number) 9972000000L, (java.lang.Number) 1.0d, (java.lang.Number) 2000);
        java.lang.String str5 = illegalFieldValueException4.getIllegalValueAsString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "9972000000" + "'", str5.equals("9972000000"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.joda.time.DurationFieldType durationFieldType0 = null;
        try {
            org.joda.time.IllegalFieldValueException illegalFieldValueException4 = new org.joda.time.IllegalFieldValueException(durationFieldType0, (java.lang.Number) (-1), (java.lang.Number) (short) -1, (java.lang.Number) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test100");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
//        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
//        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
//        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
//        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
//        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
//        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = remainderDateTimeField38.getAsShortText(28800035L, locale61);
//        java.lang.String str64 = remainderDateTimeField38.getAsText((long) 58089);
//        int int65 = remainderDateTimeField38.getMaximumValue();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(dateMidnight50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "8" + "'", str62.equals("8"));
//        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "7" + "'", str64.equals("7"));
//        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 8 + "'", int65 == 8);
//    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.joda.time.DateTimeZone dateTimeZone1 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime2 = org.joda.time.DateTime.now(dateTimeZone1);
//        org.joda.time.DateTimeZone dateTimeZone3 = dateTime2.getZone();
//        org.joda.time.YearMonthDay yearMonthDay4 = dateTime2.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone5 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime6 = org.joda.time.DateTime.now(dateTimeZone5);
//        org.joda.time.DateTime dateTime7 = dateTime2.withZoneRetainFields(dateTimeZone5);
//        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
//        int int10 = dateTime9.getDayOfYear();
//        int int11 = dateTimeZone5.getOffset((org.joda.time.ReadableInstant) dateTime9);
//        org.joda.time.chrono.GJChronology gJChronology12 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone5);
//        int int13 = gJChronology12.getMinimumDaysInFirstWeek();
//        org.joda.time.DateTimeField dateTimeField14 = gJChronology12.dayOfWeek();
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate(54464793L, (org.joda.time.Chronology) gJChronology12);
//        org.junit.Assert.assertNotNull(dateTimeZone1);
//        org.junit.Assert.assertNotNull(dateTime2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(yearMonthDay4);
//        org.junit.Assert.assertNotNull(dateTimeZone5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTimeZone8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 365 + "'", int10 == 365);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-28800000) + "'", int11 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
//        org.junit.Assert.assertNotNull(dateTimeField14);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test102");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getDayOfYear();
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField26 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
//        int int29 = skipDateTimeField28.getMaximumValue();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
//        org.joda.time.DateTimeZone dateTimeZone32 = dateTime31.getZone();
//        org.joda.time.YearMonthDay yearMonthDay33 = dateTime31.toYearMonthDay();
//        org.joda.time.Chronology chronology35 = null;
//        org.joda.time.LocalDate localDate36 = new org.joda.time.LocalDate((long) (short) 10, chronology35);
//        boolean boolean37 = yearMonthDay33.isBefore((org.joda.time.ReadablePartial) localDate36);
//        org.joda.time.LocalDate.Property property38 = localDate36.dayOfYear();
//        java.util.Locale locale40 = null;
//        java.lang.String str41 = skipDateTimeField28.getAsText((org.joda.time.ReadablePartial) localDate36, 58087, locale40);
//        java.util.Locale locale43 = null;
//        java.lang.String str44 = skipDateTimeField28.getAsShortText((long) 6, locale43);
//        org.joda.time.DateTimeZone dateTimeZone45 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime46 = org.joda.time.DateTime.now(dateTimeZone45);
//        org.joda.time.DateTimeZone dateTimeZone47 = dateTime46.getZone();
//        org.joda.time.YearMonthDay yearMonthDay48 = dateTime46.toYearMonthDay();
//        org.joda.time.Chronology chronology50 = null;
//        org.joda.time.LocalDate localDate51 = new org.joda.time.LocalDate((long) (short) 10, chronology50);
//        boolean boolean52 = yearMonthDay48.isBefore((org.joda.time.ReadablePartial) localDate51);
//        org.joda.time.LocalDate.Property property53 = localDate51.dayOfYear();
//        org.joda.time.LocalDate localDate54 = property53.roundHalfFloorCopy();
//        java.util.Date date55 = localDate54.toDate();
//        org.joda.time.LocalDate localDate56 = org.joda.time.LocalDate.fromDateFields(date55);
//        java.util.Locale locale57 = null;
//        java.lang.String str58 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate56, locale57);
//        long long61 = skipDateTimeField28.add((long) 2000, 57600120);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(yearMonthDay17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 31 + "'", int29 == 31);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTimeZone32);
//        org.junit.Assert.assertNotNull(yearMonthDay33);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertNotNull(property38);
//        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "58087" + "'", str41.equals("58087"));
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "31" + "'", str44.equals("31"));
//        org.junit.Assert.assertNotNull(dateTimeZone45);
//        org.junit.Assert.assertNotNull(dateTime46);
//        org.junit.Assert.assertNotNull(dateTimeZone47);
//        org.junit.Assert.assertNotNull(yearMonthDay48);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertNotNull(property53);
//        org.junit.Assert.assertNotNull(localDate54);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNotNull(localDate56);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "31" + "'", str58.equals("31"));
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 4976650364402000L + "'", long61 == 4976650364402000L);
//    }

//    @Test
//    public void test103() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test103");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.Chronology chronology5 = null;
//        org.joda.time.LocalDate localDate6 = new org.joda.time.LocalDate((long) (short) 10, chronology5);
//        boolean boolean7 = yearMonthDay3.isBefore((org.joda.time.ReadablePartial) localDate6);
//        org.joda.time.LocalDate.Property property8 = localDate6.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone9 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime10 = org.joda.time.DateTime.now(dateTimeZone9);
//        org.joda.time.DateTimeZone dateTimeZone11 = dateTime10.getZone();
//        org.joda.time.YearMonthDay yearMonthDay12 = dateTime10.toYearMonthDay();
//        org.joda.time.Chronology chronology14 = null;
//        org.joda.time.LocalDate localDate15 = new org.joda.time.LocalDate((long) (short) 10, chronology14);
//        boolean boolean16 = yearMonthDay12.isBefore((org.joda.time.ReadablePartial) localDate15);
//        org.joda.time.Chronology chronology18 = null;
//        org.joda.time.LocalDate localDate19 = new org.joda.time.LocalDate((long) (short) 10, chronology18);
//        org.joda.time.DateTimeFieldType dateTimeFieldType20 = null;
//        int int21 = localDate19.indexOf(dateTimeFieldType20);
//        boolean boolean22 = yearMonthDay12.isAfter((org.joda.time.ReadablePartial) localDate19);
//        int int23 = localDate6.compareTo((org.joda.time.ReadablePartial) yearMonthDay12);
//        org.joda.time.LocalDate localDate25 = localDate6.minusYears(58097);
//        org.joda.time.DateTimeZone dateTimeZone26 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime27 = org.joda.time.DateTime.now(dateTimeZone26);
//        org.joda.time.DateTimeZone dateTimeZone28 = dateTime27.getZone();
//        org.joda.time.YearMonthDay yearMonthDay29 = dateTime27.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone30 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime31 = org.joda.time.DateTime.now(dateTimeZone30);
//        org.joda.time.DateTime dateTime32 = dateTime27.withZoneRetainFields(dateTimeZone30);
//        boolean boolean33 = dateTime27.isEqualNow();
//        org.joda.time.ReadableDuration readableDuration34 = null;
//        org.joda.time.DateTime dateTime35 = dateTime27.minus(readableDuration34);
//        org.joda.time.DateTime.Property property36 = dateTime35.dayOfMonth();
//        org.joda.time.DateTime.Property property37 = dateTime35.centuryOfEra();
//        org.joda.time.DateTime dateTime38 = property37.withMaximumValue();
//        boolean boolean39 = localDate6.equals((java.lang.Object) property37);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertNotNull(property8);
//        org.junit.Assert.assertNotNull(dateTimeZone9);
//        org.junit.Assert.assertNotNull(dateTime10);
//        org.junit.Assert.assertNotNull(dateTimeZone11);
//        org.junit.Assert.assertNotNull(yearMonthDay12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
//        org.junit.Assert.assertNotNull(localDate25);
//        org.junit.Assert.assertNotNull(dateTimeZone26);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTimeZone28);
//        org.junit.Assert.assertNotNull(yearMonthDay29);
//        org.junit.Assert.assertNotNull(dateTimeZone30);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(dateTime32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
//        org.junit.Assert.assertNotNull(dateTime35);
//        org.junit.Assert.assertNotNull(property36);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(dateTime38);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.joda.time.Chronology chronology1 = null;
        org.joda.time.LocalDate localDate2 = new org.joda.time.LocalDate((long) (short) 10, chronology1);
        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone3);
        org.joda.time.DateTime dateTime6 = localDate2.toDateTimeAtMidnight(dateTimeZone3);
        org.joda.time.DateTime.Property property7 = dateTime6.yearOfCentury();
        org.joda.time.DateTime dateTime9 = property7.setCopy(0);
        org.joda.time.DateTime dateTime11 = property7.addToCopy(17);
        org.junit.Assert.assertNotNull(dateTimeZone3);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(property7);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyearWeekDay();
        java.util.Locale locale1 = null;
        org.joda.time.format.DateTimeFormatter dateTimeFormatter2 = dateTimeFormatter0.withLocale(locale1);
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTimeFormatter2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.joda.time.format.DateTimeFormatter dateTimeFormatter0 = org.joda.time.format.ISODateTimeFormat.weekyear();
        org.joda.time.DateTime dateTime2 = dateTimeFormatter0.parseDateTime("58087");
        org.joda.time.ReadablePeriod readablePeriod3 = null;
        org.joda.time.DateTime dateTime4 = dateTime2.plus(readablePeriod3);
        org.joda.time.DateTime dateTime6 = dateTime4.minusMillis((int) (short) 100);
        org.joda.time.chrono.ISOChronology iSOChronology8 = org.joda.time.chrono.ISOChronology.getInstanceUTC();
        org.joda.time.LocalDate localDate9 = new org.joda.time.LocalDate((java.lang.Object) (-1L), (org.joda.time.Chronology) iSOChronology8);
        org.joda.time.DateTime dateTime10 = dateTime4.toDateTime((org.joda.time.Chronology) iSOChronology8);
        int int11 = dateTime10.getSecondOfDay();
        org.junit.Assert.assertNotNull(dateTimeFormatter0);
        org.junit.Assert.assertNotNull(dateTime2);
        org.junit.Assert.assertNotNull(dateTime4);
        org.junit.Assert.assertNotNull(dateTime6);
        org.junit.Assert.assertNotNull(iSOChronology8);
        org.junit.Assert.assertNotNull(dateTime10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 28800 + "'", int11 == 28800);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.joda.time.tz.FixedDateTimeZone fixedDateTimeZone4 = new org.joda.time.tz.FixedDateTimeZone("69", "69", 14, 58097);
        int int6 = fixedDateTimeZone4.getOffsetFromLocal((long) 58092);
        long long8 = fixedDateTimeZone4.previousTransition(6900035L);
        long long10 = fixedDateTimeZone4.nextTransition((-25200000L));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 14 + "'", int6 == 14);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 6900035L + "'", long8 == 6900035L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-25200000L) + "'", long10 == (-25200000L));
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        org.joda.time.DateTimeZone dateTimeZone16 = dateTime15.getZone();
//        org.joda.time.YearMonthDay yearMonthDay17 = dateTime15.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone18 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime19 = org.joda.time.DateTime.now(dateTimeZone18);
//        org.joda.time.DateTime dateTime20 = dateTime15.withZoneRetainFields(dateTimeZone18);
//        org.joda.time.DateTimeZone dateTimeZone21 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime22 = org.joda.time.DateTime.now(dateTimeZone21);
//        int int23 = dateTime22.getDayOfYear();
//        int int24 = dateTimeZone18.getOffset((org.joda.time.ReadableInstant) dateTime22);
//        org.joda.time.chrono.GJChronology gJChronology25 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone18);
//        org.joda.time.DurationField durationField26 = gJChronology25.millis();
//        org.joda.time.DateTimeField dateTimeField27 = gJChronology25.dayOfMonth();
//        org.joda.time.field.SkipDateTimeField skipDateTimeField28 = new org.joda.time.field.SkipDateTimeField((org.joda.time.Chronology) gJChronology11, dateTimeField27);
//        org.joda.time.DateTimeZone dateTimeZone29 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime30 = org.joda.time.DateTime.now(dateTimeZone29);
//        org.joda.time.DateTimeZone dateTimeZone31 = dateTime30.getZone();
//        org.joda.time.YearMonthDay yearMonthDay32 = dateTime30.toYearMonthDay();
//        org.joda.time.Chronology chronology34 = null;
//        org.joda.time.LocalDate localDate35 = new org.joda.time.LocalDate((long) (short) 10, chronology34);
//        boolean boolean36 = yearMonthDay32.isBefore((org.joda.time.ReadablePartial) localDate35);
//        org.joda.time.LocalDate.Property property37 = localDate35.dayOfYear();
//        org.joda.time.LocalDate localDate38 = property37.roundHalfFloorCopy();
//        java.util.Date date39 = localDate38.toDate();
//        java.util.Locale locale41 = null;
//        java.lang.String str42 = skipDateTimeField28.getAsShortText((org.joda.time.ReadablePartial) localDate38, 58092, locale41);
//        int int43 = skipDateTimeField28.getMaximumValue();
//        java.lang.String str44 = skipDateTimeField28.toString();
//        java.lang.String str45 = skipDateTimeField28.getName();
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertNotNull(dateTimeZone16);
//        org.junit.Assert.assertNotNull(yearMonthDay17);
//        org.junit.Assert.assertNotNull(dateTimeZone18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTimeZone21);
//        org.junit.Assert.assertNotNull(dateTime22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 365 + "'", int23 == 365);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-28800000) + "'", int24 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology25);
//        org.junit.Assert.assertNotNull(durationField26);
//        org.junit.Assert.assertNotNull(dateTimeField27);
//        org.junit.Assert.assertNotNull(dateTimeZone29);
//        org.junit.Assert.assertNotNull(dateTime30);
//        org.junit.Assert.assertNotNull(dateTimeZone31);
//        org.junit.Assert.assertNotNull(yearMonthDay32);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNotNull(property37);
//        org.junit.Assert.assertNotNull(localDate38);
//        org.junit.Assert.assertNotNull(date39);
//        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "58092" + "'", str42.equals("58092"));
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 31 + "'", int43 == 31);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str44.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "dayOfMonth" + "'", str45.equals("dayOfMonth"));
//    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.joda.time.chrono.CopticChronology copticChronology0 = org.joda.time.chrono.CopticChronology.getInstance();
        org.joda.time.ReadablePeriod readablePeriod1 = null;
        long long4 = copticChronology0.add(readablePeriod1, (long) (-25200000), 8);
        org.joda.time.Chronology chronology6 = null;
        org.joda.time.LocalDate localDate7 = new org.joda.time.LocalDate((long) (short) 10, chronology6);
        org.joda.time.DateTimeZone dateTimeZone8 = org.joda.time.DateTimeZone.getDefault();
        org.joda.time.DateTime dateTime9 = org.joda.time.DateTime.now(dateTimeZone8);
        org.joda.time.DateTimeZone.setDefault(dateTimeZone8);
        org.joda.time.DateTime dateTime11 = localDate7.toDateTimeAtMidnight(dateTimeZone8);
        org.joda.time.LocalDate localDate13 = localDate7.minusYears(58087);
        int[] intArray14 = localDate13.getValues();
        boolean boolean15 = copticChronology0.equals((java.lang.Object) intArray14);
        org.joda.time.DurationField durationField16 = copticChronology0.millis();
        org.joda.time.DateTimeField dateTimeField17 = copticChronology0.yearOfEra();
        java.lang.String str18 = copticChronology0.toString();
        org.junit.Assert.assertNotNull(copticChronology0);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-25200000L) + "'", long4 == (-25200000L));
        org.junit.Assert.assertNotNull(dateTimeZone8);
        org.junit.Assert.assertNotNull(dateTime9);
        org.junit.Assert.assertNotNull(dateTime11);
        org.junit.Assert.assertNotNull(localDate13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(durationField16);
        org.junit.Assert.assertNotNull(dateTimeField17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "CopticChronology[America/Los_Angeles]" + "'", str18.equals("CopticChronology[America/Los_Angeles]"));
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.joda.time.Partial partial0 = new org.joda.time.Partial();
//        org.joda.time.ReadablePeriod readablePeriod1 = null;
//        org.joda.time.Partial partial2 = partial0.minus(readablePeriod1);
//        org.joda.time.DateTimeZone dateTimeZone3 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime4 = org.joda.time.DateTime.now(dateTimeZone3);
//        int int5 = dateTime4.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone6 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime7 = org.joda.time.DateTime.now(dateTimeZone6);
//        org.joda.time.DateTime dateTime8 = dateTime4.toDateTime(dateTimeZone6);
//        org.joda.time.DateTime dateTime9 = dateTime4.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime11 = dateTime4.plusMonths((int) (byte) -1);
//        org.joda.time.Chronology chronology13 = null;
//        org.joda.time.LocalDate localDate14 = new org.joda.time.LocalDate((long) (short) 10, chronology13);
//        org.joda.time.LocalDate localDate16 = localDate14.plusWeeks(0);
//        org.joda.time.LocalDate.Property property17 = localDate14.year();
//        org.joda.time.DateTime dateTime18 = localDate14.toDateTimeAtMidnight();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter19 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime21 = dateTimeFormatter19.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod22 = null;
//        org.joda.time.DateTime dateTime23 = dateTime21.plus(readablePeriod22);
//        org.joda.time.DateTime dateTime25 = dateTime23.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property26 = dateTime23.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType27 = property26.getFieldType();
//        int int28 = localDate14.get(dateTimeFieldType27);
//        org.joda.time.DateTime.Property property29 = dateTime11.property(dateTimeFieldType27);
//        try {
//            org.joda.time.Partial partial31 = partial2.with(dateTimeFieldType27, 58087);
//            org.junit.Assert.fail("Expected exception of type org.joda.time.IllegalFieldValueException; message: Value 58087 for dayOfMonth must not be larger than 31");
//        } catch (org.joda.time.IllegalFieldValueException e) {
//        }
//        org.junit.Assert.assertNotNull(partial2);
//        org.junit.Assert.assertNotNull(dateTimeZone3);
//        org.junit.Assert.assertNotNull(dateTime4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 365 + "'", int5 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone6);
//        org.junit.Assert.assertNotNull(dateTime7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertNotNull(dateTime9);
//        org.junit.Assert.assertNotNull(dateTime11);
//        org.junit.Assert.assertNotNull(localDate16);
//        org.junit.Assert.assertNotNull(property17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTimeFormatter19);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertNotNull(dateTime23);
//        org.junit.Assert.assertNotNull(dateTime25);
//        org.junit.Assert.assertNotNull(property26);
//        org.junit.Assert.assertNotNull(dateTimeFieldType27);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 31 + "'", int28 == 31);
//        org.junit.Assert.assertNotNull(property29);
//    }

//    @Test
//    public void test111() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test111");
//        org.joda.time.DateTimeZone dateTimeZone0 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime1 = org.joda.time.DateTime.now(dateTimeZone0);
//        org.joda.time.DateTimeZone dateTimeZone2 = dateTime1.getZone();
//        org.joda.time.YearMonthDay yearMonthDay3 = dateTime1.toYearMonthDay();
//        org.joda.time.DateTimeZone dateTimeZone4 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime5 = org.joda.time.DateTime.now(dateTimeZone4);
//        org.joda.time.DateTime dateTime6 = dateTime1.withZoneRetainFields(dateTimeZone4);
//        org.joda.time.DateTimeZone dateTimeZone7 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime8 = org.joda.time.DateTime.now(dateTimeZone7);
//        int int9 = dateTime8.getDayOfYear();
//        int int10 = dateTimeZone4.getOffset((org.joda.time.ReadableInstant) dateTime8);
//        org.joda.time.chrono.GJChronology gJChronology11 = org.joda.time.chrono.GJChronology.getInstance(dateTimeZone4);
//        org.joda.time.DurationField durationField12 = gJChronology11.millis();
//        org.joda.time.DateTimeField dateTimeField13 = gJChronology11.dayOfMonth();
//        org.joda.time.DateTimeZone dateTimeZone14 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime15 = org.joda.time.DateTime.now(dateTimeZone14);
//        int int16 = dateTime15.getDayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone17 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime18 = org.joda.time.DateTime.now(dateTimeZone17);
//        org.joda.time.DateTime dateTime19 = dateTime15.toDateTime(dateTimeZone17);
//        org.joda.time.DateTime dateTime20 = dateTime15.withEarlierOffsetAtOverlap();
//        org.joda.time.DateTime dateTime21 = dateTime20.toDateTimeISO();
//        boolean boolean22 = gJChronology11.equals((java.lang.Object) dateTime20);
//        org.joda.time.DurationField durationField23 = gJChronology11.minutes();
//        org.joda.time.DateTimeField dateTimeField24 = gJChronology11.year();
//        org.joda.time.format.DateTimeFormatter dateTimeFormatter25 = org.joda.time.format.ISODateTimeFormat.weekyear();
//        org.joda.time.DateTime dateTime27 = dateTimeFormatter25.parseDateTime("58087");
//        org.joda.time.ReadablePeriod readablePeriod28 = null;
//        org.joda.time.DateTime dateTime29 = dateTime27.plus(readablePeriod28);
//        org.joda.time.DateTime dateTime31 = dateTime29.minusMillis((int) (short) 100);
//        org.joda.time.DateTime.Property property32 = dateTime29.dayOfMonth();
//        org.joda.time.DateTimeFieldType dateTimeFieldType33 = property32.getFieldType();
//        org.joda.time.IllegalFieldValueException illegalFieldValueException36 = new org.joda.time.IllegalFieldValueException(dateTimeFieldType33, (java.lang.Number) 13, "58092");
//        org.joda.time.field.RemainderDateTimeField remainderDateTimeField38 = new org.joda.time.field.RemainderDateTimeField(dateTimeField24, dateTimeFieldType33, 9);
//        org.joda.time.DateTimeZone dateTimeZone42 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime43 = org.joda.time.DateTime.now(dateTimeZone42);
//        org.joda.time.DateTimeZone dateTimeZone44 = dateTime43.getZone();
//        org.joda.time.YearMonthDay yearMonthDay45 = dateTime43.toYearMonthDay();
//        org.joda.time.Chronology chronology47 = null;
//        org.joda.time.LocalDate localDate48 = new org.joda.time.LocalDate((long) (short) 10, chronology47);
//        boolean boolean49 = yearMonthDay45.isBefore((org.joda.time.ReadablePartial) localDate48);
//        org.joda.time.DateMidnight dateMidnight50 = localDate48.toDateMidnight();
//        org.joda.time.chrono.ISOChronology iSOChronology51 = org.joda.time.chrono.ISOChronology.getInstance();
//        org.joda.time.ReadablePeriod readablePeriod52 = null;
//        long long55 = iSOChronology51.add(readablePeriod52, (long) 58089, 6);
//        org.joda.time.DateTimeField dateTimeField56 = iSOChronology51.secondOfMinute();
//        org.joda.time.DateTime dateTime57 = dateMidnight50.toDateTime((org.joda.time.Chronology) iSOChronology51);
//        org.joda.time.LocalDate localDate58 = new org.joda.time.LocalDate((int) (byte) 1, 10, 19, (org.joda.time.Chronology) iSOChronology51);
//        int int59 = remainderDateTimeField38.getMaximumValue((org.joda.time.ReadablePartial) localDate58);
//        java.util.Locale locale61 = null;
//        java.lang.String str62 = remainderDateTimeField38.getAsShortText(28800035L, locale61);
//        java.util.Locale locale64 = null;
//        java.lang.String str65 = remainderDateTimeField38.getAsShortText((int) (byte) 10, locale64);
//        java.lang.String str66 = remainderDateTimeField38.toString();
//        org.joda.time.field.OffsetDateTimeField offsetDateTimeField68 = new org.joda.time.field.OffsetDateTimeField((org.joda.time.DateTimeField) remainderDateTimeField38, 2922789);
//        long long70 = offsetDateTimeField68.roundCeiling(908840217600086399L);
//        org.joda.time.DateTimeZone dateTimeZone71 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime72 = org.joda.time.DateTime.now(dateTimeZone71);
//        org.joda.time.DateTimeZone dateTimeZone73 = dateTime72.getZone();
//        org.joda.time.YearMonthDay yearMonthDay74 = dateTime72.toYearMonthDay();
//        org.joda.time.Chronology chronology76 = null;
//        org.joda.time.LocalDate localDate77 = new org.joda.time.LocalDate((long) (short) 10, chronology76);
//        boolean boolean78 = yearMonthDay74.isBefore((org.joda.time.ReadablePartial) localDate77);
//        org.joda.time.LocalDate.Property property79 = localDate77.dayOfYear();
//        org.joda.time.DateTimeZone dateTimeZone80 = org.joda.time.DateTimeZone.getDefault();
//        org.joda.time.DateTime dateTime81 = org.joda.time.DateTime.now(dateTimeZone80);
//        org.joda.time.DateTimeZone dateTimeZone82 = dateTime81.getZone();
//        org.joda.time.YearMonthDay yearMonthDay83 = dateTime81.toYearMonthDay();
//        org.joda.time.Chronology chronology85 = null;
//        org.joda.time.LocalDate localDate86 = new org.joda.time.LocalDate((long) (short) 10, chronology85);
//        boolean boolean87 = yearMonthDay83.isBefore((org.joda.time.ReadablePartial) localDate86);
//        org.joda.time.Chronology chronology89 = null;
//        org.joda.time.LocalDate localDate90 = new org.joda.time.LocalDate((long) (short) 10, chronology89);
//        org.joda.time.DateTimeFieldType dateTimeFieldType91 = null;
//        int int92 = localDate90.indexOf(dateTimeFieldType91);
//        boolean boolean93 = yearMonthDay83.isAfter((org.joda.time.ReadablePartial) localDate90);
//        int int94 = localDate77.compareTo((org.joda.time.ReadablePartial) yearMonthDay83);
//        java.util.Locale locale96 = null;
//        java.lang.String str97 = offsetDateTimeField68.getAsShortText((org.joda.time.ReadablePartial) yearMonthDay83, 0, locale96);
//        org.junit.Assert.assertNotNull(dateTimeZone0);
//        org.junit.Assert.assertNotNull(dateTime1);
//        org.junit.Assert.assertNotNull(dateTimeZone2);
//        org.junit.Assert.assertNotNull(yearMonthDay3);
//        org.junit.Assert.assertNotNull(dateTimeZone4);
//        org.junit.Assert.assertNotNull(dateTime5);
//        org.junit.Assert.assertNotNull(dateTime6);
//        org.junit.Assert.assertNotNull(dateTimeZone7);
//        org.junit.Assert.assertNotNull(dateTime8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 365 + "'", int9 == 365);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-28800000) + "'", int10 == (-28800000));
//        org.junit.Assert.assertNotNull(gJChronology11);
//        org.junit.Assert.assertNotNull(durationField12);
//        org.junit.Assert.assertNotNull(dateTimeField13);
//        org.junit.Assert.assertNotNull(dateTimeZone14);
//        org.junit.Assert.assertNotNull(dateTime15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 365 + "'", int16 == 365);
//        org.junit.Assert.assertNotNull(dateTimeZone17);
//        org.junit.Assert.assertNotNull(dateTime18);
//        org.junit.Assert.assertNotNull(dateTime19);
//        org.junit.Assert.assertNotNull(dateTime20);
//        org.junit.Assert.assertNotNull(dateTime21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertNotNull(durationField23);
//        org.junit.Assert.assertNotNull(dateTimeField24);
//        org.junit.Assert.assertNotNull(dateTimeFormatter25);
//        org.junit.Assert.assertNotNull(dateTime27);
//        org.junit.Assert.assertNotNull(dateTime29);
//        org.junit.Assert.assertNotNull(dateTime31);
//        org.junit.Assert.assertNotNull(property32);
//        org.junit.Assert.assertNotNull(dateTimeFieldType33);
//        org.junit.Assert.assertNotNull(dateTimeZone42);
//        org.junit.Assert.assertNotNull(dateTime43);
//        org.junit.Assert.assertNotNull(dateTimeZone44);
//        org.junit.Assert.assertNotNull(yearMonthDay45);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(dateMidnight50);
//        org.junit.Assert.assertNotNull(iSOChronology51);
//        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 58089L + "'", long55 == 58089L);
//        org.junit.Assert.assertNotNull(dateTimeField56);
//        org.junit.Assert.assertNotNull(dateTime57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "8" + "'", str62.equals("8"));
//        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "10" + "'", str65.equals("10"));
//        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "DateTimeField[dayOfMonth]" + "'", str66.equals("DateTimeField[dayOfMonth]"));
//        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 908840217628800000L + "'", long70 == 908840217628800000L);
//        org.junit.Assert.assertNotNull(dateTimeZone71);
//        org.junit.Assert.assertNotNull(dateTime72);
//        org.junit.Assert.assertNotNull(dateTimeZone73);
//        org.junit.Assert.assertNotNull(yearMonthDay74);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(property79);
//        org.junit.Assert.assertNotNull(dateTimeZone80);
//        org.junit.Assert.assertNotNull(dateTime81);
//        org.junit.Assert.assertNotNull(dateTimeZone82);
//        org.junit.Assert.assertNotNull(yearMonthDay83);
//        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
//        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-1) + "'", int92 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
//        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
//        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "0" + "'", str97.equals("0"));
//    }
//}

